$(document).ready(function(){

var data = $("input#companyNameJson").val();
	$.getJSON(data, function(result)
	{ 		
		$('#companyName').autocomplete({
			minLength: 2,
			source: function (request, response) {
			   response($.map(result.Companies, function (value, key) {
						if ( value.CompanyNames.toUpperCase().indexOf(request.term.toUpperCase()) === 0 ){
						return {
							label: value.CompanyNames,
							value: value.ucc
						}
						}
				}));
			},  
			focus: function(event, ui) {
				$('#companyName').val(ui.item.label);
				return false;
			},
			select: function(event, ui) {
				window.location.href = ui.item.value;
				$("input#companyName").val("");
				return false;
				 // event.preventDefault();
			}
		});
	});
	
});


