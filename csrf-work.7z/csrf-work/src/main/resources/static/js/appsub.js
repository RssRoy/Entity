function fillAppSubModal(id) {
	if(debug){ console.log(id);}
	if(debug){ console.log(id.id);}
	if(debug){ console.log($('#' + id.id).attr("value"));}
	 var date = new Date();
	if ($('#' + id.id).attr("value") === 'new') {
		$('#myreasonid').val('new');
		$('#appIdHide').hide();
		$('#myreasonname').val('');
		//$('#mycreatedby').val('');
		$('#mycreatedtime').val(date.getDate()+"-"+(date.getMonth()+1)+"-"+date.getFullYear());
		$('#myAppSubModal').modal('toggle');
	} else {
	
		$.ajax({
			type : "POST",
			url : "/getJsonAppSub",
			data : {
				"reasonid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				res = JSON.parse(res);
				console.log(res);
				//$('#myappid').val(res.app_id);
				$('#myreasonid').val(res.reason_id);
				$('#myreasonname').val(res.reason_name);
				$('#mycreatedby').val(res.created_by);
				$('#mycreatedtime').val(res.created_time);
				/*$('#myuserid').val(res.user_id);
				$('#myusername').val(res.user_name);
				$('#mycreateddate').val(res.created_date);*/
	
				if(debug){ console.log(res);}
	
				$('#myAppSubModal').modal('toggle');
	
				if(debug){ console.log("logging done");}
			},
			error : function(res) {
				if(debug){ console.log("error logging---------");}
				if(debug){ console.log(res);}
			}
	
		});
	}

}


function createAppSubModal(id){
if(validateSRForm()==false){
	return false;
}
	$.ajax({
		type : "POST",
		url : "/insertAppSub",
		data : {
			"reason_id": $('#myreasonid').val().trim(),
			"reason_name" : $('#myreasonname').val().trim(),
			/*"modified_time":$('#mycreatedtime').val().trim(),
			"myuser_id" : $('#myuserid').attr('value'),
			"myuser_name" : $('#myusername').val(),
					*/
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res==-1){
				if(debug){ console.log("error inserting");}
				if(debug){ console.log("ERROR INSERTING APP SUB");}
				$('#createAppSub').attr('onclick','');
				$('#createAppSub').html('Error ! Please try  after some time.');
				$('#createAppSub').attr('disabled','disabled');
				
			}else if(res==3){
				if(debug){ console.log("APP Sub Area EXISTS");}
				$('#createAppSub').attr('onclick','');
				$('#createAppSub').html('App Name Already Exists.');
				$('#createAppSub').attr('disabled','disabled');
			}else{
				
				if(debug){ console.log("SUCCESS INSERTING");}
				$('#createAppSub').attr('onclick','commit();');
				$('#createAppSub').html('Commit');
				$('#cancelAppSub').attr('disabled','disabled');
			}
			
			
			
			

		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}
function validateSRForm(){
	var valid=true;
	var innerValid=false;
	$("form input").each(function(e){
		console.log($(this).val());
		console.log(this);
		console.log($(this).attr('id'));
		
		
		innerValid=false;
		 var reg =/<(.|\n)*?>/g; 
		  var reg1 =/(\$|\^|\*|\|\/|\?|\:|\~|\!)/g; 
		 
		  
	        if (reg.test($(this).val()) == true) {
	         	console.log("HTML TAG");
	        	
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","HTML Tag are not allowed");
	          
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	       
	       return false;
	        }else if(reg1.test($(this).val()) == true){
	         	
	        	console.log("Symbols");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Special symbols like   $      \ ! ` ~  are not allowed");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');

	       
	       return false;
	        }else if($(this).val()==undefined || ($(this).val()).length==0){
	        	/*console.log($(this).val()==undefined)
	        	console.log($(this).val()===undefined)
	        	console.log($(this).val()==='undefined')*/
	        	
	        	console.log("Empty or undefined");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Please fill the field.");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        }else{
	        	console.log("No Error");
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
	        	$(this).css('color','');
	        	innerValid=true;
	        }
	        	
	        
	       valid=valid && innerValid;
	});
	$("form input[type=text]:not([type=hidden]").each(function(e){
		console.log($(this).val());
		console.log(this);
		console.log($(this).attr('id'));
		
		
		innerValid=false;
		 var reg =/<(.|\n)*?>/g; 
		  var reg1 =/(\$|\^|\*|\||\<|\>|\/|\?|\:|\~|\!)/g; 
		 
		  
	        if (reg.test($(this).val()) == true) {
	         	console.log("HTML TAG");
	        	
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","HTML Tag are not allowed");
	          
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	       
	       return false;
	        }else if(reg1.test($(this).val()) == true){
	         	
	        	console.log("Symbols");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Special symbols like   $   < > ,  \ ! ` ~  are not allowed");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');

	       
	       return false;
	        }else if($(this).val()==undefined || ($(this).val()).length==0){
	        	/*console.log($(this).val()==undefined)
	        	console.log($(this).val()===undefined)
	        	console.log($(this).val()==='undefined')*/
	        	
	        	console.log("Empty or undefined");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Please fill the field.");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        }else{
	        	console.log("No Error");
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
	        	$(this).css('color','');
	        	innerValid=true;
	        }
	        	
	        
	       valid=valid && innerValid;
	});
	
	
	/*$("form select").each(function(e){
		innerValid=innerValid && true;
		console.log($(e));
		if($(this).val()==undefined || $(this).val().trim().length==0){
			console.log("Empty or undefined select");
        	$(this).attr("data-toggle","tooltip")
        	$(this).attr("data-placement","auto")
        	$(this).attr("data-original-title","Please fill the field.");
           
        	$(this).css('color','red');
            $(this).tooltip({trigger: 'manual'}).tooltip('show');
            console.log("False");
            innerValid=false;
            
		}else{
			console.log("No Error in select ");
        	$(this).removeAttr("data-toggle")
        	$(this).removeAttr("data-placement")
        	$(this).removeAttr("title");
        	$(this).removeAttr("data-original-title");
            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
            $(this).attr('disabled','disabled');
        	$(this).css('color','');
        	innerValid=innerValid && true;
		}
		valid=valid && innerValid;
	});
	*/
	
	return valid && innerValid;
	
}