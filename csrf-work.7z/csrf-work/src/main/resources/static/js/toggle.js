$(document).ready(function() {
	

	

	
	
	
	
$("#toggle-i").on("click",function(){
	var toggle=$("#toggle").val();

	if(toggle==='no'){
	
		
		//alert($("#toggle").val()+" = no"+(toggle==='no'));
		$("#toggle-i").css("right", "-570px");
		//$("#main-window").css("right","-550px");
		$("#main-window").toggle(false);
		$("#toggle").val('yes');
		
		
	}else{
		
		
		
		//alert($("#toggle").val()+"no");
		$("#toggle-i").css("right", "-20px");
		//$("#main-window").css("right","0px");
		$("#main-window").toggle(true);
		
		$("#toggle").val('no');
	}
});












	/*$('img').on('click',function() {
	   alert(this);
	  
	  
	$(document.getElementsByClassName('ImageData')).elevateZoom({
			zoomType: "lens",
			lensShape : "square",
			lensSize    : 200
		});
	});*/
	
	
	/*function bigImg(id){
		alert(id+"hello image bigimg");
		$(id).elevateZoom({
			zoomType: "lens",
			lensShape : "round",
			lensSize    : 100
		});
	}
*/
	
});

/*function imageZOOM(){
	alert(this+"hello image");
	$(document.getElementsByClassName('ImageData')).elevateZoom({
		zoomType: "lens",
		lensShape : "round",
		lensSize    : 100
	});
}*/
/*function bigImg(id){
	//alert(id+"hello image  ID");
	$(id).elevateZoom({
		//Lens Zoom
		zoomType: "lens",
		lensShape : "square",
		lensSize    : 100
		
		//inner Zoom
		zoomType: "inner",
		  cursor: "crosshair"
		
		//Window Zoom
		zoomWindowWidth:300,
        zoomWindowHeight:100
		
		//Outside Messages window
		//easing : true
	});
	
}
function imageZOOM(){
	if(debug){ console.log("zoomContainer Should have removed");}
	$('.zoomContainer').remove();
}*/

