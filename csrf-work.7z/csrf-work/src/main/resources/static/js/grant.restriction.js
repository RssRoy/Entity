
 
$( "#mygrantroleid").change(function() {
	  if($(this).val().toUpperCase()=='ROLE0'){
		  $("input:radio[name='mycangrant']").removeAttr('disabled');
	  }else{
		  $("input:radio[name='mycangrant']")[1].checked = true;
		  $("input:radio[name='mycangrant']").attr('disabled','disabled');
	  }
});