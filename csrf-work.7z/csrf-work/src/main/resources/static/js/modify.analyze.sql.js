$.urlParam = function(name) {
	var results = new RegExp('[\?&]' + name + '=([^&#]*)')
			.exec(window.location.href);
	if (results == null) {
		return null;
	} else {
		return decodeURI(results[1]) || 0;
	}
}
var appName = $.urlParam('appName');
if (appName !== null && appName.toString().length > 0) {
	//$('#AppNameSelect option:contains("'+ appName.toString().trim().toUpperCase() + '")').prop('selected', true);
	
	
	if($("#myappname option[value="+appName.toString().trim().toLowerCase()+"]").length > 0){
		$('#myappname').val(appName.toLowerCase());
	}else{
		$('#myappname option:contains("'+ appName.toString().trim().toUpperCase() + '")').each(function(){
		    if ($(this).text().toLowerCase() == appName.toLowerCase()) {
		        $(this).attr('selected', 'selected');
		        return false;
		    }
		    return true;
		});
	}
	
	appName = $('#myappname').val().toString().toLowerCase();
	if (debug) {
if(debug){console.log("App Name: " + appName);}
	}
}

function modifySearchSqlData(){

var appName = $('#myappname').val().toString().trim();


var id = $('#myid').val().toString().trim();
	$.ajax({
			type : "POST",
			url : "/searchData",
			data : {
				"appName" : appName,
				"id" : id
			},
			success : function(res) {
				if(debug){ console.log(res);}

				if(debug){ console.log("res=:" + res);}
				var qa = JSON.parse(res);
				if(debug){ console.log("qa:" + qa.hits.hits.length);}
				if(debug){ console.log('-------------------------------------');}
				if(qa.hits.hits[0]._source.hasOwnProperty('image') || qa.hits.hits[0]._source.hasOwnProperty('file')){
					
					 $('#alerttext').removeAttr('hidden');
					   $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>This Question has Image or File data which can't be modified. Please delete and create new Data.");
					   $('#alerttext').addClass('alert alert-danger').addClass('btn-danger').removeClass('alert-success btn-success');
					
				
					return;
				}
				if(qa.hits.hits[0]._source.hasOwnProperty('sql')){
					if(qa.hits.hits[0]._source.hasOwnProperty('question')){
						$('#question').val(qa.hits.hits[0]._source.question);
					}
					if(qa.hits.hits[0]._source.hasOwnProperty('answer')){
						$('#answer').val(qa.hits.hits[0]._source.answer);
					}
					if(qa.hits.hits[0]._source.hasOwnProperty('sql')){
						$('#sql').val(qa.hits.hits[0]._source.sql);
					}
					
					$('#sqllevel0').removeAttr('hidden');
				}else{
					 $('#alerttext').removeAttr('hidden');
					   $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>This Question has No SQL  data . Please input correct document id.");
					   $('#alerttext').addClass('alert alert-danger').addClass('btn-danger').removeClass('alert-success btn-success');
					
				
					return;
				}
				


			},
			error : function(res) {
				if(debug){ console.log("fail");}
				 $('#alerttext').removeAttr('hidden');
				   $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ERROR : Please Check ID and Application Name");
				   $('#alerttext').addClass('alert alert-danger').addClass('btn-danger').removeClass('alert-success btn-success');
				
			
			}
		});// end of ajax

}



var valreg=/(@[A-Za-z0-9_\-]+@)/g;
function parse_sql(){
	var json = {};
	json.app_id=$('#myappname option:selected').attr('data-id');
	json.question=$('#question').val();
	json.answer=$('#answer').val();
	json.sql=$('#sql').val();	
	
if(debug){ console.log(JSON.stringify(json));}
// now parse table details and column details;

//note only character allowed are a-z A-Z 0-9 _ -
var valreg=/(@[A-Za-z0-9_\-]+@)/g;
if(debug){console.log(json.sql.match(valreg));}
if(debug){console.log(json);}

$('#parse_data').val(JSON.stringify(json));

// get input of respective values;
var listval=Array.from(new Set(json.sql.match(valreg)));
console.log(listval);
listval.forEach(function(val){
	$.ajax({
		type : "POST",
		url : "/getJsonMap",
		data : {
			"mapid" : val
		},
		success : function(res) {
			res=JSON.parse(res);
			append_column_value(res.map_id,res.map_name);
		},
		error:function(res){
			res=JSON.parse(res);
			append_column_value_readonly(res.map_id,res.map_name);
		}

	
		});
	});

	$('#upload_sql').html('Check');
	$('#upload_sql').attr('onclick','check_sql()');
	
}

function append_column_value(id,col_ask_name){
	var table_html="";
if(debug){console.log(id);}
	if(col_ask_name==='undefined' || col_ask_name==undefined){
		table_html+='<div class="form-group"><label id="label'+id+'" for="'+id+'" class="control-label col-sm-5" style="color:red;">'+col_ask_name +': </label><div class="col-md-4"><input type="text"  class="form-control col-md-4" id="'+id+'" placeholder="mapping value not defined for '+col_ask_name+'" required="required" readonly="readonly" /></div></div>';
	}else{
		table_html+='<div class="form-group"><label id="label'+id+'" for="'+id+'" class="control-label col-sm-5">'+col_ask_name +': </label><div class="col-md-4"><input type="text"  class="form-control col-md-4" id="'+id+'" placeholder="value for '+id+'" required="required" /></div></div>';
	}
$('#sqllevel0').append(table_html);
	
}


function check_sql(){
	var json=$('#parse_data').val();
	json=JSON.parse(json);
	var keylist=Array.from(new Set(json.sql.match(valreg)));
	var coldata={};
	keylist.forEach(function(a){
		coldata[a]=$('#'+$.escapeSelector(a)).val();
		
	});
if(debug){console.log(keylist);}
if(debug){console.log(keylist.toString());}
	$.ajax({
		type : "POST",
		url : "/checkSql",
		data : {
			"appName" : $('#myappname').val().toLowerCase(),
			"keylist":keylist.toString(),
			"sqldata":JSON.stringify(json),
			"coldata":JSON.stringify(coldata)
		},
		success : function(res) {
			if(res.indexOf('Exception: ORA-')>0){
				$('#sqlresultbody').html("<h2>ERROR In SQL as per our Analysis:</h2></br>"+res);
				$('#sql_result_div').removeAttr('hidden');
				return;
			}
			$('#sqlresultbody').html(res);
			$('#sql_result_div').removeAttr('hidden');
			$('#submit_sql').removeAttr('disabled');
			$('#submit_sql').removeClass('btn-danger').addClass('btn-success');
			$('#submit_sql').html('Modify');
			$('#submit_sql').attr('onclick','confirm_modify_sql();');
			//$('#upload_sql').html('Modify');
			//$('#upload_sql').attr('onclick',modify_sql());
		},
		error:function(res){
			$('#sqlresultbody').html(res);
			$('#sql_result_div').removeAttr('hidden');
		}

	
		});
	
}


function confirm_modify_sql(){
	$('#question').attr('readonly','readonly');
	$('#answer').attr('readonly','readonly');
	$('#sql').attr('readonly','readonly');
	$('#myappname').attr('disabled','disabled');
	$('#submit_sql').html('Confirm Modify');
	$('#submit_sql').attr('onclick','modify_sql();');
}
function modify_sql(){
if(debug){console.log('MODIFY-------------->SQL->>>>>>>>>>>>>>>>>>>');}
	var json=$('#parse_data').val();
	json=JSON.parse(json);
	var id = $('#myid').val().toString().trim();
	$.ajax({
		type : "POST",
		url : "/modifySql",
		data : {
			"app_name" : $('#myappname').val().toLowerCase(),
			"id":id,
			"jsonObj":JSON.stringify(json)		
		},
		success : function(res) {
			 $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ID: "+id+" \n Data Modified successfully");
				$('#data').html('');
				  $('#alerttext').addClass('alert alert-success').addClass('btn-success').removeClass(
				'btn-danger');
			//window.location.reload();
		},
		error:function(res){
			$('#sqlresultbody').html('ERROR');
			$('#sql_result_div').removeAttr('hidden');
		}

	
		});
	
}






$('#myappname').change(function(){
if(debug){console.log("appname--> change-->"+$('#myappname :selected').val().toUpperCase());}

	var t_app=$(this).val().trim();
	
	$('#myappid').val($('#myappname :selected').attr('data-id').toUpperCase());
	console.log($('#myappname :selected').attr('data-id'))
	
	//$('#myappid option[text="'+encodeHtml(t_app).trim().toUpperCase()+'"]').attr("selected", "selected");
	$.ajax({
		type : "POST",
		url : "/appTnsExist",
		data : {
			"app_id" : $('#myappid').val()
		},

		success : function(res) {
if(debug){console.log(res);}
			if(res.toString().toUpperCase()=="NO"){
				$('#tns_exist').addClass("well well-sm alert-danger")
				$('#tns_exist').html("TNS not present. Please change app or contact application manager");
				$('#tns_exist').removeAttr("hidden");
			}else{
				$('#tns_exist').removeClass("well well-sm alert-danger");
				$('#tns_exist').attr("hidden","hidden");
				//$('#upload_sql').attr('disabled','disabled');
			}
		},
		error:function(res){
			$('#tns_exist').html("<button class='btn btn-danger'>ERROR</button>");
			
		}
	});
	
	
});

