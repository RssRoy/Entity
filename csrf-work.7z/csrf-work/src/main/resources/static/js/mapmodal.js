

function fillMapModal(id) {
	if(debug){ console.log(id);}
	if(debug){ console.log(id.id);}
	if(debug){ console.log($('#' + $.escapeSelector(id.id)).attr("value"));}
	 var date = new Date();
	if ($('#' + $.escapeSelector(id.id)).attr("value") === 'new') {
		$('#mymapid').val('new');
		$('#MapIdHide').hide();
		$('#mymapname').val('');
		$('#mymapvalue').val('');
		$('#mymaplist').val('');
		
		$('#myMapModal').modal('toggle');
	} else {
	
		$.ajax({
			type : "POST",
			url : "/getJsonMap",
			data : {
				"mapid" : $('#' + $.escapeSelector(id.id)).attr("value")
			},
			success : function(res) {
				res = JSON.parse(res);
				$('#mymapid').val(res.map_id);
				$('#mymapname').val(res.map_name);
				$('#mymapvalue').val(res.map_value);
				$('#mymaplist').val(res.map_list);
				
				if(debug){ console.log(res);}
	
				$('#myMapModal').modal('toggle');
	
				if(debug){ console.log("logging done");}
			},
			error : function(res) {
				if(debug){ console.log("error logging---------");}
				if(debug){ console.log(res);}
			}
	
		});
	}

}


function createMapModal(id){

	$.ajax({
		type : "POST",
		url : "/insertMap",
		data : {
			"mymap_name" : $('#mymapname').val().trim(),
			"mymap_id" : $('#mymapid').val(),
			"mymap_value" : $('#mymapvalue').val(),
			"mymap_list" : $('#mymaplist').val(),
					
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res===-1){
				if(debug){ console.log("error inserting");}
				if(debug){ console.log("ERROR INSERTING MAP");}
				$('#createMap').attr('onclick','');
				$('#createMap').html('Error ! Please try  after some time.');
				$('#createMap').attr('disabled','disabled');
				
			}else if(res===3){
				if(debug){ console.log("MAP ALREADY EXISTS");}
				$('#createMap').attr('onclick','');
				$('#createMap').html('Map Name Already Exists.');
				$('#createMap').attr('disabled','disabled');
			}else{
				
				if(debug){ console.log("SUCCESS INSERTING");}
				$('#createMap').attr('onclick','commit();');
				$('#createMap').html('Commit');
				$('#cancelMap').attr('disabled','disabled');
			}
			
			
			
			

		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}
