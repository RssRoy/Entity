/*----------------------------------------------------------*/
function toJson(id, filename, i) {

	
	if(debug){ console.log("i---->" + i);}
	if(debug){ console.log(filename);}

	if(debug){ console.log("id:" + id);}
	var children = id.childNodes;
	if(debug){ console.log(children);}
	
	children.forEach(function(item) {
			
			if (item.nodeName.toLowerCase() === 'li') {
				var json = {};
				var q = 0;
				var a = 0;
				var que = '';
				var ans = '';
				var assign=0;
				var arr=[];
				
				var ul=0;
				if(debug){ console.log("start of loop ");}
				if(debug){ console.log(json);}
				if(debug){ console.log(item);}
					child1 = item.childNodes;
					if(debug){ console.log(child1);}
					child1.forEach(function(nextitem) {
						if(debug){ console.log(nextitem.nodeName.toLowerCase());}
								if (nextitem.nodeName.toLowerCase() === 'div') {
									child2 = nextitem.childNodes;
									child2.forEach(function(nextnextitem) {
												if (nextnextitem.nodeName.toLowerCase() === 'div') {
													child3 = nextnextitem.childNodes;
													child3.forEach(function(nextnextnextitem) {
															if (nextnextnextitem.nodeName.toLowerCase() === 'textarea') {
																if (nextnextnextitem.id.toLowerCase() === 'question') {
																	json.question=nextnextnextitem.value.trim();
																	if(!json.hasOwnProperty("variation") || !Object.prototype.toString.call(json.variation)==="[object Array]"){
																		json.variation=[];
																		if(nextnextnextitem.value.trim().length>0){
																			json.variation.push(nextnextnextitem.value.trim());
																		}
																	}
																} else if (nextnextnextitem.id.toLowerCase() === 'answer') {
																	json.answer=nextnextnextitem.value.trim();
																}else if (nextnextnextitem.id.toLowerCase() === 'variation') {
																	json.variation.push(nextnextnextitem.value.trim());
																}else if (nextnextnextitem.id.toLowerCase() === 'article_id') {
																	json.article_id=nextnextnextitem.value.trim();
																}
															}
														});
												}
											});
								}else if (nextitem.nodeName.toLowerCase() === 'ul') {
									if(debug){ console.log("UL found");}
									filename.conv_ans = [];
									if(debug){ console.log("conv_arr");}
									if(debug){ console.log(filename);}
									i++;
									json.conv_ans=[];
									var tmp={};
									tmp=toJson(nextitem, tmp, -1);
									if(Object.keys(tmp).length>0)
									arr.push(tmp);
									if(debug){ console.log(tmp);}
									if(debug){ console.log("temppppp");}
								
									
									filename.conv_ans=json.conv_ans;
									//if(debug){ console.log(JSON.stringify(filename));}
									if(debug){ console.log(JSON.stringify(json));}
									//filename.push(json);
								}
								
							});

					
				if(debug){ console.log("loopingg");}
				if(debug){ console.log(json);}
				if(debug){ console.log(filename);}
				if(json.hasOwnProperty("question") && json.question.length>0)
					filename.question=json.question;
				if(json.hasOwnProperty("answer") && json.answer.length>0){	
					filename.answer=json.answer;
					$('#answer_exist').val('true');
				}
				if(json.hasOwnProperty("article_id") && json.article_id.length>0){	
					filename.article_id=json.article_id;
					$('#answer_exist').val('true');
				}
				if(json.hasOwnProperty("variation") && json.variation.length>0){	
					var jsonSet=new Set(json.variation);
					filename.variation=Array.from(jsonSet);
				}
				if(arr.length>0)
				filename.conv_ans=arr;
			
				
			}
				
			});
	if(debug){ console.log(JSON.stringify(filename));}
	if(debug){ console.log("return with i-->"+i);}
return filename;
}
/******************end tojson() ***************************************************/
/* html related  functions */

function addQuestion(id) {
	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	var liname = '#lilevel' + q;
	qlevel = q + 1;
	qparentlevel = q + 1;
	
	var question = '<div class="form-group">'
		+ '<label class="control-label col-md-1 pt5" for="question">Question:</label>'
		+ '<div class="col-md-11">'
		+ '<textarea class="form-control" id="question" rows="1"'
		+ 'placeholder="Enter question" required="required">'
		+ '</textarea>'
		+ '</div>'
		+ '</div>'
		+ '<div class="form-group">'
		+ '<div class="col-sm-offset-2 col-sm-10">'
		+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
		+ qlevel
		+ '"'
		+ ' onclick="addQuestion(this);">Add Question</button>'
		+ ' <button type="button" class="btn btn-primary" id="addsolution" value="'
		+ qparentlevel + '"'
		+ ' onclick="addSolution(this);">Add Solution</button>' 
		
		+ ' <button type="button" class="btn btn-primary" id="addanswer" value="'
		+ qparentlevel + '"'
		+ ' onclick="addAnswer(this);">Add Answer</button>'; 
		
		if($('#enable_article_id').val()=='true'){
			question+= ' <button type="button" class="btn btn-primary" id="addarticleid" value="'+ qparentlevel + '"'+ ' onclick="addArticleId(this);">Add Article ID</button>'; 
		}
		question+= '</div>'+ '</div>';
	if(debug){ console.log("Conv_ans:---");}
	var ulid = '#lilevel' + qlevel;
	
	$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ question + "</li></ul>").insertAfter($(id).parent('div').parent('div'));

	//$(id).parent('div').find('button#addarticleid').prop('disabled',true);

}

function addSolution(id) {

	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	var liname = '#lilevel' + q;
	qlevel = q + 1;
	qparentlevel = q + 1;
	var solution = '<div class="form-group">'
		+ '<label class="control-label col-md-1 pt5" for="answer">Solution:</label>'
		+ '<div class="col-md-11">'
		+ '<textarea class="form-control" id="answer" rows="1"'
		+ 'placeholder="Enter Solution" required="required">' + '</textarea>'
		+ '<input type="hidden" id="qlevel" value="' + qlevel + '"/>'
		+ '<input type="hidden" id="qparentlevel" value="' + qparentlevel
		+ '"/>' + '</div>' + '</div>'
		+ '<div class="form-group">'
		+ '<div class="col-sm-offset-2 col-sm-10">'
		+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
		+ qlevel
		+ '"'
		+ ' onclick="addQuestion(this);">Add Question</button>'
		+ '</div>'
		+ '</div>';
if(debug){ console.log(liname);}
	var ulid = '#lilevel' + qlevel;
	
	
	
	if($(ulid).length>0){
		if(debug){ console.log("not zero");}
		$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ solution + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}else{
		if(debug){ console.log(" zero");}
	$("<ul  id='lilevel"
			+ qlevel
			+ "' class='lilevel"
			+ qlevel
			+ "' style='border-left:2px solid #000;list-style-type:none;'><li>"
			+ solution + "</li></ul>").insertAfter($(id).parent('div').parent('div'));
	}
	$(id).prop('disabled',true);
	$(id).parent('div').find('button#addarticleid').prop('disabled',true);




}

function addAnswer(id) {
	// alert("click");

	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	if(debug){ console.log("id of answer----------------" + q);}
	var liname = '.lilevel' + q;
	qlevel = q;
	qparentlevel = q;

	var answer = '<div class="form-group">'
		+ '<label class="control-label col-md-1 pt5" for="answer">Answer:</label>'
		+ '<div class="col-md-10">'
		+ '<textarea class="form-control" id="answer" rows="1"'
		+ 'placeholder="Enter Answer" required="required">' + '</textarea>'
		+ '</div>' 
		+'<div class="col-md-1">'
		+'<button type="button" class="btn btn-danger delete_answer" id="delete_answer"	onclick="deleteAnswer(this);" style="font-size:small;padding:0px;margin:0px;">Delete</button>'
		+ '</div>' 
		+ '</div>'
	if(debug){ console.log(liname);}
	$(answer).insertBefore($(id).parent('div').parent('div'));
	$(id).prop('disabled', true);
	$(id).parent('div').find('button#addarticleid').prop('disabled',true);
	if(debug){ console.log(liname);}
}

function addArticleId(id) {
	// alert("click");

	var q = 0;
	var qparentlevel = 0;

	q = $(id).val();
	if(debug){ console.log("id of article id----------------" + q);}
	var liname = '.lilevel' + q;
	qlevel = q;
	qparentlevel = q;

	var answer = '<div class="form-group">'
		+ '<label class="control-label col-md-1 pt5" for="article_id">Article ID:</label>'
		+ '<div class="col-md-6">'
		+ '<textarea class="form-control" id="article_id" rows="1"'
		+ 'placeholder="Enter Article ID" required="required">' + '</textarea>'
		+'</div>'
		+'<div class="col-md-1">'
		+'<button type="button" class="btn btn-danger check_article_id" id="check_article_id" onclick="checkArticleId(this);" style="font-size:small;padding:0px;margin:0px;">Check</button>'
		+ '</div>' 
		+'<div class="col-md-1">'
		+'<button type="button" class="btn btn-danger delete_article_id" id="delete_article_id"	onclick="deleteArticleId(this);" style="font-size:small;padding:0px;margin:0px;">Delete</button>'
		+ '</div>'
		+'<div class="col-md-1">'
		+'<button type="button" class="btn btn-info search_article_id" id="search_article_id"	onclick="searchArticleId(this);" style="font-size:small;padding:0px;margin:0px;">Search</button>'
		+ '</div>'
		
		+ '</div>'

	if(debug){ console.log(liname);}
	$(answer).insertBefore($(id).parent('div').parent('div'));
	$(id).prop('disabled', true);
	if(debug){ console.log(liname);}
	$(id).parent('div').find('button#addanswer').prop('disabled',true);
	$(id).parent('div').find('button#addsolution').prop('disabled',true);
	$(id).parent('div').find('button#addquestion').prop('disabled',true);
	$(id).parent('div').find('button#addvariation').prop('disabled',true);

}
function addVariation(id) {
	var q = 0;
	var qparentlevel = 0;
	q = $(id).val();
	if(debug){ console.log("id of Variation----------------" + q);}
	var liname = '.lilevel' + q;
	qlevel = q;
	qparentlevel = q;
	var variation = '<div class="form-group">'
			+ '<label class="control-label col-md-2 pt5" for="variation">Variation:</label>'
			+ '<div class="col-md-10">'
			+ '<textarea class="form-control" id="variation" rows="1"'
			+ 'placeholder="Enter Variation" required="required">' + '</textarea>'
			+ '<input type="hidden" id="qlevel" value="' + qlevel + '"/>'
			+ '<input type="hidden" id="qparentlevel" value="' + qparentlevel
			+ '"/>' + '</div>' + '</div>'
	if(debug){ console.log(liname);}
	$(variation).insertBefore($(id).parent('div').parent('div'));
	if(debug){ console.log(liname);}
	countVariation+=1;	

}





/*-----------------------------------------------------------------*/
var isVariation=true;

var countVariation=1;

function addQ(id, que) {

    var q = 0;
    var qparentlevel = 0;

    q = id;

var liname = '#lilevel' + q;
qlevel = q + 1;
qparentlevel = q + 1;
// alert(liname);

var question = '<div class="form-group">'
+ '<label class="control-label col-md-1 pt5" for="question">Question:</label>'
+ '<div class="col-md-11">'
+ '<textarea class="form-control" id="question" rows="1" placeholder="Enter question" required="required">'+que+'</textarea>'
+ '</div>'
+ '</div>'
+ '<div class="form-group">'
+ '<div class="col-sm-offset-2 col-sm-10">'
+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
+ qlevel
+ '"'
+ ' onclick="addQuestion(this);">Add Question</button>'
+ ' <button type="button" class="btn btn-primary" id="addsolution" value="'
+ qparentlevel + '"'
+ ' onclick="addSolution(this);">Add Solution</button>' 

+ ' <button type="button" class="btn btn-primary" id="addanswer" value="'
+ qparentlevel + '"'
+ ' onclick="addAnswer(this);">Add Answer</button>' ;


if($('#enable_article_id').val()=='true'){
	question+='<button type="button" class="btn btn-primary" id="addarticleid"		value="0" onclick="addArticleId(this);">Add Article ID</button>';
}
question+='</div>'+ '</div>';

if(isVariation){
	
	 question = '<div class="form-group">'
		+ '<label class="control-label col-md-1 pt5" for="question">Question:</label>'
		+ '<div class="col-md-11">'
		+ '<textarea class="form-control" id="question" rows="1" placeholder="Enter question" required="required">'+que+'</textarea>'
		+ '</div>'
		+ '</div>'
		+ '<div class="form-group">'
		+ '<div class="col-sm-offset-2 col-sm-10">'
		+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
		+ qlevel
		+ '"'
		+ ' onclick="addQuestion(this);">Add Question</button>'
		+ ' <button type="button" class="btn btn-primary" id="addvariation" value="'
		+ qparentlevel + '"'
		+ ' onclick="addVariation(this);">Add Variation</button>' 
		+ ' <button type="button" class="btn btn-primary" id="addsolution" value="'
		+ qparentlevel + '"'
		+ ' onclick="addSolution(this);">Add Solution</button>' 

		+ ' <button type="button" class="btn btn-primary" id="addanswer" value="'
		+ qparentlevel + '"'
		+ ' onclick="addAnswer(this);">Add Answer</button>' ;
	 if($('#enable_article_id').val()=='true'){
			question+='<button type="button" class="btn btn-primary " id="addarticleid"		value="0" onclick="addArticleId(this);">Add Article ID</button>';
		}
		question+='</div>'+ '</div>';
		
	 isVariation=false;
}
    //if(debug){ console.log("Conv_ans:---");}
    var ulid = '#lilevel' + qlevel;
    $('.'+id).last().children("li").last().append(question);
    if(debug){ console.log(liname);}


}

function addA(id, ans) {
	 var q = 0;
	    var qparentlevel = 0;

	    q = id;
	    if(debug){ console.log("id of answer----------------" + q+id);}
	    var liname = '.lilevel' + q;
	    qlevel = q;
	    qparentlevel = q;
	     //alert(liname);

	    var answer = '<div class="form-group">'
	            + '<label class="control-label col-md-1 pt5" for="question">Answer:</label>'
	            + '<div class="col-md-10">'
	            + '<textarea class="form-control" id="answer" rows="1"'
	            + 'placeholder="Enter Answer" required="required">' + ans+'</textarea>'
	            + '</div>' 
	            +'<div class="col-md-1">'
				+'<button type="button" class="btn btn-danger delete_answer" id="delete_answer"	onclick="deleteAnswer(this);" style="font-size:small;padding:0px;margin:0px;">Delete</button>'
				+ '</div>' 
	            +'</div>';
	    if(debug){ console.log(liname);}
	    $(answer).insertBefore($('.'+id).last().children("li").children('div').last());
	    $('.'+id).last().children("li").children('div').last().children('div').last().children('button').last().prop('disabled', true);
	    
	    if($('#enable_article_id').val()=='true'){
	    	$('.'+id).last().children("li").children('div').last().children('div').last().children('button').last().prev().prop('disabled', true);
	    }
	    if(debug){ console.log(liname);}
}

function addAt(id, ans) {
	 var q = 0;
	    var qparentlevel = 0;

	    q = id;
	    if(debug){ console.log("id of article_id----------------" + q+id);}
	    var liname = '.lilevel' + q;
	    qlevel = q;
	    qparentlevel = q;
	     //alert(liname);

	    var answer = '<div class="form-group">'
			+ '<label class="control-label col-md-1 pt5" for="article_id">Article ID:</label>'
			+ '<div class="col-md-6">'
			+ '<textarea class="form-control " id="article_id" rows="1"'
			+ 'placeholder="Enter Article ID" required="required">' + ans+'</textarea>'
			+'</div>'
			+'<div class="col-md-1">'
			+'<button type="button" class="btn btn-danger check_article_id" id="check_article_id"	 onclick="checkArticleId(this);" style="font-size:small;padding:0px;margin:0px;">Check</button>'
			+ '</div>'
			+'<div class="col-md-1">'
			+'<button type="button" class="btn btn-danger delete_article_id" id="delete_article_id"	onclick="deleteArticleId(this);" style="font-size:small;padding:0px;margin:0px;">Delete</button>'
			+ '</div>' 
			+'<div class="col-md-1">'
			+'<button type="button" class="btn btn-info search_article_id" id="search_article_id"	onclick="searchArticleId(this);" style="font-size:small;padding:0px;margin:0px;">Search</button>'
			+ '</div>'
			+ '</div>'
	    if(debug){ console.log(liname);}
	    $(answer).insertBefore($('.'+id).last().children("li").children('div').last());
    	//$('.'+id).last().children("li").children('div').last().children('div').last().children('button').last().prop('disabled', true);
    	$('.'+id).last().children("li").children('div').last().children('div').find('button#addanswer').prop('disabled',true);
    	$('.'+id).last().children("li").children('div').last().children('div').find('button#addsolution').prop('disabled',true);
    	$('.'+id).last().children("li").children('div').last().children('div').find('button#addquestion').prop('disabled',true);
    	$('.'+id).last().children("li").children('div').last().children('div').find('button#addvariation').prop('disabled',true);
    	
    	
	    if($('#enable_article_id').val()=='true'){
		   // $('.'+id).last().children("li").children('div').last().children('div').last().children('button').last().prev().prop('disabled', true);
	    	$('.'+id).last().children("li").children('div').last().children('div').find('button#addarticleid').prop('disabled',true);

	    }
	    
	    
	    
	    if(debug){ console.log(liname);}
}

function addV(id, variation_que) {
	 var q = 0;
	    var qparentlevel = 0;

	    q = id;
	    if(debug){ console.log("id of variation----------------" + q+id);}
	    var liname = '.lilevel' + q;
	    qlevel = q;
	    qparentlevel = q;
	    for(var i=0;i<variation_que.length;i++){
	    var variation = '<div class="form-group">'
	            + '<label class="control-label col-md-2 pt5" for="variation">Variation:</label>'
	            + '<div class="col-md-10">'
	            + '<textarea class="form-control" id="variation" rows="1"'
	            + 'placeholder="Enter Variation" required="required">' + variation_que[i]+'</textarea>'
	            + '<input type="hidden" id="qlevel" value="' + qlevel + '"/>'
	            + '<input type="hidden" id="qparentlevel" value="' + qparentlevel
	            + '"/>' + '</div>' + '</div>';
	    if(debug){ console.log(liname);}
	    
	    $(variation).insertBefore($('.'+id).last().children("li").children('div').last());
	    
	    if(debug){ console.log(liname);}
	    
	    countVariation+=1;
	    }
}

function addBoth(id, obj) {

	addQ(id, obj.question);
	addA(id, obj.answer);
}

function addThree(id, obj) {

	addQ(id, obj.question);
	addA(id, obj.answer);
	addV(id, obj.variation);
}
function addS(id, sol) {

    var q = 0;
    var qparentlevel = 0;
    q = id;

    var liname = '#lilevel' + q;
    qlevel = q + 1;
    qparentlevel = q + 1;
	var solution = '<div class="form-group">'
	+ '<label class="control-label col-md-1 pt5" for="answer">Solution:</label>'
	+ '<div class="col-md-11">'
	+ '<textarea class="form-control" id="answer" rows="1" placeholder="Enter question" required="required">'+sol+'</textarea>'
	+ '</div>'
	+ '</div>'
	+ '<div class="form-group">'
	+ '<div class="col-sm-offset-2 col-sm-10">'
	+ '<button type="button" class="btn btn-primary" id="addquestion" value="'
	+ qlevel
	+ '"'
	+ ' onclick="addQuestion(this);">Add Question</button>'
	+ '</div>'
	+ '</div>';
    
    var ulid = '#lilevel' + qlevel;
    $('.'+id).last().children("li").last().append(solution);
   // $('.'+id).last().parent().children('div').children('div').find('#addsolution').prop('disabled','true');
	//$('.'+id).last().children("li").children('div').last().children('div').find('button#addsolution').prop('disabled',true);
	//$('.'+id).last().children("li").children('div').last().children('div').find('button#addarticleid').prop('disabled',true);
    $('.'+id).last().parent().children('div').children('div').find('#addsolution').prop('disabled','true');
    $('.'+id).last().parent().children('div').children('div').find('#addarticleid').prop('disabled','true');

    if(debug){ console.log(liname);}
   

}




/**********************to html related data *********************************/

/**********************to html *********************************/
function jsonToHtml(id,obj) {
    if(debug){ console.log(obj);}
    if(debug){ console.log('#'+id);}
    if(_first===0){
        _first=1;
        $('#data').append("<ul class='"+id+"' id='"+id+"' style='border-left:2px solid #000;list-style-type:none;'></ul>");

    }else {
        var parentUl=id.substring(0,id.length-1);
        $('.' + parentUl).last().children('li').append("<ul class='" + id + "' id='" + id + "' style='border-left:2px solid #000;list-style-type:none;'></ul>");
    }
    
    if (obj.hasOwnProperty('question') && obj.hasOwnProperty('answer') && obj.hasOwnProperty('conv_ans') && obj.hasOwnProperty('variation') ) {
        $('.'+id).last().append("<li></li>");
        if(debug){ console.log($('.'+id).last());}
       
       // addBoth(id,obj);
        addThree(id,obj);
        for(var ele in obj.conv_ans) {
            if(debug){ console.log("call--->");}
            jsonToHtml(id + 1, obj.conv_ans[ele]);
        }

    }else if (obj.hasOwnProperty('question') && obj.hasOwnProperty('answer') && obj.hasOwnProperty('conv_ans')) {
        $('.'+id).last().append("<li></li>");
        if(debug){ console.log($('.'+id).last());}
       
        addBoth(id,obj);
        for(var ele in obj.conv_ans) {
            if(debug){ console.log("call--->");}
            jsonToHtml(id + 1, obj.conv_ans[ele]);
        }

    }else if (obj.hasOwnProperty('question') && obj.hasOwnProperty('answer') && obj.hasOwnProperty('variation') ) {
        $('.'+id).last().append("<li></li>");

       
        if(debug){ console.log($('.'+id).last());}
        //addBoth(id,obj);
        addThree(id,obj);

    }else if (obj.hasOwnProperty('question') && obj.hasOwnProperty('answer')) {
        $('.'+id).last().append("<li></li>");

       
        if(debug){ console.log($('.'+id).last());}
        addBoth(id,obj);

    } else if (obj.hasOwnProperty('question') && obj.hasOwnProperty('conv_ans') && obj.hasOwnProperty('variation') ) {
        $('.'+id).last().append("<li></li>");
        if(debug){ console.log($('.'+id).last());}

      
        addQ(id,obj.question);
        addV(id,obj.variation);
        for(var ele in obj.conv_ans) {
            if(debug){ console.log("call::::");}
            jsonToHtml(id + 1, obj.conv_ans[ele]);
        }
    } else if (obj.hasOwnProperty('question') && obj.hasOwnProperty('conv_ans')) {
        $('.'+id).last().append("<li></li>");
        if(debug){ console.log($('.'+id).last());}

      
        addQ(id,obj.question);
        for(var ele in obj.conv_ans) {
            if(debug){ console.log("call::::");}
            jsonToHtml(id + 1, obj.conv_ans[ele]);
        }
    } else if (obj.hasOwnProperty('answer') && obj.hasOwnProperty('conv_ans')) {
        $('.'+id).last().append("<li></li>");
        if(debug){ console.log($('.'+id).last());}

      
        addS(id,obj.answer);
        for(var ele in obj.conv_ans) {
            if(debug){ console.log("call::::");}
            jsonToHtml(id + 1, obj.conv_ans[ele]);
        }
    }else if(obj.hasOwnProperty('question') && obj.hasOwnProperty('article_id') && obj.hasOwnProperty('variation')){
    	$('.'+id).last().append("<li></li>");
    	 if(debug){ console.log($('.'+id).last());}
    	 addQ(id,obj.question);
    	 addAt(id,obj.article_id);
    	 addV(id,obj.variation);
    }else if(obj.hasOwnProperty('question') && obj.hasOwnProperty('variation')){
      	 $('.'+id).last().append("<li></li>");
         if(debug){ console.log($('.'+id).last());}

         addV(id,obj.variation);
         addQ(id,obj.question);
    }else if(obj.hasOwnProperty('question') ){
    	 $('.'+id).last().append("<li></li>");
         if(debug){ console.log($('.'+id).last());}

       
         addQ(id,obj.question);
    }

}
$(document).ready(
		function() {
			$.urlParam = function(name) {
				var results = new RegExp('[\?&]' + name + '=([^&#]*)')
						.exec(window.location.href);
				if (results == null) {
					return null;
				} else {
					return decodeURI(results[1]) || 0;
				}
			}
			$('#id').val($.urlParam('id'));
			var appName = $.urlParam('appName');
			$('#appName option[value="' + appName + '"]')
					.prop('selected', true)
		});

/*----------------------------------------------------------*/

/*-----------------------check article id-------------------------------------*/
function checkArticleId(id){
	var id_value=$(id).parent('div').prev('div').find('textarea#article_id').val().trim();
	$.ajax({
				type : "POST",
				url : "/searchData",
				data : {
					"appName" :$("#appName").val(),
					"id" : id_value
				},
				success : function(res) {
					if(debug){ console.log(res);}

					
					var qa = JSON.parse(res);
					if(debug){ console.log("qa=:" + qa);}
					if(qa.hits.hits.length>0){
						$(id).parent().parent().append('<div class="col-md-2 well pull-right" style="font-size:x-small;padding:0px;margin:0px;">'+qa.hits.hits[0]._source.question+'</div>');
						$(id).parent('div').prev('div').find('textarea#article_id').attr("readonly","readonly");
						$(id).html("Valid ID");
						$(id).addClass('btn-success');
						$(id).attr('disabled','disabled');
						$(id).parent('div').parent('div').find('button#search_article_id').attr('disabled','disabled');
						$(id).removeClass('btn-danger');
					}else{
						$(id).html("Invalid ID");
						$(id).addClass('btn-danger');
						$(id).removeClass('btn-success');
						
					}

				},
				error : function(res) {
					if(debug){ console.log("fail");}
					
				}
	});// end of ajax

}
/*-----------------------delete article id-------------------------------------*/
function deleteArticleId(id){
	//console.log(id);
	var id_div=$(id).parent('div').parent('div');
	var id_parent=$(id).parent('div').parent('div').parent('li').children('div').last();
	var id_value=$(id).parent('div').prev('div').find('textarea#article_id').val();
	
	/*console.log($(id).parent('div'));
	console.log($(id).parent('div').parent('div'));
	console.log($(id).parent('div').parent('div').parent('li'));
	console.log($(id).parent('div').parent('div').parent('li').children('div').last());*/
	
	
	//console.log(id_parent);
	$(id_div).remove();
	$(id_parent).find('button#addarticleid').prop('disabled',false);
	$(id_parent).find('button#addanswer').prop('disabled',false);
	$(id_parent).find('button#addanswer').prop('disabled',false);
	$(id_parent).find('button#addsolution').prop('disabled',false);
	$(id_parent).find('button#addquestion').prop('disabled',false);
	$(id_parent).find('button#addvariation').prop('disabled',false);

	
	
}
/*-----------------------delete answer-------------------------------------*/
function deleteAnswer(id){
	//console.log(id);
	var id_div=$(id).parent('div').parent('div');
	var id_parent=$(id).parent('div').parent('div').parent('li').children('div').last();
	var id_value=$(id).parent('div').prev('div').find('textarea#answer').val();
	
	/*console.log($(id).parent('div'));
	console.log($(id).parent('div').parent('div'));
	console.log($(id).parent('div').parent('div').parent('li'));
	console.log($(id).parent('div').parent('div').parent('li').children('div').last());*/
	
	
	//console.log(id_parent);
	$(id_div).remove();
	$(id_parent).find('button#addanswer').prop('disabled',false);
	$(id_parent).find('button#addarticleid').prop('disabled',false);
	
	
	
	
}

currentArticleID=null;
function searchArticleId(id){
	var MyWindow=null;
	currentArticleID=id;
	MyWindow=window.open('/popupsearch?appName='+$('#appName').val(),"myWindow", "width=700,height=700");

}
function setArticleIDFromSearch(id,data){
	console.log(id);
	console.log(data);
	console.log('From Popup  Window');
	console.log($(id).parent('div').parent('div').find('textarea#article_id'));
	//console.log($(id).parent('div').prev('div'));
	//console.log($(id).parent('div').prev('div').prev('div').find('textarea#article_id'));
	var id_value=$(id).parent('div').parent('div').find('textarea#article_id').text(data);
}

function encodeHtml(text) {
	  return text
	      .replace(/&/g, "&amp;")
	      .replace(/</g, "&lt;")
	      .replace(/>/g, "&gt;")
	      .replace(/"/g, "&quot;")
	      .replace(/'/g, "&#039;");
}
function decodeHtml(text) {
	  return text
	      .replace(/&amp;/g, "&")
	      .replace(/&lt;/g, "<")
	      .replace(/&gt;/g, ">")
	      .replace(/&quot;/g, "\"")
	      .replace(/&#039;/g, "\'");
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

