
function insertSynonyms() {
	
	var data = $('#synonymdata').val().toString().trim();
	var tarr=data.split('\n');
//	var synonymdata="";
//	tarr.forEach(function(t){
//		
//		var temp=t.toString().trim();
//		if(temp.lenght>0)
//			synonymdata+=temp.toString()+"\n";
//	});
	if(debug){ console.log("Synonyms "+data);}

	//if(debug){ console.log("Synonyms "+synonymdata);}
	$.ajax({
					type : "POST",
					url : "/insertSynonyms",
					data : {
						"synonymData":data
					},

					success : function(res) {
						if(debug){ console.log(res);}
						
						$('#alerttext')
								.html("<h3 class='alert alert-success'>Synonyms inserted successfully..</h3>");
						$("#result").removeAttr("hidden");
						$('#resulttext').addClass('btn-success').removeClass(
								'btn-danger');
						$('#resulttext').val("Success");
						window.reload();						
					},
					error : function(res) {
						$('#alerttext').html("<h3 class='alert alert-danger'>Error inserting synonyms..</h3>");
						if(debug){ console.log(res.toString());}
						alert(res);
						$('#result').removeAttr("hidden");
						$('#resulttext').addClass('btn-danger').removeClass(
								'btn-success');
						$('#resulttext').val("Failed");

					}
				});// end of ajax
	
}