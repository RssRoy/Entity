
// set the dimensions and margins of the graph
var linemargin = {top: 20, right: 20, bottom: 30, left: 50},
    linewidth = 500
    lineheight = 150
// parse the date / time
var parseTime = d3.timeParse("%d-%b-%y");

// set the ranges
var line_x = d3.scaleTime().range([0, linewidth]);
var line_y = d3.scaleLinear().range([lineheight, 0]);

// define the line
var line_valueline = d3.line()
    .x(function(d) { return line_x(d.date); })
    .y(function(d) { return line_y(d.close); });

// append the svg obgect to the body of the page
// appends a 'group' element to 'svg'
// moves the 'group' element to the top left margin
var svg = d3.select("#scatter-plot").append("svg")
    .attr("width", linewidth + linemargin.left + linemargin.right)
    .attr("height", lineheight + linemargin.top + linemargin.bottom)
  .append("g")
    .attr("transform",
          "translate(" + linemargin.left + "," + linemargin.top + ")");

// gridlines in x axis function
function make_x_gridlines() {		
    return d3.axisBottom(line_x)
        .ticks(5)
}

// gridlines in y axis function
function make_y_gridlines() {		
    return d3.axisLeft(line_y)
        .ticks(5)
}

// Get the data
d3.csv("data/line.csv", function(error, data) {
  if (error) throw error;

  // format the data
  data.forEach(function(d) {
      d.date = parseTime(d.date);
      d.close = +d.close;
  });

  // Scale the range of the data
  line_x.domain(d3.extent(data, function(d) { return d.date; }));
  line_y.domain([0, d3.max(data, function(d) { return d.close; })]);

  // add the X gridlines
  svg.append("g")			
      .attr("class", "grid")
      .attr("transform", "translate(0," + lineheight + ")")
      .call(make_x_gridlines()
          .tickSize(-lineheight)
          .tickFormat("")
      )

  // add the Y gridlines
  svg.append("g")			
      .attr("class", "grid")
      .call(make_y_gridlines()
          .tickSize(-linewidth)
          .tickFormat("")
      )

  // add the valueline path.
  svg.append("path")
      .data([data])
      .attr("class", "line")
      .attr("d", line_valueline);

  
  
  // Add the scatterplot
  svg.selectAll("dot")
      .data(data)
    .enter().append("circle")
      .attr("r", 5)
      .attr("cx", function(d) { return line_x(d.date); })
      .attr("cy", function(d) { return line_y(d.close); });


  // add the X Axis
  svg.append("g")
      .attr("transform", "translate(0," + lineheight + ")")
      .call(d3.axisBottom(line_x));

  // add the Y Axis
  svg.append("g")
      .call(d3.axisLeft(line_y));

});
