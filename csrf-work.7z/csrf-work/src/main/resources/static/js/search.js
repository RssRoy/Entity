/////////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////

if (typeof Array.prototype.forEach != 'function') {
    Array.prototype.forEach = function(callback){
      for (var i = 0; i < this.length; i++){
        callback.apply(this, [this[i], i, this]);
      }
    };
}

if (typeof NodeList.prototype.forEach != 'function') {
    NodeList.prototype.forEach = function(callback){
      for (var i = 0; i < this.length; i++){
        callback.apply(this, [this[i], i, this]);
      }
    };
}
/////////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////

function encodeHtml(text) {
	if(text==null || text==='undefined'){
		return text;
	}
	  return text
	      .replace(/&/g, "&amp;")
	      .replace(/</g, "&lt;")
	      .replace(/>/g, "&gt;")
	      .replace(/"/g, "&quot;")
	      .replace(/'/g, "&#039;");
}
function decodeHtml(text) {
	if(text==null || text==='undefined'){
		return text;
	}
	  return text
	      .replace(/&amp;/g, "&")
	      .replace(/&lt;/g, "<")
	      .replace(/&gt;/g, ">")
	      .replace(/&quot;/g, "\"")
	      .replace(/&#039;/g, "\'");
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function searchData() {
    var appName = $('#appName').val().toString().trim();
    var query = $('#search_box').val().toString().trim();
    if (appName.length > 0) {
        $('#result').html(' ');
        $
                .ajax({
                    type : "GET",
                    url : "/searchQuery",
                    data : {
                        "appName" : appName,
                        "q" : query
                    },
                    success : function(res) {
                        if(debug){ console.log(res);}

                        if(debug){ console.log("res=:" + res);}
                        var qa = JSON.parse(res);
                        if(debug){ console.log("qa:" + qa.hits.hits.length);}
                        if(debug){ console.log(qa.hits.hits);}
                        var table = "<table class='table table-striped table-bordered table-hover'><thead><tr><td>No.</td><td>ID</td><td>Question</td><td>Action</td></tr></thead><tbody>";
                        result = null;
                        result = qa.hits.hits;
                        var i = 1;
                        qa.hits.hits.forEach(function(entry) {

                            if(debug){ console.log("source:" + entry._source.question);}
                            if(debug){  console.log("------------------------->source:" + entry._source.question);}
							entry._source.question=encodeHtml(entry._source.question);
							 if(debug){ console.log("--------------------->source<>:" + entry._source.question);}
							
                            table += "<tr><td>" + i + "</td><td>" + entry._id
                                    + "</td><td>"
                                    + entry._source.question;
                                    if(entry._source.hasOwnProperty('sql')){
    									table+="</td><td><a href='./modifysql?id=";
    								}else{
    									table+="</td><td><a href='./modify?id=";
    								}
                                    table+= entry._id + "&appName=" + entry._type
                                    + "' class='btn btn-warning'>Modify</a>"
                                    + "<a href='./delete?id=" + entry._id
                                    + "&appName=" + entry._type
                                    + "' class='btn btn-danger'>Delete</a>"
                                    + "</td></tr>";

                            i = i + 1;

                        });
                        table += "</tbody></table>";
                        $('#databody').html(table);
                        // $('#alerttext').html("<h3 class='alert
                        // alert-success'>Success Loading..</h3>");

                    },
                    error : function(res) {
                        if(debug){ console.log("fail");}
                        $('#alerttext')
                                .html(
                                        "<h3 class='alert alert-danger'>Error Searching data..</h3>");

                    }
                });// end of ajax
    } else {
        $('#alertbox').text("Please select an Application:")
    }
}


function searchArticleID() {
    var appName = $('#appName').val().toString().trim();
    var query = $('#search_box').val().toString().trim();
    if (appName.length > 0) {
        $('#result').html(' ');
        $
                .ajax({
                    type : "GET",
                    url : "/searchQuery",
                    data : {
                        "appName" : appName,
                        "q" : query
                    },
                    success : function(res) {
                        if(debug){ console.log(res);}

                        if(debug){ console.log("res=:" + res);}
                        var qa = JSON.parse(res);
                        if(debug){ console.log("qa:" + qa.hits.hits.length);}
                        if(debug){ console.log(qa.hits.hits);}
                        var table = "<table class='table table-striped table-bordered table-hover'><thead><tr><td>No.</td><td>ID</td><td>Question</td><td>Action</td></tr></thead><tbody>";
                        result = null;
                        result = qa.hits.hits;
                        var i = 1;
                        qa.hits.hits.forEach(function(entry) {

                            if(debug){ console.log("source:" + entry._source.question);}
                            if(debug){  console.log("------------------------->source:" + entry._source.question);}
							entry._source.question=encodeHtml(entry._source.question);
							 if(debug){ console.log("--------------------->source<>:" + entry._source.question);}
							var id=entry._id;
                            table += "<tr><td>" + i + "</td><td>" + entry._id
                                    + "</td><td>"
                                    + entry._source.question;
                                    table+="</td>";
                                    table+="<td>";
                                    table+='<a  data-id="'+id+'"onclick="setArticleID(this);" class="btn btn-primary">Select</a></td></tr>';

                            i = i + 1;

                        });
                        table += "</tbody></table>";
                        $('#databody').html(table);
                        // $('#alerttext').html("<h3 class='alert
                        // alert-success'>Success Loading..</h3>");

                    },
                    error : function(res) {
                        if(debug){ console.log("fail");}
                        $('#alerttext')
                                .html(
                                        "<h3 class='alert alert-danger'>Error Searching data..</h3>");

                    }
                });// end of ajax
    } else {
        $('#alertbox').text("Please select an Application:")
    }
}

function onResult(id) {
    var t = $(id).html();
    t = t.replace('<h5>', '');
    t = t.replace('</h5>', '');
    t = t.trim();
    // alert(t);
    if(debug){ console.log(t + $('#search_box').val());}
    t=decodeHtml(t);
    $('#search_box').val(t);
}
function onUserResult(id) {
    var t = $(id).html();
    t = t.replace('<h6>', '');
    t = t.replace('</h6>', '');
    t = t.trim();
   
    var name=t.substring(t.indexOf('|'),t.indexOf("/"));
    name=name.trim();
    // alert(name);
    if(debug){ console.log(name + $('#user_search_box').val());}
   
    $('#user_search_box').val(name);
}
function liveSearchData() {
    var appName = $('#appName').val().toString().trim();

    var value = $('#search_box').val().toString().trim();

    if(debug){ console.log(value);}
    $
            .ajax({
                type : "GET",
                url : "/searchQuery",
                data : {
                    "appName" : appName,
                    "q" : value
                },
                success : function(res) {
                    if(debug){ console.log("res=:" + res);}
                    var qa = JSON.parse(res);
                    if(debug){ console.log("qa:" + qa.hits.hits.length);}
                    if(debug){ console.log(qa.hits.hits);}
                    $("#result li").remove();
                    result = null;
                    result = qa.hits.hits;
                    var i = 0;
                    qa.hits.hits
                            .forEach(function(entry) {
                                $("#result").show();
                                if(debug){ console.log("source:" + entry._source.question);}
                                // if(entry._source.question){
                                if(debug){  console.log("------------------------->source:" + entry._source.question);}
    							entry._source.question=encodeHtml(entry._source.question);
    							 if(debug){ console.log("--------------------->source<>:" + entry._source.question);}
    							
                                
                                $("#result")
                                        .append(
                                                "<li class='show' id='"
                                                        + i
                                                        + "' style='cursor: pointer; cursor: hand;border: 1px solid blue;' onclick='onResult(this);'><h5>"
                                                        + entry._source.question
                                                        + "</h5></li>");

                                i = i + 1;
                                //}
                            });
                },
                error : function(res) {
                    if(debug){ console.log("fail");}
                    //sendMessage("Not enough data");
                }

            });

}


/********************************USER SEARCH ********************************************/


function searchUser() {
   
    var query = $('#user_search_box').val().toString().trim();
    window.location.replace("/user-management?search="+query);
}


function liveSearchUser() {
    var value = $('#user_search_box').val().toString().trim();
    if(value.length<=2){
    	$("#user_result li").remove();
    	return;
    }
    if(debug){ console.log(value);}
    $
            .ajax({
                type : "POST",
                url : "/searchLiveUser",
                data : {
                    "value" : value,
                    "userid":$('#userid').attr('value'),
            		"issuper":$('#isSuper').val()
                },
                success : function(res) {
                    if(debug){ console.log("res=:" + res);}
                    var res = JSON.parse(res);
                    if(debug){ console.log("res:" + res.length);}
                    if(debug){ console.log(res);}
                    $("#user_result li").remove();
                    result = null;
                    result = res;
                    var i = 0;
                    res.forEach(function(entry) {
                                $("#user_result").show();
                                if(debug){ console.log("source:" + entry.user_name);}
                                // if(entry._source.question){
                               
                                var name=entry.user_name.substring(entry.user_name.indexOf('|'),entry.user_name.indexOf("/"));
                                if(debug){ console.log(name);}
                                if(name.length==0)
                                    name=entry.user_name;
                                $("#user_result")
                                        .append(
                                                "<li class='show' id='"
                                                        + i
                                                        + "' style='cursor: pointer; cursor: hand;border: 1px solid blue;' onclick='onUserResult(this);'><h6>"
                                                        + entry.user_id+" | "+name
                                                        + "</h6></li>");

                                i = i + 1;
                                //}
                            });
                },
                error : function(res) {
                    if(debug){ console.log("fail");}
                    //sendMessage("Not enough data");
                }

            });

}

/********************************GRANT SEARCH ********************************************/


function onGrantResult(id) {
    var t = $(id).html();
    t = t.replace('<h6>', '');
    t = t.replace('</h6>', '');
    t = t.trim();
   
    var name=t.substring(t.indexOf('|'),t.indexOf("/"));
    name=name.trim();
    // alert(name);
    if(debug){ console.log(name + $('#grant_search_box').val());}
    $('#grant_search_box').val(name);
}

function searchGrant() {
   
    var query = $('#grant_search_box').val().toString().trim();
    window.location.replace("/grant-management?search="+query);
}


function liveSearchGrant() {
    var value = $('#grant_search_box').val().toString().trim();
    if(value.length<=2){
    	$("#grant_result li").remove();
    	return;
    }
    if(debug){ console.log(value);}
    $
            .ajax({
                type : "POST",
                url : "/searchLiveGrant",
                data : {
                    "value" : value,
                    "userid":$('#userid').attr('value'),
            		"issuper":$('#isSuper').val()
                },
                success : function(res) {
                    if(debug){ console.log("res=:" + res);}
                    var res = JSON.parse(res);
                    if(debug){ console.log("res:" + res.length);}
                    if(debug){ console.log(res);}
                    $("#grant_result li").remove();
                    result = null;
                    result = res;
                    var i = 0;
                    res.forEach(function(entry) {
                                $("#grant_result").show();
                                if(debug){ console.log("source:" + entry.grantee_name);}
                                // if(entry._source.question){
                               
                                var name=entry.grantee_name.substring(entry.grantee_name.indexOf('|'),entry.grantee_name.indexOf("/"));
                                if(debug){ console.log(name);}
                                if(name.length==0)
                                    name=entry.grantee_name;
                                $("#grant_result")
                                        .append(
                                                "<li class='show' id='"
                                                        + i
                                                        + "' style='cursor: pointer; cursor: hand;border: 1px solid blue;' onclick='onGrantResult(this);'><h6>"
                                                        + entry.grantee_id+" | "+name
                                                        + "</h6></li>");

                                i = i + 1;
                                //}
                            });
                },
                error : function(res) {
                    if(debug){ console.log("fail");}
                    //sendMessage("Not enough data");
                }

            });

}



/********************************APP PROP  SEARCH ********************************************/


function onPropResult(id) {
    var t = $(id).html();
    t = t.replace('<h6>', '');
    t = t.replace('</h6>', '');
    t = t.trim();
   
    var name=t.substring(t.indexOf('|'),t.indexOf("/"));
    name=name.trim();
    // alert(name);
    if(debug){ console.log(name + $('#appprop_search_box').val());}
    $('#appprop_search_box').val(name);
}

function searchAppProp() {
   
    var query = $('#appprop_search_box').val().toString().trim();
    window.location.replace("/appPropertiesPage?search="+query);
}


function liveSearchAppProp() {
    var value = $('#appprop_search_box').val().toString().trim();
    if(value.length<=2){
    	$("#appprop_result li").remove();
    	return;
    }
    if(debug){ console.log(value);}
    $
            .ajax({
                type : "POST",
                url : "/searchLiveAppProp",
                data : {
                    "value" : value,
            		"issuper":$('#isSuper').val()
                },
                success : function(res) {
                    if(debug){ console.log("res=:" + res);}
                    var res = JSON.parse(res);
                    if(debug){ console.log("res:" + res.length);}
                    if(debug){ console.log(res);}
                    $("#grant_result li").remove();
                    result = null;
                    result = res;
                    var i = 0;
                    res.forEach(function(entry) {
                                $("#appprop_result").show();
                                if(debug){ console.log("source:" + entry.app_name);}
                                // if(entry._source.question){
                               
                                var name=entry.app_name;
                                if(debug){ console.log(name);}
                                if(name.length==0)
                                    name=entry.app_name;
                                $("#appprop_result")
                                        .append(
                                                "<li class='show' id='"
                                                        + i
                                                        + "' style='cursor: pointer; cursor: hand;border: 1px solid blue;' onclick='onAppPropResult(this);'><h6>"
                                                        + entry.app_id+" | "+name
                                                        + "</h6></li>");

                                i = i + 1;
                                //}
                            });
                },
                error : function(res) {
                    if(debug){ console.log("fail");}
                    //sendMessage("Not enough data");
                }

            });

}