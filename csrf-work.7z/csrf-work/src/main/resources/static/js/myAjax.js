function getdata(){
		$.ajax({
			type:"POST",
	    	url: "/getData",
	    	data : {
	    		"option" : $('#option').val(),
	    		"totIntDate" : $('#totIntDate').val(),
	    		"totInt" : $('#totInt').val(),
	    	},
	    	success : function(res){
	    		$('#json-data').val(res);
	    		if(res != "[]"){
	    			d3.select("#bar-graph").select("g").remove();
	    			plot_bar();
	    			console.log(res);
	    			selectedValuePass = $("#option").find("option:selected").text();
	    			console.log("**************"+selectedValuePass);
	    			$('#selectedValuePass').val(selectedValuePass);
	    		} else {
	    			d3.select("#bar-graph").select("g").remove();
	    		}
	    		
	    	},error:function(res){
	    		$('#json-data').html('ERROR');
	    	}
		});
}
   
/*function getSucRatio(){
	$.ajax({
		type:"POST",
    	url: "/getSucRatio",
    	data : {
    		"option" : $('#option').val(),
    		"totIntDate" : $('#totIntDate').val(),
    		"totInt" : $('#totInt').val(),
    	},
    	success : function(res){
    		console.log(res);
    		$('#ratio').val(res);
    	},error:function(res){
    		$('#ratio').html('ERROR');
    	}
	});
}*/

function getCountForLineBar(){
	$.ajax({
		type:"POST",
    	url: "/getCountForLineBar",
    	data : {
    		"option" : $('#option').val(),
    	},
    	success : function(res){
    		$('#csv_data').val(res);
    		if(res != "[]"){
    			d3.select("#line-graph").select("g").remove();
    			lineBarChart();
    			console.log("Line Bar Json Array ::---- "+res);
    		}else{
    			d3.select("#line-graph").select("g").remove();
    		}
    	},error:function(res){
    		$('#csv_data').html('ERROR');
    	}
	});
}

function getTopTrending(){
	$.ajax({
		type:"POST",
    	url: "/getTopTrending",
    	function () {
    	    $("#topTrendingDate").change(function () {
    	        var selectedText = $("#topTrendingDate").find("option:selected").text();
    	        var selectedValue = $("#topTrendingDate").val();
    	    });
    	},
    	data : {
    		"optionTop" : $('#optionTop').val(),
    		"topTrendingDate" : $("#topTrendingDate").find("option:selected").text(),
    	},
    	success : function(res){
    		$('#json-toptrending').val(res);
    		selectedDatePass = $("#topTrendingDate").find("option:selected").text();
    		console.log("getTopTrending**************"+selectedDatePass);
    		$('#selectedDatePass').val(selectedDatePass);
    		
    		if(res != "{}"){
    			d3.select("#tree-map").select("g").remove();
    			topTrending();
    			console.log("json-toptrending -- "+res);
    			document.getElementById('topTrendingLabel').style.visibility  = 'hidden';	
    		} else {
    			document.getElementById('topTrendingLabel').style.visibility  = 'visible';
    			//document.getElementById('topTrendingLabel').innerHTML = 'There is no data available for Top Trending on '+selectedDatePass;
    			document.getElementById('topTrendingLabel').innerHTML = 'There is no data available for Top Trending';
    			d3.select("#tree-map").select("g").remove();
    			return false;
    		}
    		//document.getElementById('topTrendingLabel').style.display = 'none';	
    		
    	},error:function(res){
    		$('#json-toptrending').html('ERROR');
    	}
	});
}


function getQesWithNoSugg(){
	$.ajax({
		type:"POST",
    	url: "/getQesWithNoSugg",
    	function () {
    	    $("#queWithNoSuggDate").change(function () {
    	        var selectedText = $("#queWithNoSuggDate").find("option:selected").text();
    	        var selectedValue = $("#queWithNoSuggDate").val();
    	    });
    	},
    	data : {
    		"optionQue" : $('#optionQue').val(),
    		//"queWithNoSuggDate" : $("#queWithNoSuggDate").find("option:selected").text(),
    		"queWithNoSuggDate" : $("#queWithNoSuggDate").val(),
    	},
    	
    	success : function(res){
    		$('#json-QuesWithNoSugg').val(res);
    		if(res != "{}"){
    			d3.select("#QuesWithNoSug_tree_map").select("g").remove();
    			document.getElementById('strLabel').style.visibility  = 'hidden';	
    			questionWithNoSugg();
    		} else {
    			//document.getElementById('strLabel').innerHTML = 'There is no questions with no suggestion on '+$("#queWithNoSuggDate").val();
    			document.getElementById('strLabel').style.visibility  = 'visible';
    			document.getElementById('strLabel').innerHTML = 'There are no questions with no suggestion';
    			d3.select("#QuesWithNoSug_tree_map").select("g").remove();
    			return false;
    		}
    		console.log("json-QuesWithNoSugg -- "+res);
    	},error:function(res){
    		$('#json-QuesWithNoSugg').html('ERROR');
    	}
	});
}

function getQesLeadToSR(){
	$.ajax({
		type:"POST",
    	url: "/getQesLeadToSR",
    	function () {
    	    $("#queleadSRDate").change(function () {
    	        var selectedText = $("#queleadSRDate").find("option:selected").text();
    	        var selectedValue = $("#queleadSRDate").text();
    	    });
    	},
    	data : {
    		"optionQuetSR" : $('#optionQuetSR').val(),
    		"queleadSRDate" : $("#queleadSRDate").find("option:selected").text(),
//    		"queleadSRDate" :$("#queleadSRDate").val(),
    		
    	},
    	
    	success : function(res){
    		$('#json-QuesLeadingToSR').val(res);
    		if(res != "{}"){
    			d3.select("#QuesLeadingToSR_tree_map").select("g").remove();
    			document.getElementById('QuesLeadingToSRLabel').style.visibility  = 'hidden';
    			questionToSR();
    			
    		} else {
    			//document.getElementById('QuesLeadingToSRLabel').innerHTML = 'There is no questions leading to SR on '+$("#queleadSRDate").val();
    			document.getElementById('QuesLeadingToSRLabel').style.visibility  = 'visible';
    			document.getElementById('QuesLeadingToSRLabel').innerHTML = 'There are no questions leading to SR';
    			d3.select("#QuesLeadingToSR_tree_map").select("g").remove();
    			return false;
    		}
    		console.log("json-QuesLeadingToSR -- "+res);
    	},error:function(res){
    		$('#json-QuesLeadingToSR').html('ERROR');
    	}
	});
}

function getIntrDetails(){
	$.ajax({
		type:"POST",
    	url: "/getIntrDetails",
    	function () {
    	    $("#intrDtlsDTdropdown").change(function () {
    	        var selectedText = $("#intrDtlsDTdropdown").find("option:selected").text();
    	        var selectedValue = $("#intrDtlsDTdropdown").val();
    	    });
    	},
    	data : {
    		"intrDtlsDropdown" : $('#intrDtlsDropdown').val(),
    		//"intrDtlsDTdropdown" : $("#intrDtlsDTdropdown").find("option:selected").text(),
    		"intrDtlsDTdropdown" : $("#intrDtlsDTdropdown").val(),
    	},
    	success : function(res){
    		$('#json_IntrDtls').val(res);
    		console.log("json_IntrDtls ::---- "+res);
    		d3.select('table').remove();
    		intrstDetails(res);
    	},error:function(res){
    		$('#json_IntrDtls').html('ERROR');
    	}
	});
}

function populateDates(){
	$.ajax({
		type:"POST",
    	url: "/populateDates",
    	data : {
    	},
    	success : function(res){
    		$('#json_listOfDates').val(res);
//    		alert($('#option').val());
    		//for TopTrending
    		console.log("Fetching Dates :- "+res);
            var $el = $("#topTrendingDate");
            $el.empty(); // remove old options
            /*$el.append($("<option></option>")
                .attr("value", '').text('Date'));*/

            // for each set of data, add a new option
            $.each(res, function(value, key) {
                $el.append($("<option></option>")
                    .attr("value", key).text(key));
            });
            // end top
            
            //Question with no Sugg
          /*  var $el = $("#queWithNoSuggDate");
            $el.empty(); // remove old options
            $el.append($("<option></option>")
                .attr("value", '').text('Date'));

            // for each set of data, add a new option
            $.each(res, function(value, key) {
                $el.append($("<option></option>")
                    .attr("value", key).text(key));
            });*/
            // end sugg
            
            //Question Leading to SR
           /* var $el = $("#queleadSRDate");
            $el.empty(); // remove old options
            $el.append($("<option></option>")
                .attr("value", '').text('Date'));

            $.each(res, function(value, key) {
                $el.append($("<option></option>")
                    .attr("value", key).text(key));
            });*/
            // end sr
            
            //Interaction Details
         /*   var $el = $("#intrDtlsDTdropdown");
            $el.empty(); // remove old options
            $el.append($("<option></option>")
                .attr("value", '').text('Date'));

            $.each(res, function(value, key) {
                $el.append($("<option></option>")
                    .attr("value", key).text(key));
            });*/
            // end Interaction Details
            
    	},error:function(res){
    		$('#popDates').html('ERROR');
    	}
	});
}
//window.setInterval(getdata, 100);