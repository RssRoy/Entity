$(document).ready(function(){

  $(".message_input ").keyup(function(){
      if($(".upper_results li").length > 1){
          $(".upper_results.dropup").css("display","block");
          $(".results").css("bottom","92px");
      } else{
          $(".upper_results.dropup").css("display","none");
         $(".results").css("bottom","57px");
      }
     
  });
  $(".results").on('click', 'li', function(){
      $(".upper_results.dropup").css("display","none");
      $(".results").css("bottom","57px");
  });
 

$(".message_input").on("change paste keyup", function() {
    if($(".message_input").val() == ""){
    $(".results").css("display","none");
    }
});


$(document).keyup(function(e) {
    $(".results li.show").addClass("highlive");
    var $highlive = $('.results li.highlive'), $liHighlive = $('li.highlive');
    if (e.keyCode == 40) {
$highlive.removeClass('highlive').next().addClass('highlive');
        if ($highlive.next().length == 0) {
            $liHighlive.eq(0).addClass('highlive')
        }
    } else if (e.keyCode === 38) {
$highlive.removeClass('highlive').prev().addClass('highlive');
        if ($highlive.prev().length == 0) {
            $liHighlive.eq(-1).addClass('highlive')
        }
    }
})


  /*$(".messages").mouseover(function(){

      $(".results").css("display","none");

  });*/
 
 
});