function openLink(que){
	var appName=$('#AppNameSelect').val();
	//var srlink = getSRLink();
	
	que=que.trim();
	if(que.indexOf('\'')>=0 && que.lastIndexOf('\'')>=0){
		que=que.replace(/(\')(.{0,})(\')/g,/$2/g);
	}
	if(debug){console.log("link.js: 8 Question: "+que);}
	log(appName,"FEEDBACK",que,"DOWN","NULL","CLICKED ON SR LINK");
	
	if(debug){ console.log("link.js:6: "+$('#AppNameSelect').val()+"FEEDBACK",que,"DOWN","NULL","CLICKED ON SR LINK");}
	
	
	
	if(debug){ console.log(que);}
	//var url1='http://hydihelp101dev.icicibankltd.com:8383/IHelpDesk/';
	//var url2='http://hydihelp101dev.icicibankltd.com:8383/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=I-CORE INDIA&type3=Report an Issue-I-Core India&chatBotFlag=y';
	//var url2="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/";
	//var url2 = "http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?SRType=IT APPLICATION CALLS_I-CORE INDIA_Report an Issue-I-Core India";

	
	var i_core="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=I-CORE INDIA&type3=Report an Issue-I-Core India&chatBotFlag=y";
	
	var i_view="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=I-VIEW&type3=Report an Issue-I-VIEW&chatBotFlag=y";
	
	var i_sense="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=I-SENSE&type3=Report an Issue-I-SENSE&chatBotFlag=y";
	var dms="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=DELIVERABLES MANAGEMENT SYSTEM[DMP]&type3=Report an Issue-DMP&chatBotFlag=y";
	//log($('#AppNameSelect').val(),"FEEDBACK",que,"DOWN","NULL","CLICKED ON SR LINK");
	
	
	
	
	
	/*
	if($('#AppNameSelect').val().toLowerCase().trim()==='finacle'){
		if(debug){console.log(i_core);}
		var win2 = window.open(i_core, '_blank');
	}else if($('#AppNameSelect').val().toLowerCase().trim()==='i-view'){
		if(debug){console.log(i_view);}
		var win2 = window.open(i_view, '_blank');
	}else if($('#AppNameSelect').val().toLowerCase().trim()==='i-sense'){
		if(debug){console.log(i_sense);}
		var win2 = window.open(i_sense, '_blank');
	}else if($('#AppNameSelect').val().toLowerCase().trim()==='deliverables management system[dmp]'){
		if(debug){console.log(dms);}
		var win2 = window.open(dms, '_blank');
	}else {
		
		var url="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=";
		var issue="&type3=Report an Issue-";
		var chatbotflag="chatBotFlag=y";
		
		var finalurl=url+$('#AppNameSelect option:selected').text().trim()+issue+$('#AppNameSelect option:selected').text().trim()+chatbotflag;
		var win2 = window.open(finalurl, '_blank');
	}*/
	
	/*----------------- GET SR LINK ----------------------*/
	
	 var appnameselect = $('#AppNameSelect').val().toLowerCase().trim();
	    
	    
	    //if(debug){ console.log(value);}
	 
	    $.ajax({
	                type : "POST",
	                url : "/getSRLink",
	                data : {
	                    "app_name" : $('#AppNameSelect option:selected').html().toUpperCase().trim()
	                },
	                success : function(res) {
	                	 if(debug){ console.log("res=:" + res);}
	                	 if(debug){ console.log("res:" + res.length);}
	                	 if(debug){ console.log(res);}
	  	                    
	                	/*if(res.length>10){
	                		 
	  	                    var SRlink = res.trim();
	  	                   
	  	                    
	  	                    var win2 = window.open(res, '_blank');
	  	                	
	  	                	window.close();
	                	}else{
	                		 if(debug){ console.log(" SR link from table small");}
	 	                    
	 	                    var url="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=";
	 	            		var issue="&type3=Report an Issue-";
	 	            		var chatbotflag="&chatBotFlag=y";
	 	            		
	 	            		var finalurl=url+$('#AppNameSelect option:selected').text().trim()+issue+$('#AppNameSelect option:selected').text().trim()+chatbotflag;
	 	            		var win2 = window.open(finalurl, '_blank');
	 	                    //sendMessage("Not enough data");
	 	            		//alert(finalurl);
	 	            		//console.log(finalurl);
	 	                	window.close();
	                	}*/
	                	
	                	 var SRlink = res.trim();
	  	                   
	  	                    
	  	                 var win2 = window.open(res, '_blank');
	  	                	
	  	                 window.close();
	                	
	                   
	                },
	                error : function(res) {
	                    if(debug){ console.log("fail to get SR link from table");}
	                    
	                    var url="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=";
	            		var issue="&type3=Report an Issue-";
	            		var chatbotflag="&chatBotFlag=y";
	            		
	            		var finalurl=url+$('#AppNameSelect option:selected').text().trim()+issue+$('#AppNameSelect option:selected').text().trim()+chatbotflag;
	            		var win2 = window.open(finalurl, '_blank');
	                    //sendMessage("Not enough data");
	            		console.log(finalurl);
	                	window.close();
	                }

	            });
	
}

function openReasonLink(id){
	var que=$(id).attr('data-que');
	que=que.trim();
	if(que.indexOf('\'')>=0 && que.lastIndexOf('\'')>=0){
		que=que.replace(/(\')(.{0,})(\')/g,/$2/g);
	}
	if(debug){console.log("link.js: 8 Question: "+que);}
	log(appName,"FEEDBACK",que,"DOWN","NULL","CLICKED ON SR LINK");
	$('#raisesrselect').attr('disabled','disabled');
	
	var res=$('#raisesrselect :selected').attr('value');
	//alert($('#raisesrselect :selected').text());
	/*if($('#raisesrselect :selected').text() == "REPORT AN ISSUE"){
			var appnameselect = $('#AppNameSelect').val().toLowerCase().trim();
	    
	    
	    //if(debug){ console.log(value);}
	 
		    $.ajax({
		                type : "POST",
		                url : "/getSRLink",
		                data : {
		                    "app_name" : $('#AppNameSelect option:selected').html().toUpperCase().trim()
		                },
		                success : function(res) {
		                	 if(debug){ console.log("res=:" + res);}
		                	 if(debug){ console.log("res:" + res.length);}
		                	 if(debug){ console.log(res);}
		  	                    
		                	if(res.length>10){
		                		 
		  	                    var SRlink = res.trim();
		  	                   
		  	                    
		  	                    var win2 = window.open(res, '_blank');
		  	                	
		  	                	window.close();
		                	}else{
		                		 if(debug){ console.log(" SR link from table small");}
		 	                    
		 	                    var url="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=";
		 	            		var issue="&type3=Report an Issue-";
		 	            		var chatbotflag="&chatBotFlag=y";
		 	            		
		 	            		var finalurl=url+$('#AppNameSelect option:selected').text().trim()+issue+$('#AppNameSelect option:selected').text().trim()+chatbotflag;
		 	            		var win2 = window.open(finalurl, '_blank');
		 	                    //sendMessage("Not enough data");
		 	            		//alert(finalurl);
		 	            		//console.log(finalurl);
		 	                	window.close();
		                	}
		                	
		                	 var SRlink = res.trim();
		  	                   
		  	                    
		  	                 var win2 = window.open(res, '_blank');
		  	                	
		  	                 window.close();
		                	
		                   
		                },
		                error : function(res) {
		                    if(debug){ console.log("fail to get SR link from table");}
		                    
		                    var url="http://ihelpdesk10.icicibankltd.com:64201/IHelpDesk/LoginPage.jsp?first=true&flg=false&type1=IT APPLICATION CALLS&type2=";
		            		var issue="&type3=Report an Issue-";
		            		var chatbotflag="&chatBotFlag=y";
		            		
		            		var finalurl=url+$('#AppNameSelect option:selected').text().trim()+issue+$('#AppNameSelect option:selected').text().trim()+chatbotflag;
		            		var win2 = window.open(finalurl, '_blank');
		                    //sendMessage("Not enough data");
		            		console.log(finalurl);
		                	window.close();
		                }
	
		            });
		}
	else{*/
	
	var SRlink = res.trim();
       
       
       var win2 = window.open(res, '_blank');
       $('#raisesrdiv').remove();
       window.close();
	//}
}





function getSRLink() {
    var appnameselect = $('#AppNameSelect').val().toLowerCase().trim();
    
    
    if(debug){ console.log(value);}
    $
            .ajax({
                type : "POST",
                url : "/getSRLink",
                data : {
                    "app_name" : appnameselect
                },
                success : function(res) {
                	
                	
                	
                	
                	
                    if(debug){ console.log("res=:" + res);}
                    var SRlink = res.trim();
                    if(debug){ console.log("res:" + res.length);}
                    if(debug){ console.log(res);}
                    return res;
                   
                },
                error : function(res) {
                    if(debug){ console.log("fail to get SR link from table");}
                    //sendMessage("Not enough data");
                }

            });

}