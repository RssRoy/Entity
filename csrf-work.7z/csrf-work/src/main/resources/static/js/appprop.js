$('#myappname').change(function(){
	console.log("appname--> change-->"+$('#myappname :selected').val().toUpperCase());

	var t_app=$(this).val().trim();
	
	$('#myappid').val($('#myappname :selected').attr('data-id'));
	
	//$('#myappid option[text="'+encodeHtml(t_app).trim().toUpperCase()+'"]').attr("selected", "selected");
	//console.log("app id ----"+$('#myappid').val());
});
