
		
var insertHtml='<li>'
		+'<div class="form-group"><label class="control-label col-md-1 pt5" for="question">Question:</label><div class="col-md-11"><textarea class="form-control mb10" id="question" rows="1"	placeholder="Enter question" required="required"></textarea>		<input type="hidden" id="qlevel0" value="0"> <input			type="hidden" id="qparentlevel0" value="0">	</div></div><div class="form-group">'
		+'<div class="col-sm-offset-2 col-sm-10">	'
		+'<button type="button" class="btn btn-primary" id="addquestion"			value="0" onclick="addQuestion(this);">Add Question</button>'
		+'<button type="button" class="btn btn-primary" id="addvariation"			value="0" onclick="addVariation(this);">Add Variation</button>'
		+'<button type="button" class="btn btn-primary" id="addsolution"			value="0" onclick="addSolution(this);">Add Solution</button>'
		+'<button type="button" class="btn btn-primary" id="addanswer"			value="0" onclick="addAnswer(this);">Add Answer</button>'
		if(debug){console.log($('#enable_article_id').val());};
		if($('#enable_article_id').val()=='true'){
			insertHtml+='<button type="button" class="btn btn-primary addarticleid" id="addarticleid"	name="addarticleid"	value="0" onclick="addArticleId(this);">Add Article ID</button>';
		}
		+'</div></div></li>';


$('#appName').on('change',function(){
	var appName = $('#appName').val().toString().trim();
	appName=decodeHtml(appName);
	if(appName!='none'){
		$('#appName').removeAttr("data-toggle")
    	$('#appName').removeAttr("data-placement")
    	$('#appName').removeAttr("data-original-title");
       
    	$('#appName').css('color','');
    	$('#appName').tooltip({trigger: 'manual'}).tooltip('hide');
	}else{
		$('#appName').attr("data-toggle","tooltip")
    	$('#appName').attr("data-placement","auto")
    	$('#appName').attr("data-original-title","Please select an Application.");
       
    	$('#appName').css('color','red');
    	$('#appName').tooltip({trigger: 'manual'}).tooltip('show');
        //console.log("False");
       
	}
});
		
		


function insertData() {
	
	$('#answer_exist').val('false');
	var appName = $('#appName').val().toString().trim();
	appName=decodeHtml(appName);
	console.log(appName);
	if(appName==='none'){
		console.log("Empty or undefined");
		
    	$('#appName').attr("data-toggle","tooltip")
    	$('#appName').attr("data-placement","auto")
    	$('#appName').attr("data-original-title","Please select an Application.");
       
    	$('#appName').css('color','red');
    	$('#appName').tooltip({trigger: 'manual'}).tooltip('show');
        //console.log("False");
       return false;
		
	}
	if(appName==null || appName==undefined || appName.length==0){
		console.log("Empty or undefined");
		
    	$('#appName').attr("data-toggle","tooltip")
    	$('#appName').attr("data-placement","auto")
    	$('#appName').attr("data-original-title","Please select an Application.");
       
    	$('#appName').css('color','red');
    	$('#appName').tooltip({trigger: 'manual'}).tooltip('show');
        //console.log("False");
       return false;
		
	}
	if($('#question').val()==undefined || $('#question').val().trim().length==0){
		console.log("Empty or undefined");
		
    	$('#question').attr("data-toggle","tooltip")
    	$('#question').attr("data-placement","auto")
    	$('#question').attr("data-original-title","Please fill the field.");
       
    	$('#question').css('color','red');
    	$('#question').tooltip({trigger: 'manual'}).tooltip('show');
        //console.log("False");
       return false;
	}
	
	
	if(debug){console.log("Insert  Data()");}
	var art_id=$('.check_article_id');
	for(var i = 0; i < art_id.length; i++){
		if(debug){console.log($(art_id[i]).html());}
	   if($(art_id[i]).html().trim()=='Invalid ID' || $(art_id[i]).html().trim()=='Check'){
		   $('#alerttext').removeAttr('hidden');
		   $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ERROR : Please Check All Article IDs to be VALID.");
		   $('#alerttext').addClass('alert alert-danger').addClass('btn-danger').removeClass('alert-success btn-success');
		  return false; 
	   }
	}
	var id = document.getElementById('lilevel0');
	filejson = {}
	filejson=toJson(id, filejson, -1);
	if($('#answer_exist').val()=='false'){
		console.log("Answer Not Exists");
		
    	$('#question').attr("data-toggle","tooltip")
    	$('#question').attr("data-placement","auto")
    	$('#question').attr("data-original-title","Please Add Answer or Article ID w.r.t this question.");
       
    	$('#question').css('color','red');
    	$('#question').tooltip({trigger: 'manual'}).tooltip('show');
        //console.log("False");
       return false;
	}
	if(debug){ console.log("--------------Final------------------------------------------");}
	if(debug){ console.log(JSON.stringify(filejson));}
	
	var appName = $('#appName').val().toString().trim();
	appName=decodeHtml(appName);
	if(Object.getOwnPropertyNames(filejson).length > 0){
	if (appName.length > 0) {
		$
				.ajax({
					type : "POST",
					url : "/insertJson",
					data : {
						"appName" : appName,
						"jsonObj" : JSON.stringify(filejson)
					},

					success : function(res) {
						if(debug){ console.log(res);}
						var id=res.substring(res.search('#')+2,res.length-1);
						if(id===null ){
							$('#alerttext')
							.html(
									"<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ERROR : Inserting data");
							  $('#alerttext').addClass('alert alert-danger').addClass('btn-danger').removeClass(
					'btn-success').removeClass('alert-success');;
							return;
						}
						if(debug){ console.log(id);}
						Activitylog(appName,filejson.question,"INSERT",id);
						/*$('#alerttext')
						.html(
								"<h3 class='alert alert-success'>Data inserted successfully..</h3>");*/
						$("#alerttext").removeAttr("hidden");
						$('#alerttext').addClass("alert");
						$('#alerttext').addClass("alert-success").removeClass('alert-danger');
						$('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ID: "+id+"   Data inserted successfully..");
						$("#result").removeAttr("hidden");
						$('#resulttext').addClass('btn-success').removeClass(
								'btn-danger');
						$('#resulttext').val("Success");
						$('#lilevel0').html(insertHtml);
					},
					error : function(res) {
						/*$('#alerttext')
								.html(
										"<h3 class='alert alert-danger'>Error inserting data..</h3>");*/
						$("#alerttext").removeAttr("hidden");
						$('#alerttext').addClass("alert");
						$('#alerttext').addClass("alert-danger").removeClass('alert-success');
						$('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Error inserting data..");
						
						if(debug){ console.log(res);}
						$('#result').removeAttr("hidden");
						$('#resulttext').addClass('btn-danger').removeClass(
								'btn-success');
						$('#resulttext').val("Failed");

					}
				});// end of ajax
	} else {
		/*$('#alerttext')
				.html(
						"<h3 class='alert alert-danger'>Please Fill All The Details..</h3>");*/
		$("#alerttext").removeAttr("hidden");
		$('#alerttext').addClass("alert");
		$('#alerttext').addClass("alert-danger");
		$('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Please Fill All The Details..");
		
	}
	}else{
		/*$('#alerttext')
		.html(
				"<h3 class='alert alert-danger'>Please Fill All The Details..</h3>");*/
		$("#alerttext").removeAttr("hidden");
		$('#alerttext').addClass("alert");
		$('#alerttext').addClass("alert-danger");
		$('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Please Fill All The Details..");
	}
}

/* select app from url*/


$(document).ready(
		function() {
			$.urlParam = function(name) {
				var results = new RegExp('[\?&]' + name + '=([^&#]*)')
						.exec(window.location.href);
				if (results == null) {
					return null;
				} else {
					return decodeURI(results[1]) || 0;
				}
			}
			var appName = $.urlParam('appName');
			var que = $.urlParam('question');
			$('#appName option[value="' + appName + '"]')
					.prop('selected', true)
					$("#question").val(que);
		});
