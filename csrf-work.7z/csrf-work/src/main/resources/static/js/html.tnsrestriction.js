	
function validateTnsForm(){
	var valid=true;
	var innerValid=false;
	$("form input[type=text]").each(function(e){
		console.log($(this).val());
		console.log(this);
		console.log($(this).attr('id'));
		
		
		innerValid=false;
		 var reg =/<(.|\n)*?>/g; 
		  var reg1 =/(\@|\|\$|\&|\,|\%|\^|\*|\||\<|\>|\/|\?|\:|\;|\=|\+|\`|\~|\!)/g; 
		  var regHIP=/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/g;

		  //var regHN=/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$/g;
		  var regHN=/^(?:[a-zA-Z0-9-]{2,20}\.[a-zA-Z0-9-]{0,20}\.{0,1}[a-zA-Z0-9-]{2,20})$/g;
		  var regP=/^\d+$/g;
		  
	        if (reg.test($(this).val()) == true) {
	         	console.log("HTML TAG");
	        	
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","HTML Tag are not allowed");
	          
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	       
	       return false;
	        }else if(reg1.test($(this).val()) == true){
	         	
	        	console.log("Symbols");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Special symbols like @ # $ & % < > , \' \" ! ` ~  are not allowed");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');

	       
	       return false;
	        }else if($(this).val()==undefined || ($(this).val()).length==0){
	        	/*console.log($(this).val()==undefined)
	        	console.log($(this).val()===undefined)
	        	console.log($(this).val()==='undefined')*/
	        	
	        	console.log("Empty or undefined");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Please fill the field.");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        }else if(regP.test($('#mytnsserverport').val()) == false){
	        	console.log("port");
	        	$('#mytnsserverport').attr("data-toggle","tooltip")
	        	$('#mytnsserverport').attr("data-placement","auto")
	        	$('#mytnsserverport').attr("data-original-title","Port cannot contains alphabate.");
	           
	        	$('#mytnsserverport').css('color','red');
	            $('#mytnsserverport').tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        } else if(regHIP.test($('#mytnsserverhost').val()) == false && regHN.test($('#mytnsserverhost').val()) == false){
	        	console.log("server address");
	        	$('#mytnsserverhost').attr("data-toggle","tooltip")
	        	$('#mytnsserverhost').attr("data-placement","auto")
	        	$('#mytnsserverhost').attr("data-original-title","Please fill correct host IP / NAME.");
	           
	        	$('#mytnsserverhost').css('color','red');
	            $('#mytnsserverhost').tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        }          
	        else{
	        	console.log("No Error");
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
	        	$(this).css('color','');
	        	innerValid=true;
	        }
	        	
	        
	       valid=valid && innerValid;
	});
	
	
	
	$("form select").each(function(e){
		innerValid=innerValid && true;
		console.log($(e));
		if($(this).val()==undefined || $(this).val().trim().length==0){
			console.log("Empty or undefined select");
        	$(this).attr("data-toggle","tooltip")
        	$(this).attr("data-placement","auto")
        	$(this).attr("data-original-title","Please fill the field.");
           
        	$(this).css('color','red');
            $(this).tooltip({trigger: 'manual'}).tooltip('show');
            console.log("False");
            innerValid=false;
            
		}else{
			console.log("No Error in select ");
        	$(this).removeAttr("data-toggle")
        	$(this).removeAttr("data-placement")
        	$(this).removeAttr("title");
        	$(this).removeAttr("data-original-title");
            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
            $(this).attr('disabled','disabled');
        	$(this).css('color','');
        	innerValid=innerValid && true;
		}
		valid=valid && innerValid;
	});
	
	
	return valid && innerValid;
	
}

$(document).on('click','#createTns',function(e){
		console.log("button click");
		if(validateTnsForm()===true){
			console.log("Form Validated");
			
			$('#myappname').attr('readonly','readonly');
			$('#mytnsserverhost').attr('readonly','readonly');
			$('#mytnsserverport').attr('readonly','readonly');
			$('#mytnsservicename').attr('readonly','readonly');
			$('#mytnsdatabasename').attr('readonly','readonly');
			$('#mytnsusername').attr('readonly','readonly');
			$('#mytnspassword').attr('readonly','readonly');
			
			
			//$('#createGrant').attr('onclick','createGrantModal(this);');
			
			$('#mytnsModal').css('display','block');
			
			
			$('#createTns').removeAttr('disabled');
			//console.log(this);
			$('#createTns').attr('onclick','createtnsModal(this)');
			$('#createTns').html('Create');
			
			$('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('hide'); 
			$(this).removeAttr("data-toggle")
			$(this).removeAttr("data-placement")
			$(this).removeAttr("data-original-title");
		    
			$('form input').css('color','');
		}
});



$( "input[type=text] :not([readonly])" ).focusin(function(e) {
		if(debug){console.log($(this).val());}
		  
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            
	        	$(this).css('color','');
	         
	        
	        if(debug){console.log(this);}
	        e.preventDefault();
});
 