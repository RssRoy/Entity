
if($('#imageZoom').val()==='true'){


	var toZoom=true;
	
	$(document).on("click","img",function(id){
		if(debug){console.log(":: Image zoom:"+toZoom);}
		if(debug){console.log(this);}
		if(debug){console.log(id);}
		if(toZoom==true){
			$(this).elevateZoom({
				 zoomType	: "lens",
				 lensShape : "square",
				
				  lensSize  : 300,
				  scrollZoom : true,
				  responsive:true,
				 
			});
			if(debug){console.log(":: Image zoom true");}
			toZoom=false;
		}else{
			
			
			
			$.removeData($(this), 'elevateZoom');//remove zoom instance from image

	        $('.zoomContainer').remove();// remove zoom container from DOM
	        
			/*$("img").last().elevateZoom({
				  zoomType	: "lens",
				  lensShape : "square",
				  lensSize  : 0,
				  scrollZoom : false
			});*/
			
			if(debug){console.log(":: Image zoom false");}
			toZoom=true;
			
		}
		
	});
}	
