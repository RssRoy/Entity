$("#image").change(function () {
        var fileExtension = ['jpeg', 'jpg', 'png', 'bmp'];
        if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
           
            if(debug){console.log("Image Type Doesn't match");}
    		
        	$('#image').attr("data-toggle","tooltip")
        	$('#image').attr("data-placement","auto")
        	$('#image').attr("data-original-title","Only formats are allowed : "+fileExtension.join(', '));
           
        	$('#image').css('color','red');
        	$('#image').tooltip({trigger: 'manual'}).tooltip('show');
            //console.log("False");
           return false;
    		
        }
    });
$("#file").change(function () {
    var fileExtension = ['zip', '7z', 'tar', 'rar','pdf','doc','docx','xls','xlsx','png','jpg','jpeg'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
       
        if(debug){console.log("Image Type Doesn't match");}
		
    	$('#file').attr("data-toggle","tooltip")
    	$('#file').attr("data-placement","auto")
    	$('#file').attr("data-original-title","Only formats are allowed : "+fileExtension.join(', '));
       
    	$('#file').css('color','red');
    	$('#file').tooltip({trigger: 'manual'}).tooltip('show');
        //console.log("False");
       return false;
		
    }
});

function checkFileSize() {
    var input, file;

    // (Can't use `typeof FileReader === "function"` because apparently
    // it comes back as "object" on some browsers. So just see if it's there
    // at all.)
    
    if($('#appName').val()=='none'){
    	$('#file').removeAttr('readonly');
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR: Please select an Application ');
    	
    	return false;
    }
    if($('#question').val().trim()==''){
    	$('#file').removeAttr('readonly');
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR: Please Input Question: ');
    	
    	return false;
    }
    if($('#answer').val().trim()==''){
    	$('#file').removeAttr('readonly');
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR: Please Input Answer: ');
    	
    	return false;
    }
    
    if (!window.FileReader) {
        alert("p", "The file API isn't supported on this browser yet.");
        return;
    }

    input = document.getElementById('file');
    var limit='';
    var item=0;
    for(var i=0;i<input.files.length;i++){
    	file=input.files[i];
    	if(file.size>1048576){
    		limit+=("<h5>File: "+file.name+" size:"+parseInt(file.size/1024)+" KB  Please select files less than 1024 KB </h5>");
    		item++;
    	}
    }
    if(item>0){
    	$('#file').removeAttr('readonly');
    	$('#filelimit').css('color','red');
    	$('#filelimit').html(limit);
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR');
    	
    	return false;
    }
    if(input.files.length==0){
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR : Please select a File:');
    	return false;
    }
    
    var fileExtension = ['zip', '7z', 'tar', 'rar','pdf','doc','docx','xls','xlsx','png','jpg','jpeg'];
    if ($.inArray($('#file').val().split('.').pop().toLowerCase(), fileExtension) == -1) {
       
        if(debug){console.log("Image Type Doesn't match");}
		
    	$('#file').attr("data-toggle","tooltip")
    	$('#file').attr("data-placement","auto")
    	$('#file').attr("data-original-title","Only formats are allowed : "+fileExtension.join(', '));
       
    	$('#file').css('color','red');
    	$('#file').tooltip({trigger: 'manual'}).tooltip('show');
        //console.log("False");
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR : Please check File format:');
       return false;
		
    }
    if(item==0 && input.files.length>0){
    	$('#appName').attr('disabled','disabled');
    	$('#file').attr('disabled','disabled');
    	$('#question').attr('readonly','readonly');
    	$('#answer').attr('readonly','readonly');
    	
    	$('#file').attr('readonly','readonly');
    	$('#appName').attr('readonly','readonly');
    	$('#filelimit').css('color','green');
    	$('#filelimit').html('');
    	$('#filemessage').css('color','green');
    	$('#filemessage').html('Please Click on Upload Button');
    	$('#submit-btn').removeClass('btn-danger');
    	$('#submit-btn').addClass('btn-success');
    	$('#submit-btn').html('Upload');
    	$('#submit-btn').attr('type','submit');
    	$('#submit-btn').attr('onclick','remove_disabled("#file");');
    	return false;
    	
    	
    }
    
    
   
    if(debug){console.log("Hell");};
}
function checkImageSize() {
    var input, file;

    // (Can't use `typeof FileReader === "function"` because apparently
    // it comes back as "object" on some browsers. So just see if it's there
    // at all.)
    if($('#appName').val()=='none' || $('#appName').val()=='' ){
    	$('#image').removeAttr('readonly');
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR: Please select an Application ');
    	
    	return false;
    }
    if($('#question').val().trim()==''){
    	$('#image').removeAttr('readonly');
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR: Please Input Question: ');
    	
    	return false;
    }
    if($('#answer').val().trim()==''){
    	$('#image').removeAttr('readonly');
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR: Please Input Answer: ');
    	
    	return false;
    }
    if (!window.FileReader) {
        alert("p", "The file API isn't supported on this browser yet.");
        return;
    }

    input = document.getElementById('image');
    var limit='';
    var item=0;
    if(input.files!==null){
    for(var i=0;i<input.files.length;i++){
    	file=input.files[i];
    	if(file.size>100*1024){
    		limit+=("<h5>File: "+file.name+" size:"+parseInt(file.size/1024)+"KB  Please select files less than 100KB </h5>");
    		item++;
    	}
    }
    }
    if(item>0){
    	$('#image').removeAttr('readonly');
    	$('#filelimit').css('color','red');
    	$('#filelimit').html(limit);
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR');
    	return false;
    }
    if(input.files.length==0){
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR : Please select a File:');
    }
    
    var fileExtension = ['jpeg', 'jpg', 'png', 'bmp'];
    if ($.inArray($('#image').val().split('.').pop().toLowerCase(), fileExtension) == -1) {
       
        if(debug){console.log("Image Type Doesn't match");}
		
    	$('#image').attr("data-toggle","tooltip")
    	$('#image').attr("data-placement","auto")
    	$('#image').attr("data-original-title","Only formats are allowed : "+fileExtension.join(', '));
       
    	$('#image').css('color','red');
    	$('#image').tooltip({trigger: 'manual'}).tooltip('show');
        //console.log("False");
    	$('#filemessage').css('color','red');
    	$('#filemessage').html('ERROR : Please check File format:');
       return false;
		
    }
    if(item==0 && input.files.length>0){
    	$('#appName').attr('disabled','disabled');
    	$('#question').attr('readonly','readonly');
    	$('#answer').attr('readonly','readonly');
    	
    	$('#image').attr('disabled','disabled');
    	$('#image').attr('readonly','readonly');
    	$('#appName').attr('readonly','readonly');
    	$('#filelimit').css('color','green');
    	$('#filelimit').html('');
    	$('#filemessage').css('color','green');
    	$('#filemessage').html('Please Click on Upload Button');
    	$('#submit-btn').removeClass('btn-danger');
    	$('#submit-btn').addClass('btn-success');
    	$('#submit-btn').html('Upload');
    	$('#submit-btn').attr('type','submit');
    	$('#submit-btn').attr('onclick','remove_disabled("#image");return false;');
    	
    	return true;
    	
    	
    }
    console.log("Hell");
}
function remove_disabled(id){
	if(debug){console.log("remove disabled");}
	$(id).removeAttr('disabled');
	$('#appName').removeAttr('disabled');
	$('#submit-btn').attr('onclick','');
	$('#submit-btn').click();
	return true;
}


