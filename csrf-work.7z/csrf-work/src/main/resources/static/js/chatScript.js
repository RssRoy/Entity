///show console log controller
var debug = false;
/////////////////////////////////////////////////////////////////////////////////////////////////// getting error message
/*$('#alerttext').removeClass('alert-success').addClass('alert-danger');
$('#alerttext').html($.urlParam('msg'));*/
///////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////url passing parameter


var result = null;

function suggest_on_down(data,uQuery){
	
	var suggest = "<h4>Suggestions :</h4>";
	var k=0;
	for(i=1;i<data.length && i<4;i++){
		if(i!=$('#data_id').val()){
			suggest = suggest+"<h5><button class='suggestion btn btn-responsive ' id='"+i+"' style=\""+"font-family:'Calibri','Roboto','sans-serif';size=16;\">"+(k+1)+".&nbsp;"+data[i]._source.question+"</button></h5>";
			log(appName,uQuery,data[i]._source.question,"DOWN","SUGGESTION","THUMBS DOWN");
			if(debug){ console.log(appName,uQuery,data[i]._source.question,"DOWN","SUGGESTION","THUMBS DOWN");}
	
			k=k+1;
		}
	}
	if(k>0){
		sendMessage(suggest,1);
		
	}else{
		var desired_q=$('#comment').val();
		$('#desired_question').html('Desired Question : '+desired_q);
		sendMessage('<form id="desired_question"><div class="form-group"> <label for="comment">Please enter your desired question:</label> <textarea class="form-control" rows="2" id="comment"></textarea> </div><button type="button" id="wantedBtn" onclick ="wantedQ(this);" class="btn btn-default">Submit</button></form>',1);
		
		//set parent question:
    	$('#parentquestion').val(encode($('#comment').val()));
    	
		sendDivFeedBack();// added 29 morning
		log(appName,uQuery,"SORRY_NO_SUGGESTION","DOWN","NULL","THUMBS DOWN"); 
		if(debug){ console.log(appName,uQuery,"SORRY_NO_SUGGESTION","DOWN","NULL","THUMBS DOWN");}

	}
}
	


function suggestion_click(data,id,uQuery){
	//set parent question:
	$('#parentquestion').val(encode(data[id]._source.question));

	flow_data(data,id,uQuery);

	log(appName,uQuery,data[id]._source.question,"NULL","SUGGESTION_CLICK");
	if(debug){ console.log(appName,uQuery,data[id]._source.question,"NULL","SUGGESTION_CLICK");}
}


function on_thumbsup(data,id,uQuery){
	if(debug){ console.log(data);}
	if(debug){ console.log(id);}
	if(debug){ console.log(uQuery);}
	log(appName,uQuery,data[id]._source.question,"UP","NULL","SUCCESS");
	if(debug){ console.log(appName,uQuery,data[id]._source.question,"UP","NULL","SUCCESS");}

	sendMessage("Thank You for your feedback",1);
}


$(document).on('click','button.suggestion',function(){	
	if(debug){console.log("suggestion click");}
	suggestion_click(JSON.parse(decode($('#elastic_data').val())),$(this).attr("id"));
	

});
	
	$(document).on("click",'.gotOhelpDesk .btn-success',function(){
		on_thumbsup(JSON.parse(decode($('#elastic_data').val())),$('#data_id').val(),$('#user_last_query').val());
	});
	$(document).on("click",'.gotOhelpDesk .btn-warning',function(){
		if(debug){console.log("Click on .gotOhelpDesk .btn-warning");}
		
		suggest_on_down(JSON.parse(decode($('#elastic_data').val())),$('#user_last_query').val());
	});





/////////////////////////////////////////////////on CLICK START/////////////////////////////////////////////////////////////////////////////     



$('.send_message').click(function (e) {
	if(debug){ console.log(appName);}
	if(typeof appName === "undefined" || ($('#AppNameSelect option:selected').val())=== "none"){
		var userid=$('#userid').text().trim();
		if(debug){ console.log("text-----userid-------"+userid+"-----AppName---"+appName+"-------selected value---"+($('#AppNameSelect option:selected').val()));}
		sendMessage(getMessageText(),2)
		return sendMessage('Hello <b>'+userid.trim()+'</b>, Please choose an application from the dropdown above to let me assist you:',1);
		
	}
	var uQuery = getMessageText();
	
	/*------ #feedback check ----*/
	var is_feedback=($('#user_feedback').val()=='true');
	if(debug){
		console.log("is_feedback:"+is_feedback);
	}
	if (is_feedback == true) {
		if(debug){
			console.log("is_feedback:uQuery:"+uQuery);
		}
		if (uQuery.length>9 && uQuery.substring(0, 9).toLowerCase() == "#feedback") {
			log(appName, uQuery, uQuery.substring(9), "NULL", "NULL","#FEEDBACK");
			sendMessage(uQuery, 2);
			sendMessage("Thank You For your feedback", 1);
			return;
	}

					}
	$(".results li").remove();
    sendMessage(uQuery,2);
    uQuery=uQuery.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g," ");
    if(uQuery.length === 0)
    	return;
    
    $.ajax({
    	type:"GET",
    	url: "/getvalue",
    	data : {"appName" : appName,
    			"q" : uQuery
    			},
    	success : function(res){
    		if(debug){ console.log(res);}
    		var qa = JSON.parse(res);
    		result=qa.hits.hits;
    		if(debug){ console.log(qa.hits.hits.length);}
    		$('#elastic_data').val(encode(JSON.stringify(qa.hits.hits)));
    		$('#user_last_query').val(encode(uQuery));
    		//set parent question:
			$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));

    		flow_data(qa.hits.hits,0,uQuery);// calling to function in constant.js 
    		
    		
    		},
    	error: function(res){
    		if(debug){ console.log(res);}
    		sendMessage("Sorry, I didn't quite understand what you said.Try asking another way.",1);
    		log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","ERROR IN SEND MSG CLICK");
    		if(debug){ console.log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","ERROR IN SEND MSG CLICK");}
			
    	}
    });
    
  if(debug){console.log("out of ajax");}  
});



////////////////////////////////////ON CLICK  END //////////////////////////////////////////////////////////////////////////


////////////////////////////////////ON KEYUP   START //////////////////////////////////////////////////////////////////////////


$('.message_input').keyup(function (e) {
		var uQuery=getMessageText().trim();
		var words=getMessageText().split(' ');
		//alert("words "+words);
		if(getMessageText().trim().length==0)
			return;
		var tmp=words[words.length-1];
		if(tmp.trim().length==0){
			tmp=words[words.length-2];
		}
		if(tmp.length==0)
			return;


		/*------ #feedback check ----*/
		var is_feedback=($('#user_feedback').val()=='true');
		if(is_feedback==true){
			if(debug){
				console.log("is_feedback:uQuery"+uQuery);
			}
			if( e.which === 13 && uQuery.length>9 && uQuery.substring(0,9).toLowerCase()=="#feedback"){
				if(debug){
					console.log("ENTER HIT 1");
				}
				log(appName,uQuery,uQuery.substring(9),"NULL","NULL","#FEEDBACK");	
				sendMessage(uQuery,2);
				sendMessage("Thank You For your feedback",1);
				$(".upper_results li").remove();
				
				return;
			}
		}

if(debug){ console.log("temp->>>>>>>>>>>>>>"+tmp.length+">>>>>>>>>>>>"+tmp);}
//suggested words ajax start
			$.ajax({
					type:"POST",
					url: "/suggestWords",
					data : {"appName" : appName,
					"word" : tmp 
					},
				success : function(res){
					
					//if(debug){ console.log("suggest Words:"+Object.values(res));}
					
					var sg = JSON.parse(res);
					str=getMessageText().replace(tmp,'');
					var cont="";
					var i=0;
					sg.forEach(function(entry) {
						cont+="<li  class='list-inline-item' id='suggest_"+i+"' style='cursor: pointer; cursor: hand;'>"+str+entry.text+"</li>"
						i+=1;
					});
	
					$('.upper_results').html(cont);
				},error:function(res){
					if(debug){ console.log(Object.values(res));}
					if(debug){ console.log("fail");}
				}
			});
//suggest word ajax end

	       	
//////////////////////////////////ON KEY UP -->//ON HIT ENTER KEY //////////////////////////////////////////////////////////////////////////



		if (e.which === 13) {
			if(debug){
			console.log("ENTER HIT");
			}
		if(typeof appName === "undefined" || ($('#AppNameSelect option:selected').val())=== "none" || appName==null){
			var userid=$('#userid').text().trim();
			if(debug){ console.log("text-----userid-------"+userid+"-----AppName---"+appName+"-------selected value---"+($('#AppNameSelect option:selected').val()));}
			sendMessage(getMessageText())
			sendMessage('Hello <b>'+userid.trim()+'</b>, Please choose an application from the dropdown above to let me assist you:');
			return;
		}


		var uQuery = getMessageText().trim();
		
		/*------ #feedback check ----*/
		var is_feedback=($('#user_feedback').val()=='true');
		if(debug){
			console.log("is_feedback:"+is_feedback);
		}
		if(is_feedback==true){
			if(debug){
				console.log("is_feedback:uQuery"+uQuery);
			}
			if(uQuery.length>9 && uQuery.substring(0,9).toLowerCase()=="#feedback"){
				if(debug){console.log("TESTING #FEEDBACK");}
				log(appName,uQuery,uQuery.substring(9),"NULL","NULL","#FEEDBACK");	
						sendMessage(uQuery,2);
						sendMessage("Thank You For your feedback",1);
				return;
			}
		}
		sendMessage(uQuery,2);
		uQuery=uQuery.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g," ");

		if(uQuery.length === 0)
			return;

			$.ajax({
				type:"GET",
				url: "/getvalue",
				data : {"appName" : appName,
						"q" : uQuery
						},
				success : function(res){
					if(debug){ console.log(res);}
					
					var qa = JSON.parse(res);
					$('#elastic_data').val(encode(JSON.stringify(qa.hits.hits)));
					if(debug){ console.log(qa.hits.hits);}
					result = qa.hits.hits;
					if(debug){ console.log(result);}
					//log(appName,uQuery,"QA","NULL","NULL",result[0]._source.question);
					
					if(debug){ console.log(result);}
					//log(appName,uQuery,"QA","NULL","NULL",result[0]._source.question);
	    			//set parent question:
					if(debug){console.log("got it : "+qa.hits.hits[0]+"\n made it : "+result[0]);}
					
					if(result.length < 1){
						if(debug){ console.log(res);}
						sendMessage("Sorry, I didn't quite understand what you said.Try asking another way.",1);
						log(appName,uQuery,"SORRY_NO_SUGGESTION","NULL","NULL","NOT ENOUGH DATA");
						if(debug){ console.log(appName,uQuery,"SORRY_NO_SUGGESTION","NULL","NULL","NOT ENOUGH DATA");}
					}
					else{
						$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
		    			
						flow_data(qa.hits.hits,0,uQuery);
					}
	    			
					$(".results li").remove();
					$(".upper_results li").remove();
					
				},
				error: function(res){
					if(debug){ console.log(res);}
					sendMessage("Sorry, I didn't quite understand what you said.Try asking another way.",1);
					log(appName,uQuery,"SORRY_NO_SUGGESTION","NULL","NULL","NOT ENOUGH DATA");
					if(debug){ console.log(appName,uQuery,"SORRY_NO_SUGGESTION","NULL","NULL","NOT ENOUGH DATA");}
					
				}
			});
			$(".upper_results li").remove();
			$(".results li").remove();

		}else if(typeof appName != "undefined"){

				if( ($('#AppNameSelect option:selected').val())=== "none" || appName==null){
					var userid=$('#userid').text().trim();
					if(debug){ console.log("text-----userid-------"+userid+"-----AppName---"+appName+"-------selected value---"+($('#AppNameSelect option:selected').val()));}
					return;
				}


				var value = $(this).val();
				/*------ #feedback check ----*/
				var is_feedback=($('#user_feedback').val()=='true');
				if(debug){
					console.log("is_feedback:"+is_feedback+" Value:"+value);
				}
				if(is_feedback==true){
					if(debug){
						console.log("is_feedback:uQuery"+uQuery);
					}
					if(value.length>9 && value.substring(0,9).toLowerCase()=="#feedback"){
					/*log(appName,value,value.substring(9),"NULL","NULL","#FEEDBACK");	
							sendMessage(value,2);
							sendMessage("Thank You For your feedback",1);*/
					return;
					}
				}
				value=value.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g," ");
				
				if(debug){ console.log(value);}
					$.ajax({
					type : "GET",
					url : "/searchQuery",
					data : {"appName" : appName,
						"q" : value
					},
					success : function(res) {
						
						
					
						if(debug){ console.log("res=:"+res);}
						var qa = JSON.parse(res);
						$('#elastic_data').val(encode(JSON.stringify(qa.hits.hits)));
						$('#user_last_query').val(value);
						if(debug){ console.log("qa:"+qa.hits.hits.length);}
						if(debug){ console.log(qa.hits.hits);}
						$(".results li").remove();
						 $(".upper_results li").remove();
						result = null;
						result = qa.hits.hits;
						var i=0;
						qa.hits.hits.forEach(function(entry) {
							$(".results").show();
							if(debug){ console.log("source:"+entry._source.question);}
							
							$(".results").append(
									"<li class='show' id='"+i+"' style='cursor: pointer; cursor: hand;'><h5>" + entry._source.question
											+ "</h5></li>");
						
							i=i+1;
							
						});
					},
					error : function(res) {
						if(debug){ console.log("fail");}
						log(appName,value,"SORRY_NO_SUGGESTION","NULL","NULL","NOT ENOUGH DATA");	
						if(debug){ console.log(appName,value,"SORRY_NO_SUGGESTION","NULL","NULL","NOT ENOUGH DATA");}	
						
						//sendMessage("Not enough data");
					}
					});
				}
});
	

////////////////////////////////ON CLICK ON RESULTS SUGGESTION LIST/////////////////////////////////////////////////////////////////////////
$(".results").on('click', 'li', function(){
	
	if(debug){console.log(this.id);}
	$('.upper_results').html('');
	var uQuery=$(".message_input").val();
	var data=JSON.parse(decode($('#elastic_data').val()));
	if(debug){console.log(data);}
	//set parent question:
	$('#parentquestion').val(encode(data[$(this).attr("id")]._source.question));
	if(debug){
		console.log(data[$(this).attr("id")]);
	}
	sendMessage(data[$(this).attr("id")]._source.question);
	flow_data(data,$(this).attr("id"),uQuery);//send data to flow
	 $(".results li").remove();
	 $(".upper_results li").remove();
   	
});
