
function fillTnsModal(id) {
	if(debug){ console.log(id);}
	if(debug){ console.log(id.id);}
	if(debug){ console.log($('#' + id.id).attr("value"));}
	if ($('#' + id.id).attr("value") === 'new') {
		$('#myappid').val('');
		$('#myappname').val('');
		$('#myappname').removeAttr('disabled');
		$('#mytnsusername').val('');
		$('#mytnsdatabasename').val('');
		$('#mytnsservicename').val('');
		$('#mytnsserverport').val('');
		$('#mytnsserverhost').val('');
		
		
		$('#mytnsModal').modal('toggle');
	} else {
		//alert($('#' + id.id).attr("value"));
		$.ajax({
			type : "POST",
			url : "/getJsonTns",
			data : {
				"app_id" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				//alert(res);
				res = JSON.parse(res);
				//alert(res);
				if(debug){
					console.log(res);
				}
			    
				$('#myappid').val(res.app_id);
				console.log("app id tns-modal.js -----------"+$('#myappid').val());
				console.log(res.app_name);
				
				$('#myappname option[value="'+decodeHtml(res.app_name.trim().toLowerCase())+'"]').attr("selected", "selected");
				console.log(decodeHtml(res.app_name.trim().toLowerCase()));
				//console.log("app name ----"+$('#myappname').val());
				if(encodeHtml(res.app_name).trim().toLowerCase()=='i-core india'){
					$('#myappname option[value="finacle"]').attr("selected", "selected");
				}
				
				$('#myappid').attr("disabled","disabled");
				$('#myappname').attr("disabled","disabled");
				
				//$('#mysrpath').val(res.app_sr_link);
				$('#mytnsserverhost').val(res.server_host);
				$('#mytnsserverport').val(res.server_port);
				$('#mytnsservicename').val(res.service_name);
				$('#mytnsdatabasename').val(res.database_name);
				$('#mytnsusername').val(res.server_user_name);
				$('#mytnspassword').val(res.server_password);
				//alert(res.server_password);
				
				if(debug){ console.log(res);}
				if(debug){ console.log($('#userid').val());}

				$('#mytnsModal').modal('toggle');
					
				if(debug){ console.log("logging done");}
			},
			error : function(res) {
				if(debug){ console.log("error logging---------");}
				//alert(res);
				if(debug){ console.log(res);}
			}

		});
	}

}

function createtnsModal(id){

	$.ajax({
		type : "POST",
		url : "/insertTnsEntry",
		data : {
			"app_id" : $('#myappid ').val(),
			"app_name" : $('#myappname option:selected').html(),
			"server_host":$('#mytnsserverhost').val(),
			"server_port":$('#mytnsserverport').val(),
			"service_name":$('#mytnsservicename').val(),
			"database_name":$('#mytnsdatabasename').val(),
			"server_user_name":$('#mytnsusername').val(),
			"server_password":$('#mytnspassword').val(),
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res==='-1'){
				if(debug){ console.log("error inserting");}
				$('#createTns').attr('onclick','filltnsModal(this);');
				$('#createTns').html('Create');
				
			}else if(res==2){
				if(debug){ console.log("SUCCESS UPDATING TNS");}
				$('#createTns').attr('onclick','commit();');
				$('#createTns').html('Confirm');
				$('#cancelTns').attr('disabled','disabled');
			}else{
				
				
				
				
				if(debug){ console.log("SUCCESS INSERTING");}
				$('#createTns').attr('onclick','commit();');
				$('#createTns').html('Confirm');
				$('#cancelTns').attr('disabled','disabled');
				
			}
			
			

		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}






////////////////////////////////////////////////COMMIT Function for SQL/////////////////////////////////////////////////////


function commit(){
	if(debug){ console.log("commit");}

	$.ajax({
		type : "POST",
		url : "/commit",
		data : {
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res==='-1'){
				if(debug){ console.log("error commiting");}
			}else{
				
				if(debug){ console.log("SUCCESS COMMIT");}
				
			}
			$('#createUser').attr('onclick','createUserModal(this);');
			$('#createUser').html('Create');
			$('#myUserModal').modal('toggle');
			$('#createRole').attr('onclick','createRoleModal(this);');
			$('#createRole').html('Create');
			$('#myRoleModal').modal('toggle');
			$('#createGrant').attr('onclick','createGrantModal(this);');
			$('#createGrant').html('Create');
			$('#myGrantModal').modal('toggle');
			$('#createApp').attr('onclick','createAppModal(this);');
			$('#createApp').html('Create');
			$('#myAppModal').modal('toggle');
			$('#createAppProp').html('Create');
			$('#myAppPropModal').modal('toggle');
			
			location.reload();
		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}

////////////////////////////////////////////////COMMIT Function for SQL/////////////////////////////////////////////////////



function rollback(){
	if(debug){ console.log("rollback");}

	$.ajax({
		type : "POST",
		url : "/rollback",
		data : {
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res==='-1'){
				if(debug){ console.log("error rollback");}
			}else{
				
				if(debug){ console.log("SUCCESS ROLLBACK");}
				
			}
			location.reload();
		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}


