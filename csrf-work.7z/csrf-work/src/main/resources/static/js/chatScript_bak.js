///show console log controller
var debug = false;
////

function encode(s){
	s=s.toString();
	s=s.replace(/"/g,'#&dblq');
	s=s.replace(/'/g,'#&snglq');
	return s;
}
function decode(s){
	s=s.toString();
	s=s.replace(/#&dblq/g,'"');
	s=s.replace(/#&snglq/g,'\'');
	return String(s);
}


/////////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////

if (typeof Array.prototype.forEach != 'function') {
    Array.prototype.forEach = function(callback){
      for (var i = 0; i < this.length; i++){
        callback.apply(this, [this[i], i, this]);
      }
    };
}


/////////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////

////////////////////////////////////////////get selected app name from url////////////////////////////////////////////////////////////////////

$.urlParam = function(name) {
                   var results = new RegExp('[\?&]' + name + '=([^&#]*)')
                           .exec(window.location.href);
                   if (results == null) {
                       return null;
                   } else {
                       return decodeURI(results[1]) || 0;
                   }
               }

/////////////////////////////////////////////////////////////////////////////////////////////////// getting error message


$('#alerttext').removeClass('alert-success').addClass('alert-danger');
$('#alerttext').html($.urlParam('msg'));
///////////////////////////////////////////////////////////////////////////////////////////////
function raiseSR(id){
		if(debug){ if(debug){ console.log(id.value);}}
		sendMessage("No",2);
		var que=decode(id.value);
		var old_que=que;
		que=que.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g," ");
		que="'"+que+"'";
		sendMessage('<h4>Thanks for your feedback </br><a class="btn-link" onclick="openLink('+que+');">Raise a Service Request </a></h4>',1);
		log($('#AppNameSelect').val(),"FEEDBACK",que+':'+old_que,"DOWN","NULL","SERVICE REQUEST LINK GIVEN");
		if(debug){ console.log($('#AppNameSelect').val()+"FEEDBACK"+que+':'+old_que+"UP"+"NULL"+"SERVICE REQUEST LINK GIVEN");}
	};
function thankyou(id){
	if(debug){ console.log(id);}
	if(debug){ console.log(id.value);}	
	sendMessage("Yes",2);
	var que=decode(id.value);
	var old_que=que;
	que=que.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g," ");
	que="'"+que+"'";
		sendMessage('<h4>Thank You,Have a Nice Day. </h4>',1);
		log($('#AppNameSelect').val(),"FEEDBACK",que+":"+old_que,"UP","NULL","RESOLVED ISSUE");
		
		if(debug){ console.log($('#AppNameSelect').val(),"FEEDBACK",que+':'+old_que,"UP","NULL","RESOLVED ISSUE");}
	};
	var divfeedback='<div><h4>Does it resolve your issue?</h4><button class="btn btn-link btn-success yesbtn" onclick="thankyou(this);" value="'+$('#parentquestion').val()+'" style="padding-right: 5px;padding-left: 5px;"><span class="" style="color:chartreuse">Yes</span></button><button class="btn btn-link btn-warning nobtn" value="'+$('#parentquestion').val()+'"  onclick="raiseSR(this);" nstyle="padding-right: 5px;padding-left: 5px;"><span class=" " style="color:darkorange;">No</span></button></div>';

	function sendDivFeedBack(){
		 divfeedback='<div><h4>Does it resolve your issue?</h4><button class="btn btn-link btn-success yesbtn" onclick="thankyou(this);" value="'+$('#parentquestion').val()+'" style="padding-right: 5px;padding-left: 5px;"><span class="" style="color:chartreuse">Yes</span></button><button class="btn btn-link btn-warning nobtn" value="'+$('#parentquestion').val()+'"  onclick="raiseSR(this);" nstyle="padding-right: 5px;padding-left: 5px;"><span class=" " style="color:darkorange;">No</span></button></div>';
		 if(debug){ console.log($('#parentquestion').val());}
		 $('.yesbtn').last().attr('disabled','disabled');
		$('.nobtn').last().attr('disabled','disabled');
		if(debug){ console.log("Does this resolve your query"+divfeedback);}
		sendMessage(divfeedback,1);
		
	}



var newLinkBtn='<div class="gotOhelpDesk" style="font-size:small; "><a class="" style="text-decoration: none;"><span>find this helpful?</span></a><button class="btn btn-link btn-success" style="padding-right: 5px;padding-left: 5px;"><span class="glyphicon glyphicon-thumbs-up" style="color:chartreuse"></span></button><button class="btn btn-link btn-warning" style="padding-right: 5px;padding-left: 5px;"><span class="glyphicon glyphicon-thumbs-down " style="color:darkorange;"></span></button></div>';
var linkbtn="<button class='btn btn-sm col-sm-5 btn-link' style='color:blue,background-color:transparent;' onclick='openLink();'><span>Raise a Service Request</span></button>";

////////////////////////////////////////////old yesno//////////////////////////////////////////////////////////////////////////////////////////////
var oldyesno="<div class='col-lg-12 pull-right' style='font-size:small; '>"+linkbtn+"<a class='col-sm-5 ' style='text-decoration: none;'><span>find this helpful?</span></a><button class='col-sm-1 btn btn-link btn-success' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-up' style='color:chartreuse'></span></button><button class='col-sm-1 btn btn-link btn-warning' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-down ' style='color:darkorange;'></span></button></div>";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var yesno='<div class="gotOhelpDesk" style="font-size:small; "><button class="btn btn-sm btn-link" style="color:blue,background-color:transparent;" onclick="openLink();"><span>Raise a Service Request</span></button><a class="" style="text-decoration: none;"><span>find this helpful?</span></a><button class="btn btn-link btn-success" style="padding-right: 5px;padding-left: 5px;"><span class="glyphicon glyphicon-thumbs-up" style="color:chartreuse"></span></button><button class="btn btn-link btn-warning" style="padding-right: 5px;padding-left: 5px;"><span class="glyphicon glyphicon-thumbs-down" style="color:darkorange;"></span></button></div>';


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var content = $(".mergingText").next().find(".text").html();
$(content).insertAfter(".mergingText .text");
$(".mergingText").next().remove();
$("li").removeClass("mergingText");

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var result = null;

function wantedQ(id){
	if(debug){ console.log(id);}
	let msg=$('#comment').val();
	if(debug){ console.log(msg);}
	log($("#AppNameSelect").val(),msg,"USER WANT THIS TO BE IN THE SYSTEM","NULL",msg,"WANTED QUESTION SUBMITTED BY USER");
	Userlog($("#AppNameSelect").val(),msg,"USER WANT THIS TO BE IN THE SYSTEM","NULL",msg,"WANTED QUESTION SUBMITTED BY USER");	
	$('#wantedBtn').remove();
	
	sendMessage('This is my desired question : <br/>'+msg,2);

	sendDivFeedBack();
	$('#comment').remove();
}





(function () {
    var Message;
    Message = function (arg) {
        this.text = arg.text, this.message_side = arg.message_side;
        this.draw = function (_this) {
            return function () {
                var $message;
                $message = $($('.message_template').clone().html());
                $message.addClass(_this.message_side).find('.text').html(_this.text);
                $('.messages').append($message);
                return setTimeout(function () {
                    return $message.addClass('appeared');
                }, 0);
            };
        }(this);
        return this;
    };
    
    $(function () {
        var getMessageText, message_side, sendMessage, appName;
        message_side = 'right';
                getMessageText = function () {
            var $message_input;
            $message_input = $('.message_input');
            return $message_input.val();
        };
        
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////url passing parameter
        
        appName = $.urlParam('appName');
        
        if(appName!==null && appName.toString().length>0){
        	$('#AppNameSelect option:contains("' + appName.toString().trim().toUpperCase() + '")').prop('selected', true);
        	appName=$('#AppNameSelect').val().toString().toLowerCase();
        	if(debug){ console.log("App Name: "+appName);}
        }
        
        //////////////////////////////////////////////////////////////////////////////////
        
        sendMessage = function (text,side) {
        	
        	//For Internet Explorer
        	 var side = side ||  0;
        	///////////////////////
        	
            var $messages, message;
            if (text.trim() === '') {
                return;
            }
            $('.message_input').val('');
            $messages = $('.messages');
            if(side=== 0){
            	message_side = message_side === 'left' ? 'right' : 'left';
            }else if(side===1){
            	message_side='left';
            }else if(side===2){
            	message_side='right';
            }
            
            message = new Message({
                text: text,
                message_side: message_side
            });
            message.draw();
            return $messages.animate({ scrollTop: $messages.prop('scrollTop')+100 }, 300);
        };
        

        
        
 /////////////////////////////////////////////////on CLICK START/////////////////////////////////////////////////////////////////////////////     
        	
        
               
        $('.send_message').click(function (e) {
        	if(debug){ console.log(appName);}
        	if(typeof appName === "undefined" || ($('#AppNameSelect option:selected').val())=== "none"){
        		/*sendMessage(getMessageText())
        		return sendMessage('Please choose an application from the drop down above ',1);*/
        		var userid=$('#userid').text().trim();
        		if(debug){ console.log("text-----userid-------"+userid+"-----AppName---"+appName+"-------selected value---"+($('#AppNameSelect option:selected').val()));}
        		sendMessage(getMessageText(),2)
        		return sendMessage('Hello <b>'+userid.trim()+'</b>, Please choose an application from the dropdown above to let me assist you:',1);
        		
        	}
        	var q = getMessageText();
        	$(".results li").remove();
            sendMessage(q,2);
            q=q.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g," ");
            if(q.length === 0)
            	return;
            $.ajax({
            	type:"GET",
            	url: "/getvalue",
            	data : {"appName" : appName,
            			"q" : q 
            			},
            	success : function(res){
            		if(debug){ console.log(res);}
            		var qa = JSON.parse(res);
            		result=qa.hits.hits;
            		if(debug){ console.log(qa.hits.hits.length);}
            		
            		var yesno='<div class="gotOhelpDesk" style="font-size:small; ">'+
            			'<button class="btn btn-sm btn-link" style="color:blue,background-color:transparent;" onclick="openLink();">'+
            			'<span>Raise a Service Request</span></button>'+
            			'<a class="" style="text-decoration: none;"><span>find this helpful?</span></a>'+
            			'<button class="btn btn-link btn-success" style="padding-right: 5px;padding-left: 5px;">'+
            			'<span class="glyphicon glyphicon-thumbs-up" style="color:chartreuse"></span></button>'+
            			'<button class="btn btn-link btn-warning" style="padding-right: 5px;padding-left: 5px;">'+
            			'<span class="glyphicon glyphicon-thumbs-down " style="color:darkorange;"></span></button></div>';

            		if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("file") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
                		
            			var jsonfile=qa.hits.hits[0]._source.file;
            			if(debug){ console.log(jsonfile);}
            			var file='';
            			
            			jsonfile.forEach(function(entry){
            				//file+='<p><object width="100%" height="5%" data="'+entry.replace(/\\/g,'/')+'"></object> <a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
            				file+='<p><a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
            			});
            			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+file);
			        	
            			//set parent question:
			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
            			
			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","FILE QA");	
            			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","FILE QA");}
            			

            	
            	
            	}else if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("image") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
                		
            			var jsonimage=qa.hits.hits[0]._source.image;
            			if(debug){ console.log(jsonimage);}
            			var images='';
            			jsonimage.forEach(function(entry){
            				images+='<p><img src="'+entry.replace(/\\/g,'/')+'" /></p>';
            			});
            			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+images);
			        	
            			//set parent question:
			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
            			
			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");	
            			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");}
            			

            	
            	
            	}else if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("image") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
                		
            			var jsonimage=qa.hits.hits[0]._source.image;
            			var images='';
            			
            			jsonimage.forEach(function(entry){
            				images+='<p><img src="'+entry.replace(/\\/g,'/')+'" /></p>';
            				
            			});	
            			
            			//set parent question:
			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
            			
			        	sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+images);
            			log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");	
            			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");}
            			
            	
            	
            	}else if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("conv_ans") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
            			
            			if(debug){ console.log('array found with answer');}
			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");
			        	if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");}
			        	
			        	//set parent question:
			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
			        	
    					sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer);
			        	startConversation(qa.hits.hits[0]._source.conv_ans);
			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");	
            			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");}
            			
            			
            			
            			
            	}else if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer") ){
            				/* start added by dipu */
            				//check if answer is a query
                			
                			log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","QUERY ENTER");	
                			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","QUERY ENTER");}	
                			
                			//set parent question:
    			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
    			        	
            				var ans=qa.hits.hits[0]._source.answer;
            				if(debug){ console.log("1.answer is this->"+qa.hits.hits[0].answer);}
            				var startkey=new String(ans.substring(0,7).toLowerCase().trim());
            				startkey=startkey.toString();
            				var selectvar=new String("select");
            				selectvar=selectvar.toString();
            				if(debug){ console.log(startkey+"------"+selectvar);}
            				

            				//this ans is to check connection working or not
            				//ans="select A.CATEGORY_DET ,ROUND(sum(A.LIMIT_VAL),2) ||' billion.' from RMWB_PERF_EXPOSURE A, CAR_ROLE_USER_MAP B where B.USER_ID = '326970' and A.UCC_ID = B.UCC_ID GROUP BY A.CATEGORY_DET ";
            				
            				if(startkey==selectvar){
            					ans=ans.replace(";","");
            					var isUserId=ans.search("&variable1");
            					if(debug){ console.log(isUserId);}
            					ans=ans.replace(/&variable1/gi,"326970");
            					
            					var isCompany=ans.search("&variable2");
            					var isUccId=ans.search("&variable3");
            					if(isCompany!=-1 && isUccId!=-1){
            						$('#company').remove();
            						$('#sendcompany').remove();
            						$('#ans').remove();
            						$('#sendUccId').remove();
	    							$('#uccid').remove();
	    							var tmp="<div class='row'><a class='companyWrapper'>Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>";
	    							
	    							sendMessage("<div class='row'><a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' onkeyup='getList();' style='color:black;'/><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>"+tmp,1);
	    							log(appName,q,qa.hits.hits[0].question,"NULL","NULL","USER ENTERED  SQL QUERY");
	    							if(debug){ console.log(appName,q,qa.hits.hits[0].question,"NULL","NULL","USER ENTERED  SQL QUERY");}
	                    									
            					}else if(isCompany!=-1){
            						
            						
            						$('#company').remove();
            						$('#sendcompany').remove();
            						$('#ans').remove();
            						
            						sendMessage("<a class='companyWrapper'>Please Enter Company Name: </a><input id='company' name='company' onkeyup='getList();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
            						
                        			
            						
            						
            						
            					}else if(isUccId!=-1){
            						$('#uccid').remove();

            						$('#sendUccId').remove();
            						$('#ans').remove();
            						sendMessage("<a class='col-lg-5' >Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
            						

            					
            					}else{
            					
            					if(debug){ console.log("Final query after all :"+ans);}
            					$.ajax({
            		            	type:"GET",
            		            	url: "/executeQuery",
            		            	data : {"appName" : appName,
            		            			"q" : ans 
            		            			},
            		            	success : function(res){
            		            			sendMessage(res,1);
            		            			$('.companylist').remove();
            		            	},
            		            	error:function(res){
    	    							log(appName,ans,qa.hits.hits[0].question,"NULL","NULL","ERROR SQL QUERY");	
    	    							if(debug){ console.log(appName,ans,qa.hits.hits[0].question,"NULL","NULL","ERROR SQL QUERY");}
            		            		sendMessage("Sorry error in sql query",1);
            		            	}
            		            });//end of ajax
            					
            					}
            				}else{
            				/* end of addd by dipu*/
            					//set parent question:
        			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
        			        	
            					sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+newLinkBtn,1);
            					//sendMessage(divfeedback,1);//new added on 25 morning
            					sendDivFeedBack();
            					//log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","QA");	
                    			//if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","QA");}
            				}//this also
            			if(result.length<4){
            				$('.gotOhelpDesk .btn-warning').click(function(e){
            					
            					var suggest = "<h4>Suggestions :</h4>";
            					var k=0;
            					for(i=0;i<result.length;i++){
            						suggest = suggest+"<h5><button class='suggestion btn btn-responsive ' id='"+i+"' style=\""+"font-family:'Calibri','Roboto','sans-serif';size=16;\">"+i+".&nbsp;"+qa.hits.hits[i]._source.question+"</button></h5>";
            						k=k+1;
            					}
            					if(k>0){
            						sendMessage(suggest,1);
            						
            						log(appName,q,qa.hits.hits[0].question,"DOWN","SUGGESTION","THUMBS DOWN");
            						if(debug){ console.log(appName,q,qa.hits.hits[0].question,"DOWN","SUGGESTION","THUMBS DOWN");}
                        			
            					}else{
            						log(appName,q,"NO_SUGGESTED_QUESTION","DOWN","NULL","THUMBS DOWN");	
                        			if(debug){ console.log(appName,q,"NO_SUGGESTED_QUESTION","DOWN","NULL","THUMBS DOWN");}

                        		
            						sendMessage('<form><div class="form-group"> <label for="comment">Please enter your desired question:</label> <textarea class="form-control" rows="2" id="comment"></textarea> </div><button type="button" id="wantedBtn" onclick ="wantedQ(this);" class="btn btn-default">Submit</button></form>',1);
            						
            						//sendMessage(divfeedback,1);
            						//sendDivFeedBack();
            					}
            					$('.suggestion').click(function(sgst){
            						
            						//set parent question:
            			        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
            			        	
               					 ///if conv  ////
            			        	
            			        	if( result[$(this).attr("id")]._source.hasOwnProperty("answer")  && result[$(this).attr("id")]._source.hasOwnProperty("file") && result[$(this).attr("id")]._source.hasOwnProperty("question") ){
                                		
                            			var jsonfile=result[$(this).attr("id")]._source.file;
                            			if(debug){ console.log(jsonfile);}
                            			var file='';
                            			
                            			jsonfile.forEach(function(entry){
                            				//file+='<p><object width="100%" height="5%" data="'+entry.replace(/\\/g,'/')+'"></object> <a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                            				file+='<p><a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                            			});
                            			sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4>"+result[$(this).attr("id")]._source.answer+file);
                			        	
                			        	log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","FILE QA");	
                            			if(debug){ console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","FILE QA");}
                            			

                            	
                            	
                            	}else if( result[$(this).attr("id")]._source.hasOwnProperty("answer")  && result[$(this).attr("id")]._source.hasOwnProperty("image") && result[$(this).attr("id")]._source.hasOwnProperty("question") ){
                                		
                            			var jsonimage=result[$(this).attr("id")]._source.image;
                            			if(debug){ console.log(jsonimage);}
                            			var images='';
                            			jsonimage.forEach(function(entry){
                            				images+='<p><img src="'+entry.replace(/\\/g,'/')+'" /></p>';
                            			});
                            			sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4>"+result[$(this).attr("id")]._source.answer+images);
                			        	
                			        	log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","IMAGE QA");	
                            			if(debug){ console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","IMAGE QA");}
                            			

                            	
                            	
                            	}else  if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && !result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
                    					 //sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
                    					 //with no link in suggestion clicks
                    					 
                    				//set parent question:
                    		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                    		        	
                    				 
                    				 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);

                    					 //sendMessage(divfeedback,1);//new added on 25 morning
                    					 sendDivFeedBack();
                    					 log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");
                    					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}
                    			 }else if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
                    				 
                    				 
                    				 
                    				//set parent question:
                    		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                    		        	
                    		        	
                    		        	
                    				 sendMessage(result[$(this).attr("id")]._source.question,2);
                    				sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
                    					log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");	
                   					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

                    					startConversation(result[$(this).attr("id")]._source.conv_ans);
                    			 }else{
                    				 sendMessage(result[$(this).attr("id")]._source.question,2);
                    					
                    				log($("#AppNameSelect").val(),"CLICK ON LINK ",result[$(this).attr("id")]._source.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	
                  					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

                    					startConversation(result[$(this).attr("id")]._source.conv_ans);
                    			 }
            			        	
            			        	//sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
               					
            			        	
            			        	
            			        	//sendMessage(divfeedback,1);
               					//sendDivFeedBack();
               					 log(appName,q,result[$(this).attr("id")]._source.question,"NULL","SUGGESTION_CLICK");
               					if(debug){ console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","SUGGESTION_CLICK");}
                    			
            					});
            				});
            			}
            			else{
            			$('.gotOhelpDesk .btn-warning').click(function (e){
                        	//var feedback = prompt("Suggest your ideas to make it better :) ","Your feedback please");
            				 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='1' style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+qa.hits.hits[1]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='2'  style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+qa.hits.hits[2]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+qa.hits.hits[3]._source.question+"</button></h5>",1);
             	        	
            				 $('.suggestion').click(function(sgst){
            					 //sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
            					 //with no link in suggestion clicks
            					//set parent question:
         			        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
         			        	
         			        	//if conv//
         			        	
         			        	if( result[$(this).attr("id")]._source.hasOwnProperty("answer")  && result[$(this).attr("id")]._source.hasOwnProperty("file") && result[$(this).attr("id")]._source.hasOwnProperty("question") ){
                            		
                        			var jsonfile=result[$(this).attr("id")]._source.file;
                        			if(debug){ console.log(jsonfile);}
                        			var file='';
                        			
                        			jsonfile.forEach(function(entry){
                        				//file+='<p><object width="100%" height="5%" data="'+entry.replace(/\\/g,'/')+'"></object> <a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                        				file+='<p><a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                        			});
                        			sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4>"+result[$(this).attr("id")]._source.answer+file);
                        			//set parent question:
             			        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
            			        	log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","FILE QA");	
                        			if(debug){ console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","FILE QA");}
                        			

                        	
                        	
                        	}else if( result[$(this).attr("id")]._source.hasOwnProperty("answer")  && result[$(this).attr("id")]._source.hasOwnProperty("image") && result[$(this).attr("id")]._source.hasOwnProperty("question") ){
                            		
                        			var jsonimage=result[$(this).attr("id")]._source.image;
                        			if(debug){ console.log(jsonimage);}
                        			var images='';
                        			jsonimage.forEach(function(entry){
                        				images+='<p><img src="'+entry.replace(/\\/g,'/')+'" /></p>';
                        			});
                        			sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4>"+result[$(this).attr("id")]._source.answer+images);
                        			//set parent question:
             			        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
            			        	log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","IMAGE QA");	
                        			if(debug){ console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","IMAGE QA");}
                        			

                        	
                        	
                        	}else   if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && !result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
                					 //sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
                					 //with no link in suggestion clicks
                					 
                				//set parent question:
                		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                		        	
                				 
                				 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);

                					 //sendMessage(divfeedback,1);//new added on 25 morning
                					 sendDivFeedBack();
                					 log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");
                					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}
                			 }else if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
                				 
                				 
                				 
                				//set parent question:
                		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                		        	
                		        	
                		        	
                				 sendMessage(result[$(this).attr("id")]._source.question,2);
                				sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
                					log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");	
               					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

                					startConversation(result[$(this).attr("id")]._source.conv_ans);
                			 }else{
                				 sendMessage(result[$(this).attr("id")]._source.question,2);
                					
                				log($("#AppNameSelect").val(),"CLICK ON LINK ",result[$(this).attr("id")]._source.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	
              					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}
              					//set parent question:
          			        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                					startConversation(result[$(this).attr("id")]._source.conv_ans);
                			 }
         			        	
         			        	
         			        	
         			        	
            					 //sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);

            					 // sendMessage(divfeedback,1);
            					 //sendDivFeedBack();
            					// log(appName,q,result[$(this).attr("id")]._source.question,"NULL","SUGGESTION_CLICK");
            					 if(debug){ console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","SUGGESTION_CLICK");}
                     			
            				 });
            			
            			
            				 
                        });
            			}
            			                			
            			$('.gotOhelpDesk .btn-success').click(function(e){
            				log(appName,q,result[$(this).attr("id")]._source.question,"UP","NULL","SUCCESS ");
            				if(debug){ console.log(appName,q,result[$(this).attr("id")]._source.question,"UP","NULL","SUCCESS ");}
                			
            				sendMessage("Thanks for your feedback",1); //commented on morning 25
            				//sendMessage(divfeedback,1);//commented on morning 25
            			});
            		
            		
            		}else  if(qa.hits.hits.length>0 && qa.hits.hits[0]._source.hasOwnProperty("conv_ans")){
            			
            			/*******************/
            			 if(qa.hits.hits[0]._source.hasOwnProperty("conv_ans") && qa.hits.hits[0]._source.hasOwnProperty("question") && qa.hits.hits[0]._source.hasOwnProperty("answer")){
            				//set parent question:
     			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
     			        	
            				 sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+newLinkBtn,1);
            				// sendMessage(divfeedback,1);
            				 sendDivFeedBack();
            			 }
            			 else{
            				//set parent question:
      			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
      			        	
            				 sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>",1);
            			 }
            			 
            			 /*******************/
            			
			        	if(debug){ console.log('array found');}
			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");
			        	if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");}
   	
			        	startConversation(qa.hits.hits[0]._source.conv_ans);
			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");	
            			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");}
			        
				
            		}else{
            			log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL");
            			if(debug){ console.log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL");}
            			
            			sendMessage("Sorry, I didnâ€™t quite understand what you said.Try asking another way.",1);
            		}
            	},
            	error: function(res){
            		if(debug){ console.log(res);}
            		sendMessage("Sorry, I didnâ€™t quite understand what you said.Try asking another way.",1);
            		log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","ERROR IN SEND MSG CLICK");
            		if(debug){ console.log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","ERROR IN SEND MSG CLICK");}
        			
            	}
            });
        });
        
        
////////////////////////////////////ON CLICK  END //////////////////////////////////////////////////////////////////////////
        
////////////////////////////////////ON KEYUP   START //////////////////////////////////////////////////////////////////////////
        
               
        $('.message_input').keyup(function (e) {
        	var words=getMessageText().split(' ');
        	//alert("words "+words);
            if(getMessageText().trim().length==0)
            	return;
        	var tmp=words[words.length-1];
        	if(tmp.trim().length==0){
        		tmp=words[words.length-2];
        	}
        	if(tmp.length==0)
        		return;
        		
        	
           // alert("tmp"+tmp);
            	if(debug){ console.log("temp->>>>>>>>>>>>>>"+tmp.length+">>>>>>>>>>>>"+tmp);}
            	$.ajax({
                	type:"POST",
                	url: "/suggestWords",
                	data : {"appName" : appName,
                			"word" : tmp 
                			},
                	success : function(res){
                		if(debug){ console.log("suggest Words:"+Object.values(res));}
                		//alert("result--->"+Object.values(res));
                		var sg = JSON.parse(res);
                		str=getMessageText().replace(tmp,'');
            			var cont="";
            			var i=0;
                		sg.forEach(function(entry) {
                			cont+="<li  class='list-inline-item' id='suggest_"+i+"' style='cursor: pointer; cursor: hand;'>"+str+entry.text+"</li>"
                			i+=1;
                		});

            			$('.upper_results').html(cont);
                	},error:function(res){
                		//alert("result---->"+Object.values(res));
                		if(debug){ console.log(Object.values(res));}
                		if(debug){ console.log("fail");}
                	}
            	});
                	
            	
            
        	
        	
        	
        	
        	
        	
        	
        	
        	
////////////////////////////////// ON KEY UP -->//ON HIT ENTER KEY //////////////////////////////////////////////////////////////////////////
                
            	  
        	
            if (e.which === 13) {
            	if(typeof appName === "undefined" || ($('#AppNameSelect option:selected').val())=== "none" || appName==null){
            		var userid=$('#userid').text().trim();
            		if(debug){ console.log("text-----userid-------"+userid+"-----AppName---"+appName+"-------selected value---"+($('#AppNameSelect option:selected').val()));}
            		sendMessage(getMessageText())
            		sendMessage('Hello <b>'+userid.trim()+'</b>, Please choose an application from the dropdown above to let me assist you:');
            		return;
            	}
            	
            	var q = getMessageText();
            	q=q.trim();
                sendMessage(q,2);
                q=q.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g," ");
                
                
                
                
                
                
                if(q.length === 0)
                	return;
                
                
                
                $.ajax({
                	type:"GET",
                	url: "/getvalue",
                	data : {"appName" : appName,
                			"q" : q 
                			},
                	success : function(res){
                		if(debug){ console.log(res);}
                		var qa = JSON.parse(res);
                		//if(debug){ console.log(qa.hits.hits[0].length);}
                		if(debug){ console.log(qa.hits.hits);}
                		result = qa.hits.hits;
                		if(debug){console.log("Result----------------");}
                		if(debug){ console.log(result);}
                		$(".results li").remove();
                		$(".upper_results li").remove();
                		//if(debug){ console.log(typeof(qa.hits.hits[0]._source.question));}
                		//var yesno="<div class='col-lg-12 pull-right' style='font-size:small; '>"+linkbtn+"<a class='col-sm-5 ' style='text-decoration: none;color:white'><span>find this helpful?</span></a><button class='col-sm-1 btn btn-link btn-success' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-up' style='color:chartreuse'></span></button><button class='col-sm-1 btn btn-link btn-warning' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-down ' style='color:darkorange;'></span></button></div>";
                		var yesno='<div class="gotOhelpDesk" style="font-size:small; "><button class="btn btn-sm btn-link" style="color:blue,background-color:transparent;" onclick="openLink();"><span>Raise a Service Request</span></button><a class="" style="text-decoration: none;"><span>find this helpful?</span></a><button class="btn btn-link btn-success" style="padding-right: 5px;padding-left: 5px;"><span class="glyphicon glyphicon-thumbs-up" style="color:chartreuse"></span></button><button class="btn btn-link btn-warning" style="padding-right: 5px;padding-left: 5px;"><span class="glyphicon glyphicon-thumbs-down " style="color:darkorange;"></span></button></div>';
                		if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("file") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
                    		
                			var jsonfile=qa.hits.hits[0]._source.file;
                			if(debug){ console.log(jsonfile);}
                			var file='';
                			
                			jsonfile.forEach(function(entry){
                				//file+='<p><object width="100%" height="5%" data="'+entry.replace(/\\/g,'/')+'"></object> <a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                				file+='<p><a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                			});
                			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+file);
    			        	
                			//set parent question:
    			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
                			
    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","FILE QA");	
                			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","FILE QA");}
                			

                	
                	
                	}else if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("image") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
                    		
                			var jsonimage=qa.hits.hits[0]._source.image;
                			if(debug){ console.log(jsonimage);}
                			var images='';
                			jsonimage.forEach(function(entry){
                				images+='<p><img src="'+entry.replace(/\\/g,'/')+'" /></p>';
                			});
                			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+images);
    			        	
                			//set parent question:
    			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
                			
    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");	
                			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");}
                			

                	
                	
                	}else if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("question")  && qa.hits.hits[0]._source.hasOwnProperty("conv_ans") && qa.hits.hits[0]._source.hasOwnProperty("answer") ){
                			
                			if(debug){ console.log('array found with answer');}
    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");
    			        	if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");}
        					sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer);
        					//set parent question:
    			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
                			
        					startConversation(qa.hits.hits[0]._source.conv_ans);
    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");	
                			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");}
                			
                			
                			
                			
                	}else if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer") ){
            				/* start added by dipu */
            				//check if answer is a query
                			
                		//set parent question:
			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
            			
                					
                			/* start added by dipu */
            				//check if answer is a query
            				var ans=qa.hits.hits[0]._source.answer;
            				if(debug){ console.log("2.answer is this->"+qa.hits.hits[0].answer);}
            				var startkey=new String(ans.substring(0,7).toLowerCase().trim());
            				startkey=startkey.toString();
            				var selectvar=new String("select");
            				selectvar=selectvar.toString();
            				if(debug){ console.log(startkey+"------"+selectvar);}
            				
            				
            				//this ans is to check connection working or not
            				//ans="select A.CATEGORY_DET ,ROUND(sum(A.LIMIT_VAL),2) ||' billion.' from RMWB_PERF_EXPOSURE A, CAR_ROLE_USER_MAP B where B.USER_ID = '326970' and A.UCC_ID = B.UCC_ID GROUP BY A.CATEGORY_DET ";
            				
            				
            				if(startkey==selectvar){
            					ans=ans.replace(";","");
            					var isUserId=ans.search("&variable1");
            					if(debug){ console.log(isUserId);}
            					ans=ans.replace(/&variable1/gi,"326970");
            					var isCompany=ans.search("&variable2");
            					var isUccId=ans.search("&variable3");
            					
            					if(isCompany!=-1 && isUccId!=-1){
            						$('#company').remove();
            						$('#sendcompany').remove();
            						$('#ans').remove();
            						$('#sendUccId').remove();
	    							$('#uccid').remove();
	    							var tmp="<div class='row'><a class='companyWrapper'>Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>";
	    							
	    							sendMessage("<div class='row'><a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' onkeyup='getList();' style='color:black;'/><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>"+tmp,1);
	    							            							
	    							log(appName,q,qa.hits.hits[0].question,"NULL","NULL","SEND BUTTON CLICKED");
	    							if(debug){ console.log(appName,q,qa.hits.hits[0].question,"NULL","NULL","SEND BUTTON CLICKED");}

            					}else if(isCompany!=-1){
            						
            						$('#company').remove();
            						$('#sendcompany').remove();
            						$('#ans').remove();
            						$('#uccid').remove();

            						$('#sendUccId').remove();
            						$('#ans').remove();
            						
            						sendMessage("<a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' onkeyup='getList();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
            						
            						
            						
            						
            					}else if(isUccId!=-1){
            						$('#uccid').remove();

            						$('#sendUccId').remove();
            						$('#ans').remove();
            						sendMessage("<a class='col-lg-5' >Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
            						

            					
            					}else{
            					if(debug){ console.log("Final query after all :"+ans);}
            					$.ajax({
            		            	type:"GET",
            		            	url: "/executeQuery",
            		            	data : {"appName" : appName,
            		            			"q" : ans 
            		            			},
            		            	success : function(res){
            		            			sendMessage(res,1);
            		            			//set parent question:
            	     			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
            	     			        	
            		            			//sendMessage(divfeedback,1);//new added on 25 morning
            		            			sendDivFeedBack(); // added 29 morning
            		            			$('.companylist').remove();
            		            	},
            		            	error:function(res){
            		            		//set parent question:
                 			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
                 			        	
            		            		sendMessage("Sorry error in sql query",1);
    	    							log(appName,ans,qa.hits.hits[0].question,"NULL","NULL","ERROR IN SQL");
    	    							if(debug){ console.log(appName,ans,qa.hits.hits[0].question,"NULL","NULL","ERROR IN SQL");}

            		            	}
            		            });//end of ajax
            					}
            				}else{
            				/* end of addd by dipu*/
            			
            					//set parent question:
         			        $('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
         			        	
                			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+newLinkBtn,1);
                			//sendMessage(divfeedback,1);//new added on 25 morning                			
                			sendDivFeedBack();
                			log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","QA");
                			//if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","QA");}
            				}//this also 
            				
            				if(result.length<4){
                				$('.gotOhelpDesk .btn-warning').click(function(e){
                					let  tmp_s="";
                					var suggest = "<h4>Suggestions :</h4>";
                					var k=0;
                					for(i=1;i<result.length;i++){
                						suggest = suggest+"<h5><button class='suggestion btn btn-responsive ' id='"+i+"' style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+qa.hits.hits[i]._source.question+"</button></h5>";
                						log(appName,q,qa.hits.hits[i]._source.question,"NULL","NULL","SUGGESTION");
                						if(debug){ console.log(appName,q,qa.hits.hits[i]._source.question,"NULL","NULL","SUGGESTION");}
                						k=k+1;
                					}
                					if(k>0){
                						sendMessage(suggest,1);
                							
                					}else{
                					log(appName,q,qa.hits.hits[0]._source.question,"DOWN","NULL","SORRY_NO_SUGGESTION THUMBS DOWN");
                					if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"DOWN","NULL","SORRY_NO_SUGGESTION"+" THUMBS DOWN");}
                					//commented on 25 morning
            						//sendMessage('<form><div class="form-group"> <label for="comment">Please enter your desired question:</label> <textarea class="form-control" rows="2" id="comment"></textarea> </div><button type="button" id="wantedBtn" onclick ="wantedQ(this);" class="btn btn-default">Submit</button></form>',1);
            						//sendMessage(divfeedback,1);
                					
                					//set parent question:
             			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
             			        	
                					sendDivFeedBack(); //added 29 morning
                					}
                					$('.suggestion').click(function(sgst){
                   					 
                						
                						
                						
                						 ///if conv  ////
                						if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("file") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
                                    		
                                			var jsonfile=qa.hits.hits[0]._source.file;
                                			if(debug){ console.log(jsonfile);}
                                			var file='';
                                			
                                			jsonfile.forEach(function(entry){
                                				//file+='<p><object width="100%" height="5%" data="'+entry.replace(/\\/g,'/')+'"></object> <a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                                				file+='<p><a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                                			});
                                			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+file);
                    			        	
                    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","FILE QA");	
                                			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","FILE QA");}
                                			

                                	
                                	
                                	}else if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("image") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
                                    		
                                			var jsonimage=qa.hits.hits[0]._source.image;
                                			if(debug){ console.log(jsonimage);}
                                			var images='';
                                			jsonimage.forEach(function(entry){
                                				images+='<p><img src="'+entry.replace(/\\/g,'/')+'" /></p>';
                                			});
                                			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+images);
                    			        	
                    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");	
                                			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");}
                                			

                                	
                                	
                                	}else if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && !result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
                       					 //sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
                       					 //with no link in suggestion clicks
                       					 
                       				//set parent question:
                       		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                       		        	
                       				 
                       				 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);

                       					 //sendMessage(divfeedback,1);//new added on 25 morning
                       					 sendDivFeedBack();
                       					 log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");
                       					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}
                       			 }else if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
                       				 
                       				 
                       				 
                       				//set parent question:
                       		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                       		        	
                       		        	
                       		        	
                       				 sendMessage(result[$(this).attr("id")]._source.question,2);
                       				sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
                       					log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");	
                      					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

                       					startConversation(result[$(this).attr("id")]._source.conv_ans);
                       			 }else{
                       				 sendMessage(result[$(this).attr("id")]._source.question,2);
                       					
                       				log($("#AppNameSelect").val(),"CLICK ON LINK ",result[$(this).attr("id")]._source.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	
                     					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

                       					startConversation(result[$(this).attr("id")]._source.conv_ans);
                       			 }
                						
                						//set parent question:
                 			        	//$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                 			        	
                					//	sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
                   					//sendMessage(divfeedback,1);
                   					// sendDivFeedBack();
                   					// log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION_CLICK");
                   					if(debug){ console.log(appName,q,result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION_CLICK");}
            						
                					});
                				});
                			}
                			else{
                			$('.gotOhelpDesk .btn-warning').click(function (e){
                            	//var feedback = prompt("Suggest your ideas to make it better :) ","Your feedback please");
                				 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='1' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+qa.hits.hits[1]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='2'  style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+qa.hits.hits[2]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+qa.hits.hits[3]._source.question+"</button></h5>",1);
                				 log(appName,q,qa.hits.hits[0]._source.question,"DOWN","NULL","SUGGESTION");
                				 if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"DOWN","NULL","SUGGESTION");}
                			 log(appName,q,qa.hits.hits[1]._source.question,"DOWN","NULL","SUGGESTION");
                			 if(debug){ console.log(appName,q,qa.hits.hits[1]._source.question,"DOWN","NULL","SUGGESTION");}
                				 log(appName,q,qa.hits.hits[2]._source.question,"DOWN","NULL","SUGGESTION");	
         						if(debug){ console.log(appName,q,qa.hits.hits[2]._source.question,"DOWN","NULL","SUGGESTION");}
                				 $('.suggestion').click(function(sgst){
                					// sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
                					 //with no link in suggestion clicks
                					
                					 //set parent question:
              			        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
              			        	
              			        	 ///if conv  ////
              			      	if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("file") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
                            		
                        			var jsonfile=qa.hits.hits[0]._source.file;
                        			if(debug){ console.log(jsonfile);}
                        			var file='';
                        			
                        			jsonfile.forEach(function(entry){
                        				//file+='<p><object width="100%" height="5%" data="'+entry.replace(/\\/g,'/')+'"></object> <a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                        				file+='<p><a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
                        			});
                        			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+file);
            			        	
            			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","FILE QA");	
                        			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","FILE QA");}
                        			

                        	
                        	
                        	}else if( qa.hits.hits.length > 0 && qa.hits.hits[0]._source.hasOwnProperty("answer")  && qa.hits.hits[0]._source.hasOwnProperty("image") && qa.hits.hits[0]._source.hasOwnProperty("question") ){
                            		
                        			var jsonimage=qa.hits.hits[0]._source.image;
                        			if(debug){ console.log(jsonimage);}
                        			var images='';
                        			jsonimage.forEach(function(entry){
                        				images+='<p><img src="'+entry.replace(/\\/g,'/')+'" /></p>';
                        			});
                        			sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+images);
            			        	
            			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");	
                        			if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","IMAGE QA");}
                        			

                        	
                        	
                        	}else if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && !result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
                   					 //sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
                   					 //with no link in suggestion clicks
                   					 
                   				//set parent question:
                   		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                   		        	
                   				 
                   				 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);

                   					 //sendMessage(divfeedback,1);//new added on 25 morning
                   					 sendDivFeedBack();
                   					 log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");
                   					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}
                   			 }else if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
                   				 
                   				 
                   				 
                   				//set parent question:
                   		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
                   		        	
                   		        	
                   		        	
                   				 sendMessage(result[$(this).attr("id")]._source.question,2);
                   				sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
                   					log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");	
                  					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

                   					startConversation(result[$(this).attr("id")]._source.conv_ans);
                   			 }else{
                   				 sendMessage(result[$(this).attr("id")]._source.question,2);
                   					
                   				log($("#AppNameSelect").val(),"CLICK ON LINK ",result[$(this).attr("id")]._source.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	
                 					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

                   					startConversation(result[$(this).attr("id")]._source.conv_ans);
                   			 }
              			        	
             						 
                					 //sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
                					 //sendDivFeedBack();
                					 //sendMessage(divfeedback,1);//new added on 25 morning
                					 
                					// log(appName,q,result[$(this).attr("id")]._source.question,"DOWN","NULL","SUGGESTION_CLICK");
                					 if(debug){ console.log(appName,q,result[$(this).attr("id")]._source.question,"DOWN","NULL","SUGGESTION_CLICK");}
             					
                				 ////////////////////////////////////////////////////////////////////////////////////////////
                					 
                				 });
                			
                			
                				 
                            });
                			}
                			                			
                			$('.gotOhelpDesk .btn-success').click(function(e){
                				sendMessage("Thanks for your feedback",1); //commented on morning 25
                				//sendMessage(divfeedback,1);//commented on morning 25
                				log(appName,q,qa.hits.hits[0]._source.question,"UP","NULL","SUCCESS");
                				if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"UP","NULL","SUCCESS");}
        						
                			});
                			 
                			
                		}else  if(qa.hits.hits.length>0 && qa.hits.hits[0]._source.hasOwnProperty("conv_ans")){
                			
                			/*******************/
                			//set parent question:
    			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
                			
               			 if( qa.hits.hits[0]._source.hasOwnProperty("question") && qa.hits.hits[0]._source.hasOwnProperty("answer")){
               			
     						
               				 sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>"+qa.hits.hits[0]._source.answer+newLinkBtn,1);
               				
               			 }
               			 else{
               				 
               				 sendMessage("<h4>"+qa.hits.hits[0]._source.question+"</h4>",1);
               			 }
               			 
               			 /*******************/
                			
    			        	if(debug){ console.log('array found');}
    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");
    			        	if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_START");}
    			        	//set parent question:
      			        	$('#parentquestion').val(encode(qa.hits.hits[0]._source.question));
      			        	
    			        	startConversation(qa.hits.hits[0]._source.conv_ans);
    			        	log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");
    			        	if(debug){ console.log(appName,q,qa.hits.hits[0]._source.question,"NULL","NULL","CONV_CHAT_END");}
    						
    			        
    				
                		}else{
                			sendMessage("Sorry, I didnâ€™t quite understand what you said.Try asking another way.<br>",1);
                			log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","NOT ENOUGH DATA");
                			if(debug){ console.log(appName,q,"NO_QUESTION_MATCHED","NULL","NULL","NOT ENOUGH DATA");}
    						
                		}
                	},
                	error: function(res){
                		if(debug){ console.log(res);}
                		sendMessage("Sorry, I didnâ€™t quite understand what you said.Try asking another way.",1);
                		log(appName,q,"NO SUGGESTION","NULL","NULL","NOT ENOUGH DATA");
                		if(debug){ console.log(appName,q,"NO SUGGESTION","NULL","NULL","NOT ENOUGH DATA");}
						
                	}
                });
                $(".upper_results li").remove();
                $(".results li").remove();
                //result = null;// not clearing result;
            }else if(typeof appName != "undefined"){
            	
            	if( ($('#AppNameSelect option:selected').val())=== "none" || appName==null){
            		var userid=$('#userid').text().trim();
            		if(debug){ console.log("text-----userid-------"+userid+"-----AppName---"+appName+"-------selected value---"+($('#AppNameSelect option:selected').val()));}
            		return;
            	}
            	
            	var value = $(this).val();
            	
            
                value=value.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g," ");

				if(debug){ console.log(value);}
				$.ajax({
					type : "GET",
					url : "/searchQuery",
					data : {"appName" : appName,
						"q" : value
					},
					success : function(res) {
						if(debug){ console.log("res=:"+res);}
						var qa = JSON.parse(res);
						if(debug){ console.log("qa:"+qa.hits.hits.length);}
						if(debug){ console.log(qa.hits.hits);}
						$(".results li").remove();
						 $(".upper_results li").remove();
						result = null;
						result = qa.hits.hits;
						var i=0;
						qa.hits.hits.forEach(function(entry) {
							$(".results").show();
							if(debug){ console.log("source:"+entry._source.question);}
							//if(entry._source.question){
							$(".results").append(
									"<li class='show' id='"+i+"' style='cursor: pointer; cursor: hand;'><h5>" + entry._source.question
											+ "</h5></li>");
							
						
			//				log(appName,q,entry._source.question,"NULL","NULL","SUGGESTION");	
    						
							
							
							i=i+1;
							//}
						});
					},
					error : function(res) {
						if(debug){ console.log("fail");}
						log(appName,q,"NO SUGGESTION","NULL","NULL","NOT ENOUGH DATA");	
						if(debug){ console.log(appName,q,"NO SUGGESTION","NULL","NULL","NOT ENOUGH DATA");}	
						
						//sendMessage("Not enough data");
					}
				});
            }
        });
        
        
        
        
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /*$('form').submit(function (e){
        	alert("form submit");
        	return sendMessage(getMessageText());
        	e.preventDefault();
        });*/
        
        var userid=$('#userid').text();
        if(debug){ console.log("val----------userid---------"+userid);}
        //sendMessage('Hello <b>'+userid.trim()+'</b>, Please choose an application from the dropdown above to let me assist you:');
        
        //////////////////////////////////////////////////////////////////////////////////appName passing parameter//////////////////////////
        //if(typeof appName === "undefined" || $('#AppNameSelect option:selected').val() === "none"){
        if(typeof appName === "undefined" || ($('#AppNameSelect option:selected').val())=== "none"){
            sendMessage('Hello <b>'+userid.trim()+'</b>, Please choose an application from the dropdown above to let me assist you:',1);
        }else{
            //sendMessage('Hello <b>'+userid.trim()+'</b>,You have selected <b>'+$('#AppNameSelect option:selected').text()+"</b> application. <br/>What can I help you with ?",1);
            //sendMessage( 'Please start typing Keyword of Issue/Subject Area or type problem statement in message box.System will display list of frequently occurring issues which you can choose as per your applicability',1);
        	//sendMessage( '<b>'+$('#AppNameSelect option:selected').text()+':</b> Please start typing Keyword of Issue/Subject Area or type problem statement in message box.System will display list of frequently occurring issues which you can choose as per your applicability',1);
           
        	//sendMessage('<b>'+ $('#AppNameSelect option:selected').text()+':</b>Please enter  your issue details at the bottom of the Chatbot message window.  System will display option of  matching Questions which you need to select as per your requirement.<br/>For e.g<br/>If  your problem statement is <b>"Which option should user use to inquire about FD Interest details at FD account level?"</b>, you can enter the keywords like <b>"Fixed Deposit"</b> or <b>"FD"</b> and the system will prompt entire question related to the typed keyword and select the matching options as per your requirement.',1)
            sendMessage('<b>'+ $('#AppNameSelect option:selected').text()+'</b>:'+$('#welcomemessage').val(),1);

        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        /*setTimeout(function () {
            return sendMessage('Hi Sandy! How are you?');
        }, 1000);
        return setTimeout(function () {
            return sendMessage('I\'m fine, thank you!');
        }, 2000);*/
        $("#AppNameSelect").change(function(e){
        	$(".messages").html('');
        	if(typeof appName === "undefined" || ($('#AppNameSelect option:selected').val())=== "none"){
                sendMessage('Hello <b>'+userid.trim()+'</b>, Please choose an application from the dropdown above to let me assist you:',1);
            }
        	if(this.value === "none")
        		appName = undefined;
        	else{
        	appName = this.value;
        	//sendMessage("You have selected <b>"+appName.toUpperCase()+"</b> application. <br/>What can I help you with ?",1);
        	//sendMessage("You have selected <b>"+$('#AppNameSelect option:selected').text()+"</b> application. <br/>What can I help you with ?",1);
        	//sendMessage('You have selected <b>'+$('#AppNameSelect option:selected').text()+"</b> application. <br/>What can I help you with ?",1);
            //sendMessage( 'Please start typing Keyword of Issue/Subject Area or type problem statement in message box.System will display list of frequently occurring issues which you can choose as per your applicability',1);
        	//sendMessage('<b>'+ $('#AppNameSelect option:selected').text()+':</b> Please start typing Keyword of Issue/Subject Area or problem statement in message box. System will display list of frequently occurring issues which you can choose as per your applicability.',1);

        	
        	//sendMessage('<b>'+ $('#AppNameSelect option:selected').text()+':</b>Please enter  your issue details at the bottom of the Chatbot message window.  System will display option of  matching Questions which you need to select as per your requirement.<br/>For e.g<br/>If  your problem statement is <b>"Which option should user use to inquire about FD Interest details at FD account level?"</b>, you can enter the keywords like <b>"Fixed Deposit"</b> or <b>"FD"</b> and the system will prompt entire question related to the typed keyword and select the matching options as per your requirement.',1)
            sendMessage('<b>'+ $('#AppNameSelect option:selected').text()+'</b>:'+$('#welcomemessage').val(),1);

        	
        	log(appName,"NULL","NULL","NULL","NULL","SELECTED APPLICATION "+appName);	
        	if(debug){ console.log(appName,"NULL","NULL","NULL","NULL","SELECTED APPLICATION "+appName);}	
			
        	}
        });
        
        
        
        $(".upper_results").on('click', 'li', function(){
        	//alert($(this).text());
        	$('.message_input').val($(this).text());
        	$('.upper_results').html('');
        	//log(appName,$(this).text(),"NULL","NULL","NULL","KEYWORD SUGGESTION");	
        	if(debug){ console.log(appName,$(this).text(),"NULL","NULL","NULL","KEYWORD SUGGESTION");}	
			
        	
        });
        
        
        
        
        $(".results").on('click', 'li', function(){
        	//alert("click");
        	$('.upper_results').html('');
        	//$('.upper_results').attr('display','none');
        	
        	//(result[$(this).attr("id")]._source.question);
        	//var yesno="<div class='col-lg-12' style='margin-bottom: -1.3em;' ><p class='col-lg-5' style='margin-right: 4em;'>&nbsp;</p><span><span class='col-lg-5 ' style='color:white;font-size:small;padding-right: 0px;padding-left: 0px;margin-right: -70;' >Is this Helpful?</span><button class='col-sm-1 btn btn-link btn-success'  ><span class='glyphicon glyphicon-thumbs-up' style='color:chartreuse'></span></button><button class='col-sm-1 btn btn-link btn-warning'><span class='glyphicon glyphicon-thumbs-down ' style='color:darkorange;'></span></button></span></div>";
    		var yesno="<div class='col-lg-12 pull-right' style='font-size:small; '>"+"<a class='col-sm-5 ' style='text-decoration: none;'><span>find this helpful?</span></a><button class='col-sm-1 btn btn-link btn-success' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-up' style='color:chartreuse'></span></button><button class='col-sm-1 btn btn-link btn-warning' style='padding-right: 5px;padding-left: 5px;'><span class='glyphicon glyphicon-thumbs-down ' style='color:darkorange;'></span></button></div>";
        	
    		
    		var uQuery=$(".message_input").val();
        	sendMessage(result[$(this).attr("id")]._source.question);
        	//log(appName,"CLICKED ON LINK",result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK");
        	//if(debug){ console.log(appName,"CLICKED ON LINK",result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK");}

    		/* start added by dipu */
			//check if answer is a query
			var ans=result[$(this).attr("id")]._source;
			if(debug){ console.log(ans);}
			 
			//this ans is to check connection working or not
			//ans="select A.CATEGORY_DET ,ROUND(sum(A.LIMIT_VAL),2) ||' billion.' from RMWB_PERF_EXPOSURE A, CAR_ROLE_USER_MAP B where B.USER_ID = '326970' and A.UCC_ID = B.UCC_ID GROUP BY A.CATEGORY_DET ";
			if( result[$(this).attr("id")]._source.hasOwnProperty("answer")  && result[$(this).attr("id")]._source.hasOwnProperty("file") && result[$(this).attr("id")]._source.hasOwnProperty("question") ){
        		
    			var jsonfile=result[$(this).attr("id")]._source.file;
    			if(debug){ console.log(jsonfile);}
    			var file='';
    			
    			jsonfile.forEach(function(entry){
    				//file+='<p><object width="100%" height="5%" data="'+entry.replace(/\\/g,'/')+'"></object> <a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
    				file+='<p><a href="'+entry.replace(/\\/g,'/')+'" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '+entry.replace(/\\/g,'/').substring((entry.replace(/\\/g,'/').lastIndexOf('/')+1))+'</span></a> </p>';
    			});
    			sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4>"+result[$(this).attr("id")]._source.answer+file);
	        	
    			
    			//set parent question:
	        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
    			
	        	
	        	log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","FILE QA");	
    			if(debug){ console.log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","FILE QA");}
    			

    	
    	
    	}else if( result[$(this).attr("id")]._source.hasOwnProperty("answer")  && result[$(this).attr("id")]._source.hasOwnProperty("image") && result[$(this).attr("id")]._source.hasOwnProperty("question") ){
        		
    			var jsonimage=result[$(this).attr("id")]._source.image;
    			if(debug){ console.log(jsonimage);}
    			var images='';
    			jsonimage.forEach(function(entry){
    				images+='<p><img src="'+entry.replace(/\\/g,'/')+'" /></p>';
    			});
    			sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4>"+result[$(this).attr("id")]._source.answer+images);
	        	
    			//set parent question:
	        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
    			
	        	log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","IMAGE QA");	
    			if(debug){ console.log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","IMAGE QA");}
    			

    	
    	
    	}else if( ans.hasOwnProperty("answer")   && ans.hasOwnProperty("question") && ans.hasOwnProperty("conv_ans") ){
						
				//set parent question:
		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
		        	
				 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);

					
     	
		        	//instance of array object;
		        	if(debug){ console.log('array found');}
		        	log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_START");
		        	if(debug){ console.log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_START");}
		        	
		        	startConversation(ans.conv_ans);
		        	if(debug){ console.log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_END");}	

			
			
			
			 }else if(ans.hasOwnProperty('answer')  ){
				ans=result[$(this).attr("id")]._source.answer;
				if(debug){ console.log("3.answer is this->"+result[$(this).attr("id")]._source.answer);}
				var startkey=new String(ans.substring(0,7).toLowerCase().trim());
				startkey=startkey.toString();
				var selectvar=new String("select");
				selectvar=selectvar.toString();
				if(debug){ console.log(startkey+"------"+selectvar);}

				//set parent question:
	        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
	        	
			
			if(selectvar===startkey){
				ans=ans.replace(";","");
				var isUserId=ans.search("&variable1");
				if(debug){ console.log(isUserId);}
				ans=ans.replace(/&variable1/gi,"326970"); ////Emp id Employee ID to be replaced for RMWB
				var isCompany=ans.search("&variable2");
				
				var isUccId=ans.search("&variable3");
	        	log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND IS A  QUERY");
	        	if(debug){ console.log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND IS A  QUERY");}

				if(isCompany!=-1 && isUccId!=-1){
					$('#company').remove();
					$('#sendcompany').remove();
					$('#ans').remove();
					$('#sendUccId').remove();
					$('#uccid').remove();
					
					var tmp="<div class='row'><a class='companyWrapper'>Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>";
					
					sendMessage("<div class='row'><a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' onkeyup='getList();' style='color:black;'/><input type='submit' id='sendcompany' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='hidden' id='ans' name='ans' value=\""+ans+"\" /></div>"+tmp,1);
										
					
				}else if(isCompany!=-1){
					
					$('#company').remove();
					$('#sendcompany').remove();
					$('#ans').remove();
					
					sendMessage("<a class='companyWrapper'>Please Enter Company Name:</a> <input id='company' name='company' class='col-lg-5' onkeyup='getList();' style='color:black;'/><input type='submit' style=' color: black;' id='sendcompany' class='col-lg-1' name='sendcompany' value='ok' onclick='getCompany();' style='color:black;'/><ul class='companylist' style='margin-top:0em;margin-left:9.4em; width:49.3%; overflow-y:scroll; min-height:0px; max-height:100px;'></ul><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
					
					
					
					
				}else if(isUccId!=-1){
					$('#uccid').remove();

					$('#sendUccId').remove();
					$('#ans').remove();
					sendMessage("<a class='col-lg-5' >Please Enter UCC_ID of Company:</a> <input id='uccid' name='uccid' class='col-lg-5' style='color:black;'/><input type='submit' id='sendUccId' name='sendUccId' value='ok'  onclick='getUccId();' class='col-lg-1 ' style='color:black;' /><input type='hidden' id='ans' name='ans' value=\""+ans+"\" />",1);
					

				
				}else{
					if(debug){ console.log("Final query after all :"+ans);}
		        	
					$.ajax({
						type:"GET",
						url: "/executeQuery",
						data : {"appName" : appName,
								"q" : ans 
	            				},
	            		success : function(res){
	            					sendMessage(res,1);
	            					
	            					//sendMessage(divfeedback,1);//new added on 25 morning
	            					sendDivFeedBack();
	            					$('.companylist').remove();
	            		},
	            		error:function(res){
	            			sendMessage("Sorry error in sql query",1);
	        	        	log(appName,ans,result[$(this).attr("id")]._source.question,"NULL","NULL","ERROR IN SQL QUERY");	
	        	        	if(debug){ console.log(appName,ans,result[$(this).attr("id")]._source.question,"NULL","NULL","ERROR IN SQL QUERY");}
	            	}
	            });// end of ajax
				
			}
			
			}else{
				
				//set parent question:
	        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
	        	
				sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
				//sendMessage(divfeedback,1);//new added on 25 morning
				sendDivFeedBack();
				log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK ");	
	        	if(debug){ console.log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK ");}	

			}
			}else if(ans.hasOwnProperty('conv_ans')){
				//case if not sql statement 
				//case if its a direct answer or its a conversational ans//
				
				//set parent question:
	        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
    			
				 if( ans.hasOwnProperty("answer")   && ans.hasOwnProperty("question") && ans.hasOwnProperty("conv_ans") ){
					
			        		
					 sendMessage("<h4>"+ans.question+"</h4>"+ans.answer);

				 }
        	
		        	//instance of array object;
		        	if(debug){ console.log('array found');}
		        	log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_START");
		        	if(debug){ console.log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_START");}

		        	startConversation(ans.conv_ans);
		        	if(debug){ console.log(appName,uQuery,result[$(this).attr("id")]._source.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_END");}	

		        	
		        }
			
			
				
				
				
				
				
				
        	
        	
        	
			//this also
			
			var ths=$(this).attr("id");
        	if(debug){ console.log("result ----------"+result.length);}
        	$(".results").hide();
        	if(result.length<=3){
        		$('.gotOhelpDesk .btn-warning').click(function(){
        			if(debug){ console.log(ths);}
        			if(ths==0 && result.lenght>=2){
        				sendMessage("<h5><button class='suggestion btn btn-responsive ' id='1' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5>",1);
    		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	

        				
        			}else if(ths==1){
        				sendMessage("<h5><button class='suggestion btn btn-responsive ' id='0' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>",1);
    		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	

        			}else if(ths==2){
        				sendMessage("<h5><button class='suggestion btn btn-responsive ' id='1' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='0' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>",1);
        				
    		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	

        			}else{
        				//commented on 25 morning
						sendMessage('<form><div class="form-group"> <label for="comment">Please enter your desired question:</label> <textarea class="form-control" rows="2" id="comment"></textarea> </div><button type="button" id="wantedBtn" onclick ="wantedQ(this);" class="btn btn-default">Submit</button></form>',1);
						//sendMessage(divfeedback,1);
						//set parent question:
			        	$('#parentquestion').val(encode($('#comment').val()));
			        	
						sendDivFeedBack();// added 29 morning
						log(appName,getMessageText(),"NO SUGGESTION","DOWN","NULL","SUGGESTION");
    		        	if(debug){ console.log(appName,getMessageText(),"NO SUGGESTION","DOWN","NULL","SUGGESTION");}
    		        	
        			}
        			
        			$('.suggestion').on('click',function(){
            			// alert("suggestion"+$(this).attr("id")+result[$(this).attr("id")]._source.question);
            			 //sendMessage(result[$(this).attr("id")]._source.question);
    					 
            			 //sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
            			
            			 //with no link in suggestion clicks
        				
        				//set parent question:
        	        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
        	        	
    					 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);

            			 //sendMessage(divfeedback,1);//new added on 25 morning
            			 sendDivFeedBack();
            			 log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");
     		        	if(debug){ console.log(appName,getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

            		 });
        			
        		});
        		
        	}
        	else{
        	 $('.gotOhelpDesk .btn-warning').click(function(){
        		 //sendMessage();
             	if(debug){ console.log(ths);}
        		 if(ths>2){
        		 
        		// sendMessage(result[$("#1").attr("id")]._source.question+"</br>"+result[$("#1").attr("id")]._source.answer+"</br></br>"+result[$("#2").attr("id")]._source.question+"</br>"+result[$("#3").attr("id")]._source.question);
        		 //sendMessage("These are some suggestions which might fulfill your need..");
        		 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='0' style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='1'  style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='2' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+result[$("#2").attr("id")]._source.question+"</button></h5>",1);
		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
		        	log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
		        	if(debug){ console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	
		        	if(debug){ console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	
		        	if(debug){ console.log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}

        		 }
        		 else{
        			 if(debug){ console.log(ths);}
        			 if(debug){ console.log(result.length);}
        			 if(ths==0){
        				 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive ' id='1' style='font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>1.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='2'  style=' font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+result[$("#2").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+result[$("#3").attr("id")]._source.question+"</button></h5>",1);
     		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}
        			 }else if(ths==1){
        				 sendMessage("<h4>Suggestions :</h4><h5><button class='suggestion btn btn-responsive' id='0' style='font-family:'Calibri','Roboto','sans-serif';size=16;'>1.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>"+"<h5><h5><button class='suggestion btn btn-responsive ' id='2'  style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>2.&nbsp;"+result[$("#2").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style='  font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;'>3.&nbsp;"+result[$("#3").attr("id")]._source.question+"</button></h5>",1);
     		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#2").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}
        			 }else if(ths==2){
        				 sendMessage("<h4>Suggestions :</h4>"+"<h5><button class='suggestion btn btn-responsive' id='0' style=\"font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;\">1.&nbsp;"+result[$("#0").attr("id")]._source.question+"</button></h5>"+"<h5><button class='suggestion btn btn-responsive ' id='1'  style=\"font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;\">2.&nbsp;"+result[$("#1").attr("id")]._source.question+"</button></h5><h5><button class='suggestion btn btn-responsive ' id='3' style=\" font-family: 'Calibri', 'Roboto', 'sans-serif';size=16;\">3.&nbsp;"+result[$("#3").attr("id")]._source.question+"</button></h5>",1);
     		        	log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");	
    		        	log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");
    		        	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#0").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#1").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}	
    		        	if(debug){ console.log(appName,getMessageText(),result[$("#3").attr("id")]._source.question,"DOWN","NULL","SUGGESTION");}

        			 }
        			 
        		 }
        		 
        		 $('.suggestion').on('click',function(){
        			//alert("suggestion"+$(this).attr("id")+result[$(this).attr("id")]._source.question);
        			 //sendMessage(result[$(this).attr("id")]._source.question);
					 
        			 /// added as on link click if solution present it is not showing
        		/*	if(debug){ console.log(result[$(this).attr("id")]._source.hasOwnProperty('answer'));}
        			if(debug){ console.log(result[$(this).attr("id")]._source.hasOwnProperty('question'));}
        			if(debug){ console.log(result[$(this).attr("id")]._source.hasOwnProperty('conv_ans'));}
        			*/
        			 if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && !result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
        					 //sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer+newLinkBtn,1);
        					 //with no link in suggestion clicks
        					 
        				//set parent question:
        		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
        		        	
        				 
        				 sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);

        					 //sendMessage(divfeedback,1);//new added on 25 morning
        					 sendDivFeedBack();
        					 log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");
        					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}
        			 }else if(result[$(this).attr("id")]._source.hasOwnProperty('answer') && result[$(this).attr("id")]._source.hasOwnProperty('question') && result[$(this).attr("id")]._source.hasOwnProperty('conv_ans')){
        				 
        				 
        				 
        				//set parent question:
        		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
        		        	
        		        	
        		        	
        				 sendMessage(result[$(this).attr("id")]._source.question,2);
        				sendMessage("<h4>"+result[$(this).attr("id")]._source.question+"</h4></br>"+result[$(this).attr("id")]._source.answer,1);
        					log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");	
       					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

        					startConversation(result[$(this).attr("id")]._source.conv_ans);
        			 }else{
        				 sendMessage(result[$(this).attr("id")]._source.question,2);
        					
        					//set parent question:
        		        	$('#parentquestion').val(encode(result[$(this).attr("id")]._source.question));
        	    			
        				log($("#AppNameSelect").val(),"CLICK ON LINK ",result[$(this).attr("id")]._source.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	
      					 if(debug){ console.log($("#AppNameSelect").val(),getMessageText(),result[$(this).attr("id")]._source.question,"NULL","NULL","SUGGESTION CLICK");}

        					startConversation(result[$(this).attr("id")]._source.conv_ans);
        			 }
        		 });
        		 
        		 $(".results li").remove();
        		 $(".upper_results li").remove();
            	 //result=null;
        		 
        	 });
        	}
        	 $('.gotOhelpDesk .btn-success').click(function(e){
        		sendMessage("Thanks for your feedback",1); //commented on morning 25
 				//sendMessage(divfeedback,1);//commented on morning 25		        	log(appName,getMessageText(),result[ths]._source.question,"UP","NULL","THUMBS UP");
		        	if(debug){ console.log(appName,getMessageText(),result[ths]._source.question,"UP","NULL","THUMBS UP");}

 			});
        	
        });
       
    });
   
    
}.call(this));

