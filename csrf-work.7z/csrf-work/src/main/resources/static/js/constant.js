var debug=false;
function encode(s) {
	s = s.toString();
	s = s.replace(/"/g, '#&dblq');
	s = s.replace(/'/g, '#&snglq');
	return s;
}
function decode(s) {
	s = s.toString();
	s = s.replace(/#&dblq/g, '"');
	s = s.replace(/#&snglq/g, '\'');
	return String(s);
}
// ///////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////

if (typeof Array.prototype.forEach != 'function') {
	Array.prototype.forEach = function(callback) {
		for (var i = 0; i < this.length; i++) {
			callback.apply(this, [ this[i], i, this ]);
		}
	};
}

// ///////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////

function encodeHtml(text) {
	  return text
	      .replace(/&/g, "&amp;")
	      .replace(/</g, "&lt;")
	      .replace(/>/g, "&gt;")
	      .replace(/"/g, "&quot;")
	      .replace(/'/g, "&#039;");
}
function decodeHtml(text) {
	  return text
	      .replace(/&amp;/g, "&")
	      .replace(/&lt;/g, "<")
	      .replace(/&gt;/g, ">")
	      .replace(/&quot;/g, "\"")
	      .replace(/&#039;/g, "\'");
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// //////////////////////////////////////////get selected app name from
// url////////////////////////////////////////////////////////////////////
$.urlParam = function(name) {
	var results = new RegExp('[\?&]' + name + '=([^&#]*)')
			.exec(window.location.href);
	if (results == null) {
		return null;
	} else {
		return decodeURI(results[1]) || 0;
	}
}



// ///////////////////////////////////////////////////////////Message/////////////////////////////////////////////////////////////////////////////
var Message = function(arg) {
	this.text = arg.text, this.message_side = arg.message_side;
	this.draw = function(_this) {
		return function() {
			var $message;
			$message = $($('.message_template').clone().html());
			$message.addClass(_this.message_side).find('.text')
					.html(_this.text);
			$('.messages').append($message);
			return setTimeout(function() {
				return $message.addClass('appeared');
			}, 0);
		};
	}(this);
	return this;
};

// /////////////////////////////////////////////sendMessage////////////////////////////////////////////////////////////////////////////////
function sendMessage(text, side) {

	if((side==1 || side==2 | side==0) && text.indexOf("<h4>Does it resolve your issue?</h4>")==-1){
		$('.messages').prop('scrollTop',$('.messages').prop('scrollHeight')) ;
	}
	// For Internet Explorer
	var side = side || 0;
	// /////////////////////

	var $messages, message;
	if (text.trim() === '') {
		return;
	}
	
	
	text = text.replace(/↵/g, '</br>');
	text = text.replace(/\n/g, '</br>');
	if (debug) {
		console.log("sendMessage:" + text);
	}

	$('.message_input').val('');

	$messages = $('.messages');
	if (side === 0) {
		message_side = message_side === 'left' ? 'right' : 'left';
	} else if (side === 1) {
		message_side = 'left';
	} else if (side === 2) {
		message_side = 'right';
	}

	message = new Message({
		text : text,
		message_side : message_side
	});
	message.draw();
	
	setTimeout(function(){
		var scrollLength=parseInt(parseInt($('.messages').prop('scrollTop'))-80+parseInt($('.messages').prop('clientHeight')));
		if(parseInt($('.messages').prop('scrollTop'))>200){
			$messages.animate({
				scrollTop : parseInt($('.messages').prop('scrollTop'))+350
			}, 300)
		}else{
			$messages.animate({
				scrollTop : scrollLength
			}, 300)
		}
		
	},100);
	
		
		
	/*return $messages.animate({
		scrollTop : (parseInt($('.messages').prop('scrollTop'))+parseInt(220))
	}, 300);*/
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var appName = $.urlParam('appName');
if(debug){console.log(appName);}
if (appName !== null && appName.toString().length > 0) {
	//$('#AppNameSelect option:contains("'+ appName.toString().trim().toUpperCase() + '")').prop('selected', true);
	if($('#AppNameSelect option[value="'+appName.toString().trim().toLowerCase()+'"]').length > 0){
		$('#AppNameSelect').val(appName.toLowerCase());
	}else{
		$('#AppNameSelect option:contains("'+ appName.toString().trim().toUpperCase() + '")').each(function(){
		    if ($(this).text().toLowerCase() == appName.toLowerCase()) {
		        $(this).attr('selected', 'selected');
		        return false;
		    }
		    return true;
		});
	}
	
	appName = $('#AppNameSelect').val().toString().toLowerCase();
	if (debug) {
		console.log("App Name: " + appName);
	}
}
////////////////////////////////////////////////////////////////////////////////Welcome message on load 
if(debug){console.log(appName);}
if(typeof appName === "undefined" || ($('#AppNameSelect option:selected').val())=== "none"){
	$(".messages").html('');
	$(".results").html('');
	var userid=$('#userid').text();
    sendMessage('Hello <b>'+userid.trim()+'</b>, Please choose an application from the dropdown above to let me assist you: ',1);
    if(debug){console.log(appName+"Please 1");}

}else{
	$(".messages").html('');
	$(".results").html('');
	
	
	var welcomeMsg='';
	if(debug){ console.log(value);}
	//alert($('#AppNameSelect option:selected').text().toLowerCase().trim());
	    $.ajax({
	                type : "POST",
	                url : "/getWelcomeMessage",
	                data : {
	                    "app_name" : $('#AppNameSelect option:selected').text().toLowerCase().trim()
	                },
	                success : function(res) {
	                	if(debug){ console.log("res=:" + res);}
	           	 		if(debug){ console.log("res:" + res.length);}
	           	 		if(debug){ console.log(res);}
	           	 		sendMessage('<b>'+ encodeHtml($('#AppNameSelect option:selected').text())+'</b>:'+res.trim(),1);
		                    /*if(res.trim().length>0){
		                		  var welcomeMsg = res.trim();
			   	                  sendMessage('<b>'+ encodeHtml($('#AppNameSelect option:selected').text())+'</b>:'+welcomeMsg,1);
	                		}else{
	                			
	                			 sendMessage('<b>'+ encodeHtml($('#AppNameSelect option:selected').text())+'</b>:'+$('#welcomemessage').val(),1);
	     	                	
	                		}*/
	                	
	                  
	                },
	                error : function(res) {
	                    if(debug){ console.log("fail to get welcome message from table");}
	                    //sendMessage("Not enough data");
	                	 sendMessage('<b>'+ encodeHtml($('#AppNameSelect option:selected').text())+'</b>:'+$('#welcomemessage').val(),1);
	                }

	            });
	
    
}
$("#AppNameSelect").change(function(e){
	$(".messages").html('');
	$(".results").html('');
	var userid=$('#userid').text();
	
	if(typeof appName === "undefined" || ($('#AppNameSelect option:selected').val())=== "none"){
        sendMessage('Hello <b>'+userid.trim()+'</b>, Please choose an application from the dropdown above to let me assist you:',1);
        if(debug){console.log(appName+"Please 2");}
	}
	if(this.value === "none")
		appName = undefined;
	else{
		$(".messages").html('');
		$(".results").html('');
	appName = this.value;
	
	var welcomeMsg='';
	$.ajax({
        type : "POST",
        url : "/getWelcomeMessage",
        data : {
            "app_name" : $('#AppNameSelect option:selected').text().toLowerCase().trim()
        },
        success : function(res) {
        		if(debug){ console.log("res=:" + res);}
       	 		if(debug){ console.log("res:" + res.length);}
       	 		if(debug){ console.log(res);}
       	 		sendMessage('<b>'+ encodeHtml($('#AppNameSelect option:selected').text())+'</b>:'+res.trim(),1);
       	 		/*if(res.trim().length>0){
       	 			var welcomeMsg = res.trim();
  	                sendMessage('<b>'+ encodeHtml($('#AppNameSelect option:selected').text())+'</b>:'+res.trim(),1);
       	 		}else{
	       			sendMessage('<b>'+ encodeHtml($('#AppNameSelect option:selected').text())+'</b>:'+$('#welcomemessage').val(),1);
                	
       	 		}*/
        },
       	
        error : function(res) {
            if(debug){ console.log("fail to get welcome from table");}
            //sendMessage("Not enough data");
        	 sendMessage('<b>'+ encodeHtml($('#AppNameSelect option:selected').text())+'</b>:'+$('#welcomemessage').val(),1);
        }

    });
	
	log(appName,"NULL","NULL","NULL","NULL","SELECTED APPLICATION "+appName);	
	if(debug){ console.log(appName,"NULL","NULL","NULL","NULL","SELECTED APPLICATION "+appName);}	
	}
});

// //////////////////////////////////////getMessageText///////////////////////////////////////////////////////////////////////////////

var getMessageText = function() {
	return $('.message_input').val();
}

function raiseSR(id) {
	$(id).attr('disabled','disabled');
	if (debug) {
		if (debug) {
			console.log(id.value);
		}
	}
	sendMessage("No", 2);
	var que = decode(id.value);
	var old_que = que;
	que = que.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, " ");
	que = "'" + que + "'";
	
	
	$.ajax({
		type : "POST",
		url : "/getReasonsForApp",
		data : {
			"appname" : $('#AppNameSelect').val().toLowerCase(),
			"appid":$('#AppNameSelect :selected').attr('data-id')
		},
		success : function(res) {
			console.log(res);
			res=JSON.parse(res);
			if(res==null || res.length == 0){
				sendMessage(
						'<h4>Thank You for your feedback </br><a class="btn-link" onclick="openLink('
								+ que + ');">Raise a Service  Request </a></h4>', 1);
				log($('#AppNameSelect').val(), "FEEDBACK", que, "DOWN",
						"NULL", "SERVICE REQUEST LINK GIVEN");
			}
			else{
				var selectreason="<div class='col-md-8' id='raisesrdiv'><div class='col-md-6'>";
				selectreason+="<select id='raisesrselect' class='form-control'>";
				res.forEach(function(entry){
					selectreason+="<option value='"+entry.reason_link+"' data-app-id='"+entry.app_id+"' data-reason-id='"+entry.reason_id+"'>"+entry.reason_name+"</option>";
				});
				selectreason+="</select> </div> <div class='col-md-2'><a class='btn btn-warning' data-que='"+que+"' onclick='openReasonLink(this);'>Go</a></div>";
				selectreason+="</div>";
	
				sendMessage('<h4>Select a Service Request Sub Area:</h4> </br>'+selectreason,1);
				log($('#AppNameSelect').val(), "FEEDBACK", que, "DOWN",
						"NULL", "SERVICE REQUEST LINK GIVEN");
				
			}
			/*
			sendMessage(
					'<h4>Thank You for your feedback </br><a class="btn-link" onclick="openLink('
							+ que + ');">Raise a Service  Request </a></h4>', 1);
			log($('#AppNameSelect').val(), "FEEDBACK", que, "DOWN",
					"NULL", "SERVICE REQUEST LINK GIVEN");*/
			if (debug) {
				console.log($('#AppNameSelect').val() + "FEEDBACK" + que + ':'
						+ old_que + "UP" + "NULL" + "SERVICE REQUEST LINK GIVEN");
			}
		},
		error:function(res){
			
		}

	
		});
	
	

	/*sendMessage(
			'<h4>Thank You for your feedback </br><a class="btn-link" onclick="openLink('
					+ que + ');">Raise a Service  Request </a></h4>', 1);
	log($('#AppNameSelect').val(), "FEEDBACK", que, "DOWN",
			"NULL", "SERVICE REQUEST LINK GIVEN");
	if (debug) {
		console.log($('#AppNameSelect').val() + "FEEDBACK" + que + ':'
				+ old_que + "UP" + "NULL" + "SERVICE REQUEST LINK GIVEN");
	}*/
};
function thankyou(id) {
	$(id).attr('disabled','disabled');
	if (debug) {
		console.log(id);
	}
	if (debug) {
		console.log(id.value);
	}
	sendMessage("Yes", 2);
	var que = decode(id.value);
	var old_que = que;
	que = que.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, " ");
	que = "'" + que + "'";
	sendMessage('<h4>Thank You,Have a Nice Day. </h4>', 1);
	log($('#AppNameSelect').val(), "FEEDBACK", que , "UP",
			"NULL", "RESOLVED ISSUE");

	if (debug) {
		console.log($('#AppNameSelect').val(), "FEEDBACK", que + ':' + old_que,
				"UP", "NULL", "RESOLVED ISSUE");
	}
};
var divfeedback = '<div><h4>Does it resolve your issue?</h4><button class="btn btn-link btn-success yesbtn" onclick="thankyou(this);" value="'
		+ $('#parentquestion').val()
		+ '" style="padding-right: 5px;padding-left: 5px;"><span class="" style="color:chartreuse">Yes</span></button><button class="btn btn-link btn-warning nobtn" value="'
		+ $('#parentquestion').val()
		+ '"  onclick="raiseSR(this);" nstyle="padding-right: 5px;padding-left: 5px;"><span class=" " style="color:darkorange;">No</span></button></div>';

function sendDivFeedBack() {
	divfeedback = '<div><h4>Does it resolve your issue?</h4><button class="btn btn-link btn-success yesbtn" onclick="thankyou(this);" value="'
			+ $('#parentquestion').val()
			+ '" style="padding-right: 5px;padding-left: 5px;"><span class="" style="color:chartreuse">Yes</span></button><button class="btn btn-link btn-warning nobtn" value="'
			+ $('#parentquestion').val()
			+ '"  onclick="raiseSR(this);" nstyle="padding-right: 5px;padding-left: 5px;"><span class=" " style="color:darkorange;">No</span></button></div>';
	if (debug) {
		console.log($('#parentquestion').val());
	}
	$('.yesbtn').last().attr('disabled', 'disabled');
	$('.nobtn').last().attr('disabled', 'disabled');
	if (debug) {
		console.log("Does this resolve your query" + divfeedback);
	}
	sendMessage(divfeedback, 1);

}

var newLinkBtn = '<div class="gotOhelpDesk" style="font-size:small; "><a class="" style="text-decoration: none;"><span>find this helpful?</span></a><button class="btn btn-link btn-success" style="padding-right: 5px;padding-left: 5px;"><span class="glyphicon glyphicon-thumbs-up" style="color:chartreuse"></span></button><button class="btn btn-link btn-warning" style="padding-right: 5px;padding-left: 5px;"><span class="glyphicon glyphicon-thumbs-down " style="color:darkorange;"></span></button></div>';

// //////////////////////////////////////////////given by prassana
// ////////////////////////////////////////////////////////////////////////////////////
var content = $(".mergingText").next().find(".text").html();
$(content).insertAfter(".mergingText .text");
$(".mergingText").next().remove();
$("li").removeClass("mergingText");

// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function wantedQ(id) {
	if (debug) {
		console.log(id);
	}
	let msg = $('#comment').val();
	if (debug) {
		console.log(msg);
	}
	log($("#AppNameSelect").val(), msg, "USER WANT THIS TO BE IN THE SYSTEM",
			"NULL", msg, "WANTED QUESTION SUBMITTED BY USER");
	Userlog($("#AppNameSelect").val(), msg,
			"USER WANT THIS TO BE IN THE SYSTEM", "NULL", msg,
			"WANTED QUESTION SUBMITTED BY USER");
	$('#wantedBtn').remove();

	sendMessage('This is my desired question : <br/>' + msg, 2);

	sendDivFeedBack();
	$('#comment').remove();
}






/*****************SQL FUNCTIONS*******************START**********************/
/******  append column value to chat screen---*/
function append_column_value(id,col_ask_name){
	var table_html="";
	console.log(id);
	if(col_ask_name==='undefined' || col_ask_name==undefined){
		table_html+='<div class="form-group"><label id="label'+id+'" for="'+id+'" class="control-label col-sm-5" style="color:red;">'+col_ask_name +': </label><div class="col-md-4"><input type="text"  class="form-control col-md-4" id="'+id+'" placeholder="mapping value not defined for '+col_ask_name+'" required="required" readonly="readonly" /></div></div>';
	}else{
		table_html+='<div class="form-group"><label id="label'+id+'" for="'+id+'" class="control-label col-sm-5">'+col_ask_name +': </label><div class="col-md-4"><input type="text"  class="form-control col-md-4" id="'+id+'" placeholder="value for '+id+'" required="required" /></div></div>';
	}
	var tsql=$('#sql_ask_html').val();
	$('#sql_ask_html').val(tsql+table_html);

}

function execute_sql(json){
	var valreg=/(@[A-Za-z0-9_\-]+@)/g;
	json=JSON.parse(json);
	var keylist=Array.from(new Set(json.sql.match(valreg)));
	var coldata={};
	keylist.forEach(function(a){
		coldata[a]=$('#'+$.escapeSelector(a)).val();
		$('#'+$.escapeSelector(a)).attr('readonly','readonly');
		$('#'+$.escapeSelector(a)).attr('id','');
	});
	console.log(keylist);
	console.log(keylist.toString());
	$.ajax({
		type : "POST",
		url : "/checkSql",
		data : {
			"appName" : $('#AppNameSelect').val().toLowerCase(),
			"keylist":keylist.toString(),
			"sqldata":JSON.stringify(json),
			"coldata":JSON.stringify(coldata)
		},
		success : function(res) {
			sql_que=JSON.parse($('#sql_json').val());
			
			sendMessage("<h4>" + sql_que.question + "</h4>"
					+  sql_que.answer + res + newLinkBtn, 1);
			sendDivFeedBack();
			//we have to reset all variables;
			$('#sql_json').val('');
			$('#sql_ask_html').val("<div id='sql_form' class='sql_form' >");
			$('#sql_ask_list_len').val('0');
			$('#sql_ask_html_sent').val('-1');
			
			$('#sql_form').attr('id','');
			$('#submit_sql_data').remove();
			$('#sql_form').remove();
			
			clearInterval(send_sql_form);
		},
		error:function(res){
			sendMessage('Sorry Data not found');
			$('#sql_json').val('');
			$('#sql_ask_html').val("<div id='sql_form' class='sql_form' >");
			$('#sql_ask_list_len').val('0');
			$('#sql_ask_html_sent').val('-1');
			
			$('#sql_form').attr('id','');
			$('#submit_sql_data').remove();
			$('#sql_form').remove();
			
			clearInterval(send_sql_form);
		}

	
		});
	
}

function get_the_sql_result(){
	//$('#submit_sql_data').attr('disabled','disabled');
	execute_sql($('#sql_json').val());
}
/// to get data by sql query 

function get_by_sql(data,id,uQuery){
	
	
	
	$('#sql_json').val(JSON.stringify(data[id]._source));
	log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
			"SQL QUERY ENTER");
	if (debug) {
		console.log(appName, uQuery, data[id]._source.question, "NULL",
				"NULL", "SQL QUERY ENTER");
	}

	// set parent question:
	$('#parentquestion').val(encode(data[id]._source.question));

	var sql = data[id]._source.sql;
	
	var sqljson = {};
	sqljson.app_id=data[id]._source.app_id;
	sqljson.question=data[id]._source.question;
	sqljson.answer=data[id]._source.answer;
	sqljson.sql=data[id]._source.sql;	

	
	data[id]._source.sql = data[id]._source.sql.replace(";", "");
	
	if(debug){
		console.log('SQL : '+sql);
	}
	var valreg=/(@[A-Za-z0-9_\-]+@)/g;
	
	console.log(sqljson.sql.match(valreg));

	// get input of respective values;
	var listval=Array.from(new Set(sqljson.sql.match(valreg)));
	
	console.log("constant.js 453 : listval:"+listval);
	console.log(listval);
	if(listval.length>0){
		$('#sql_ask_html_sent').val('0');

		setInterval(send_sql_form, 500);
	}else{
		$('#sql_ask_html_sent').val('-1');
		clearInterval(send_sql_form);
		execute_sql($('#sql_json').val());
	}
	listval.forEach(function(val){
		$.ajax({
			type : "POST",
			url : "/getJsonMap",
			data : {
				"mapid" : val
			},
			success : function(res) {
				console.log('constant.js 472:Result:');
				
				res=JSON.parse(res);
				console.log(res);
				append_column_value(res.map_id,res.map_name);
				console.log('constant.js 474:');
				console.log(res);
				$('#sql_ask_list_len').val(parseInt($('#sql_ask_list_len').val())+1);
			},
			error:function(res){
				res=JSON.parse(res);
				append_column_value_readonly(res.map_id,res.map_name);
				$('#sql_ask_list_len').val(parseInt($('#sql_ask_list_len').val())+1);
				console.log(res);
			}

		
			});
		});


	
}

function send_sql_form(){
	var valreg=/(@[A-Za-z0-9_\-]+@)/g;

	
	var sql=$('#sql_json').val();
	if(sql.length>0){
		sql=JSON.parse(sql);
	
	var listvallen=Array.from(new Set(sql.sql.match(valreg)));
	console.log("ready function--->"+listvallen);
	console.log(sql);
	console.log(valreg);
	
	if($('#sql_ask_html_sent').val()=='0' && $('#sql_ask_list_len').val()==listvallen.length){
		var sql_submit='<div class="form-group"><button class="btn btn-sm btn-warning" id="submit_sql_data" name="submit_sql_data" onclick="get_the_sql_result();">Submit</button></div>';

		var tsql=$('#sql_ask_html').val();
		$('#sql_ask_html').val(tsql+sql_submit);
		sendMessage($('#sql_ask_html').val(),1);
		
		
		$('#sql_ask_html_sent').val('1');
		
		clearInterval(send_sql_form);
	}
	}
}
// to get data by article id
function get_article_id(id,uQuery){
		
		$.ajax({
					type : "POST",
					url : "/searchData",
					data : {
						"appName" :$("#AppNameSelect").val(),
						"id" : id
					},
					success : function(res) {
						if(debug){ console.log(res);}

						
						var qa = JSON.parse(res);
						if(debug){ console.log("qa=:" + qa);}
						flow_data(qa.hits.hits,0,uQuery);
						return;
						if(debug){ console.log("qa: length" + qa.hits.hits.length);}
						if(debug){ console.log('-------------------------------------');}

					},
					error : function(res) {
						if(debug){ console.log("fail");}
						
					}
		});// end of ajax

	

}








/////////////////////////////////////////////////////////////CHAT FLOW WITH
//DATA AS A ARRAY OF RESULT and uQuery as user Query AND id as the click question id value;
//START////////////////////////////////////////////////////////////////////////////


function flow_data(data,id,uQuery) {
	// if flow start
	$('#data_id').val(id);
	
	if(data.length > 0 && data[id]._source.hasOwnProperty("question")
			&& data[id]._source.hasOwnProperty("article_id") && data[id]._source.hasOwnProperty("answer")){
		sendMessage("<h4>" + data[id]._source.question + "</h4>"
				+ data[id]._source.answer, 1);
		get_article_id(data[id]._source.article_id,uQuery);
		
	}else if(data.length > 0 && data[id]._source.hasOwnProperty("question")
			&& data[id]._source.hasOwnProperty("article_id")){
		
		get_article_id(data[id]._source.article_id,uQuery);
		
	}else if (data.length > 0 && data[id]._source.hasOwnProperty("answer")
			&& data[id]._source.hasOwnProperty("file")
			&& data[id]._source.hasOwnProperty("question")) {

		var jsonfile = data[id]._source.file;
		if (debug) {
			console.log(jsonfile);
		}
		var file = '';

		jsonfile.forEach(function(entry) {
					
					file += '<p><a href="'
							+ entry.replace(/\\/g, '/')
							+ '" class="btn btn-link" download><span class="glyphicon glyphicon-download-alt"> Download : '
							+ entry.replace(/\\/g, '/')
									.substring(
											(entry.replace(/\\/g, '/')
													.lastIndexOf('/') + 1))
							+ '</span></a> </p>';
				});
		sendMessage("<h4>" + data[id]._source.question + "</h4>"
				+ data[id]._source.answer + file + newLinkBtn, 1);

		/*// set parent question:
		$('#parentquestion').val(encode(data[id]._source.question));*/

		log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
				"FILE QA");
		if (debug) {
			console.log(appName, uQuery, data[id]._source.question, "NULL",
					"NULL", "FILE QA");
		}
		sendDivFeedBack();
		 

	} else if (data.length > 0 && data[id]._source.hasOwnProperty("answer")
			&& data[id]._source.hasOwnProperty("image")
			&& data[id]._source.hasOwnProperty("question")) {

		var jsonimage = data[id]._source.image;
		if (debug) {
			console.log(jsonimage);
		}
		var images = '';
		jsonimage.forEach(function(entry) {
			images += '<p><img id="zoom"  src="' + entry.replace(/\\/g, '/') + '" data-zoom-image="' + entry.replace(/\\/g, '/') + '" /></p>';
		});
		sendMessage("<h4>" + data[id]._source.question + "</h4>"
				+ data[id]._source.answer + images + newLinkBtn, 1);
		sendDivFeedBack();
	/*
	  	// set parent question:
		$('#parentquestion').val(encode(data[id]._source.question));
	*/
		log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
				"IMAGE QA");
		if (debug) {
			console.log(appName, uQuery, data[id]._source.question, "NULL",
					"NULL", "IMAGE QA");
		}

		 

	} else if (data.length > 0 && data[id]._source.hasOwnProperty("answer")
			&& data[id]._source.hasOwnProperty("conv_ans")
			&& data[id]._source.hasOwnProperty("question")) {

		if (debug) {
			console.log('array found with answer');
		}
		log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
				"CONV_CHAT_START");
		if (debug) {
			console.log(appName, uQuery, data[id]._source.question, "NULL",
					"NULL", "CONV_CHAT_START");
		}

		/*
	  	// set parent question:
		$('#parentquestion').val(encode(data[id]._source.question));
	*/
		sendMessage("<h4>" + data[id]._source.question + "</h4>"
				+ data[id]._source.answer, 1);
		startConversation(data[id]._source.conv_ans);
		/*log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
				"CONV_CHAT_END");
		if (debug) {
			console.log(appName, uQuery, data[id]._source.question, "NULL",
					"NULL", "CONV_CHAT_END");
		}*/

	}  else if (data.length > 0 &&  data[id]._source.hasOwnProperty("conv_ans")
			&& data[id]._source.hasOwnProperty("question")) {

		if (debug) {
			console.log('array found with answer');
		}
		log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
				"CONV_CHAT_START");
		if (debug) {
			console.log(appName, uQuery, data[id]._source.question, "NULL",
					"NULL", "CONV_CHAT_START");
		}

		/*
	  	// set parent question:
		$('#parentquestion').val(encode(data[id]._source.question));
	*/
		sendMessage("<h4>" + data[id]._source.question + "</h4>", 1);
		startConversation(data[id]._source.conv_ans);
		/*log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
				"CONV_CHAT_END");
		if (debug) {
			console.log(appName, uQuery, data[id]._source.question, "NULL",
					"NULL", "CONV_CHAT_END");
		}*/

	}
	else if (data.length > 0 &&  data[id]._source.hasOwnProperty("conv_ans")
			&& data[id]._source.hasOwnProperty("answer")) {

		if (debug) {
			console.log('array found with answer and conv_ans');
		}
		log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
				"CONV_CHAT_START");
		if (debug) {
			console.log(appName, uQuery, data[id]._source.question, "NULL",
					"NULL", "CONV_CHAT_START");
		}

		sendMessage("<h4><b>" + data[id]._source.answer + "</b></h4>", 1);
		startConversation(data[id]._source.conv_ans);
	}
	else if (data.length > 0 && data[id]._source.hasOwnProperty("question")
			&& data[id]._source.hasOwnProperty("sql")) {
		
		log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
		"SQL_QA");
		 get_by_sql(data,id,uQuery);
		 
		

	} else if (data.length > 0 && data[id]._source.hasOwnProperty("answer")
			&& data[id]._source.hasOwnProperty("question")) {
		// case if not sql statement
		// case if its a direct answer or its a conversational ans//

		/*
	  	// set parent question:
		$('#parentquestion').val(encode(data[id]._source.question));
	*/
		sendMessage("<h4>" + data[id]._source.question + "</h4>"
				+ data[id]._source.answer + newLinkBtn, 1);
		sendDivFeedBack();
		 

		log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
				"QA");
		if (debug) {
			console.log(appName, uQuery, data[id]._source.question, "NULL",
					"NULL", "QA");
		}

	} else if (data.length > 0 && data[id]._source.hasOwnProperty("conv_ans")) {
		//case if not sql statement 
		//case if its a direct answer or its a conversational ans//

		/*
	  	// set parent question:
		$('#parentquestion').val(encode(data[id]._source.question));
	*/
		sendMessage("<h4>" + data[id]._source.question + "</h4>", 1);
		//sendDivFeedBack();

		startConversation(data[id]._source.conv_ans);
		log(appName, uQuery, data[id]._source.question, "NULL", "NULL",
				"CONV_CHAT_START");
		if (debug) {
			console.log(appName, uQuery, data[id]._source.question, "NULL",
					"NULL", "CONV_CHAT_START");
		}

	}else {
		log(appName, uQuery, "NO_QUESTION_MATCHED", "NULL", "NULL");
		if (debug) {
			console.log(appName, uQuery, "NO_QUESTION_MATCHED", "NULL", "NULL");
		}

		sendMessage(
				"Sorry, I didn't quite understand what you said.Try asking another way.",
				1);
	}

	////if flow end
	
	
}



