package com.icici.athena.controller;

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Controller
@RestController
public class InsertController {
	
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	//private String driverName = "oracle.jdbc.driver.OracleDriver";
	private String driverName=ConstantController.userDatabaseDriverClassName;
	//private String dbURL = "jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
	private String dbURL=ConstantController.userDatabaseUrl;
	//private String dbUser = "CXPSADM";
	private String dbUser=ConstantController.userDatabaseUserName;
	//private String dbPassword = "CXPSADM_123";
	private String dbPassword=ConstantController.userDatabasePassword;
	
	//@RequestMapping(value = "/insertUser", method = RequestMethod.POST)
	public int insertUser(@RequestParam(value = "myuser_id", required = false) String myuserid,
			@RequestParam(value = "myuser_name", required = false) String myusername,
			@RequestParam(value = "myrole_id", required = false) String myroleid,
			@RequestParam(value = "mymanager_id", required = false) String mymanagerid,
			@RequestParam(value = "myis_superuser", required = false) String myissuperuser,
			@RequestParam(value = "myis_locked", required = false) String myislocked,

			HttpServletRequest request) throws IOException {
		
		
		
		myuserid=myuserid.toUpperCase();

		 
		myusername=myusername.toUpperCase();
		myroleid=myroleid.toUpperCase();
		mymanagerid=mymanagerid.toUpperCase();
		myissuperuser=myissuperuser.toUpperCase();
		myislocked=myislocked.toUpperCase();
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			if(isDebug){
				System.out.println("Where is your Oracle JDBC Driver?");
			}
			e.printStackTrace();
			return -1;

		}

		if(isDebug){
			System.out.println("Oracle JDBC Driver Registered!");
		}

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			if(isDebug){
				System.out.println("Connection Failed! Check output console");
			}
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "SELECT COUNT(*) FROM "+ConstantController.userTable+" WHERE USER_ID='" + myuserid + "'";
				ResultSet rs = stmt.executeQuery(query);
				rs.next();
				String ifExist = rs.getString(1);
				rs.close();
				if (ifExist.equalsIgnoreCase("0")) {
					query = "INSERT INTO "+ConstantController.userTable+" (user_id, user_name,manager_id,login_time,is_locked,lock_time,is_superuser,role_id ) "
							+ "VALUES " + "('" + myuserid + "','" + myusername + "','" + mymanagerid + "',SYSDATE,'"
							+ myislocked + "',SYSDATE,'" + myissuperuser + "','" + myroleid + "')";

					if(isDebug){
						System.out.println(query);
					}
					rs = stmt.executeQuery(query);
					rs.close();
					return 1;
				} else {
					query = "UPDATE  "+ConstantController.userTable+" SET user_id='" + myuserid + "', user_name='" + myusername
							+ "',manager_id='" + mymanagerid + "',is_locked='" + myislocked
							+ "',lock_time='',is_superuser='" + myissuperuser + "',role_id='" + myroleid + "'  "
							+ "WHERE USER_ID='" + myuserid + "'";

					Statement tstmt = connection.createStatement();

					ResultSet trs = tstmt.executeQuery(query);
					trs.close();
					rs.close();
					if(isDebug){
						System.out.println(query);
					}
					connection.close();
					return 2;
				}

			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in insert stmt creation");
				}
				e.printStackTrace();
				return -1;
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			return -1;
		}

	}

	@RequestMapping(value = "/commit", method = RequestMethod.POST)
	public int commit(HttpServletRequest request) throws IOException {
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			if(isDebug){
				System.out.println("Where is your Oracle JDBC Driver?");
			}
			e.printStackTrace();
			return -1;

		}

		if(isDebug){
			System.out.println("Oracle JDBC Driver Registered!");
		}

		Connection connection = null;
		Statement stmt = null;
		ResultSet rs=null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			if(isDebug){
				System.out.println("Connection Failed! Check output console");
			}
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
				stmt = null;
				stmt = connection.createStatement();
				String query = "COMMIT";

				if(isDebug){
					System.out.println(query);
				}
				rs = stmt.executeQuery(query);
				rs.close();
				connection.close();
				return 1;
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in commit creation");
				}
				// e.printStackTrace();
				return -1;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (stmt != null) stmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			return -1;
		}

	}


	@RequestMapping(value = "/rollback", method = RequestMethod.POST)
	public int rollback(HttpServletRequest request) throws IOException {
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			if(isDebug){
				System.out.println("Where is your Oracle JDBC Driver?");
			}
			e.printStackTrace();
			return -1;

		}

		if(isDebug){
			System.out.println("Oracle JDBC Driver Registered!");
		}

		Connection connection = null;
		Statement stmt = null;
		ResultSet rs=null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			if(isDebug){
				System.out.println("Connection Failed! Check output console");
			}
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
				stmt = null;
				stmt = connection.createStatement();
				String query = "ROLLBACK";

				if(isDebug){
					System.out.println(query);
				}
				rs = stmt.executeQuery(query);
				rs.close();
				connection.close();
				return 1;
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in commit creation");
				}
				// e.printStackTrace();
				return -1;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (stmt != null) stmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			return -1;
		}

	}
	@RequestMapping(value = "/insertRole", method = RequestMethod.POST)
	public int insertRole(@RequestParam(value = "myrole_name", required = false) String myrolename,
			@RequestParam(value = "myrole_details", required = false) String myroledetails,

			HttpServletRequest request) throws IOException {

		myrolename=myrolename.toUpperCase();
		myroledetails=myroledetails.toUpperCase();
		
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			if(isDebug){
				System.out.println("Where is your Oracle JDBC Driver?");
			}
			e.printStackTrace();
			return -1;

		}

		if(isDebug){
			System.out.println("Oracle JDBC Driver Registered!");
		}

		Connection connection = null;
		Statement stmt = null;
		ResultSet rs=null;
		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			if(isDebug){
				System.out.println("Connection Failed! Check output console");
			}
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
				stmt = null;
				stmt = connection.createStatement();
				String query = "INSERT INTO "+ConstantController.userRoleTable+" (role_id, role_name,priviledges ) VALUES " + "('','"
						+ myrolename + "','" + myroledetails + "')";

				if(isDebug){
					System.out.println(query);
				}
				rs = stmt.executeQuery(query);
				rs.close();
				connection.close();
				return 1;
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in insert stmt creation");
				}
				// e.printStackTrace();
				return -1;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (stmt != null) stmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			return -1;
		}

	}

	//@RequestMapping(value = "/insertGrant", method = RequestMethod.POST)
	public int insertGrant(

			@RequestParam(value = "mygrant_id", required = false) String mygrantid,

			@RequestParam(value = "mygranter_id", required = false) String mygranterid,
			@RequestParam(value = "mygranter_name", required = false) String mygrantername,
			@RequestParam(value = "myrole_id", required = false) String myroleid,
			@RequestParam(value = "myapp_id", required = false) String myappid,
			@RequestParam(value = "mygrantee_id", required = false) String mygranteeid,
			@RequestParam(value = "mygrantee_name", required = false) String mygranteename,
			@RequestParam(value = "can_grant", required = false) String cangrant,
			@RequestParam(value = "is_validGrant", required = false) String isvalidgrant,

			HttpServletRequest request) throws IOException {
		
		
		
		if(ConstantController.isDebug){
			System.out.println("insert Grant: ");
			System.out.println("Granter Name: "+mygrantername);
			System.out.println("Granter ID: "+mygranterid);
			System.out.println("Grantee Name: "+mygranteename);
			System.out.println("Grantee ID: "+mygranteeid);
			
			
			
		}
		
		
		
		mygrantername=UserController.refineName(mygrantername);
		mygranteename=UserController.refineName(mygranteename);
		mygranterid=UserController.refineName(mygranterid);
		mygranteeid=UserController.refineName(mygranteeid);
		
		
		
		
		mygrantid=mygrantid.toUpperCase();
		mygranterid=mygranterid.toUpperCase();
		mygrantername=mygrantername.toUpperCase();
		myroleid=myroleid.toUpperCase();
		myappid=myappid.toUpperCase();
		mygranteeid=mygranteeid.toUpperCase();
		mygranteename=mygranteename.toUpperCase();
		cangrant=cangrant.toUpperCase();
		isvalidgrant=isvalidgrant.toUpperCase();
		
	
		if(ConstantController.isDebug){
			System.out.println("insert Grant refine: ");
			System.out.println("Granter Name: "+mygrantername);
			System.out.println("Granter ID: "+mygranterid);
			System.out.println("Grantee Name: "+mygranteename);
			System.out.println("Grantee ID: "+mygranteeid);
			
			
			
		}
		
		
		
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			if(isDebug){
				System.out.println("Where is your Oracle JDBC Driver?");
			}
			e.printStackTrace();
			return -1;

		}

		if(isDebug){
			System.out.println("Oracle JDBC Driver Registered!");
		}

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

		} catch (SQLException e) {

			if(isDebug){
				System.out.println("Connection Failed! Check output console");
			}
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query = "";
				if(isDebug){
					System.out.println("QUERY--->" + query + "  " + mygrantid);
				}
				
				
				//check if user has name grant in the table;
				
				query="SELECT COUNT(*) FROM "+ConstantController.userGrantTable+" WHERE grantee_id='"+mygranteeid+"' AND app_id='"+myappid+"' AND role_id='"+myroleid+"' AND is_valid_grant='YES'";
				if(isDebug){
					System.out.println(query);
				}
				ResultSet rs = stmt.executeQuery(query);
				rs.next();
				if(rs.getString(1).equals("0")){
					if(isDebug){
						System.out.println("GRANT CAN BE INSERTED");
					}
				}else{
					if(isDebug){
						System.out.println("Return 3: Exists");
					}
					return 3;
				}
				query = "";
				
				
				
				
				
				
				
				
				rs.close();
				if (!mygrantid.trim().equals("NEW")) {
					query = "UPDATE "+ConstantController.userGrantTable+" SET grant_id='" + mygrantid + "',granter_id='" + mygranterid
							+ "',granter_name='" + mygrantername + "',role_id='" + myroleid + "',app_id='" + myappid
							+ "',grantee_id='" + mygranteeid + "',grantee_name='" + mygranteename + "',can_grant='"
							+ cangrant + "',is_valid_grant='" + isvalidgrant + "' WHERE grant_id='" + mygrantid + "'";
					if(isDebug){
						System.out.println(query);
					}
					 ResultSet rst = stmt.executeQuery(query);
					rst.close();
					if(isDebug){
						System.out.println("Return 2: Updated");
					}
					return 2;
				} else {
					query = "INSERT INTO "+ConstantController.userGrantTable+" (grant_id,granter_id,granter_name,role_id,app_id,grantee_id,grantee_name,can_grant,is_valid_grant ) VALUES "
							+ "('','" + mygranterid + "','" + mygrantername + "','" + myroleid + "','" + myappid + "','"
							+ mygranteeid + "','" + mygranteename + "','" + cangrant + "','" + isvalidgrant + "')";
					if(isDebug){
						System.out.println(query);
					}
					ResultSet rst = stmt.executeQuery(query);
					rst.close();
					if(isDebug){
						System.out.println("Connection Closed");
					}
					connection.close();
					if(isDebug){
						System.out.println("Return 1: Inserted");
					}
					return 1;
				}

			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in insert stmt creation");
				}
				// e.printStackTrace();
				return -1;
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			return -1;
		}

	}

	//@RequestMapping(value = "/insertApp", method = RequestMethod.POST)
	public int insertApp(			
			@RequestParam(value="myapp_name",required=false) String myappname,
			@RequestParam(value="myuser_id",required=false) String myuserid,
			@RequestParam(value="myuser_name",required=false) String myusername) throws IOException {
		
		 
			myusername=UserController.refineName(myusername);
			myappname=UserController.refineName(myappname);
			myusername=myusername.toUpperCase();
			myuserid=myuserid.toUpperCase();
			myappname=myappname.toUpperCase();
			
			
		
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			if(isDebug){
				System.out.println("Where is your Oracle JDBC Driver?");
			}
			e.printStackTrace();
			return -1;

		}

		if(isDebug){
			System.out.println("Oracle JDBC Driver Registered!");
		}

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
			
		} catch (SQLException e) {

			if(isDebug){
				System.out.println("Connection Failed! Check output console");
			}
			e.printStackTrace();
			return -1;

		}

		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
				Statement stmt = null;
				stmt = connection.createStatement();
				String query="";
				/// check if app already exist
				query="SELECT COUNT(*) FROM "+ConstantController.userAppTable+" WHERE APP_NAME='"+myappname+"'";
				if(isDebug){
					System.out.println(query);
				}
				ResultSet rs = stmt.executeQuery(query);
				
				rs.next();
				if(rs.getString(1).equals("0")){
					if(isDebug){
						System.out.println("APP CAN BE INSERTED");
					}
				}else{
					return 3;
				}
				stmt.close();
				Statement tstmt  = connection.createStatement();

					query = "INSERT INTO "+ConstantController.userAppTable+" (app_id,app_name,user_id,user_name,created_date ) VALUES "+ "('','"+myappname+"','"+myuserid+"','"+myusername+"',SYSDATE)";
					if(isDebug){
						System.out.println(query);
					}
					ResultSet trs = tstmt.executeQuery(query);
					tstmt.close();
					trs.close();
					
					
					
						String body=" {\"dynamic\": true,\"_all\": {\"analyzer\": \"nGram_analyzer\","
								+ "\"search_analyzer\": \"whitespace_analyzer\"} ,\"properties\": {\"answer\": {\"type\": \"text\","
								+ "\"index\":\"not_analyzed\"},\"question\": {\"type\": \"text\",\"index\": \"not_analyzed\"},"
								+ "\"conv_ans\":{\"type\":\"nested\"}}}";
												
						if(isDebug){
							System.out.println("App Creation Body----"+body);
						}
						
						if(AjaxController.isDebug){
							System.out.println("Passing the following params for App Creation in elasticsearch: \n 1.Appname : "+myappname+"\nbody : "+body+"\n server ip : "+AjaxController.eserver+"\n Index name : "+AjaxController.eindex);
						}
						myappname=URLEncoder.encode(myappname, "UTF-8");
						//RestClient restClient80 = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
						RestClient restClient80 = RestClient.builder(new HttpHost(AjaxController.eserver, 9200, "http")).build();
						
						HttpEntity entity80 = new NStringEntity(body.toString(), ContentType.APPLICATION_JSON);

				        Response indexResponse80 = restClient80.performRequest("POST", "/" + AjaxController.eindex + "/" +myappname.toLowerCase()+"/_mapping" ,
				                Collections.<String, String>emptyMap(), entity80);
				        if(isDebug){
							System.out.println("App Creation query posted to elasticsearch");
						}
				        
				        if(isDebug){
				        	
							System.out.println("RESPONSE CODE for 80---"+indexResponse80.getStatusLine().getStatusCode());
						}
				        
				        ///////////////////////////////////////////////Check if UAT or Production
				        if(AjaxController.eserver.equals(AjaxController.nextServer)){
				        	System.out.println("FINAL RESPONSE CODE ---"+indexResponse80.getStatusLine().getStatusCode());
				        	try {
								restClient80.close();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
				    		
				        	return indexResponse80.getStatusLine().getStatusCode();
				        }
				        
				        ///////////////////////////////////////////////Check if UAT or Production

				        //RestClient restClient79 = RestClient.builder(new HttpHost("10.50.72.79", 9200, "http")).build();
				        RestClient restClient79 = RestClient.builder(new HttpHost(AjaxController.nextServer, 9200, "http")).build();
						
						HttpEntity entity79 = new NStringEntity(body.toString(), ContentType.APPLICATION_JSON);

				        Response indexResponse79 = restClient79.performRequest("POST", "/" + AjaxController.eindex + "/" +myappname.toLowerCase()+"/_mapping" ,
				                Collections.<String, String>emptyMap(), entity79);
				        if(isDebug){
							System.out.println("App Creation query posted to elasticsearch");
						}
				        connection.close();
				        if(isDebug){
				        	
							System.out.println("RESPONSE CODE for 79---"+indexResponse79.getStatusLine().getStatusCode());
						}
				        if(indexResponse79.getStatusLine().getStatusCode() == indexResponse80.getStatusLine().getStatusCode()){
				        	try {
								restClient80.close();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
				    		try {
								restClient79.close();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
				        	return indexResponse79.getStatusLine().getStatusCode(); 
				        }else{
				        	try {
								restClient80.close();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
				    		try {
								restClient79.close();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
				        	return -1;
				        }
				        	
				        
				        
					
				}catch (Exception e) {
					if(isDebug){
						System.out.println("error in App insert stmt creation");
					}
				 e.printStackTrace();
				return -1;
			}
		}else

	{
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
		return -1;
	}

}

}
