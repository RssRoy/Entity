
package com.icici.athena.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.ParseException;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.ResponseException;
import org.elasticsearch.client.RestClient;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.icici.athena.app.SqlMap;
import com.icici.athena.user.User;

import oracle.sql.TIMESTAMP;

@Controller
@Component
@RestController
public class SqlMapElasticController {

	public int insertToElastic(String method, String index, String type, String id, String body) {
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);

		Response response = null;
		try {
			response = restClient.performRequest(method.toUpperCase(),
					"/" + index.toLowerCase() + "/" + type.toLowerCase() + "/" + id + "/",
					Collections.<String, String>emptyMap(), entity);
			ElasticController.reindex(index);
		} catch (IOException e1) {
			// TODO Auto-generated catch block

			e1.printStackTrace();
			return -1;
		}
		try {
			restClient.close();
			return response.getStatusLine().getStatusCode();
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -2;
		}
	}

	 @RequestMapping(value = "/getJsonMap", method = RequestMethod.POST)
	public String getJsonMap(@RequestParam("mapid") String mymapid) throws IOException {
		JsonObject result = new JsonObject();
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body = "";
		String res = "";
		// int cnt = 0;
		JsonParser parser = new JsonParser();

		body = "";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		// appName=URLEncoder.encode(appName, "UTF-8");
		Response response = null;
		try {
			response = restClient.performRequest("GET", "/"+ConstantController.tnsIndex+"/sqlmap/" + mymapid + "/",
					Collections.<String, String>emptyMap(), entity);
			if (ConstantController.isDebug) {
				System.out.println(response.toString() + "  " + mymapid);
			}
		}catch (ResponseException e) {
			// TODO Auto-generated catch block
			response = e.getResponse();
			if (ConstantController.isDebug) {
				System.out.println("Map Not found" + res + "<----"+mymapid);
			}
			JsonObject jsonMap=new JsonObject();
			
			e.printStackTrace();
			jsonMap.addProperty("map_id", mymapid);
			jsonMap.addProperty("map_value", mymapid);
			return jsonMap.toString();
		}  catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject jsonMap = null;
		
		jsonMap = parser.parse(res).getAsJsonObject().get("_source").getAsJsonObject();
		result = jsonMap;

		if (ConstantController.isDebug) {
			System.out.println("this is result" + result.toString());
		}
		return result.toString();
	}

	public ArrayList<SqlMap> getMap(User user) throws IOException {
		return getUserMap(user, "NULL");
	}

	 @RequestMapping(value = "/getUserMap", method = RequestMethod.POST)
	public ArrayList<SqlMap> getUserMap(User user, String mymapid) throws IOException {

		ArrayList<SqlMap> result = new ArrayList<SqlMap>();
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body = "";
		JsonParser parser = new JsonParser();
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		// appName=URLEncoder.encode(appName, "UTF-8");
		Response response = restClient.performRequest("GET", "/"+ConstantController.tnsIndex+"/sqlmap/_search?size=1000",
				Collections.<String, String>emptyMap(), entity);
		String res = EntityUtils.toString(response.getEntity());
		restClient.close();
		// System.out.println("*********************************"+res.toString());
		int resultSize = parser.parse(res).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray()
				.size();
		for (int i = 0; i < resultSize; i++) {
			JsonObject jsonMap = parser.parse(res).getAsJsonObject().get("hits").getAsJsonObject().get("hits")
					.getAsJsonArray().get(i).getAsJsonObject().get("_source").getAsJsonObject();
			if(ConstantController.isDebug) {
				System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + jsonMap.toString());
			}
			SqlMap temp = new SqlMap();
			// map_value is acting as a id.
			temp.setMap_id(jsonMap.get("map_value").getAsString());
			temp.setMap_name(jsonMap.get("map_name").getAsString());
			temp.setMap_value(jsonMap.get("map_value").getAsString());
			temp.setMap_list(new ArrayList<String>(Arrays.asList(jsonMap.get("map_list").getAsString().split("\\s*,\\s*"))));
			if(jsonMap.has("modified_by")){
				temp.setModified_by(jsonMap.get("modified_by").getAsString());
			}else{
				temp.setModified_by("");
			}
			if(jsonMap.has("modified_time")){
			temp.setModified_time(new TIMESTAMP(jsonMap.get("modified_time").getAsString()));
			}else{
				temp.setModified_by("");
			}
			result.add(temp);
		}
		return result;

	}

	 @RequestMapping(value = "/getAllMap", method = RequestMethod.POST)
	public ArrayList<SqlMap> getAllMap() throws IOException {

		ArrayList<SqlMap> result = new ArrayList<SqlMap>();
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body = "";
		JsonParser parser = new JsonParser();
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		// appName=URLEncoder.encode(appName, "UTF-8");
		Response response = restClient.performRequest("GET", "/"+ConstantController.tnsIndex+"/sqlmap/_search?size=1000",
				Collections.<String, String>emptyMap(), entity);
		String res = EntityUtils.toString(response.getEntity());
		restClient.close();
		// System.out.println("*********************************"+res.toString());
		int resultSize = parser.parse(res).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray()
				.size();
		for (int i = 0; i < resultSize; i++) {
			JsonObject jsonMap = parser.parse(res).getAsJsonObject().get("hits").getAsJsonObject().get("hits")
					.getAsJsonArray().get(i).getAsJsonObject().get("_source").getAsJsonObject();
			if (ConstantController.isDebug) {
				System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + jsonMap.toString());
			}
			SqlMap temp = new SqlMap();
			// map_value is acting as a id.
			temp.setMap_id(jsonMap.get("map_value").getAsString());
			temp.setMap_name(jsonMap.get("map_name").getAsString());
			temp.setMap_value(jsonMap.get("map_value").getAsString());
			temp.setMap_list(
					(ArrayList<String>) Arrays.asList(jsonMap.get("map_list").getAsString().split("\\s*,\\s*")));
			if(jsonMap.has("modified_by")){
				temp.setModified_by(jsonMap.get("modified_by").getAsString());
			}else{
				temp.setModified_by("");
			}
			if(jsonMap.has("modified_time")){
			temp.setModified_time(new TIMESTAMP(jsonMap.get("modified_time").getAsString()));
			}else{
				temp.setModified_by("");
			}
			result.add(temp);
		}
		return result;

	}

	 @RequestMapping(value = "/MapExist", method = RequestMethod.POST)
	public String mapMapExist(@RequestParam(value = "mapid", required = false) String mymapid) {
		 if (ConstantController.isDebug) {
			 System.out.println("MapExist::" + mymapid);
		 }
		SqlMap temp = getMapById(mymapid);

		if (temp == null) {
			if (ConstantController.isDebug) {
				System.out.println("NO");
			}
			return "NO";
		} else {
			if (ConstantController.isDebug) {
				System.out.println(temp.getMap_id());
			}
			return "YES";
		}

	}

	public SqlMap getMapById(String mymapid) {

		SqlMap result = null;

		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body = "";
		String res = "";
		// int cnt = 0;
		JsonParser parser = new JsonParser();

		body = "";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		// appName=URLEncoder.encode(appName, "UTF-8");
		Response response = null;
		try {
			response = restClient.performRequest("GET", "/"+ConstantController.tnsIndex+"/sqlmap/" + mymapid + "/",
					Collections.<String, String>emptyMap(), entity);
		} catch (ResponseException e) {
			// TODO Auto-generated catch block
			response = e.getResponse();
			if (ConstantController.isDebug) {
				System.out.println("Map Not found" + res + "<----");
			}
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject jsonMap = parser.parse(res).getAsJsonObject().get("_source").getAsJsonObject();

		SqlMap temp = new SqlMap();
		if (jsonMap.get("map_id").toString().equals(mymapid)) {
			temp.setMap_id(jsonMap.get("map_id").getAsString());
			temp.setMap_name(jsonMap.get("map_name").getAsString());
			temp.setMap_value(jsonMap.get("map_value").getAsString());
			temp.setMap_list(
					(ArrayList<String>) Arrays.asList(jsonMap.get("map_list").getAsString().split("\\s*,\\s*")));
			
			result = temp;
		}

		return result;

	}

	// Find MAP
	public int findMapById(String mymapid) throws IOException {
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body = "";
		String res = "";
		// int cnt = 0;
		JsonParser parser = new JsonParser();

		body = "";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		// appName=URLEncoder.encode(appName, "UTF-8");
		Response response = null;
		try {
			response = restClient.performRequest("GET", "/"+ConstantController.tnsIndex+"/sqlmap/" + mymapid + "/",
					Collections.<String, String>emptyMap(), entity);
		} catch (ResponseException e) {
			// TODO Auto-generated catch block
			response = e.getResponse();
			if (ConstantController.isDebug) {
				System.out.println("Map Not found" + res + "<----");
			}
			e.printStackTrace();
			return -1;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject jsonMap = parser.parse(res).getAsJsonObject();

		if (jsonMap.get("found").getAsBoolean() == true) {
			return 1;
		} else {
			return -1;
		}

	}

	 @RequestMapping(value = "/insertMap", method = RequestMethod.POST)
	public int insertMapEntry(

			@RequestParam(value = "mymap_id", required = false) String mymapid,
			@RequestParam(value = "mymap_name", required = false) String mymapname,
			@RequestParam(value = "mymap_value", required = false) String mymapvalue,
			@RequestParam(value = "mymap_list", required = false) String mymaplist,

			HttpServletRequest request) throws IOException {

		 
			if(request.getSession(false)==null && request.getSession(false).getAttribute("user")==null){
				return -1;
			}
			User user=(User)request.getSession(false).getAttribute("user");
		 
		if (ConstantController.isDebug) {
			System.out.println("TNS Controller: ");
			System.out.println("map Name: " + mymapname);
			System.out.println("Map ID: " + mymapid);
			System.out.println("map value : " + mymapvalue);
			System.out.println("map list: " + mymaplist);

		}
		if (findMapById(mymapvalue) == 1) {
			if (ConstantController.isDebug) {
				System.out.println("MAP WILL BE UPDATED.");
			}
			// return 3;
		} else {
			if (ConstantController.isDebug) {
				System.out.println("MAP CAN BE INSERTED");
			}
		}
		
		//map id is map_value 
		JsonObject map = new JsonObject();
		map.addProperty("map_id", mymapvalue);
		map.addProperty("map_name", mymapname);
		map.addProperty("map_value", mymapvalue);
		map.addProperty("map_list", mymaplist);
		map.addProperty("modified_by", user.getUser_name());
		map.addProperty("modified_time",new java.sql.Timestamp(System.currentTimeMillis()).toString());
		int resp = insertToElastic("POST", ""+ConstantController.tnsIndex+"", "sqlmap", mymapvalue, map.toString());

		if (resp >= 200) {

			return 2;

		} else {

			return -1;

		}
	}

}
