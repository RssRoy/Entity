package com.icici.athena.controller;

import java.io.IOException;
import java.util.Collections;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;

public class ElasticController {

	
	public static void refresh (String server,String eindex) throws IOException{
		//int status =-1;
		HttpEntity entity = null;
		Response response = null;
		String body = "";
		RestClient restClient = RestClient.builder(new HttpHost(server, 9200, "http")).build();
		entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		if(ConstantController.isDebug){
			System.out.println("Body:+"+body);
		}
		response = restClient.performRequest("POST", "/"+eindex+"/_refresh", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		if(ConstantController.isDebug){
			System.out.println("body:::::"+body+"\nresult:::::"+result);
		}
		
		restClient.close();
		//status = response.getStatusLine().getStatusCode();
		
	}
	public static  int reindex(String eindex) throws IOException{
		
		if(ConstantController.eserver.equals(ConstantController.nextServer)){
			return 200;
		}
		
		int statusCode = -1;
		String nextServer = "";
		
		String body="";
		HttpEntity entity = null;
		Response response = null;
		
		
		refresh(ConstantController.eserver,eindex);
	
		
		
		nextServer = ConstantController.nextServer;
		
		if(ConstantController.isDebug){
    		System.out.println("Reindexing from "+ConstantController.eserver+" to "+ConstantController.nextServer);
    	}
		//body = "{\"source\":{\"remote\":{\"host\":\"http://"+ConstantController.nextServer+":9200\",\"username\":\"hdpuser\",\"password\":\"hdpuser@123\"},\"index\":\""+eindex+"\"},\"dest\":{\"index\":\""+eindex+"\"}}";
		body = "{\"source\":{\"remote\":{\"host\":\"http://"+ConstantController.eserver+":9200\",\"username\":\""+ConstantController.user+"\",\"password\":\""+ConstantController.pwd+"\"},\"index\":\""+eindex+"\"},\"dest\":{\"index\":\""+eindex+"\"}}";
		
		//RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.nextServer, 9200, "http")).build();
		entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		if(ConstantController.isDebug){
			System.out.println("Body:+"+body);
		}
		response = restClient.performRequest("POST", "/_reindex?pretty=true'", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		if(ConstantController.isDebug){
			System.out.println("body:::::"+body+"\nresult:::::"+result);
		}
		statusCode = response.getStatusLine().getStatusCode();
		
		refresh(ConstantController.eserver,eindex);
		refresh(ConstantController.nextServer,eindex);

		if(statusCode == 200){
			restClient.close();

			if(ConstantController.isDebug){
	    		System.out.println("Reindexing Successful");
	    	}
			return statusCode;
			
		}
		else{
			restClient.close();
			if(ConstantController.isDebug){
	    		System.out.println("Failed while reindexing");
	    	}
		}
		return statusCode;
	}
}
