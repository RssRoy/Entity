package com.icici.athena;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.WebUtils;

import com.icici.athena.controller.*;

@Component
public class WebSecurityConfig extends OncePerRequestFilter {

	private String mode = "DENY";

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		/*
		 * if (request.getMethod().equals("OPTIONS") ||
		 * request.getMethod().equals("TRACE") || request.getMethod().equals("HEAD") ||
		 * request.getMethod().equals("PATCH") || request.getMethod().equals("PROPFIND")
		 * ) { response.sendError(HttpServletResponse.SC_FORBIDDEN); } else {
		 * filterChain.doFilter(request, response); }
		 */

		CsrfToken csrf = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
		//System.out.println("Request-->" + request.getRequestURL() + " --->CSRF-->" + CsrfToken.class.getName() + "  "+csrf.getToken());

		if (csrf != null) {
			updateCookie(request, response, "CSRF-TOKEN", csrf.getToken());
			updateCookie(request, response, "CSRF-HEADER", csrf.getHeaderName());
		}
		if (request.getMethod().equals("GET") || request.getMethod().equals("POST")) {
			if (ConstantController.isDebug) {
				System.out.println("Request-->" + request.getRequestURL());
			}

			if (request.getSession(false) != null) {
				if (ConstantController.isDebug) {
					System.out.println("Before-->" + request.getSession(false).getId());
				}
				if (ConstantController.isDebug) {
					System.out.println("Request with session-->" + request.getRequestURL());
				}

				request.changeSessionId();
				if (ConstantController.isDebug) {
					System.out.println("After-->" + request.getSession(false).getId());
				}
			}
			HttpServletResponse res = (HttpServletResponse) response;

			response.addHeader("X-FRAME-OPTIONS", mode);
			response.addHeader("Server", "ICICI Bank");
			response.addHeader("HTTP/1.1", "ICICI Bank");
			filterChain.doFilter(request, response);

		} else {
			if (request.getSession(false) != null) {
				if (ConstantController.isDebug) {
					System.out.println("Before-->" + request.getSession(false).getId());
				}
				request.changeSessionId();
				if (ConstantController.isDebug) {
					System.out.println("After-->" + request.getSession(false).getId());
				}
			}
			HttpServletResponse res = (HttpServletResponse) response;
			response.addHeader("X-FRAME-OPTIONS", mode);
			response.addHeader("Server", "ICICI Bank");
			response.addHeader("HTTP/1.1", "ICICI Bank");
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
		}
	}

	private void updateCookie(HttpServletRequest request, HttpServletResponse response, String cookieName,
			String value) {
		Cookie cookie = WebUtils.getCookie(request, cookieName);
		if (cookie == null || value != null && !value.equals(cookie.getValue())) {
			cookie = new Cookie(cookieName, value);
			cookie.setPath(request.getContextPath());
			response.addCookie(cookie);
		}
	}
}