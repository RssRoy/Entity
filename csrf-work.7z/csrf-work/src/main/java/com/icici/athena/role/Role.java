package com.icici.athena.role;

import org.springframework.security.core.GrantedAuthority;

public class Role implements GrantedAuthority{

	private String role_id;
	private String role_name;
	private String priviledges;
	
	public Role(){
		
	}
	public Role(String id,String name,String priviledge){
		this.role_id=id;
		this.role_name=name;
		this.priviledges=priviledge;
	}
	
	public String getRole_id() {
		return role_id;
	}

	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}

	public String getRole_name() {
		return role_name;
	}

	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}

	public String getPriviledges() {
		return priviledges;
	}

	public void setPriviledges(String priviledges) {
		this.priviledges = priviledges;
	}
	@Override
	public String getAuthority() {
		// TODO Auto-generated method stub
		return null;
	}

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub

	}*/

}
