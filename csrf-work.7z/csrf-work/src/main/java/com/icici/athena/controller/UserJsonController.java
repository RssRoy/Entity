package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.ldap.LdapContext;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.icici.athena.ldap.LDAPUtil;
import com.icici.athena.user.User;

import oracle.sql.TIMESTAMP;
@Controller
@Component 
@RestController
public class UserJsonController {

	
	//private String driverName = "oracle.jdbc.driver.OracleDriver";
		private String driverName=ConstantController.userDatabaseDriverClassName;
		//private String dbURL = "jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
		private String dbURL=ConstantController.userDatabaseUrl;
		//private String dbUser = "CXPSADM";
		private String dbUser=ConstantController.userDatabaseUserName;
		//private String dbPassword = "CXPSADM_123";
		private String dbPassword=ConstantController.userDatabasePassword;
	
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	
	@RequestMapping(value = "/verifyGranteeUser", method = RequestMethod.POST)
	public String verifyGranteeUser(@RequestParam("userid") String myuserid) throws IOException {
		if(isDebug){
			System.out.println(myuserid);
		}
		String ans="";
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("UserJsonController:---:You made it, take control of your database now!");
			}
			/*
			 
			String query = "SELECT COUNT(*) FROM "+ConstantController.userTable+" WHERE USER_ID='"+myuserid+"'";

			 */
			try {
				String sql = "SELECT * FROM "+ConstantController.userTable+" WHERE USER_ID=?";

				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myuserid.toUpperCase());
				rs = pstmt.executeQuery();
				if(rs.next()){
					ans="YES";
				}else{
					ans="NO";
				}
				pstmt.close();
				connection.close();
					
					
					try {
						LdapContext conn = LDAPUtil.getConnection(ConstantController.ldapUser,ConstantController.ldapPwd,ConstantController.ldapDc);
						LDAPUtil user = LDAPUtil.getUser(myuserid, conn);
						//System.out.println("USER CHECKED"+username);
						try{
							
							if(user.getUserName()!=null){
								if(isDebug){
									System.out.println(ans+"#"+user.getUserName());
								}
								return ans+"#"+user.getUserName();
							}
							
						}catch(Exception e){
							return "Failed";
						}
									
						conn.close();
						if(isDebug){
							System.out.println("Success!");
						}
						return ans+"#"+user.getUserName();
					} catch(Exception e) {
						//Failed to authenticate user or change password...
						e.printStackTrace();
						return "Failed";
					}
					
				

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return "Failed SQL";
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
					
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return  "Failed DATABASE CONNECTION";
		}
		
	}
	
	@RequestMapping(value = "/getJsonUser", method = RequestMethod.POST)
	public  String getJsonUser(@RequestParam("userid") String myuserid) throws IOException {
		JsonObject result=new JsonObject();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if(isDebug){
				System.out.println("~You made it, take control of your database now!");
			}

			try {
				
				if(isDebug){
					System.out.println(myuserid.toUpperCase());
				}
				String sql = "SELECT * FROM "+ConstantController.userTable+" WHERE user_id=?";//WHERE user_id='" + user_id + "' ;"
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myuserid.toUpperCase());
				rs = pstmt.executeQuery();
				while(rs.next()){
				//ResultSetMetaData rsmd = rs.getMetaData();
				result.addProperty("user_id",rs.getString("user_id"));
				result.addProperty("user_name",rs.getString("user_name"));
				if(rs.getObject("login_time") != null) {
					result.addProperty("login_time",(String) rs.getObject("login_time").toString());
				}else {
					result.addProperty("login_time","");
				}
				result.addProperty("is_locked",rs.getString("is_locked"));
					if(rs.getObject("lock_time")!=null)
						result.addProperty("lock_time", rs.getObject("lock_time").toString());
				result.addProperty("is_superuser",rs.getString("is_superuser"));
				result.addProperty("role_id",rs.getString("role_id"));
				result.addProperty("manager_id",rs.getString("manager_id"));
				
				}
				if(isDebug){
					System.out.println("~this is result" + result);
				}
				connection.close();
				return result.toString();
			} catch (SQLException  e) {
				if(isDebug){
					System.out.println("~error in stmt creation"+e.getMessage());
				}
				e.printStackTrace();
				return result.toString();
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("~Failed to make connection!");
			}
			return result.toString();
		}

	}
	
	@RequestMapping(value = "/getJsonRole", method = RequestMethod.POST)
	public  String getJsonRole(@RequestParam("roleid") String myroleid) throws IOException {
		JsonObject result=new JsonObject();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if(isDebug){
				System.out.println("~You made it, take control of your database now!");
			}

			try {
				
				
				if(isDebug){
					System.out.println(myroleid.toUpperCase());
				}
				String sql = "SELECT * FROM "+ConstantController.userRoleTable+" WHERE role_id=?";
				
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myroleid.toUpperCase());
				rs = pstmt.executeQuery();
				
				if(isDebug){
					System.out.println(sql);
				}
				
				while(rs.next()){
				//ResultSetMetaData rsmd = rs.getMetaData();
				result.addProperty("role_id",rs.getString("role_id"));
				result.addProperty("role_name",rs.getString("role_name"));
				result.addProperty("details",(String) rs.getObject("priviledges").toString());
				
				}
				if(isDebug){
					System.out.println("~this is result" + result);
				}
				pstmt.close();
				connection.close();
				return result.toString();
			} catch (SQLException  e) {
				if(isDebug){
					System.out.println("~error in stmt creation"+e.getMessage());
				}
				// e.printStackTrace();
				return result.toString();
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("~Failed to make connection!");
			}
			return result.toString();
		}

	}
	

	@RequestMapping(value = "/getJsonGrant", method = RequestMethod.POST)
	public  String getJsonGrant(@RequestParam("grantid") String mygrantid) throws IOException {
		JsonObject result=new JsonObject();

		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;

		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
				
				String sql = "SELECT * FROM "+ConstantController.userGrantTable+" WHERE UPPER(grant_id)=? ";
				
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, mygrantid.toUpperCase());
				rs = pstmt.executeQuery();
				if(isDebug){
					System.out.println(sql);
				}
				while (rs.next()) {
					
					result.addProperty("grant_id",rs.getString("grant_id"));
					result.addProperty("granter_name",rs.getString("granter_name"));
					result.addProperty("granter_id",(String) rs.getObject("granter_id").toString());
					result.addProperty("role_id", rs.getString("role_id"));
					result.addProperty("grantee_id",rs.getString("grantee_id"));
					result.addProperty("grantee_name", rs.getObject("grantee_name").toString());
					result.addProperty("can_grant",rs.getString("can_grant"));
					result.addProperty("app_id",rs.getString("app_id"));
					result.addProperty("is_valid_grant",rs.getString("is_valid_grant"));
					result.addProperty("modified_by",rs.getString("modified_by"));
					result.addProperty("modified_time",rs.getString("modified_time"));
					
				}
				
				if(isDebug){
					System.out.println("this is result" + result);
				}
				if (result.size() == 0) {
					if(isDebug){
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result.toString();
				}
				connection.close();
				return result.toString();
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in stmt creation");
				}
				// e.printStackTrace();
				return result.toString();
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			return result.toString();
		}

	}
	

	@RequestMapping(value = "/getJsonApp", method = RequestMethod.POST)
	public  String getJsonApp(@RequestParam("appid") String myappid) throws IOException {
		JsonObject result=new JsonObject();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
				
			
				String sql = "SELECT * FROM "+ConstantController.userAppTable+" WHERE UPPER(app_id)=?";
				
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myappid.toUpperCase());
				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					
					result.addProperty("app_id",rs.getString("app_id"));
					result.addProperty("app_name",rs.getString("app_name"));
					result.addProperty("user_id",(String) rs.getObject("user_id").toString());
					
					result.addProperty("created_date", rs.getObject("created_date").toString());
					result.addProperty("user_name",rs.getString("user_name"));
					
					
				}
				
				if(isDebug){
					System.out.println("this is result" + result);
				}
				if (result.size() == 0) {
					if(isDebug){
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result.toString();
				}
				connection.close();
				return result.toString();
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in stmt creation");
				}
				// e.printStackTrace();
				return result.toString();
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			return result.toString();
		}

	}
	
	
	
}
