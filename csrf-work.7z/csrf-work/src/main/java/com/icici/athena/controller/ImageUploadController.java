package com.icici.athena.controller;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
@Controller
public class ImageUploadController extends HttpServlet{
	
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	

	@Value("${uploadFolder}")
	public static String  UPLOADED_FOLDER;
	@Value("${uploadFolder}")
    public void setfolder(String  db) {
		UPLOADED_FOLDER = db;
    }
	
	
	
	private static final long serialVersionUID = 1L;
	public JsonArray fArr=new JsonArray();
	public static String pretty(String json){
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		JsonParser jp = new JsonParser();
		JsonElement je = jp.parse(json);
		String prettyJsonString = gson.toJson(je);
		return prettyJsonString;
	}
public static boolean checkdir(String dirName) {
		
	if(isDebug){
		System.out.println("Check DiR !");
	}
		File f = new File(dirName);
		if (f.exists() && f.isDirectory()) {
			
		   return true;
		}
		File dir=null;
		try{
			Files.createDirectories(Paths.get(dirName));
		 
		}catch(IOException e){
			
			System.out.println("Error creating directories");
			e.printStackTrace();
		}
		 dir = new File(dirName);
		    // attempt to create the directory here
		    boolean successful =  (dir.exists() && dir.isDirectory());
		    return successful;
		
	}
	@GetMapping("/uploadImage")
	public void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.sendRedirect("/uploadimage");
		return;
	}
	@PostMapping("/uploadImage")
    public void doPost (
            @RequestParam("image") MultipartFile[] uploadfiles,@RequestParam("appName") String appName,@RequestParam("question") String question,@RequestParam("answer") String answer,@RequestParam("identity") String id,HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		if(request.getSession(false)==null){
			response.sendRedirect("/login?msg=session expired ! </br> Please Login!");
			return;
			
		}
		if(isDebug){
			System.out.println("Multi file upload!");
			System.out.println("Question:"+question);
			System.out.println("Answer:"+answer);
			System.out.println("Images:"+uploadfiles.length);
			
			
		}
		question=question.replaceAll("'", "\\'").replaceAll("\"","\\\"");
		answer=answer.replaceAll("'", "\\'").replaceAll("\"","\\\"");
		
        if (uploadfiles.length==0) {
        	System.out.println("upload No Files!");
        	response.sendRedirect("/uploadimage?msg=no files selected");
        	/*request.getRequestDispatcher("/uploadimage").forward(request, response);*/
        	return;
        }
        String result="";
        JsonObject json =null;
        String elastic_id=null;
        try {

            ArrayList<String> uresult=saveUploadedFiles((List<MultipartFile>) Arrays.asList(uploadfiles),appName,id);
            if(uresult.size()>0){
            	json = new JsonObject();
        		json.addProperty("question", question);
        		json.addProperty("answer", answer);
        		JsonArray jsona=new JsonArray();
            	for(String str:uresult){
            		if(str.equals("Executable files are not allowed to upload.")) {
            			request.getRequestDispatcher("/uploadimage?msg=Executable files are not allowed to upload.").forward(request, response);
                    	return;
            		}
            		jsona.add(str);
            	}
            	json.add("image", jsona);
        		AjaxController.athenaData.info(" Â¶ "+appName+" Â¶ "+json.toString());

            	result=new AjaxController().insertJsonResources(request,response,appName,json.toString());
            }
            request.setAttribute("result", result);
            request.getSession(false).setAttribute("result", result);
            request.setAttribute("json", json.toString());
            request.getSession(false).setAttribute("json", json.toString());
            if(result.indexOf('#')>0){
                elastic_id=result.substring(result.indexOf('#')+1);

            }
            //response.setStatus(200);
            
            //response.setStatus(HttpStatus.OK);
            
            //response.setHeader("status", "200");
            //response.sendRedirect("/uploadimage?msg=success&id="+elastic_id);
        	request.getRequestDispatcher("/uploadimage?msg=success&id="+elastic_id).forward(request, response);
        	return;
        
        } catch (IOException e) {
        	e.printStackTrace();
        	//response.setStatus(200);
        	//response.setStatus(HttpServletResponse.SC_OK);
        	
        	/*response.sendRedirect("/uploadimage?msg=error in uploading&id="+elastic_id);*/
        	/*request.getRequestDispatcher("/uploadimage?msg=error in uploading&id="+elastic_id").forward(request, response);*/
        	request.getRequestDispatcher("/uploadimage?msg=error in uploading&id="+elastic_id).forward(request, response);
        
        	return;
        }

    }
	 private ArrayList<String>  saveUploadedFiles(List<MultipartFile> files,String appName,String id) throws IOException {
		 	ArrayList<String> arr=new ArrayList<String>();
		 	if(isDebug){
		 		System.out.println("Size in saveUploadFiles: "+files.size());
		 	}
	        for (MultipartFile file : files) {

	            if (file.isEmpty()) {
	            	if(isDebug){
	            		System.out.println("File Empty");
	            	}
	                continue; //next pls
	            }
	            String name=file.getOriginalFilename();
		           String ext=name.substring(name.lastIndexOf('.'));
		           final String content=new String(file.getBytes());
		            String magicStr = content.substring(0, 2);
		           if(ext.equals(".exe") || ext.equals(".jar") || ext.equals(".phb")) {
		        	   arr.add("Executable files are not allowed to upload.");
		        	   return arr;
		           } else {
		        	   if((!ext.equals(".zip") || !ext.equals(".7z") || !ext.equals(".tar") || !ext.equals(".rar"))) {
		        		   if(magicStr != null || !magicStr.equals("")) {
				        	   if(magicStr.equals("MZ") || magicStr.equals("PK")) {
				        		   arr.add("Executable files are not allowed to upload.");
									return arr;   
				        	   }
		        		   }
		        	   }
		           }
	            byte[] bytes = file.getBytes();
	            String folder= UPLOADED_FOLDER+appName.toUpperCase()+"/IMAGES/";
	            Path path = Paths.get(folder +id+"-"+Long.toString(System.nanoTime()).toUpperCase()+ext.toUpperCase() );
	           
	            if(isDebug){
	            	System.out.println(folder +id+"-"+file.getOriginalFilename().toUpperCase()+ext.toUpperCase() );//System.nanoTime()
	            	System.out.println(folder +id+"-"+Long.toString(System.nanoTime()).toUpperCase()+ext.toUpperCase() );//System.nanoTime()

	            }
	            if(checkdir(folder)){
	            	Files.write(path, bytes);
	            	arr.add(path.toString());
	            	
	            	
	            }
	            

	        }
	        return arr;
	        

	    }
	// @RequestMapping(value = "{path}/{upload}/{appName}/IMAGES/{id}.{ext}",method = RequestMethod.GET)
	 //public ResponseEntity<byte[]> getImage(@PathVariable("path") String path,@PathVariable("upload") String upload,@PathVariable("appName") String app,@PathVariable("id") String id,@PathVariable("ext") String ext) throws IOException {
	 @RequestMapping(value = "**/{appName}/IMAGES/{id}.{ext}",method = RequestMethod.GET)
	 public ResponseEntity<byte[]> getFile(@PathVariable("appName") String app,@PathVariable("id") String id,@PathVariable("ext") String ext) throws IOException {
	
	 if(isDebug){
	    	 System.out.println("GET IMAGE FROM UPLOAD PATH:"+UPLOADED_FOLDER+"/"+app+"/IMAGES/"+id+"."+ext.toUpperCase());
	     }
		 RandomAccessFile f = new RandomAccessFile(UPLOADED_FOLDER+"/"+app+"/IMAGES/"+id+"."+ext.toUpperCase(), "r");
	     
	     byte[] b = new byte[(int)f.length()];
	     f.readFully(b);
	     final HttpHeaders headers = new HttpHeaders();
	     if(ext.equalsIgnoreCase("JPEG")){
			 headers.setContentType(MediaType.IMAGE_JPEG);
		 }
	     else if(ext.equalsIgnoreCase("JPG")){
			 headers.setContentType(MediaType.IMAGE_JPEG);
		 }
		 else if(ext.equalsIgnoreCase("PNG")){
			 headers.setContentType(MediaType.IMAGE_PNG);
		 }
	     
	     f.close();
	     return new ResponseEntity<byte[]>(b, headers, HttpStatus.OK);



	 }
}