

package com.icici.athena;

import com.icici.athena.LoginServlet.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
@SpringBootApplication
public class DemoApplication extends SpringBootServletInitializer {
    public DemoApplication() {
        super();
        setRegisterErrorPageFilter(false); // <- this one to disable error page filteration
    }


	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		  setRegisterErrorPageFilter(false);
		return application.sources(DemoApplication.class);
	}
  
  
    public static void main(String[] args) throws Exception {
        SpringApplication.run(DemoApplication.class, args);
        new SessionServlet().resetAllUsers();
    }

}

