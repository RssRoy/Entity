package com.icici.athena.controller;

public class DashBoard {

	private String date =  null;
	private String maxInteractionUsers;
	private String activeUsers;
	
	public DashBoard(String dt, String MaxInt,String activeUsers) {
		this.date = dt;
		this.maxInteractionUsers = MaxInt;
		this.activeUsers = activeUsers;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String timestamp) {
		this.date = timestamp;
	}
	public String getMaxInteractionUsers() {
		return maxInteractionUsers;
	}
	public void setMaxInteractionUsers(String string) {
		this.maxInteractionUsers = string;
	}
	public String getActiveUsers() {
		return activeUsers;
	}
	public void setActiveUsers(String activeUsers) {
		this.activeUsers = activeUsers;
	}
	
}
