package com.icici.athena.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;

import javax.annotation.PreDestroy;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.icici.athena.controller.*;
import com.icici.athena.user.User;

@Controller
@RestController
public class DatabaseController {
	// private String driverName = "oracle.jdbc.driver.OracleDriver";
	private String driverName = ConstantController.userDatabaseDriverClassName;
	// private String dbURL = "jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
	private String dbURL = ConstantController.userDatabaseUrl;
	// private String dbUser = "CXPSADM";
	private String dbUser = ConstantController.userDatabaseUserName;
	// private String dbPassword = "CXPSADM_123";
	private String dbPassword = ConstantController.userDatabasePassword;

	//////////// create connection
	public Connection createUserConnection() {
		try {

			Class.forName(driverName);

		} catch (ClassNotFoundException e) {

			if (ConstantController.isDebug) {
				System.out.println("Where is your Oracle JDBC Driver?");
			}
			e.printStackTrace();
			return null;

		}

		if (ConstantController.isDebug) {
			System.out.println("Oracle JDBC Driver Registered!");
		}

		Connection connection = null;

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
			connection.setAutoCommit(false);
			return connection;
		} catch (SQLException e) {

			if (ConstantController.isDebug) {
				System.out.println("Connection Failed! Check output console");
			}
			e.printStackTrace();
			return null;

		}

	}

	/// elastic search app creation
	public int createElasticApp(String myappname) {

		String body = " {\"dynamic\": true,\"_all\": {\"analyzer\": \"nGram_analyzer\","
				+ "\"search_analyzer\": \"whitespace_analyzer\"} ,\"properties\": {\"answer\": {\"type\": \"text\","
				+ "\"index\":\"not_analyzed\"},\"question\": {\"type\": \"text\",\"index\": \"not_analyzed\"},"
				+ "\"conv_ans\":{\"type\":\"nested\"}}}";

		if (ConstantController.isDebug) {
			System.out.println("App Creation Body----" + body);
		}

		if (ConstantController.isDebug) {
			System.out.println("Passing the following params for App Creation in elasticsearch: \n 1.Appname : "
					+ myappname + "\nbody : " + body + "\n server ip : " + AjaxController.eserver + "\n Index name : "
					+ AjaxController.eindex);
		}
		try {
			myappname = URLEncoder.encode(myappname, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			if (ConstantController.isDebug) {
				System.out.println("Unsupported Encoding Exception in app creation in elasticsearch");
			}
			e1.printStackTrace();
			return -1;
		}
		// RestClient restClient80 = RestClient.builder(new
		// HttpHost("10.50.72.80", 9200, "http")).build();
		RestClient restClient80 = RestClient.builder(new HttpHost(AjaxController.eserver, 9200, "http")).build();

		HttpEntity entity80 = new NStringEntity(body.toString(), ContentType.APPLICATION_JSON);

		Response indexResponse80 = null;
		try {
			indexResponse80 = restClient80.performRequest("POST",
					"/" + AjaxController.eindex + "/" + myappname.toLowerCase() + "/_mapping",
					Collections.<String, String>emptyMap(), entity80);
		} catch (IOException e1) {

			if (ConstantController.isDebug) {
				System.out.println("IO Exception in app creation in elasticsearch");
			}
			try {
				restClient80.close();
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			e1.printStackTrace();
			return -1;
		}
		if (ConstantController.isDebug) {
			System.out.println("App Creation query posted to elasticsearch");
		}

		if (ConstantController.isDebug) {
			if (indexResponse80 == null) {
				System.out.println("RESPONSE CODE for 80--- is NULL");
				try {
					restClient80.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();

				}
				return -1;
			} else {
				if (ConstantController.isDebug) {
					System.out.println("RESPONSE CODE for 80---" + indexResponse80.getStatusLine().getStatusCode());
				}
			}
		}

		/////////////////////////////////////////////// Check if UAT or
		/////////////////////////////////////////////// Production
		if (AjaxController.eserver.equals(AjaxController.nextServer)) {
			System.out.println("FINAL RESPONSE CODE ---" + indexResponse80.getStatusLine().getStatusCode());
			try {
				restClient80.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			return indexResponse80.getStatusLine().getStatusCode();
		}
		RestClient restClient79 = RestClient.builder(new HttpHost(AjaxController.nextServer, 9200, "http")).build();

		HttpEntity entity79 = new NStringEntity(body.toString(), ContentType.APPLICATION_JSON);

		Response indexResponse79 = null;
		try {
			indexResponse79 = restClient79.performRequest("POST",
					"/" + AjaxController.eindex + "/" + myappname.toLowerCase() + "/_mapping",
					Collections.<String, String>emptyMap(), entity79);
		} catch (IOException e) {
			if (ConstantController.isDebug) {
				System.out.println("IO Exception in app creation in elasticsearch");
			}
			try {
				restClient80.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				restClient79.close();
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			e.printStackTrace();
			return -1;

		}
		if (ConstantController.isDebug) {
			System.out.println("App Creation query posted to elasticsearch");
		}

		if (ConstantController.isDebug) {
			if (indexResponse80 == null) {
				System.out.println("RESPONSE CODE for 79--- is NULL");
				try {
					restClient80.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					restClient79.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return -1;
			} else {
				if (ConstantController.isDebug) {
					System.out.println("RESPONSE CODE for 79---" + indexResponse80.getStatusLine().getStatusCode());
				}
			}
		}
		if (indexResponse79.getStatusLine().getStatusCode() == indexResponse80.getStatusLine().getStatusCode()) {
			try {
				restClient80.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				restClient79.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return indexResponse79.getStatusLine().getStatusCode();
		} else {
			try {
				restClient80.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				restClient79.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return -1;
		}

	}

	// find app by name
	public int findAppByName(String myappname) throws IOException {
		Connection connection = createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}

			try {

				String sql = "SELECT * FROM " + ConstantController.userAppTable + " WHERE app_name = ?";

				pstmt = connection.prepareStatement(sql);

				pstmt.setString(1, myappname.toString().toUpperCase());

				rs = pstmt.executeQuery();
				if (rs.next()) {
					if (ConstantController.isDebug) {
						System.out.println("APP exists");
					}
					return 1;
				} else {
					if (ConstantController.isDebug) {
						System.out.println("App doesn't  exists");
					}
					return -1;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return -1;
		}
	}

	// find app by id
	public int findAppById(String myappid) throws IOException {
		Connection connection = createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}

			try {

				String sql = "SELECT * FROM " + ConstantController.userAppTable + " WHERE app_id = ?";

				pstmt = connection.prepareStatement(sql);

				pstmt.setString(1, myappid.toString().toUpperCase());

				rs = pstmt.executeQuery();

				if (rs.next()) {
					if (ConstantController.isDebug) {
						System.out.println("APP exists");
					}
					return 1;
				} else {
					if (ConstantController.isDebug) {
						System.out.println("App doesn't  exists");
					}
					return -1;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return -1;
		}

	}

	@RequestMapping(value = "/insertApp", method = RequestMethod.POST)
	public int insertApp(@RequestParam(value = "myapp_name", required = false) String myappname,
			@RequestParam(value = "myuser_id", required = false) String myuserid,
			@RequestParam(value = "myuser_name", required = false) String myusername) throws IOException {

		myappname = UserController.refineName(myappname);
		myuserid = UserController.refineName(myuserid);
		myusername = UserController.refineName(myusername);

		Connection connection = createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println(
						"DatabaseController:You made it, take control of your database now! for insert app management");
			}

			try {

				if (findAppByName(myappname) == 1) {
					return 3;
				}
				String sql = "INSERT INTO " + ConstantController.userAppTable
						+ " (app_name,user_id,user_name,created_date) VALUES (?,?,?,SYSDATE)";
				pstmt = connection.prepareStatement(sql);
				/*
				 * stmt = connection.createStatement(); String query =
				 * "INSERT INTO "+ConstantController.
				 * userAppTable+" (app_id,app_name,user_id,user_name,created_date ) VALUES "
				 * + "('','"+myappname+"','"+myuserid+"','"+myusername+
				 * "',SYSDATE)";
				 */
				if (ConstantController.isDebug) {
					System.out.println("->" + myappname);
					System.out.println("->" + myuserid);
					System.out.println("->" + myusername);
				}

				pstmt.setString(1, myappname.toString().toUpperCase());
				pstmt.setString(2, myuserid.toString().toUpperCase());
				pstmt.setString(3, myusername.toString().toUpperCase());

				if (ConstantController.isDebug) {
					System.out.println(sql);
					ParameterMetaData pmtdt = pstmt.getParameterMetaData();
					int count = pmtdt.getParameterCount();
					System.out.println("Insert App SQL ????? ?" + count);
					for (int i = 1; i <= count; i++) {
						System.out
								.println("?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
					}
				}
				int x = pstmt.executeUpdate();
				if (x > 0) {
					System.out.println("App Successfully Inserted");
					// create App type in Elasticsearch
					int elasticResp = createElasticApp(myappname);
					if (elasticResp != -1) {
						if (ConstantController.isDebug) {
							System.out.println("App Created and Inserted and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (ConstantController.isDebug) {
							System.out.println("return 1");
						}
						return 1;
					} else {
						connection.rollback();
						if (ConstantController.isDebug) {
							System.out.println(
									"App Created but error in elasticsearch so rollback all changes by this connection. ");
						}

						return -1;
					}

				} else {
					System.out.println("Insert Failed");

					pstmt.close();
					connection.close();
					return -1;
				}
			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation for insert app management");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection for insert app management!");
			}
			return -1;
		}
	}

	// Find Grant
	public int findGrant(String mygranteeid, String myappid, String myroleid, String cangrant, String isvalidgrant)
			throws IOException {
		Connection connection = createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println(
						"DatabaseController:You made it, take control of your database now for find grant management!");
			}

			try {

				String sql = "SELECT * FROM " + ConstantController.userGrantTable
						+ " WHERE grantee_id=? AND app_id=? AND role_id=? AND can_grant=? AND is_valid_grant=?";

				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, mygranteeid.toString().toUpperCase());
				pstmt.setString(2, myappid.toString().toUpperCase());
				pstmt.setString(3, myroleid.toString().toUpperCase());
				pstmt.setString(4, cangrant.toString().toUpperCase());
				pstmt.setString(5, isvalidgrant.toString().toUpperCase());

				rs = pstmt.executeQuery();
				if (rs.next()) {
					if (ConstantController.isDebug) {
						System.out.println("GRANT  exists");
					}
					return 1;
				} else {
					if (ConstantController.isDebug) {
						System.out.println("GRANT  doesn't  exists");
					}
					return -1;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation for find grant management");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return -1;
		}

	}

	// Insert Grant
	@RequestMapping(value = "/insertGrant", method = RequestMethod.POST)
	public int insertGrant(

			@RequestParam(value = "mygrant_id", required = false) String mygrantid,

			@RequestParam(value = "mygranter_id", required = false) String mygranterid,
			@RequestParam(value = "mygranter_name", required = false) String mygrantername,
			@RequestParam(value = "myrole_id", required = false) String myroleid,
			@RequestParam(value = "myapp_id", required = false) String myappid,
			@RequestParam(value = "mygrantee_id", required = false) String mygranteeid,
			@RequestParam(value = "mygrantee_name", required = false) String mygranteename,
			@RequestParam(value = "can_grant", required = false) String cangrant,
			@RequestParam(value = "is_validGrant", required = false) String isvalidgrant,

			HttpServletRequest request) throws IOException {

		
		if(request.getSession(false)==null && request.getSession(false).getAttribute("user")==null){
			return -1;
		}
		User user=(User)request.getSession(false).getAttribute("user");
		
		if (ConstantController.isDebug) {
			System.out.println("insert Grant: ");
			System.out.println("Granter Name: " + mygrantername);
			System.out.println("Granter ID: " + mygranterid);
			System.out.println("Grantee Name: " + mygranteename);
			System.out.println("Grantee ID: " + mygranteeid);

		}

		mygrantername = UserController.refineName(mygrantername);
		mygranteename = UserController.refineName(mygranteename);
		mygranterid = UserController.refineName(mygranterid);
		mygranteeid = UserController.refineName(mygranteeid);

		mygrantid = mygrantid.toUpperCase();
		mygranterid = mygranterid.toUpperCase();
		mygrantername = mygrantername.toUpperCase();
		myroleid = myroleid.toUpperCase();
		myappid = myappid.toUpperCase();
		mygranteeid = mygranteeid.toUpperCase();
		mygranteename = mygranteename.toUpperCase();
		cangrant = cangrant.toUpperCase();
		isvalidgrant = isvalidgrant.toUpperCase();

		if (ConstantController.isDebug) {
			System.out.println("insert Grant refine: ");
			System.out.println("Granter Name: " + mygrantername);
			System.out.println("Granter ID: " + mygranterid);
			System.out.println("Grantee Name: " + mygranteename);
			System.out.println("Grantee ID: " + mygranteeid);

		}

		Connection connection = createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println(
						"DatabaseController:You made it, take control of your database now! for insert grant management");
			}

			try {

				if (findGrant(mygranteeid, myappid, myroleid, cangrant, isvalidgrant) == 1) {
					if (ConstantController.isDebug) {
						System.out.println("Return 3: Exists");
					}
					return 3;
				} else {
					if (ConstantController.isDebug) {
						System.out.println("GRANT CAN BE INSERTED");
					}
				}
				/*
				 * /////// sql = "INSERT INTO "+ConstantController.
				 * userGrantTable+" (grant_id,granter_id,granter_name,role_id,app_id,grantee_id,grantee_name,can_grant,is_valid_grant ) VALUES "
				 * + "('','" + mygranterid + "','" + mygrantername + "','" +
				 * myroleid + "','" + myappid + "','" + mygranteeid + "','" +
				 * mygranteename + "','" + cangrant + "','" + isvalidgrant +
				 * "')";
				 * 
				 * sql =
				 * "UPDATE "+ConstantController.userGrantTable+" SET grant_id='"
				 * + mygrantid + "',granter_id='" + mygranterid +
				 * "',granter_name='" + mygrantername + "',role_id='" + myroleid
				 * + "',app_id='" + myappid + "',grantee_id='" + mygranteeid +
				 * "',grantee_name='" + mygranteename + "',can_grant='" +
				 * cangrant + "',is_valid_grant='" + isvalidgrant +
				 * "' WHERE grant_id='" + mygrantid + "'";
				 * 
				 * ///////
				 */
				if (mygrantid.trim().equals("NEW")) {

					String sql = "INSERT INTO " + ConstantController.userGrantTable
							+ " (granter_id,granter_name,role_id,app_id,grantee_id,grantee_name,can_grant,is_valid_grant,modified_by,modified_time) VALUES (?,?,?,?,?,?,?,?,?,SYSDATE)";
					pstmt = connection.prepareStatement(sql);

					pstmt.setString(1, mygranterid.toString().toUpperCase());
					pstmt.setString(2, mygrantername.toString().toUpperCase());
					pstmt.setString(3, myroleid.toString().toUpperCase());
					pstmt.setString(4, myappid.toString().toUpperCase());
					pstmt.setString(5, mygranteeid.toString().toUpperCase());
					pstmt.setString(6, mygranteename.toString().toUpperCase());
					pstmt.setString(7, cangrant.toString().toUpperCase());
					pstmt.setString(8, isvalidgrant.toString().toUpperCase());
					pstmt.setString(9, user.getUser_name());

					if (ConstantController.isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("Insert Grant SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
						System.out.println(mygranterid.toString().toUpperCase());
						System.out.println(mygrantername.toString().toUpperCase());
						System.out.println(myroleid.toString().toUpperCase());
						System.out.println(myappid.toString().toUpperCase());
						System.out.println(mygranteeid.toString().toUpperCase());
						System.out.println(mygranteename.toString().toUpperCase());
						System.out.println(cangrant.toString().toUpperCase());
						System.out.println(isvalidgrant.toString().toUpperCase());
					}
					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("Grant Successfully Inserted");

						if (ConstantController.isDebug) {
							System.out.println("Grant Inserted and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (ConstantController.isDebug) {
							System.out.println("return 1");
						}
						return 1;

					} else {
						System.out.println("Insert Failed");

						pstmt.close();
						connection.close();
						return -1;
					}
				} else {
					String sql = "UPDATE  " + ConstantController.userGrantTable + " SET " + "grant_id=?," // 1
							+ "granter_id=?," // 2
							+ "granter_name=?," // 3
							+ "role_id=?," // 4
							+ "app_id=?," // 5
							+ "grantee_id=?," // 6
							+ "grantee_name=?," // 7
							+ "can_grant=?," // 8
							+ "is_valid_grant=?,"// 9
							+ "modified_by=?,"//10
							+ "modified_time=SYSDATE"
							+ " WHERE grant_id=?";// 11

					pstmt = connection.prepareStatement(sql);

					pstmt.setString(1, mygrantid.toString().toUpperCase());
					pstmt.setString(2, mygranterid.toString().toUpperCase());
					pstmt.setString(3, mygrantername.toString().toUpperCase());
					pstmt.setString(4, myroleid.toString().toUpperCase());
					pstmt.setString(5, myappid.toString().toUpperCase());
					pstmt.setString(6, mygranteeid.toString().toUpperCase());
					pstmt.setString(7, mygranteename.toString().toUpperCase());
					pstmt.setString(8, cangrant.toString().toUpperCase());
					pstmt.setString(9, isvalidgrant.toString().toUpperCase());
					pstmt.setString(10, user.getUser_name());

					pstmt.setString(11, mygrantid.toString().toUpperCase());

					if (ConstantController.isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  Grant SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
					}

					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("Grant Successfully Updated");

						if (ConstantController.isDebug) {
							System.out.println("Grant Updated and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (ConstantController.isDebug) {
							System.out.println("return 1");
						}
						return 1;

					} else {
						System.out.println("Update Grant Failed");

						pstmt.close();
						connection.close();
						return -1;
					}
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					e.printStackTrace();
					System.out.println(e.getMessage());
					System.out.println("DatabaseController:Error in insert stmt creation for insert grant management");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection for insert grant management!");
			}
			return -1;
		}

	}

	// Find User
	public int findUserById(String myuserid) throws IOException {
		Connection connection = createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}

			try {

				String sql = "SELECT * FROM " + ConstantController.userTable + " WHERE user_id=?";

				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myuserid.toString().toUpperCase());

				rs = pstmt.executeQuery();
				if (rs.next()) {
					if (ConstantController.isDebug) {
						System.out.println("USER  exists");
					}
					return 1;
				} else {
					if (ConstantController.isDebug) {
						System.out.println("USER  doesn't  exists");
					}
					return -1;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return -1;
		}

	}

	// Update Login Time:
	public int updateLoginTime(String myuserid){
		if(ConstantController.isDebug){
			System.out.println("DatabaseController :User LOGIN TIME UPDATED!");
		}
		Connection connection=createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if(ConstantController.isDebug){
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}

			try {
				
			
				if (findUserById(myuserid)==1) {
					String sql = "UPDATE  "+ConstantController.userTable +" SET "
								+" last_login=login_time ,"
								+ " login_time=SYSDATE ,"
								+"  active=?"//1
								+"  WHERE user_id=?";//2
					
			
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1,"YES");

					pstmt.setString(2, myuserid.toString().toUpperCase());
					if(ConstantController.isDebug){
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  USER SQL ????? ?"+count);
						for (int i=1;i<=count;i++){
							System.out.println("?"+i+"?????"+pmtdt.getParameterTypeName(i)+pmtdt.getParameterType(i));
						}
					}
			
						int x = pstmt.executeUpdate();
				        if (x > 0){
				        	System.out.println("USER Login Time   Successfully Updated");
				        
				        		if(ConstantController.isDebug){
									System.out.println("USER   Login Time  Updated and Commited");
								}
				        		connection.commit();
				        		pstmt.close();
								connection.close();
								if(ConstantController.isDebug){
									System.out.println("return 1");
								}
				        		return 1;
				        	
				        }else{
				        	System.out.println("Update User Failed");
			
							pstmt.close();
							connection.close();
				        	return -1;
				        }
				}
			}catch (Exception e) {
				if(ConstantController.isDebug){
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {
					
					connection.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
					
				}
				return -1;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			return -1;	
		}else {
			if(ConstantController.isDebug){
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return -1;
		}	
	        
	}


	@RequestMapping(value = "/insertUser", method = RequestMethod.POST)
	public int insertUser(@RequestParam(value = "myuser_id", required = false) String myuserid,
			@RequestParam(value = "myuser_name", required = false) String myusername,
			@RequestParam(value = "myrole_id", required = false) String myroleid,
			@RequestParam(value = "mymanager_id", required = false) String mymanagerid,
			@RequestParam(value = "myis_superuser", required = false) String myissuperuser,
			@RequestParam(value = "myis_locked", required = false) String myislocked,
			@RequestParam(value = "operation", required = false) String operation, HttpServletRequest request)
			throws IOException {

		myuserid = myuserid.toUpperCase();

		myusername = myusername.toUpperCase();
		myroleid = myroleid.toUpperCase();
		mymanagerid = mymanagerid.toUpperCase();
		myissuperuser = myissuperuser.toUpperCase();
		myislocked = myislocked.toUpperCase();

		Connection connection = createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}

			try {

				if (findUserById(myuserid) == 1) {
					if (operation.toLowerCase().equals("create")) {
						if (ConstantController.isDebug) {
							System.out.println("USER Already exist.");
						}
						return 3;
					} else {
						if (ConstantController.isDebug) {
							System.out.println("USER WILL BE UPDATED.");
						}
					}

				} else {
					if (ConstantController.isDebug) {
						System.out.println("USER CAN BE INSERTED");
					}
				}
				/*
				 * ///////
				 * 
				 * query = "INSERT INTO "+ConstantController.
				 * userTable+" (user_id, user_name,manager_id,login_time,is_locked,lock_time,is_superuser,role_id ) "
				 * + "VALUES " + "('" + myuserid + "','" + myusername + "','" +
				 * mymanagerid + "',SYSDATE,'" + myislocked + "',SYSDATE,'" +
				 * myissuperuser + "','" + myroleid + "')"; query =
				 * "UPDATE  "+ConstantController.userTable+" SET user_id='" +
				 * myuserid + "', user_name='" + myusername + "',manager_id='" +
				 * mymanagerid + "',is_locked='" + myislocked +
				 * "',lock_time='',is_superuser='" + myissuperuser +
				 * "',role_id='" + myroleid + "'  " + "WHERE USER_ID='" +
				 * myuserid + "'";
				 * 
				 * ///////
				 */

				if (findUserById(myuserid) == 1) {
					String sql = "UPDATE  " + ConstantController.userTable + " SET " + "user_id=?," // 1
							+ "user_name=?,"// 2
							+ "manager_id=?,"// 3
							+ "is_locked=?,"// 4
							+ "lock_time=''," + "is_superuser=?,"// 5
							+ "role_id=?" // 6
							+ "WHERE USER_ID=?";// 7

					pstmt = connection.prepareStatement(sql);

					pstmt.setString(1, myuserid.toString().toUpperCase());
					pstmt.setString(2, myusername.toString().toUpperCase());
					pstmt.setString(3, mymanagerid.toString().toUpperCase());
					pstmt.setString(4, myislocked.toString().toUpperCase());
					pstmt.setString(5, myissuperuser.toString().toUpperCase());
					pstmt.setString(6, myroleid.toString().toUpperCase());
					pstmt.setString(7, myuserid.toString().toUpperCase());

					if (ConstantController.isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  USER SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
					}

					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("USER  Successfully Updated");

						if (ConstantController.isDebug) {
							System.out.println("USER Updated and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (ConstantController.isDebug) {
							System.out.println("return 1");
						}
						return 2;

					} else {
						System.out.println("Update User Failed");

						pstmt.close();
						connection.close();
						return -1;
					}

				} else {

					String sql = "INSERT INTO " + ConstantController.userTable
							+ " (user_id, user_name,manager_id,login_time,is_locked,lock_time,is_superuser,role_id) VALUES (?,?,?,NULL,?,NULL,?,?)";
					pstmt = connection.prepareStatement(sql);

					pstmt.setString(1, myuserid.toString().toUpperCase());
					pstmt.setString(2, myusername.toString().toUpperCase());
					pstmt.setString(3, mymanagerid.toString().toUpperCase());
					pstmt.setString(4, myislocked.toString().toUpperCase());
					pstmt.setString(5, myissuperuser.toString().toUpperCase());
					pstmt.setString(6, myroleid.toString().toUpperCase());

					if (ConstantController.isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("Insert USER SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
					}
					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("USER Successfully Inserted");

						if (ConstantController.isDebug) {
							System.out.println("USER Inserted and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (ConstantController.isDebug) {
							System.out.println("return 1");
						}
						return 1;

					} else {
						System.out.println("Insert Failed");

						pstmt.close();
						connection.close();
						return -1;
					}
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return -1;
		}

	}

	// Find App Properties
	public int findAppPropById(String myappid) throws IOException {
		Connection connection = createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}

			try {
				String sql = "SELECT * FROM " + ConstantController.userAppPropTable + " WHERE  app_id=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myappid.toString().toUpperCase());

				rs = pstmt.executeQuery();
				if (rs.next()) {
					if (ConstantController.isDebug) {
						System.out.println("App Properties  exists");
					}
					return 1;
				} else {
					if (ConstantController.isDebug) {
						System.out.println("App Properties   doesn't  exists");
					}
					return -1;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return -1;
		}

	}

	@RequestMapping(value = "/insertAppProperty", method = RequestMethod.POST)
	public int insertAppProperty(

			@RequestParam(value = "app_id", required = false) String myappid,

			@RequestParam(value = "app_name", required = false) String myappname,
			@RequestParam(value = "app_visibility", required = false) String myappvisibility,
			@RequestParam(value = "app_sr_link", required = false) String myappsrlink,
			@RequestParam(value = "app_welcome_msg", required = false) String myappwelcomemsg,

			HttpServletRequest request) throws IOException {

		// '||chr(38)||'
		
		
		if(request.getSession(false)==null && request.getSession(false).getAttribute("user")==null){
			return -1;
		}
		User user=(User)request.getSession(false).getAttribute("user");
		myappname = myappname.toUpperCase();
		myappid = myappid.toUpperCase();

	
		myappvisibility = myappvisibility.toUpperCase();

		if (ConstantController.isDebug) {
			System.out.println("AppPropertiesController: ");
			System.out.println("app Name: " + myappname);
			System.out.println("App ID: " + myappid);
			System.out.println("myappsrlink : " + myappsrlink);
			System.out.println("myappvisibility : " + myappvisibility);
			System.out.println("myappwelcomemsg : " + myappwelcomemsg);
		}

		Connection connection = createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}

			try {

				if (findAppPropById(myappid) == 1) {
					if (ConstantController.isDebug) {
						System.out.println("App Properties  WILL BE UPDATED.");
					}
					// return 3;
				} else {
					if (ConstantController.isDebug) {
						System.out.println("App Properties CAN BE INSERTED");
					}
				}
				/*
				 * ///////
				 * 
				 * query =
				 * "UPDATE "+ConstantController.userAppPropTable+" SET app_id='"
				 * + myappid + "',app_name='" + myappname + "',app_visibility='"
				 * + myappvisibility + "',app_sr_link='" + myappsrlink +
				 * "',app_welcome_msg='"+myappwelcomemsg+"' WHERE app_id='"
				 * +myappid+"'";
				 * 
				 * query = "INSERT INTO "+ConstantController.
				 * userAppPropTable+" (app_id,app_name,app_visibility,app_sr_link,app_welcome_msg ) VALUES "
				 * + "('"+myappid+"','" + myappname + "','" + myappvisibility +
				 * "','" + myappsrlink +"','"+myappwelcomemsg+"')";
				 * 
				 * query="SELECT COUNT(*) FROM "+ConstantController.
				 * userAppPropTable+" WHERE  app_id='"+myappid+"'";
				 * 
				 * ///////
				 */

				if (findAppPropById(myappid) == 1) {
					String sql = "UPDATE " + ConstantController.userAppPropTable + " SET " 
							+ "app_id=?," // 1
							+ "app_name=?," // 2
							+ "app_visibility=?,"// 3
							+ "app_sr_link=?," // 4
							+ "app_welcome_msg=?,"// 5
							+ "modified_by=?,"//6
							+ "modified_time=SYSDATE "
							+ " WHERE app_id=?"; // 7

					pstmt = connection.prepareStatement(sql);

					pstmt.setString(1, myappid.toString().toUpperCase());
					pstmt.setString(2, myappname.toString().toUpperCase());
					pstmt.setString(3, myappvisibility.toString().toUpperCase());
					pstmt.setString(4, myappsrlink.toString());
					pstmt.setString(5, myappwelcomemsg.toString());
					pstmt.setString(6, user.getUser_name());
					
					pstmt.setString(7, myappid.toString().toUpperCase());

					if (ConstantController.isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  App Properties SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
					}

					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("App Properties  Successfully Updated");

						if (ConstantController.isDebug) {
							System.out.println("App Properties Updated and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (ConstantController.isDebug) {
							System.out.println("return 1");
						}
						return 1;

					} else {
						System.out.println("Update App Properties Failed");

						pstmt.close();
						connection.close();
						return -1;
					}

				} else {

					String sql = "INSERT INTO " + ConstantController.userAppPropTable
							+ " (app_id,app_name,app_visibility,app_sr_link,app_welcome_msg,modified_by,modified_time ) VALUES (?,?,?,?,?,?,SYSDATE)";

					pstmt = connection.prepareStatement(sql);

					pstmt.setString(1, myappid.toString().toUpperCase());
					pstmt.setString(2, myappname.toString().toUpperCase());
					pstmt.setString(3, myappvisibility.toString().toUpperCase());
					pstmt.setString(4, myappsrlink.toString());
					pstmt.setString(5, myappwelcomemsg.toString());
					pstmt.setString(6, user.getUser_name());
					
					

					if (ConstantController.isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("Insert App Properties SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
					}
					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("App Properties Successfully Inserted");

						if (ConstantController.isDebug) {
							System.out.println("App properties Inserted and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (ConstantController.isDebug) {
							System.out.println("return 1");
						}
						return 1;

					} else {
						System.out.println("Insert Failed");

						pstmt.close();
						connection.close();
						return -1;
					}
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return -1;
		}

	}

}
