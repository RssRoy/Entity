package com.icici.athena.app;
import oracle.sql.TIMESTAMP;

public class AppProp {
	private String app_id;
	private String app_name;
	private String app_sr_link;
	private String app_visibility;
	private String app_welcome_msg;
	private TIMESTAMP modified_time;
	private String modified_by;
	
	
	
	
	public String getApp_sr_link() {
		return app_sr_link;
	}
	
	public void setApp_sr_link(String app_sr_link) {
		this.app_sr_link = app_sr_link;
	}
	
	
	public String getApp_visibility() {
		return app_visibility;
	}
	public void setApp_visibility(String app_visibility) {
		this.app_visibility = app_visibility;
	}
	
	
	
	public String getApp_welcome_msg() {
		return app_welcome_msg;
	}
	public void setApp_welcome_msg(String app_welcome_msg) {
		this.app_welcome_msg = app_welcome_msg;
	}
	
	
	
	public String getApp_name() {
		return app_name;
	}
	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}
	
	
	public String getApp_id() {
		return app_id;
	}
	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

	public TIMESTAMP getModified_time() {
		return modified_time;
	}

	public void setModified_time(TIMESTAMP modified_time) {
		this.modified_time = modified_time;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	
	

}
