package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.icici.athena.grant.Grant;
import com.icici.athena.user.User;

import oracle.sql.TIMESTAMP;

@Controller
@Component
@RestController
public class UserSearchController {

	// private String driverName = "oracle.jdbc.driver.OracleDriver";
	private String driverName = ConstantController.userDatabaseDriverClassName;
	// private String dbURL = "jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
	private String dbURL = ConstantController.userDatabaseUrl;
	// private String dbUser = "CXPSADM";
	private String dbUser = ConstantController.userDatabaseUserName;
	// private String dbPassword = "CXPSADM_123";
	private String dbPassword = ConstantController.userDatabasePassword;

	@Value("${myDebug}")
	public static boolean isDebug;

	@Value("${myDebug}")
	public void setdebug(boolean db) {
		isDebug = db;
	}

	public ArrayList<User> searchUserList = null;
	public String searchLiveUserList = null;
	ArrayList<Grant> searchGrantList = null;
	String searchLiveGrantList = null;

	@RequestMapping(value = "/searchUser", method = RequestMethod.POST)
	public ArrayList<User> searchUser(@RequestParam("userid") String userid, @RequestParam("issuper") String issuper,
			@RequestParam("value") String value) throws IOException {

		ArrayList<User> resultlist = new ArrayList<User>();

		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;

		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			 * String query = "SELECT * FROM "+ConstantController.
			 * userTable+" WHERE UPPER(user_id) like '%"+value.toUpperCase()
			 * +"%' or UPPER(user_name) like '%"+value.toUpperCase()+"%'";
			 * 
			 * if(issuper.trim().equalsIgnoreCase("YES")){ query =
			 * "SELECT * FROM "+ConstantController.
			 * userTable+" WHERE UPPER(user_id) like '%"+value.toUpperCase()
			 * +"%' or UPPER(user_name) like '%"+value.toUpperCase()+"%'";
			 * 
			 * }else{ query = "SELECT * FROM "+ConstantController.
			 * userTable+" WHERE ( UPPER(user_id) like '%"+value.toUpperCase()
			 * +"%' AND UPPER(manager_id)='"+userid.toUpperCase()
			 * +"' )  or ( UPPER(user_name) like '%"+value.toUpperCase()
			 * +"%'  AND UPPER(manager_id)='"+userid.toUpperCase()+"' )";
			 * 
			 * }
			 */
			try {
				String sql = "SELECT * FROM " + ConstantController.userTable
						+ " WHERE UPPER(user_id) like ? or UPPER(user_name) like ?";

				pstmt = null;

				if (issuper.trim().equalsIgnoreCase("YES")) {
					sql = "SELECT * FROM " + ConstantController.userTable
							+ " WHERE UPPER(user_id) like ? or UPPER(user_name) like ?";

					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, "%" + value.toUpperCase() + "%");
				} else {
					sql = "SELECT * FROM " + ConstantController.userTable
							+ " WHERE ( UPPER(user_id) like ?  or  UPPER(user_name) like ? ) AND UPPER(manager_id)=? ";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, userid.toUpperCase());
				}

				rs = pstmt.executeQuery();

				while (rs.next()) {
					// ResultSetMetaData rsmd = rs.getMetaData();
					User temp = new User();
					temp.setUser_id(rs.getString("user_id"));
					temp.setUser_name(rs.getString("user_name"));
					if(rs.getObject("login_time") != null) {
						temp.setLogin_time((TIMESTAMP)rs.getObject("login_time"));
					}else {
						temp.setLogin_time(new TIMESTAMP());
					}
					//temp.setLogin_time((TIMESTAMP) rs.getObject("login_time"));
					temp.setIs_locked(rs.getString("is_locked"));
					temp.setLock_time((TIMESTAMP) rs.getObject("lock_time"));
					temp.setIs_superuser(rs.getString("is_superuser"));
					temp.setRole_id(rs.getString("role_id"));
					temp.setManager_id(rs.getString("manager_id"));
					resultlist.add(temp);

				}

				if (isDebug) {
					System.out.println("~this is result" + resultlist);
				}

				if (resultlist.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					pstmt.close();
					connection.close();
					searchUserList = resultlist;

					return resultlist;
				} else {
					pstmt.close();
					connection.close();
					searchUserList = resultlist;
					return resultlist;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				searchUserList = resultlist;
				return resultlist;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			searchUserList = resultlist;
			return resultlist;
		}

	}

	@RequestMapping(value = "/searchLiveUser", method = RequestMethod.POST)
	public String searchLiveUser(@RequestParam("userid") String userid, @RequestParam("issuper") String issuper,
			@RequestParam("value") String value) throws IOException {
		JsonArray resultlist = new JsonArray();
		
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;

		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			 String query = "SELECT * FROM " + ConstantController.userTable + " WHERE UPPER(user_id) like '%"
						+ value.toUpperCase() + "%' or UPPER(user_name) like '%" + value.toUpperCase() + "%'";

				if (issuper.trim().equalsIgnoreCase("YES")) {
					query = "SELECT * FROM " + ConstantController.userTable + " WHERE UPPER(user_id) like '%"
							+ value.toUpperCase() + "%' or UPPER(user_name) like '%" + value.toUpperCase() + "%'";

				} else {
					query = "SELECT * FROM " + ConstantController.userTable + " WHERE ( UPPER(user_id) like '%"
							+ value.toUpperCase() + "%' AND UPPER(manager_id)='" + userid.toUpperCase()
							+ "' )  or ( UPPER(user_name) like '%" + value.toUpperCase() + "%'  AND UPPER(manager_id)='"
							+ userid.toUpperCase() + "' )";

				}
			 */
			try {
				String sql ="SELECT * FROM " + ConstantController.userTable + " WHERE UPPER(user_id) like ? or UPPER(user_name) like ?";

				pstmt = null;

				if (issuper.trim().equalsIgnoreCase("YES")) {
					sql = "SELECT * FROM " + ConstantController.userTable + " WHERE UPPER(user_id) like ? or UPPER(user_name) like ?";

					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, "%" + value.toUpperCase() + "%");
				} else {
					sql = "SELECT * FROM " + ConstantController.userTable
							+ " WHERE ( UPPER(user_id) like ?  or  UPPER(user_name) like ? ) AND UPPER(manager_id)=? ";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, userid.toUpperCase());
				}

				rs = pstmt.executeQuery();

				while (rs.next()) {
					JsonObject result = new JsonObject();
					// ResultSetMetaData rsmd = rs.getMetaData();
					result.addProperty("user_id", rs.getString("user_id"));
					result.addProperty("user_name", rs.getString("user_name"));
					//result.addProperty("login_time", (String) rs.getObject("login_time").toString());
					if(rs.getObject("login_time") != null) {
						result.addProperty("login_time",(String) rs.getObject("login_time").toString());
					}else {
						result.addProperty("login_time","");
					}
					result.addProperty("is_locked", rs.getString("is_locked"));
					if (rs.getObject("lock_time") != null)
						result.addProperty("lock_time", rs.getObject("lock_time").toString());
					result.addProperty("is_superuser", rs.getString("is_superuser"));
					result.addProperty("role_id", rs.getString("role_id"));
					result.addProperty("manager_id", rs.getString("manager_id"));
					resultlist.add(result);
				}

				if (isDebug) {
					System.out.println("~this is result" + resultlist);
				}

				if (resultlist.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					pstmt.close();
					connection.close();
					searchLiveUserList = resultlist.toString();
					return resultlist.toString();
				} else {
					pstmt.close();
					connection.close();
					searchLiveUserList = resultlist.toString();
					return resultlist.toString();
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				searchLiveUserList = resultlist.toString();
				return resultlist.toString();
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			searchLiveUserList = resultlist.toString();
			return resultlist.toString();
		}

	}

	@RequestMapping(value = "/searchGrant", method = RequestMethod.POST)
	public ArrayList<Grant> searchGrant(@RequestParam("userid") String userid, @RequestParam("issuper") String issuper,
			@RequestParam("value") String value) throws IOException {

		ArrayList<Grant> resultlist = new ArrayList<Grant>();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;

		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			 String query = "SELECT * FROM " + ConstantController.userGrantTable
						+ " WHERE ( UPPER(grantee_id) like '%" + value.toUpperCase() + "%' AND UPPER(granter_id)='"
						+ userid.toUpperCase() + "' ) or ( UPPER(grantee_name) like '%" + value.toUpperCase()
						+ "%'  AND UPPER(granter_id)='" + userid.toUpperCase() + "' )";

				if (issuper.trim().equalsIgnoreCase("YES")) {
					query = "SELECT * FROM " + ConstantController.userGrantTable + " WHERE UPPER(grantee_id) like '%"
							+ value.toUpperCase() + "%' or UPPER(grantee_name) like '%" + value.toUpperCase() + "%'";

				} else {
					query = "SELECT * FROM " + ConstantController.userGrantTable + " WHERE ( UPPER(grantee_id) like '%"
							+ value.toUpperCase() + "%' AND UPPER(granter_id)='" + userid.toUpperCase()
							+ "' ) or ( UPPER(grantee_name) like '%" + value.toUpperCase()
							+ "%'  AND UPPER(granter_id)='" + userid.toUpperCase() + "' )";

				}
			 */
			try {
				String sql = "SELECT * FROM " + ConstantController.userGrantTable
						+ " WHERE ( UPPER(grantee_id) like ?  or  UPPER(grantee_name) like ? )  AND UPPER(granter_id)=? ";

				pstmt = null;

				if (issuper.trim().equalsIgnoreCase("YES")) {
					sql = "SELECT * FROM " + ConstantController.userGrantTable
							+ " WHERE  UPPER(grantee_id) like ?  or  UPPER(grantee_name) like ?  ";

					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, "%" + value.toUpperCase() + "%");
				} else {
					sql = "SELECT * FROM " + ConstantController.userGrantTable
							+ " WHERE ( UPPER(grantee_id) like ?  or  UPPER(grantee_name) like ? )  AND UPPER(granter_id)=? ";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, userid.toUpperCase());
				}

				rs = pstmt.executeQuery();

				while (rs.next()) {
					// ResultSetMetaData rsmd = rs.getMetaData();
					Grant temp = new Grant();
					temp.setGrant_id(rs.getString("grant_id"));
					temp.setGranter_id(rs.getString("granter_id"));
					temp.setGranter_name(rs.getString("granter_name"));
					temp.setRole_id(rs.getString("role_id"));
					temp.setApp_id(rs.getString("app_id"));
					temp.setGrantee_id(rs.getString("grantee_id"));
					temp.setGrantee_name(rs.getString("grantee_name"));
					temp.setCan_grant(rs.getString("can_grant"));
					temp.setIs_valid_grant(rs.getString("is_valid_grant"));
					resultlist.add(temp);

				}


				if (isDebug) {
					System.out.println("~this is result" + resultlist);
				}

				if (resultlist.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					pstmt.close();
					connection.close();
					searchGrantList = resultlist;
					return resultlist;
				} else {
					pstmt.close();
					connection.close();
					searchGrantList = resultlist;
					return resultlist;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {
					
					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				searchGrantList = resultlist;
				return resultlist;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			searchGrantList = resultlist;
			return resultlist;
		}

	}

	@RequestMapping(value = "/searchLiveGrant", method = RequestMethod.POST)
	public String searchLiveGrant(@RequestParam("userid") String userid, @RequestParam("issuper") String issuper,
			@RequestParam("value") String value) throws IOException {
		JsonArray resultlist = new JsonArray();
		
		
		
		
		
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;

		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			 String query = "SELECT * FROM " + ConstantController.userGrantTable
						+ " WHERE ( UPPER(grantee_id) like '%" + value.toUpperCase() + "%' AND UPPER(granter_id)='"
						+ userid.toUpperCase() + "' ) or ( UPPER(grantee_name) like '%" + value.toUpperCase()
						+ "%'  AND UPPER(granter_id)='" + userid.toUpperCase() + "' )";

				if (issuper.trim().equalsIgnoreCase("YES")) {
					query = "SELECT * FROM " + ConstantController.userGrantTable + " WHERE UPPER(grantee_id) like '%"
							+ value.toUpperCase() + "%' or UPPER(grantee_name) like '%" + value.toUpperCase() + "%'";

				} else {
					query = "SELECT * FROM " + ConstantController.userGrantTable + " WHERE ( UPPER(grantee_id) like '%"
							+ value.toUpperCase() + "%' AND UPPER(granter_id)='" + userid.toUpperCase()
							+ "' ) or ( UPPER(grantee_name) like '%" + value.toUpperCase()
							+ "%'  AND UPPER(granter_id)='" + userid.toUpperCase() + "' )";

				}
			 */
			try {
				String sql = "SELECT * FROM " + ConstantController.userGrantTable
						+ " WHERE ( UPPER(grantee_id) like ?  or  UPPER(grantee_name) like ? )  AND UPPER(granter_id)=? ";

				pstmt = null;

				if (issuper.trim().equalsIgnoreCase("YES")) {
					sql = "SELECT * FROM " + ConstantController.userGrantTable
							+ " WHERE  UPPER(grantee_id) like ?  or  UPPER(grantee_name) like ?  ";

					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, "%" + value.toUpperCase() + "%");
				} else {
					sql = "SELECT * FROM " + ConstantController.userGrantTable
							+ " WHERE ( UPPER(grantee_id) like ?  or  UPPER(grantee_name) like ? )  AND UPPER(granter_id)=? ";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, "%" + value.toUpperCase() + "%");
					pstmt.setString(2, userid.toUpperCase());
				}

				rs = pstmt.executeQuery();

				while (rs.next()) {
					JsonObject result = new JsonObject();
					// ResultSetMetaData rsmd = rs.getMetaData();
					result.addProperty("grant_id", rs.getString("grant_id"));
					result.addProperty("granter_id", rs.getString("granter_id"));
					result.addProperty("granter_name", rs.getString("granter_name"));
					result.addProperty("role_id", rs.getString("role_id"));
					result.addProperty("app_id", rs.getString("app_id"));
					result.addProperty("grantee_id", rs.getString("grantee_id"));
					result.addProperty("grantee_name", rs.getString("grantee_name"));
					result.addProperty("can_grant", rs.getString("can_grant"));
					result.addProperty("is_valid_grant", rs.getString("is_valid_grant"));
					resultlist.add(result);

				}


				if (isDebug) {
					System.out.println("~this is result" + resultlist);
				}

				if (resultlist.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					pstmt.close();
					connection.close();
					searchLiveGrantList = resultlist.toString();
					return resultlist.toString();
				} else {
					pstmt.close();
					connection.close();
					searchLiveGrantList = resultlist.toString();
					return resultlist.toString();
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				searchLiveGrantList = resultlist.toString();
				return resultlist.toString();
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}


		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			searchLiveGrantList = resultlist.toString();
			return resultlist.toString();
		}

	}
}