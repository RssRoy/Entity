package com.icici.athena.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.poifs.crypt.HashAlgorithm;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Configuration
@Component
@RestController
public class DownloadController {

	public static Gson gson = new GsonBuilder().setPrettyPrinting().create();

	public static JsonParser parser = new JsonParser();

	public static DataFormatter formatter = new DataFormatter();

	public ResponseEntity<byte[]> toJson(String result, String appName) throws IOException {

		JsonArray resultArr = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits")
				.getAsJsonArray();

		JsonArray dataArr = new JsonArray();
		
		for (JsonElement je : resultArr) {
			JsonObject jobj=new JsonObject();
			jobj.add("id", je.getAsJsonObject().get("_id").getAsJsonObject());
			jobj.add("data", je.getAsJsonObject().get("_source").getAsJsonObject());
			
			dataArr.add(jobj);
			
		}

		String data = gson.toJson(dataArr);
		if (ConstantController.isDebug) {
			System.out.println(data);

		}
		byte[] b = new byte[(int) data.toString().length()];

		b = data.toString().getBytes();
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setContentDispositionFormData("attachment", appName + "_data.json");

		return new ResponseEntity<byte[]>(b, headers, HttpStatus.OK);

	}

	private String fill(JsonArray jArr, XSSFSheet st, int rStart, int rEnd, int cStart, int cEnd) {
		int icStart = cStart;
		int irStart = rStart;
		int inc = 0;
		String que = "", ans = "";

		for (JsonElement je : jArr) {
			if (je.getAsJsonObject().has("question")) {
				que = je.getAsJsonObject().get("question").getAsString();
				if (st.getRow(rStart) == null) {
					st.createRow(rStart);
				}
				if (st.getRow(rStart).getCell(cStart) == null) {
					st.getRow(rStart).createCell(cStart);
				}
				st.getRow(rStart).getCell(cStart).setCellValue(que);
				if (ConstantController.isDebug) {
					System.out.println("Question:" + rStart + ": " + cStart + " :" + que);
				}
				inc = 1;
				cStart++;

			}
			if (je.getAsJsonObject().has("answer")) {
				ans = je.getAsJsonObject().get("answer").getAsString();
				if (st.getRow(rStart) == null) {
					st.createRow(rStart);
				}
				if (st.getRow(rStart).getCell(cStart) == null) {
					st.getRow(rStart).createCell(cStart);
				}
				st.getRow(rStart).getCell(cStart).setCellValue(ans);
				if (ConstantController.isDebug) {
					System.out.println("Answer:" + rStart + ": " + cStart + " :" + ans);
				}
				inc = 1;
				cStart++;
			}
			if (je.getAsJsonObject().has("conv_ans")) {
				if (ConstantController.isDebug) {
					System.out.println("CONV_ANS::->" + rStart + ": " + cStart + " :");
				}

				String tmp = fill(je.getAsJsonObject().get("conv_ans").getAsJsonArray(), st, rStart, rEnd, cStart,
						cEnd);
				if (ConstantController.isDebug) {
					System.out.println("CONV_ANS::||" + rStart + ": " + cStart + " :");
				}

				rStart = Integer.parseInt(tmp.substring(0, tmp.indexOf('#')));
				cStart = Integer.parseInt(tmp.substring(tmp.indexOf('#') + 1));
				if (ConstantController.isDebug) {
					System.out.println("CONV_ANS::<-In" + rStart + ": " + cStart + " :");
				}

			}
			
			if (je.getAsJsonObject().has("file")) {
				if (st.getRow(rStart) == null) {
					st.createRow(rStart);
				}
				if (st.getRow(rStart).getCell(cStart) == null) {
					st.getRow(rStart).createCell(cStart);
				}
			
				
				JsonArray jarr = je.getAsJsonObject().get("file").getAsJsonArray();
				
				if (ConstantController.isDebug) {
					System.out.println("File:" + jarr.toString());
				}
				String files="";
				for (JsonElement tmp_je : jarr) {
					if (ConstantController.isDebug) {
						System.out.println("Files:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					files+= tmp_je.toString()+"\n";
					

				}
				ans=st.getRow(rStart).getCell(cStart).getRawValue().toString();
				st.getRow(rStart).getCell(cStart).setCellValue(ans+"\n"+files);
				
				
				if (ConstantController.isDebug) {
					System.out.println("Answer:" + rStart + ": " + cStart + " :" + ans+":::"+files);
				}
				inc = 1;
				cStart++;

			}
			if (je.getAsJsonObject().has("image")) {
				if (st.getRow(rStart) == null) {
					st.createRow(rStart);
				}
				if (st.getRow(rStart).getCell(cStart) == null) {
					st.getRow(rStart).createCell(cStart);
				}
			
				
				JsonArray jarr = je.getAsJsonObject().get("image").getAsJsonArray();
				
				if (ConstantController.isDebug) {
					System.out.println("Image:" + jarr.toString());
				}
				String files="";
				for (JsonElement tmp_je : jarr) {
					if (ConstantController.isDebug) {
						System.out.println("Image:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					files+= tmp_je.toString()+"\n";
					

				}
				ans=st.getRow(rStart).getCell(cStart).getRawValue().toString();
				st.getRow(rStart).getCell(cStart).setCellValue(ans+"\n"+files);
				
				
				if (ConstantController.isDebug) {
					System.out.println("Image:" + rStart + ": " + cStart + " :" + ans+":::"+files);
				}
				inc = 1;
				cStart++;

			}
			
			if (inc == 1) {
				rStart++;
			}
			cStart = icStart;
			inc = 0;
		}

		return Integer.toString(rStart - 1) + "#" + Integer.toString(cStart);
	}

	public ResponseEntity<byte[]> toXlsx(String result, String appName) throws IOException {

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet spreadsheet = workbook.createSheet(appName);

		JsonArray resultArr = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits")
				.getAsJsonArray();

		JsonArray dataArr = new JsonArray();
		ArrayList<String> idArr=new ArrayList<String>();
		for (JsonElement je : resultArr) {
			idArr.add(je.getAsJsonObject().get("_id").getAsString());
			dataArr.add(je.getAsJsonObject().get("_source").getAsJsonObject());
		}

		int rStart = 1;
		int rEnd = 1;
		int cStart = 0;
		int cEnd = 1;
		int ifvar = 0;
		int inc = 0;
		int odd = 0;
		int trStart = 1;
		int maxtcStart = 1;
		int id_count=0;
		for (JsonElement je : dataArr) {
			String id=idArr.get(id_count);
			id_count++;
			
			trStart = rStart;
			String que = "";
			String ans = "";
			ArrayList<String> var = new ArrayList<String>();
			if (je.getAsJsonObject().has("question")) {
				que = je.getAsJsonObject().get("question").getAsString();
				if (spreadsheet.getRow(rStart) == null) {
					spreadsheet.createRow(rStart);
				}
				if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
					spreadsheet.getRow(rStart).createCell(cStart);
				}
				spreadsheet.getRow(rStart).getCell(cStart).setCellValue(id);
				if (ConstantController.isDebug) {
					System.out.println("ID:" + rStart + ": " + cStart + " :" + id);
				}

				cStart++;
				inc = 1;
				if (spreadsheet.getRow(rStart) == null) {
					spreadsheet.createRow(rStart);
				}
				if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
					spreadsheet.getRow(rStart).createCell(cStart);
				}
				spreadsheet.getRow(rStart).getCell(cStart).setCellValue(que);
				if (ConstantController.isDebug) {
					System.out.println("Question:" + rStart + ": " + cStart + " :" + que);
				}
				cStart++;
				inc = 1;
			}
			
			if (je.getAsJsonObject().has("answer")) {
				ans = je.getAsJsonObject().get("answer").getAsString();
				if (spreadsheet.getRow(rStart) == null) {
					spreadsheet.createRow(rStart);
				}
				if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
					spreadsheet.getRow(rStart).createCell(cStart);
				}
				spreadsheet.getRow(rStart).getCell(cStart).setCellValue(ans);
				if (ConstantController.isDebug) {
					System.out.println("Answer:" + rStart + ": " + cStart + " :" + ans);
				}
				cStart++;
				inc = 1;
			}

			if (je.getAsJsonObject().has("variation") && ifvar == 0) {
				JsonArray jarr = je.getAsJsonObject().get("variation").getAsJsonArray();
				if (ConstantController.isDebug) {
					System.out.println("Variation:" + jarr.toString());
				}
				for (JsonElement tmp_je : jarr) {

					if (ifvar == 1) {
						rStart++;
					}
					if (ConstantController.isDebug) {
						System.out.println("Variation:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					String tmp_var = tmp_je.toString();

					if (ConstantController.isDebug) {
						System.out.println("Variation:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					var.add(tmp_var);

					if (spreadsheet.getRow(rStart) == null) {
						spreadsheet.createRow(rStart);
					}
					if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
						spreadsheet.getRow(rStart).createCell(cStart);
					}
					spreadsheet.getRow(rStart).getCell(cStart).setCellValue(tmp_var);
					if (ConstantController.isDebug) {
						System.out.println("Variation:" + rStart + ": " + cStart + " :" + tmp_var);
					}
					ifvar = 1;

				}

			}
			
			if (je.getAsJsonObject().has("file") ) {
				JsonArray jarr = je.getAsJsonObject().get("file").getAsJsonArray();
				if (ConstantController.isDebug) {
					System.out.println("File:" + jarr.toString());
				}
				for (JsonElement tmp_je : jarr) {

					if (ifvar == 1) {
						rStart++;
					}
					if (ConstantController.isDebug) {
						System.out.println("File:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					String tmp_var = tmp_je.toString();

					if (ConstantController.isDebug) {
						System.out.println("File:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					var.add(tmp_var);

					if (spreadsheet.getRow(rStart) == null) {
						spreadsheet.createRow(rStart);
					}
					if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
						spreadsheet.getRow(rStart).createCell(cStart);
					}
					spreadsheet.getRow(rStart).getCell(cStart).setCellValue(tmp_var);
					if (ConstantController.isDebug) {
						System.out.println("File:" + rStart + ": " + cStart + " :" + tmp_var);
					}
					

				}

			}
			if (je.getAsJsonObject().has("image") ) {
				JsonArray jarr = je.getAsJsonObject().get("image").getAsJsonArray();
				if (ConstantController.isDebug) {
					System.out.println("Image:" + jarr.toString());
				}
				for (JsonElement tmp_je : jarr) {

					if (ifvar == 1) {
						rStart++;
					}
					if (ConstantController.isDebug) {
						System.out.println("Image:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					String tmp_var = tmp_je.toString();

					if (ConstantController.isDebug) {
						System.out.println("Image:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					var.add(tmp_var);

					if (spreadsheet.getRow(rStart) == null) {
						spreadsheet.createRow(rStart);
					}
					if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
						spreadsheet.getRow(rStart).createCell(cStart);
					}
					spreadsheet.getRow(rStart).getCell(cStart).setCellValue(tmp_var);
					if (ConstantController.isDebug) {
						System.out.println("Image:" + rStart + ": " + cStart + " :" + tmp_var);
					}
					

				}

			}
			
			if (je.getAsJsonObject().has("sql")) {
				ans = je.getAsJsonObject().get("sql").getAsString();
				if (spreadsheet.getRow(rStart) == null) {
					spreadsheet.createRow(rStart);
				}
				if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
					spreadsheet.getRow(rStart).createCell(cStart);
				}
				spreadsheet.getRow(rStart).getCell(cStart).setCellValue(ans);
				if (ConstantController.isDebug) {
					System.out.println("SQL:" + rStart + ": " + cStart + " :" + ans);
				}
				cStart++;
				inc = 1;
			}
			
		
			if (je.getAsJsonObject().has("conv_ans")) {
				JsonArray tmp_jarr = je.getAsJsonObject().get("conv_ans").getAsJsonArray();
				if (ConstantController.isDebug) {
					System.out.println("CONV_ANS::->>" + rStart + ": " + cStart + " :");
				}

				String tmp = fill(tmp_jarr, spreadsheet, rStart, rEnd, 3, cEnd);// filling start with 3
				rStart = Integer.parseInt(tmp.substring(0, tmp.indexOf('#')));
				cStart = Integer.parseInt(tmp.substring(tmp.indexOf('#') + 1));
				if (ConstantController.isDebug) {
					System.out.println("CONV_ANS::<<-" + rStart + ": " + cStart + " :");
				}

				cStart++;
			}

			if (odd == 0) {
				CellStyle style = workbook.createCellStyle();

				/*
				* style.setFillPattern(FillPatternType.SPARSE_DOTS);
				* 
				* style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
				* style.setBottomBorderColor(IndexedColors.YELLOW.getIndex());
				*/
				Font font = workbook.createFont();
				font.setColor(IndexedColors.RED.getIndex());
				style.setFont(font);

				for (int i = trStart; i <= rStart; i++) {
					if (spreadsheet.getRow(i) == null) {
						spreadsheet.createRow(i);
					}
					spreadsheet.getRow(i).setRowStyle(style);
				}
				odd = 1;
			} else {
				CellStyle style = workbook.createCellStyle();
				/*
				* style.setFillPattern(FillPatternType.LESS_DOTS);
				* 
				* style.setFillBackgroundColor(IndexedColors.BLUE.getIndex());
				*/

				Font font = workbook.createFont();
				font.setColor(IndexedColors.BLACK.getIndex());
				style.setFont(font);

				for (int i = trStart; i <= rStart; i++) {
					if (spreadsheet.getRow(i) == null) {
						spreadsheet.createRow(i);
					}

					spreadsheet.getRow(i).setRowStyle(style);
				}
				odd = 0;
			}

			if (inc == 1) {
				rStart++;
			}
			maxtcStart = Math.max(maxtcStart, cStart);
			cStart = 0;
			inc = 0;

		}

		if (spreadsheet.getRow(0) == null) {
			spreadsheet.createRow(0);
			if (spreadsheet.getRow(0).getCell(0) == null) {
				spreadsheet.getRow(0).createCell(0);
				spreadsheet.getRow(0).getCell(0).setCellValue("Question");

			}
			if (spreadsheet.getRow(0).getCell(1) == null) {
				spreadsheet.getRow(0).createCell(1);
				spreadsheet.getRow(0).getCell(1).setCellValue("Answer");

			}
			if (spreadsheet.getRow(0).getCell(2) == null) {
				spreadsheet.getRow(0).createCell(2);
				spreadsheet.getRow(0).getCell(2).setCellValue("Variation");

			}
			if (spreadsheet.getRow(0).getCell(3) == null) {
				spreadsheet.getRow(0).createCell(3);
				spreadsheet.getRow(0).getCell(3).setCellValue("conv_ans/Files");

			}
			CellStyle style = workbook.createCellStyle();

			style.setFillPattern(FillPatternType.LESS_DOTS);

			style.setFillBackgroundColor(IndexedColors.ORANGE.getIndex());

			Font font = workbook.createFont();
			font.setColor(IndexedColors.WHITE.getIndex());
			style.setFont(font);

			spreadsheet.getRow(0).setRowStyle(style);

		}

		if (ConstantController.isDebug) {
			System.out.println("--->" + spreadsheet.getRow(0).getCell(0).toString() + "\n");
			System.out.println("--->" + spreadsheet.getRow(0).getCell(1).toString() + "\n");
			System.out.println("--->" + spreadsheet.getRow(0).getCell(2).toString() + "\n");
			System.out.println("--->" + spreadsheet.getRow(0).getCell(3).toString() + "\n");

		}

		// spreadsheet.protectSheet("icici@123");
		// workbook.setRevisionsPassword("icici@123", HashAlgorithm.md5);*/
		/*
		* for(int i=0;i<maxtcStart;i++) { spreadsheet.autoSizeColumn(i); }
		*/
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		workbook.write(byteArrayOutputStream);
		workbook.close();
		byte[] b = new byte[(int) byteArrayOutputStream.toByteArray().length];
		b = byteArrayOutputStream.toByteArray();
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(
				MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
		headers.setContentDispositionFormData("attachment", appName + "_data.xlsx");

		return new ResponseEntity<byte[]>(b, headers, HttpStatus.CREATED);

	}

	public ResponseEntity<byte[]> toCsv(String result, String appName) throws IOException {

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet spreadsheet = workbook.createSheet(appName);

		JsonArray resultArr = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits")
				.getAsJsonArray();

		JsonArray dataArr = new JsonArray();
		for (JsonElement je : resultArr) {
			dataArr.add(je.getAsJsonObject().get("_source").getAsJsonObject());
		}

		int rStart = 1;
		int rEnd = 1;
		int cStart = 0;
		int cEnd = 1;
		int ifvar = 0;
		int inc = 0;
		int odd = 0;
		int trStart = 1;
		int maxtcStart = 1;

		for (JsonElement je : dataArr) {

			trStart = rStart;
			String que = "";
			String ans = "";
			ArrayList<String> var = new ArrayList<String>();
			if (je.getAsJsonObject().has("question")) {
				que = je.getAsJsonObject().get("question").getAsString();
				if (spreadsheet.getRow(rStart) == null) {
					spreadsheet.createRow(rStart);
				}
				if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
					spreadsheet.getRow(rStart).createCell(cStart);
				}
				spreadsheet.getRow(rStart).getCell(cStart).setCellValue(que);
				if (ConstantController.isDebug) {
					System.out.println("Question:" + rStart + ": " + cStart + " :" + que);
				}
				cStart++;
				inc = 1;
			}
			if (je.getAsJsonObject().has("answer")) {
				ans = je.getAsJsonObject().get("answer").getAsString();
				if (spreadsheet.getRow(rStart) == null) {
					spreadsheet.createRow(rStart);
				}
				if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
					spreadsheet.getRow(rStart).createCell(cStart);
				}
				spreadsheet.getRow(rStart).getCell(cStart).setCellValue(ans);
				if (ConstantController.isDebug) {
					System.out.println("Answer:" + rStart + ": " + cStart + " :" + ans);
				}
				cStart++;
				inc = 1;
			}

			if (je.getAsJsonObject().has("variation") && ifvar == 0) {
				JsonArray jarr = je.getAsJsonObject().get("variation").getAsJsonArray();
				if (ConstantController.isDebug) {
					System.out.println("Variation:" + jarr.toString());
				}
				for (JsonElement tmp_je : jarr) {

					if (ifvar == 1) {
						rStart++;
					}
					if (ConstantController.isDebug) {
						System.out.println("Variation:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					String tmp_var = tmp_je.toString();

					if (ConstantController.isDebug) {
						System.out.println("Variation:" + jarr.toString() + "  tmp_je: " + tmp_je.toString());
					}
					var.add(tmp_var);

					if (spreadsheet.getRow(rStart) == null) {
						spreadsheet.createRow(rStart);
					}
					if (spreadsheet.getRow(rStart).getCell(cStart) == null) {
						spreadsheet.getRow(rStart).createCell(cStart);
					}
					spreadsheet.getRow(rStart).getCell(cStart).setCellValue(tmp_var);
					if (ConstantController.isDebug) {
						System.out.println("Variation:" + rStart + ": " + cStart + " :" + tmp_var);
					}
					ifvar = 1;

				}

			}

			if (je.getAsJsonObject().has("conv_ans")) {
				JsonArray tmp_jarr = je.getAsJsonObject().get("conv_ans").getAsJsonArray();
				if (ConstantController.isDebug) {
					System.out.println("CONV_ANS::->>" + rStart + ": " + cStart + " :");
				}

				String tmp = fill(tmp_jarr, spreadsheet, rStart, rEnd, 3, cEnd);// filling start with 3
				rStart = Integer.parseInt(tmp.substring(0, tmp.indexOf('#')));
				cStart = Integer.parseInt(tmp.substring(tmp.indexOf('#') + 1));
				if (ConstantController.isDebug) {
					System.out.println("CONV_ANS::<<-" + rStart + ": " + cStart + " :");
				}

				cStart++;
			}

			if (odd == 0) {
				CellStyle style = workbook.createCellStyle();

				/*
				* style.setFillPattern(FillPatternType.SPARSE_DOTS);
				* 
				* style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
				* style.setBottomBorderColor(IndexedColors.YELLOW.getIndex());
				*/
				Font font = workbook.createFont();
				font.setColor(IndexedColors.RED.getIndex());
				style.setFont(font);

				for (int i = trStart; i <= rStart; i++) {
					if (spreadsheet.getRow(i) == null) {
						spreadsheet.createRow(i);
					}
					spreadsheet.getRow(i).setRowStyle(style);
				}
				odd = 1;
			} else {
				CellStyle style = workbook.createCellStyle();
				/*
				* style.setFillPattern(FillPatternType.LESS_DOTS);
				* 
				* style.setFillBackgroundColor(IndexedColors.BLUE.getIndex());
				*/

				Font font = workbook.createFont();
				font.setColor(IndexedColors.BLACK.getIndex());
				style.setFont(font);

				for (int i = trStart; i <= rStart; i++) {
					if (spreadsheet.getRow(i) == null) {
						spreadsheet.createRow(i);
					}

					spreadsheet.getRow(i).setRowStyle(style);
				}
				odd = 0;
			}

			if (inc == 1) {
				rStart++;
			}
			maxtcStart = Math.max(maxtcStart, cStart);
			cStart = 0;
			inc = 0;

		}
		/*
		* if(spreadsheet.getRow(0)==null) { spreadsheet.createRow(0);
		* if(spreadsheet.getRow(0).getCell(0)==null) {
		* spreadsheet.getRow(0).createCell(0);
		* spreadsheet.getRow(0).getCell(0).setCellValue("Question");
		* 
		* } if(spreadsheet.getRow(0).getCell(1)==null) {
		* spreadsheet.getRow(0).createCell(1);
		* spreadsheet.getRow(0).getCell(1).setCellValue("Answer");
		* 
		* } if(spreadsheet.getRow(0).getCell(2)==null) {
		* spreadsheet.getRow(0).createCell(2);
		* spreadsheet.getRow(0).getCell(2).setCellValue("Variation");
		* 
		* } if(spreadsheet.getRow(0).getCell(3)==null) {
		* spreadsheet.getRow(0).createCell(3);
		* spreadsheet.getRow(0).getCell(3).setCellValue("conv_ans/Files");
		* 
		* } CellStyle style = workbook.createCellStyle();
		* 
		* style.setFillPattern(FillPatternType.LESS_DOTS);
		* 
		* style.setFillBackgroundColor(IndexedColors.ORANGE.getIndex());
		* 
		* 
		* Font font = workbook.createFont();
		* font.setColor(IndexedColors.WHITE.getIndex()); style.setFont(font);
		* 
		* spreadsheet.getRow(0).setRowStyle(style);
		* 
		* }
		* 
		* if(ConstantController.isDebug) {
		* System.out.println("--->"+spreadsheet.getRow(0).getCell(0).toString()+"\n");
		* System.out.println("--->"+spreadsheet.getRow(0).getCell(1).toString()+"\n");
		* System.out.println("--->"+spreadsheet.getRow(0).getCell(2).toString()+"\n");
		* System.out.println("--->"+spreadsheet.getRow(0).getCell(3).toString()+"\n");
		* 
		* }
		*/
		StringBuffer data = new StringBuffer();
		XSSFSheet sheet = workbook.getSheet(appName);
		int l = sheet.getLastRowNum();
		int c = maxtcStart;
		for (int i = 0; i <= l; i++) {
			for (int j = 0; j <= c; j++) {
				if (sheet.getRow(i) != null) {
					if (sheet.getRow(i).getCell(j) != null) {
						data.append(" " + sheet.getRow(i).getCell(j).getStringCellValue() + " Â¶");
					} else {
						data.append("\t" + " Â¶");

					}
				}
			}
			data.append("\n");
		}

		// spreadsheet.protectSheet("icici@123");
		// workbook.setRevisionsPassword("icici@123", HashAlgorithm.md5);*/
		/*
		* for(int i=0;i<maxtcStart;i++) { spreadsheet.autoSizeColumn(i); }
		*/
		workbook.close();
		byte[] b = new byte[(int) data.toString().length()];
		b = data.toString().getBytes();
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType("text/csv"));
		headers.setContentDispositionFormData("attachment", appName + "_data.csv");

		return new ResponseEntity<byte[]>(b, headers, HttpStatus.OK);

	}

	public ResponseEntity<byte[]> getFeedback() throws IOException {

		 if(ConstantController.isDebug){
	    	 System.out.println("GET FEEDBACK FILE  FROM LOGS PATH "+"logs/athena-feedback-log.log");
	     }
		 RandomAccessFile f = new RandomAccessFile("logs/athena-feedback-log.log", "r");
	     
	     byte[] b = new byte[(int)f.length()];
	     f.readFully(b);
	     final HttpHeaders headers = new HttpHeaders();
	     
			 headers.setContentType(MediaType.parseMediaType("text/csv"));
			 headers.setContentDispositionFormData("attachment","feedback_data.csv");
	     
	     f.close();
	     return new ResponseEntity<byte[]>(b, headers, HttpStatus.OK);


	}

	public ResponseEntity<byte[]> getFile(String result, String appName, String ext) throws IOException {
		if(ConstantController.isDebug){
			System.out.println("App Name: "+appName);
		}
		if (ext.toLowerCase().equals("json")) {
			return toJson(result, appName);
		} else if (ext.toLowerCase().equals("xlsx")) {
			return toXlsx(result, appName);
		} else if (ext.toLowerCase().equals("csv")) {
			return toCsv(result, appName);
		}else {
			return toJson(result, appName);
		}

	}
	///////////////////////////////// download data app based start

	@RequestMapping(value = "/downloadData", method = RequestMethod.POST)
	public ResponseEntity<byte[]> downloadResources(@RequestParam("appName") String appName,
			@RequestParam("filetype") String fileExt) throws IOException {

		appName=URLEncoder.encode(appName, "UTF-8");
		 if(fileExt.equalsIgnoreCase("#feedback")){
			return getFeedback();
			
		}
		
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body = "";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);

		Response response = restClient.performRequest("POST",
				"/" + ConstantController.eindex + "/" + appName + "/_search?size=1000",
				Collections.<String, String>emptyMap(), entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();

		return getFile(result, appName, fileExt);

	}
	///////////////////////////////// download stop

}