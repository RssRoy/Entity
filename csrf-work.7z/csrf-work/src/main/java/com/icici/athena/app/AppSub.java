package com.icici.athena.app;

import oracle.sql.TIMESTAMP;

public class AppSub {
	private String reason_id;
	private String reason_name;
	private TIMESTAMP modified_time;
	private String modified_by;
	private TIMESTAMP created_time;
	private String created_by;

	public String getReason_id() {
		return reason_id;
	}

	public void setReason_id(String reason_id) {
		this.reason_id = reason_id;
	}

	public String getReason_name() {
		return reason_name;
	}

	public void setReason_name(String reason_name) {
		this.reason_name = reason_name;
	}

	public TIMESTAMP getModified_time() {
		return modified_time;
	}

	public void setModified_time(TIMESTAMP modified_time) {
		this.modified_time = modified_time;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public TIMESTAMP getCreated_time() {
		return created_time;
	}

	public void setCreated_time(TIMESTAMP created_time) {
		this.created_time = created_time;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

}
