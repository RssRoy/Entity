package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.TimeZone;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
@Controller
@RestController
public class SqlUploadController {
	//private String driverName = "oracle.jdbc.driver.OracleDriver";
			private static String driverName=ConstantController.userDatabaseDriverClassName;
			//private String dbURL = "jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
			private static String dbURL=ConstantController.userDatabaseUrl;
			//private String dbUser = "CXPSADM";
			private  static String dbUser=ConstantController.userDatabaseUserName;
			//private String dbPassword = "CXPSADM_123";
			private static String dbPassword=ConstantController.userDatabasePassword;
	
	
			public   String sqlresult="";
	
	
	public JsonArray fArr=new JsonArray();
	public static String pretty(String json){
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		JsonParser jp = new JsonParser();
		JsonElement je = jp.parse(json);
		String prettyJsonString = gson.toJson(je);
		return prettyJsonString;
	}
	
	@PostMapping("/checkSql")
	public String checkSql(
			 @RequestParam("appName") String myappname,
			 @RequestParam("keylist") String keylist,
			 @RequestParam("sqldata") String mysqldata,
			 @RequestParam("coldata") String mycoldata,
			 HttpServletRequest request,HttpServletResponse response
	         )	throws ServletException, IOException {
		
		JsonParser parser = new JsonParser();
		JsonObject sqljson= parser.parse(mysqldata).getAsJsonObject();
		 
		 String tns=new TNSElasticController().getJsonTns(sqljson.get("app_id").getAsString().toLowerCase());
		 
		 JsonObject tnsjson= parser.parse(tns).getAsJsonObject();
		 
		 if(tnsjson.has("found") && tnsjson.get("found").getAsBoolean()==false){
			return "TNS Details not found for the Given Application "+myappname; 
		 }
		 
		 JsonObject coljson= parser.parse(mycoldata).getAsJsonObject();
		 ArrayList<String> arr=new ArrayList<String>(Arrays.asList(keylist.split(",")));
		 System.out.println(coljson.toString());
		 String sql=sqljson.get("sql").getAsString();
		 for(String a:arr){
			 if(coljson.has(a)){
				 System.out.println(a+"  "+sql+" ::::"+coljson.get(a).getAsString());
				 sql=sql.replaceAll(a, coljson.get(a).getAsString());
				 System.out.println(a+"  "+sql);
			 }
		 }
		 
		 //check for keywords
		 String tempsql=sql;
		 ArrayList<String> sqlarr=new ArrayList<String>(Arrays.asList(tempsql.toLowerCase().split(" ")));
		 if(sqlarr.contains("delete")
	        		||sqlarr.contains("update")
	        		||sqlarr.contains("insert")
	        		||sqlarr.contains("alter")
	        		||sqlarr.contains("create")
	        		||sqlarr.contains("rollback")
	        		||sqlarr.contains("commit")
	        		||sqlarr.contains("drop")
	        		||sqlarr.contains("remove")
	        		||sqlarr.contains("modify")
	        		||sqlarr.contains("*")
	        ){
	        	return "SQL Contains Restricted KEYWORDS ( delete,update ,insert,alter,create,rollback,commit,drop,remove,modify,*) Please remove. ";
	        }
		 
		 
		 //prepare the connection;
		 
		 Connection connection = null;
		 ResultSet rs=null;
		 Statement stmt=null;
		 String result=null;
		 
		 
		 
		 String server_host=tnsjson.get("server_host").getAsString();
		 String server_port=tnsjson.get("server_port").getAsString();
		 String database_name=tnsjson.get("database_name").getAsString();
		 String service_name=tnsjson.get("service_name").getAsString();
		 String server_user_name=tnsjson.get("server_user_name").getAsString();
		 String server_password=tnsjson.get("server_password").getAsString();
		 String dburl="jdbc:oracle:thin:@"+server_host+":"+server_port+":"+service_name;
		 System.out.println(dburl+server_user_name+" ");
		 //System.out.println(ConstantController.decodeTNS(server_password));
		    
		    try {
		    	 //TimeZone timeZone = TimeZone.getTimeZone("Asia/Kolkata");
		    	TimeZone timeZone = TimeZone.getTimeZone("Asia/Calcutta");
		    	TimeZone.setDefault(timeZone);
		      connection = DriverManager.getConnection(dburl, server_user_name,server_password ); 
		    	
		    } catch (SQLException e) {

		    	if(ConstantController.isDebug){
		    		System.out.println("Connection Failed! Check output console");
		    	}
		        e.printStackTrace();
		        return "Connection Failed!Please Check TNS and Database Version.";

		    }

		    if (connection != null) {
		    	if(ConstantController.isDebug){
		    		System.out.println("You made it, take control of your database now!");
		    	}
		        
		        try{
		        
		        	
		       //execute the sql; 	
		        stmt = null;
		        stmt=connection.createStatement();
		        sql=sql.replaceAll(";", "");
		        if(ConstantController.isDebug){
		        	System.out.println("SQL:"+sql);
		        }
		        
		        rs = stmt.executeQuery(sql);
		        ResultSetMetaData rsmd = rs.getMetaData();

		        int columnsNumber = rsmd.getColumnCount();
		        int width=0;
		        if(columnsNumber*20>100){
		        	width=100;
		        }else{
		        	width=columnsNumber*20;
		        }
		        result="<div class=\"table-responsive\"><table width='"+(width)+"%' class='table table-striped table-bordered table-hover table-condensed' >";
		       
		        for(int i = 1; i <= columnsNumber; i++)
		        {
		            result+="<th class='text-center'>"+(rsmd.getColumnName(i))+"</th>";
		        }
		        result+="</tr>";
		      
		        
		        while (rs.next()){
		        	result+="<tr>";
		        	 for(int i = 1; i <= columnsNumber; i++){
		        		 if(ConstantController.isDebug){
		 		        	System.out.println("this is result->data:"+rs.getObject(i).toString()+":"+rs.getObject(rsmd.getColumnName(i)).toString());
		 		        }
		        		 result+="<td class='text-center'>"+rs.getObject(i).toString()+"</td>";
		        	 }
		        	 result+="</tr>";
		        }
		        result+="</table></div>";
		        if(ConstantController.isDebug){
		        	System.out.println("this is result"+result);
		        }
		        sqlresult=result;
		        
		        connection.close();
		        return result;
		        }catch(Exception e){
		        	if(ConstantController.isDebug){
		        		System.out.println("error in stmt creation");
		        	}
		        	e.printStackTrace();
		        	return e.toString();
		        }finally{
					try {
						if (rs != null) rs.close(); 
						 if (stmt != null) stmt.close();
						 if (connection != null) connection.close(); 
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
				}
		    } else {
		    	if(ConstantController.isDebug){
		    		System.out.println("Failed to make connection!");
		    	}
		        return " Failed to make connection! with given TNS \nResult:"+result;
		    }
			
		 
	}
	


	@PostMapping("/insertSql")
    public String insertSql (
            @RequestParam("app_name") String myappname,
            @RequestParam("jsonObj") String jsondata,
            HttpServletRequest request,
            HttpServletResponse response
            )	throws ServletException, IOException {

		
		
		JsonParser jp = new JsonParser();
		JsonObject  json = (JsonObject) jp.parse(jsondata).getAsJsonObject();
		
        String result="";
        result=new AjaxController().insertJsonResources(request,response,myappname,json.toString())+"#";
       // request.getSession(false).setAttribute("result", result);
        //request.getSession(false).setAttribute("sql", sqlresult);
        
       // response.sendRedirect("/uploadsql?msg=success");
        	//status#id#Message
        	return result+"#+Success";
        
         
       }

	@PostMapping("/modifySql")
    public String modifySql (
            @RequestParam("app_name") String myappname,
            @RequestParam("id") String myid,
            @RequestParam("jsonObj") String jsondata,
            HttpServletRequest request,
            HttpServletResponse response
            )	throws ServletException, IOException {

		
		
		JsonParser jp = new JsonParser();
		JsonObject  json = (JsonObject) jp.parse(jsondata).getAsJsonObject();
		
        String result="";
        result=new AjaxController().modifyData(request,response,myappname, myid, json.toString())+"#"+myid+"#"+"Success";
       // request.getSession(false).setAttribute("result", result);
        //request.getSession(false).setAttribute("sql", sqlresult);
      
       
       // response.sendRedirect("/modifysql?msg=success");
        	
        	return result;
        
         
       }




}
