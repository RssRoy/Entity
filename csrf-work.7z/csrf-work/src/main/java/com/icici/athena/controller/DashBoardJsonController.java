package com.icici.athena.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@Controller
@Component
@RestController
public class DashBoardJsonController {

		private String driverName=ConstantController.userDatabaseDriverClassName;
		
		private String dbURL=ConstantController.userDatabaseUrl;
		
		private String dbUser=ConstantController.userDatabaseUserName;
		
		private String dbPassword=ConstantController.userDatabasePassword;
		
	@RequestMapping(value = "/getData", method = RequestMethod.POST)
	public String getData(@RequestParam(value = "option") String option) throws IOException {

		//System.out.println("GetData -- option ==== "+option);
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jdata=new JSONArray();

		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
//			return "Failed Connection";
		}

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
			
		} catch (SQLException e) {
			e.printStackTrace();
			return "Failed Connection :- " + e;
		}

		if (connection != null) {
			try {
				pstmt = connection.prepareStatement(FETCH_METRICS_LIST);
				pstmt.setString(1, option);
				//System.out.println("Group Bar Chart query :- " + FETCH_METRICS_LIST);
				
				rs = pstmt.executeQuery();
				while (rs.next()) {
					
					JSONObject tjson=new JSONObject();
					tjson.put("year",rs.getString(1) );
					tjson.put("Total Sessions", rs.getString(3));
					tjson.put("Active Users", rs.getString(4));
					
					JSONArray jsonList = new JSONArray();
					JSONObject innerObj = new JSONObject();
					   innerObj.put("Interactions", rs.getString(3));
					   innerObj.put("Active", rs.getString(4));
					   jsonList.put(innerObj);
//					tjson.put("Values",  jsonList);
					
					jdata.put(tjson);
				}
				
				connection.close();
				return jdata.toString();
			} catch (Exception e) {
				try {
					connection.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
//				System.out.println("Exception - " + e);
				return "Failed in stmt creation - " + e;
			}finally{
				try {
					if(rs != null){
						rs.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(connection != null)  {
						connection.close();
					}
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			}
		} else {
//			return "Failed to connect DataBase";
		}
		return jdata.toString();
	}

	/*@RequestMapping(value = "/getSucRatio", method = RequestMethod.POST)
	public double getSucRatio(@RequestParam(value = "option") String option,
			@RequestParam(value = "totIntDate") String totIntDate,
			@RequestParam(value = "totInt") String totInt) throws IOException {

		System.out.println("option - success Ratio - "+option);
		System.out.println("totIntDate - getSucRatio -- "+totIntDate);
		System.out.println("totInt - getSucRatio ---"+totInt);
		
		Connection connection = null;
		PreparedStatement pstmt;
		PreparedStatement pstmt2;
		ResultSet rs;
		Statement stmt1;
		ResultSet rs1;
		ResultSet rs2;
		double ratio = 0;
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			// return "Failed Connection";
		}

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
		} catch (SQLException e) {
			e.printStackTrace();
			// return "Failed Connection :- " + e;
		}

		if (connection != null) {
			try {
				pstmt = connection.prepareStatement(FETCH_SUCCESS_RATIO);
				pstmt.setString(1, option);
				
				if(totIntDate.equals("") || totIntDate == null) {
					Date date = new Date();  
					SimpleDateFormat formatter = new SimpleDateFormat("ddMMMyyyy");  
					totIntDate = formatter.format(date);
					pstmt2 = connection.prepareStatement(GET_TOT_INTRST);
					pstmt2.setString(1, option);
					pstmt2.setString(2, totIntDate);
					rs2 = pstmt2.executeQuery();
					while(rs2.next()) {
						totInt = rs2.getString(3);
						System.out.println("rs2.getString(3)  --- "+rs2.getString(3));
					}
				} 
				pstmt.setString(2, totIntDate);
				System.out.println("To Get Success Ratio query :- " + FETCH_SUCCESS_RATIO+" ------ totIntDate =="+totIntDate+",--option == "+option);
				rs = pstmt.executeQuery();

				while (rs.next()) {
					System.out.println("!st Query-->"+rs.getString(1)+"----------->"+totInt);
					stmt1 = connection.createStatement();
					String ratioQuery = "SELECT round((" + totInt + " - " + rs.getString(1) + ") /"
							+ totInt + " * 100,2) as Ratio from dual";
					rs1 = stmt1.executeQuery(ratioQuery);
					while (rs1.next()) {
						ratio = rs1.getDouble("Ratio");
						System.out.println("ratio :- " + ratioQuery + " -- " + ratio);
					}
				}

				connection.close();
			} catch (Exception e) {
				System.out.println("Exception - " + e);
				// return "Failed in stmt creation - " + e;
			}
		} else {
			// return "Failed to connect DataBase";
		}
		return ratio;
	}*/
	
	@RequestMapping(value = "/getCountForLineBar", method = RequestMethod.POST)
	public String getCountForLineBar(@RequestParam(value = "option") String option) throws IOException {

		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<String> list = null;
		JSONArray jArray = new JSONArray();

		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return "Failed Connection";
		}

		try {
			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
		} catch (SQLException e) {
			e.printStackTrace();
			return "Failed Connection :- " + e;
		}

		if (connection != null) {
			try {
				stmt = connection.prepareStatement(COUNT_LINE_BAR_CHAT);
				stmt.setString(1, option);
//				System.out.println("Line Bar Chart query :- " + COUNT_LINE_BAR_CHAT);
				rs = stmt.executeQuery();

				list = new ArrayList<String>();
				while (rs.next()) {
					JSONObject tjson=new JSONObject();
					tjson.put("date",rs.getString(1) );
					tjson.put("close", rs.getString(3));
					
					jArray.put(tjson);
				}
				
				connection.close();
			} catch (Exception e) {
				try {
					connection.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				System.out.println("Exception - " + e);
				return "Failed in stmt creation - " + e;
			}finally{
				try {
					if(rs != null){
						rs.close();
					}
					if(stmt != null){
						stmt.close();
					}
					if(connection != null)  {
						connection.close();
					}
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			}
		} else {
			return "Failed to connect DataBase";
		}
		return jArray.toString();
	}
	
	@RequestMapping(value = "/getTopTrending", method = RequestMethod.POST)
	public String getTopTrending(@RequestParam(value = "optionTop") String optionTop,
			@RequestParam(value = "topTrendingDate") String date) throws IOException {

		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jdata=new JSONArray();
		JSONObject tjson=new JSONObject();
		List list = null;
		JSONArray jsonList = new JSONArray();

		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return "Failed Connection";
		}

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
		} catch (SQLException e) {
			e.printStackTrace();
			return "Failed Connection :- " + e;
		}

		if (connection != null) {
			try {
				String peramOption = null;
				String peramDate = null;
				if(optionTop.equals("Choose Application")) {
					peramOption = "finacle";
//					System.out.println("TopTrending - option - "+peramOption);
				} else {
					peramOption = optionTop;
//					System.out.println("TopTrending - option else - "+peramOption);
				}
				
				if(date.equals("Date") || date.equals("")) {
					Date sysDate = new Date();  
					SimpleDateFormat formatter = new SimpleDateFormat("ddMMMyyyy");  
					peramDate = formatter.format(sysDate);
//					System.out.println("TopTrending Date - "+peramDate);
				} else {
					peramDate = date;
//					System.out.println("TopTrending Date else- "+peramDate);
				}
				TOP_TRENDING_LIST = getSQLQuery(GET_TOP_TRENDING_SQL);
				pstmt = connection.prepareStatement(TOP_TRENDING_LIST,ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				pstmt.setString(1, peramOption);
				pstmt.setString(2, peramDate);
//				System.out.println("Top Trending query :- " + TOP_TRENDING_LIST);
				rs = pstmt.executeQuery();
				
				int rowCount = 0;
				 if (rs.last()) {//make cursor to point to the last row in the ResultSet object
		             rowCount = rs.getRow();
		             rs.beforeFirst(); 
				 }
				 list = new ArrayList<String>();
				while (rs.next()) {
//					tjson.put("name",rs.getString(1));
					JSONObject innerObj = new JSONObject();
					for(int i =0; i<= rowCount; i++) {  
					   innerObj.put("name", rs.getString(2));
					   innerObj.put("size", rs.getString(5));
					}
					jsonList.put(innerObj);
					tjson.put("children",  jsonList);
					
					jdata.put(tjson);
					
				}
				
				connection.close();
				return tjson.toString();
			} catch (Exception e) {
				System.out.println("Exception - " + e);
				return "Failed in stmt creation - " + e;
			} finally {
				try {
					if(rs != null){
						rs.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(connection != null)  {
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} 
		return tjson.toString();
	}
	
	@RequestMapping(value = "/getQesWithNoSugg", method = RequestMethod.POST)
	public String getQesWithNoSugg(@RequestParam(value = "optionQue") String optionTop,
			@RequestParam(value = "queWithNoSuggDate") String date) throws IOException {

		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jdata=new JSONArray();
		JSONObject tjson=new JSONObject();
		List list = null;
		JSONArray jsonList = new JSONArray();

		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return "Failed Connection";
		}

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
		} catch (SQLException e) {
			e.printStackTrace();
			return "Failed Connection :- " + e;
		}

		if (connection != null) {
			try {
				String peramOption = null;
				String peramDate = null;
				if(optionTop.equals("Choose Application")) {
					peramOption = "finacle";
//					System.out.println("Question with no sugg - option - "+peramOption);
				} else {
					peramOption = optionTop;
//					System.out.println("Question with no sugg - option else - "+peramOption);
				}
				
				if(date.equals("Date") || date.equals("")) {
					Date sysDate = new Date();  
					SimpleDateFormat formatter = new SimpleDateFormat("ddMMMyyyy");  
					peramDate = formatter.format(sysDate);
//					System.out.println("Question with no sugg Date - "+peramDate);
				} else {
					peramDate = date;
//					System.out.println("Question with no sugg Date else- "+peramDate);
				}
				QUES_WITH_NO_SUGG_LIST = getSQLQuery(QUES_WITH_NO_SUGG_SQL);
				pstmt = connection.prepareStatement(QUES_WITH_NO_SUGG_LIST,ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				pstmt.setString(1, peramOption);
				pstmt.setString(2, peramDate);
//				System.out.println("QUES_WITH_NO_SUGG_SQL :- " + QUES_WITH_NO_SUGG_LIST);
				rs = pstmt.executeQuery();
				
				int rowCount = 0;
				 if (rs.last()) {//make cursor to point to the last row in the ResultSet object
		             rowCount = rs.getRow();
		             rs.beforeFirst(); 
				 }
				 list = new ArrayList<String>();
				while (rs.next()) {
//					tjson.put("name",rs.getString(1));
					JSONObject innerObj = new JSONObject();
					for(int i =0; i<= rowCount; i++) {  
					   innerObj.put("name", rs.getString(2));
					   innerObj.put("size", rs.getString(5));
					}
					jsonList.put(innerObj);
					tjson.put("children",  jsonList);
					
					jdata.put(tjson);
					
				}
				
				connection.close();
				return tjson.toString();
			} catch (Exception e) {
				System.out.println("Exception - " + e);
				return "Failed in stmt creation - " + e;
			} finally {
				try {
					if(rs != null){
						rs.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(connection != null)  {
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} 
		return tjson.toString();
	}
	
	@RequestMapping(value = "/getQesLeadToSR", method = RequestMethod.POST)
	public String getQesLeadToSR(@RequestParam(value = "optionQuetSR") String optionQuetSR,
			@RequestParam(value = "queleadSRDate") String queleadSRDate) throws IOException {

		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs =  null;
		JSONArray jdata=new JSONArray();
		JSONObject tjson=new JSONObject();
		List list = null;
		JSONArray jsonList = new JSONArray();

		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return "Failed Connection";
		}

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
		} catch (SQLException e) {
			e.printStackTrace();
			return "Failed Connection :- " + e;
		}

		if (connection != null) {
			try {
				String peramOption = null;
				String peramDate = null;
				if(optionQuetSR.equals("Choose Application")) {
					peramOption = "finacle";
//					System.out.println("Question Lead to SR - option - "+peramOption);
				} else {
					peramOption = optionQuetSR;
//					System.out.println("Question Lead to SR - option else - "+peramOption);
				}
				
				if(queleadSRDate.equals("Date") || queleadSRDate.equals("")) {
					Date sysDate = new Date();  
					SimpleDateFormat formatter = new SimpleDateFormat("ddMMMyyyy");  
					peramDate = formatter.format(sysDate);
//					System.out.println("Question Lead to SR Date - "+peramDate);
				} else {
					peramDate = queleadSRDate;
//					System.out.println("Question Lead to SR Date else- "+peramDate);
				}
				QUE_LEADING_TO_SR_LIST = getSQLQuery(QUE_LEADING_TO_SR_SQL);
				pstmt = connection.prepareStatement(QUE_LEADING_TO_SR_LIST,ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				pstmt.setString(1, peramOption);
				pstmt.setString(2, peramDate);
//				System.out.println("QUE_LEADING_TO_SR_SQL :- " + QUE_LEADING_TO_SR_LIST);
				rs = pstmt.executeQuery();
				
				int rowCount = 0;
				 if (rs.last()) {//make cursor to point to the last row in the ResultSet object
		             rowCount = rs.getRow();
		             rs.beforeFirst(); 
				 }
				 list = new ArrayList<String>();
				while (rs.next()) {
//					tjson.put("name",rs.getString(1));
					JSONObject innerObj = new JSONObject();
					for(int i =0; i<= rowCount; i++) {  
					   innerObj.put("name", rs.getString(3));
					   innerObj.put("size", rs.getString(4));
					}
					jsonList.put(innerObj);
					tjson.put("children",  jsonList);
					
					jdata.put(tjson);
					
				}
				
				connection.close();
				return tjson.toString();
			} catch (Exception e) {
				System.out.println("Exception - " + e);
				return "Failed in stmt creation - " + e;
			} finally {
				try {
					if(rs != null){
						rs.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(connection != null)  {
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} 
		return tjson.toString();
	}
	
	@RequestMapping(value = "/getIntrDetails", method = RequestMethod.POST)
	public String getIntrDetails(@RequestParam(value = "intrDtlsDropdown") String intrDtlsDropdown,
			@RequestParam(value = "intrDtlsDTdropdown") String intrDtlsDTdropdown) throws IOException {

		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jdata=new JSONArray();
		JSONObject tjson=new JSONObject();
		List list = null;
		JSONArray jsonList = new JSONArray();

		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return "Failed Connection";
		}

		try {

			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
		} catch (SQLException e) {
			e.printStackTrace();
			return "Failed Connection :- " + e;
		}

		if (connection != null) {
			try {
				String peramOption = null;
				String peramDate = null;
				if(intrDtlsDropdown.equals("Choose Application")) {
					peramOption = "finacle";
//					System.out.println("IntrDtls - app name - "+peramOption);
				} else {
					peramOption = intrDtlsDropdown;
//					System.out.println("IntrDtls - app name else - "+peramOption);
				}
				
				if(intrDtlsDTdropdown.equals("Date") || intrDtlsDTdropdown.equals("")) {
					Date sysDate = new Date();  
					SimpleDateFormat formatter = new SimpleDateFormat("ddMMMyyyy");  
					peramDate = formatter.format(sysDate);
//					System.out.println("IntrDtls Date - "+peramDate);
				} else {
					peramDate = intrDtlsDTdropdown;
					System.out.println("IntrDtls Date else- "+peramDate);
				}
				INTR_DTLS_LIST = getSQLQuery(INTR_DTLS_SQL);
				pstmt = connection.prepareStatement(INTR_DTLS_LIST,ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				pstmt.setString(1, peramOption);
				pstmt.setString(2, peramDate);
//				System.out.println("INTR_DTLS_SQL :- " + INTR_DTLS_LIST);
				rs = pstmt.executeQuery();
				
				int rowCount = 0;
				 if (rs.last()) {//make cursor to point to the last row in the ResultSet object
		             rowCount = rs.getRow();
		             rs.beforeFirst(); 
				 }
				 list = new ArrayList<String>();
				while (rs.next()) {
					JSONObject innerObj = new JSONObject();
					for(int i =0; i<= rowCount; i++) {  
					   innerObj.put("Emp ID", rs.getString(1));
					   innerObj.put("Date", rs.getString(2));
					   innerObj.put("Application Name", rs.getString(3));
					   innerObj.put("Question Asked", rs.getString(4));
					   innerObj.put("Question Returned", rs.getString(5));
					   innerObj.put("Clicked on SR", rs.getString(6));
					}
					jsonList.put(innerObj);
					tjson.put("children",  jsonList);
					
					jdata.put(innerObj);
					
				}
				
				connection.close();
				return jdata.toString();
			} catch (Exception e) {
				try {
					connection.close();
				} catch (SQLException en) {
					en.printStackTrace();
				}
//				System.out.println("Exception - " + e);
				return "Failed in stmt creation - " + e;
			}finally{
				try {
					if(rs != null){
						rs.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(connection != null)  {
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} 
		return jdata.toString();
	}
	
	@RequestMapping(value = "/populateDates", method = RequestMethod.POST)
	public List<String> populateDates() throws IOException {

		Connection conn = null;
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		List<String> listofDates = new ArrayList<String>();
		String dt = null;

		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try {
			conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (conn != null) {
			try {
				String query = getSQLQuery(GETDATES);
				stmt = conn.createStatement(); 
				rs = stmt.executeQuery(query);
				while(rs.next()) {
					dt = rs.getString("DT");
					listofDates.add(dt);
				}
//			System.out.println("listofDates == "+listofDates);	
			} catch(Exception exe) {
				System.out.println(exe);
			} finally {
				try {
					if(rs != null){
						rs.close();
					}
					if(stmt != null){
						stmt.close();
					}
					if(conn != null)  {
						conn.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			}
		
		return listofDates;
	}
	
	public String getSQLQuery(String sqlStr) {
		String sqlQuery = null;
		 try {
			FileInputStream fis = new FileInputStream(ConstantController.sqlpath);
			Properties prop = new Properties();
			prop.load(fis);
			sqlQuery = prop.getProperty(sqlStr);
		} catch (FileNotFoundException fe) {
			System.out.println("File path is not found: -"+fe);
		} catch (IOException io) {
			System.out.println("File path is not found: -"+io);
		}
		 return sqlQuery;
	}
	
	private String TOP_TRENDING_LIST = null;
	private String GET_TOP_TRENDING_SQL = "TopTrending";
	private String QUES_WITH_NO_SUGG_LIST = null;
	private String QUES_WITH_NO_SUGG_SQL = "QuestionWithNoSugg";
	private String QUE_LEADING_TO_SR_LIST = null;
	private String QUE_LEADING_TO_SR_SQL = "QuestionLeadingtoSR";
	private String INTR_DTLS_LIST = null;
	private String INTR_DTLS_SQL = "IntrDetails";
	private String GETDATES = "GETDATES";
	
	
	private String FETCH_METRICS_LIST = "select to_char(A.DT,'ddMonyyyy') as DT,A.APPLICATION_NAME,A.Interaction,NVL(B.Interaction,0) as ACTIVE_USER_COUNT\r\n"
			+ "from\r\n" + "(\r\n" + "Select DT,APPLICATION_NAME,Count(SESSION_ID) as Interaction from\r\n"
			+ "(select Distinct SESSION_ID,APPLICATION_NAME,TRUNC(DATE_TIME) As DT from chat_history\r\n"
			+ "where question not like 'App_Selected%' and QUESTION not in('NULL','NO_QUESTION_MATCHED','USER WANT THIS TO BE IN THE SYSTEM','NO SUGGESTION')\r\n"
			+ "order by TRUNC(DATE_TIME),APPLICATION_NAME,SESSION_ID) X\r\n" + "Group by DT,APPLICATION_NAME\r\n"
			+ "Order by APPLICATION_NAME,DT\r\n" + ")A LEFT JOIN\r\n" + "(\r\n"
			+ "Select DT,APPLICATION_NAME,Count(emp_id)  as Interaction from\r\n"
			+ "(select Distinct emp_id, APPLICATION_NAME,TRUNC(DATE_TIME) As DT from chat_history\r\n"
			+ "where  ((question not like 'App_Selected%')and QUESTION not like ('NULL') and application_name != 'none')\r\n"
			+ "order by TRUNC(DATE_TIME),APPLICATION_NAME,SESSION_ID) X Group by DT,APPLICATION_NAME\r\n"
			+ "Order by DT,APPLICATION_NAME\r\n" + ")B\r\n" + "on A.DT=B.DT\r\n"
			+ "and A.APPLICATION_NAME=B.APPLICATION_NAME\r\n"
			+ "where (A.APPLICATION_NAME is not null AND A.APPLICATION_NAME = ?)\r\n"
			+ "AND A.DT > SYSDATE - 8\r\n" + "Order By A.DT ";

	/*private String FETCH_SUCCESS_RATIO = "select count(session_id) NO_OF_SR from chat_history\r\n" + 
			" where emp_id != 'null' and (application_name != 'none')\r\n" + 
			" and chat_message = 'CLICKED ON SR LINK'\r\n" + 
			" and application_name =? and trunc(date_time) =? ";*/
	
	private String COUNT_LINE_BAR_CHAT = "select to_char(DT,'ddMonyyyy') as DT,APPLICATION_NAME,count(emp_id) from\r\n" + 
			"(\r\n" + 
			"        Select DT,APPLICATION_NAME,emp_id,question_asked,question as question_returned,CLICKED_ON_SR from\r\n" + 
			"        (\r\n" + 
			"                select Distinct emp_id,APPLICATION_NAME,question,TRUNC(DATE_TIME) As DT,\r\n" + 
			"                case when chat_message = 'CLICKED ON SR LINK' then 'YES' else 'NO' end as CLICKED_ON_SR,\r\n" + 
			"                case when user_query='NO_USER_QUERY' then 'SUGGESTION_SELECTED' else user_query end as question_asked\r\n" + 
			"                from chat_history\r\n" + 
			"                where question not like 'App_Selected%'\r\n" + 
			"                and QUESTION not in('NULL','NO_QUESTION_MATCHED','USER WANT THIS TO BE IN THE SYSTEM','NO SUGGESTION')\r\n" + 
			"                and emp_id not in('null') and application_name = ?\r\n" + 
			"                order by TRUNC(DATE_TIME),APPLICATION_NAME,emp_id,question_asked,question\r\n" + 
			"\r\n" + 
			"        ) X Group by DT,APPLICATION_NAME,emp_id,question_asked,question,CLICKED_ON_SR\r\n" + 
			"        order by APPLICATION_NAME,DT\r\n" + 
			")xyz11\r\n" + 
			"where DT > SYSDATE - 8\r\n" + 
			"group by DT,APPLICATION_NAME\r\n" + 
			"order by TO_DATE(dt,'ddMonyyyy')";
	
	/*private String GET_TOT_INTRST = "select to_char(A.DT,'ddMonyyyy') as DT,A.APPLICATION_NAME,A.Interaction,NVL(B.Interaction,0) as ACTIVE_USER_COUNT\r\n"
			+ "from\r\n" + "(\r\n" + "Select DT,APPLICATION_NAME,Count(SESSION_ID) as Interaction from\r\n"
			+ "(select Distinct SESSION_ID,APPLICATION_NAME,TRUNC(DATE_TIME) As DT from chat_history\r\n"
			+ "where question not like 'App_Selected%' and QUESTION not in('NULL','NO_QUESTION_MATCHED','USER WANT THIS TO BE IN THE SYSTEM','NO SUGGESTION')\r\n"
			+ "order by TRUNC(DATE_TIME),APPLICATION_NAME,SESSION_ID) X\r\n" + "Group by DT,APPLICATION_NAME\r\n"
			+ "Order by APPLICATION_NAME,DT\r\n" + ")A LEFT JOIN\r\n" + "(\r\n"
			+ "Select DT,APPLICATION_NAME,Count(emp_id)  as Interaction from\r\n"
			+ "(select Distinct emp_id, APPLICATION_NAME,TRUNC(DATE_TIME) As DT from chat_history\r\n"
			+ "where  ((question not like 'App_Selected%')and QUESTION not like ('NULL') and application_name != 'none')\r\n"
			+ "order by TRUNC(DATE_TIME),APPLICATION_NAME,SESSION_ID) X Group by DT,APPLICATION_NAME\r\n"
			+ "Order by DT,APPLICATION_NAME\r\n" + ")B\r\n" + "on A.DT=B.DT\r\n"
			+ "and A.APPLICATION_NAME=B.APPLICATION_NAME\r\n"
			+ "where (A.APPLICATION_NAME is not null AND A.APPLICATION_NAME = ?) AND A.DT =? \r\n"
			+ " AND A.DT > SYSDATE - 6\r\n" + "Order By A.DT ";
*/
}
