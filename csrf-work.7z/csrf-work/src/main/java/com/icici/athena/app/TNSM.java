package com.icici.athena.app;
import oracle.sql.TIMESTAMP;

public class TNSM {
	private String app_id;
	private String app_name;
	private String tns_server_host;
	private String tns_server_port;
	private String tns_service_name;
	private String tns_database_name;
	private String tns_user_name;
	private String tns_password;
	private TIMESTAMP modified_time;
	private String modified_by;
	public String getApp_id() {
		return app_id;
	}
	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}
	public String getApp_name() {
		return app_name;
	}
	public String getTns_server_host() {
		return tns_server_host;
	}
	public void setTns_server_host(String tns_server_host) {
		this.tns_server_host = tns_server_host;
	}
	public String getTns_server_port() {
		return tns_server_port;
	}
	public void setTns_server_port(String tns_server_port) {
		this.tns_server_port = tns_server_port;
	}
	public String getTns_service_name() {
		return tns_service_name;
	}
	public void setTns_service_name(String tns_service_name) {
		this.tns_service_name = tns_service_name;
	}
	public String getTns_database_name() {
		return tns_database_name;
	}
	public void setTns_database_name(String tns_database_name) {
		this.tns_database_name = tns_database_name;
	}
	public String getTns_user_name() {
		return tns_user_name;
	}
	public void setTns_user_name(String tns_user_name) {
		this.tns_user_name = tns_user_name;
	}
	public String getTns_password() {
		return tns_password;
	}
	public void setTns_password(String tns_password) {
		this.tns_password = tns_password;
	}
	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}
	public TIMESTAMP getModified_time() {
		return modified_time;
	}
	public void setModified_time(TIMESTAMP modified_time) {
		this.modified_time = modified_time;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	
	
	

}
