package com.icici.athena.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Scanner;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

@RestController
@Controller
public class SynonymController {
	
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	
	public static int insertSynonym(String server,String body) throws IOException{
		//int status =-1;
		//int ans =-1;	
		
		RestClient restClient = RestClient.builder(new HttpHost(server, 9200, "http")).build();
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		Response indexResponse = restClient.performRequest("POST", "/" + AjaxController.eindex + "/_close",Collections.<String, String>emptyMap(), entity);
		if(isDebug){
			System.out.println("Server Index  Closed for "+server);
		}
		if(indexResponse.getStatusLine().getStatusCode()==200){
			//status =200;
		indexResponse = restClient.performRequest("PUT", "/" + AjaxController.eindex + "/_settings",Collections.<String, String>emptyMap(), entity);
		if(isDebug){
			System.out.println("Server Settings Changed for "+server);
		}
		//ans = 1;
		if(indexResponse.getStatusLine().getStatusCode()==200){
				
				indexResponse = restClient.performRequest("POST", "/" + AjaxController.eindex + "/_open",Collections.<String, String>emptyMap(), entity);
				if(isDebug){
					System.out.println("Server Index  Opended for "+server+" with status code " + indexResponse.getStatusLine().getStatusCode());
				}
				if(indexResponse.getStatusLine().getStatusCode()==200){
					restClient.close();
					return 200;
				}
				
			}
		else{
			restClient.close();
			return -1;
		}
		}
		else{
			restClient.close();

			return -1;
		}
		//return 200;
		restClient.close();

		return -1;
	}
	
	@RequestMapping(value = "/insertSynonyms", method = RequestMethod.POST)
	public static int insertSynonyms(@RequestParam(value = "synonymData", required = false) String data) {
		int ans = -1;
		data = myTrim(data);
		ans = putSynonym(data);
		
		if(isDebug){
			System.out.println("insertSynonym" + data);
			System.out.println("putSynonym" + ans);
		}

		JsonObject indexobj = new JsonObject();
		JsonObject fileobj = new JsonObject();
		fileobj.addProperty("analysis.filter.synonym.synonyms_path", "analysis/synonym.txt");
		indexobj.add("index", fileobj);
		
		////////////////////////////////////Insert Synonym into Servers through method
		int StatusCodeEserver=-1,StatusCodeNextServer=-1;
		try {
			StatusCodeEserver=insertSynonym(AjaxController.eserver,indexobj.toString());
			if(isDebug){
				System.out.println("Started inserting synonym in "+AjaxController.eserver);
			}
			if(StatusCodeEserver ==200){
				if(isDebug){
					System.out.println("Synonym inserted successfully in  "+AjaxController.eserver);
				}
				if(AjaxController.eserver.equals(AjaxController.nextServer)){
					return 200;
				}
			}
			if(isDebug){
				System.out.println("Started inserting synonym in "+AjaxController.nextServer);
			}
			StatusCodeNextServer=insertSynonym(AjaxController.nextServer,indexobj.toString());
			if(StatusCodeEserver ==200 && StatusCodeNextServer==200){
				if(isDebug){
					System.out.println("Synonym inserted successfully in both servers!!! ");
				}
				return 200;
			}else{
				return -1;
			}
		} catch (IOException e1) {
			
			e1.printStackTrace();
			return -1;
		}
		
		
		

	}

	public static int bkpSynonym(String data) {
		data = myTrim(data);
		if(isDebug){
			System.out.println("BKP Synonym" + data);
		}
		try {

			///////////////////// for 80
			///////////////////// node////////////////////////////////////////
			JSch jsch80 = new JSch();

			Session session80 = jsch80.getSession(ConstantController.user, AjaxController.eserver, 22);
			// session.setConfig( "PreferredAuthentications", "password" );
			session80.setPassword(ConstantController.pwd);
			java.util.Properties config80 = new java.util.Properties();
			config80.put("StrictHostKeyChecking", "no");// do not prefer this.
														// demo only
			session80.setConfig(config80);
			session80.connect(12000);
			if(isDebug){
				System.out.println("Connected");
			}

			Channel channel80 = session80.openChannel("exec");

			((ChannelExec) channel80).setCommand("echo \"" + data
					+ "\" > "+ConstantController.path+"synonym_txt.bkp");

			if(isDebug){
				System.out.println("ECHO  1 DONE");
			}

			channel80.setInputStream(null);
			((ChannelExec) channel80).setErrStream(System.err);

			InputStream in80 = channel80.getInputStream();
			channel80.connect();
			byte[] tmp80 = new byte[1024 * 1024 * 2];
			while (true) {
				while (in80.available() > 0) {
					int i = in80.read(tmp80, 0, 1024 * 1024 * 2);
					if (i < 0)
						break;
					if(isDebug){
						System.out.print(new String(tmp80, 0, i));
					}
				}
				if (channel80.isClosed()) {
					if(isDebug){
						System.out.println("exit-status: " + channel80.getExitStatus());
					}
					break;
				}
			}
			channel80.disconnect();
			session80.disconnect();

			/////////////////////////////////////////////////////////////////
			
			if(AjaxController.eserver.equals(AjaxController.nextServer)){
				return 1;
			}
			
			///////////////////// for 79
			///////////////////// node////////////////////////////////////////
			JSch jsch79 = new JSch();

			Session session79 = jsch79.getSession(ConstantController.user, AjaxController.nextServer, 22);
			// session.setConfig( "PreferredAuthentications", "password" );
			session79.setPassword(ConstantController.pwd);
			java.util.Properties config79 = new java.util.Properties();
			config79.put("StrictHostKeyChecking", "no");// do not prefer this.
														// demo only
			session79.setConfig(config79);
			session79.connect(12000);
			
			if(isDebug){
				System.out.println("Connected");
			}

			Channel channel79 = session79.openChannel("exec");

			((ChannelExec) channel79).setCommand("echo \"" + data
					+ "\" > "+ConstantController.path+"synonym_txt.bkp");

			if(isDebug){
				System.out.println("ECHO  1 DONE");
			}

			channel79.setInputStream(null);
			((ChannelExec) channel79).setErrStream(System.err);

			InputStream in79 = channel79.getInputStream();
			channel79.connect();
			byte[] tmp79 = new byte[1024 * 1024 * 2];
			while (true) {
				while (in79.available() > 0) {
					int i = in79.read(tmp79, 0, 1024 * 1024 * 2);
					if (i < 0)
						break;
					if(isDebug){
						System.out.print(new String(tmp79, 0, i));
					}
				}
				if (channel79.isClosed()) {
					if(isDebug){
						System.out.println("exit-status: " + channel79.getExitStatus());
					}
					break;
				}
			}
			channel79.disconnect();
			session79.disconnect();

			/////////////////////////////////////////////////////////////////

			if(isDebug){
				System.out.println("CAT 2 DONE");
			}
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}

	}

	public static String myTrim(String str) {
		String data = "";
		if(isDebug){
			System.out.println(str);
		}
		Scanner in = new Scanner(str);
		while (in.hasNextLine()) {
			String temp = in.nextLine();
			temp = temp.trim();
			if (temp.length() > 3) {
				data += temp;
			}
			if (in.hasNextLine()) {
				data += "\n";
			}
		}
		in.close();

		if(isDebug){
			System.out.println(data);
		}
		return data;
	}

	public static int putSynonym(String data) {
		data = myTrim(data);
		if(isDebug){
			System.out.println("PUT Synonym" + data);
		}
		try {

			///////////////////////////////////////////////////// start for 80
			JSch jsch80 = new JSch();
			Session session80 = jsch80.getSession(ConstantController.user, AjaxController.eserver, 22);
			// session.setConfig( "PreferredAuthentications", "password" );
			session80.setPassword(ConstantController.pwd);
			java.util.Properties config80 = new java.util.Properties();
			config80.put("StrictHostKeyChecking", "no");// do not prefer this.
														// demo only
			session80.setConfig(config80);
			session80.connect(12000);
			if(isDebug){
				System.out.println("Connected");
			}

			Channel channel80 = session80.openChannel("exec");
			// not working
			/// ((ChannelExec) channel).setCommand("mv
			// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt
			// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt.bkp");

			/// ((ChannelExec) channel).setCommand("cat
			/// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt
			/// >
			/// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt.bkp");
			String tempData80 = getSynonym();
			tempData80 = myTrim(tempData80);
			bkpSynonym(tempData80);
			// ((ChannelExec) channel).setCommand("echo \""+tempData+"\" >
			// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym_txt.bkp");

			// ((ChannelExec) channel).setCommand("echo \""+tempData+"\" >
			// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym_bkp.txt");

			if(isDebug){
				System.out.println("ECHO 0   DONE" + tempData80);
			}
			((ChannelExec) channel80).setCommand(
					"echo \"" + data + "\" > "+ConstantController.path+"synonym.txt");

			if(isDebug){
				System.out.println("ECHO  1 DONE");
			}

			// ((ChannelExec) channel).setCommand("cd
			// /vertica_load/LOAD_MANAGEMENT/DC/");
			// ((ChannelExec) channel).setCommand("scp -v -pw hdpuser@123
			// hdpuser@10.50.72.80:/home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt
			// hdpuser@10.50.72.80:/home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt.bkp");

			// ((ChannelExec) channel).setCommand("scp -v -pw hdpuser@123
			// SynonymData.txt
			// hdpuser@10.50.72.80:/home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt");
			// ((ChannelExec) channel).setCommand("/opt/vertica/bin/vsql -h
			// 10.50.72.56 -p 6439 -U tech -w Tech@12345 -c \"COPY
			// reconp.temp_web_cronic_exchange_rates_y_sid FROM
			// '/vertica_load/ExtractedFiles/Test_ExchangeRates.csv' PARSER
			// fcsvparser(header = false);\"");
			channel80.setInputStream(null);
			((ChannelExec) channel80).setErrStream(System.err);

			InputStream in80 = channel80.getInputStream();
			channel80.connect();
			byte[] tmp80 = new byte[1024 * 1024 * 2];
			while (true) {
				while (in80.available() > 0) {
					int i = in80.read(tmp80, 0, 1024 * 1024 * 2);
					if (i < 0)
						break;
					if(isDebug){
						System.out.print(new String(tmp80, 0, i));
					}
				}
				if (channel80.isClosed()) {
					if(isDebug){
						System.out.println("exit-status: " + channel80.getExitStatus());
					}
					break;
				}
			}
			channel80.disconnect();
			session80.disconnect();

			////////////////////////////////////////////////// end for 80
			
			if(AjaxController.eserver.equals(AjaxController.nextServer)){
				return 1;
			}
			
			///////////////////////////////////////////////////// start for 79
			JSch jsch79 = new JSch();
			Session session79 = jsch79.getSession(ConstantController.user, AjaxController.nextServer, 22);
			// session.setConfig( "PreferredAuthentications", "password" );
			session79.setPassword(ConstantController.pwd);
			java.util.Properties config79 = new java.util.Properties();
			config79.put("StrictHostKeyChecking", "no");// do not prefer this.
														// demo only
			session79.setConfig(config79);
			session79.connect(12000);
			if(isDebug){
				System.out.println("Connected");
			}

			Channel channel79 = session79.openChannel("exec");
			// not working
			/// ((ChannelExec) channel).setCommand("mv
			// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt
			// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt.bkp");

			/// ((ChannelExec) channel).setCommand("cat
			/// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt
			/// >
			/// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt.bkp");
			String tempData79 = getSynonym();
			tempData79 = myTrim(tempData79);
			bkpSynonym(tempData79);
			// ((ChannelExec) channel).setCommand("echo \""+tempData+"\" >
			// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym_txt.bkp");

			// ((ChannelExec) channel).setCommand("echo \""+tempData+"\" >
			// /home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym_bkp.txt");

			if(isDebug){
				System.out.println("ECHO 0   DONE" + tempData79);
			}
			((ChannelExec) channel79).setCommand(
					"echo \"" + data + "\" > "+ConstantController.path+"synonym.txt");

			if(isDebug){
				System.out.println("ECHO  1 DONE");
			}

			// ((ChannelExec) channel).setCommand("cd
			// /vertica_load/LOAD_MANAGEMENT/DC/");
			// ((ChannelExec) channel).setCommand("scp -v -pw hdpuser@123
			// hdpuser@10.50.72.80:/home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt
			// hdpuser@10.50.72.80:/home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt.bkp");

			// ((ChannelExec) channel).setCommand("scp -v -pw hdpuser@123
			// SynonymData.txt
			// hdpuser@10.50.72.80:/home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt");
			// ((ChannelExec) channel).setCommand("/opt/vertica/bin/vsql -h
			// 10.50.72.56 -p 6439 -U tech -w Tech@12345 -c \"COPY
			// reconp.temp_web_cronic_exchange_rates_y_sid FROM
			// '/vertica_load/ExtractedFiles/Test_ExchangeRates.csv' PARSER
			// fcsvparser(header = false);\"");
			channel79.setInputStream(null);
			((ChannelExec) channel79).setErrStream(System.err);

			InputStream in79 = channel79.getInputStream();
			channel79.connect();
			byte[] tmp79 = new byte[1024 * 1024 * 2];
			while (true) {
				while (in79.available() > 0) {
					int i = in79.read(tmp79, 0, 1024 * 1024 * 2);
					if (i < 0)
						break;
					if(isDebug){
						System.out.print(new String(tmp79, 0, i));
					}
				}
				if (channel79.isClosed()) {
					if(isDebug){
						System.out.println("exit-status: " + channel79.getExitStatus());
					}
					break;
				}
			}
			channel79.disconnect();
			session79.disconnect();

			////////////////////////////////////////////////// end for 79

			if(isDebug){
				System.out.println("CAT 2 DONE");
			}
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}

	}

	public static int getRows(String data) {
		if(isDebug){
			System.out.println("GET ROW Synonym" + data);
		}
		int ans = 0;
		Scanner sc = new Scanner(data);
		String str="";
		while (sc.hasNextLine()) {
			str=sc.nextLine();
			if(isDebug){
				System.out.println(str);
			}
			ans++;
		}
		sc.close();
		return ans;
	}

	public static String getSynonym() {
		if(isDebug){
			System.out.println("Get Synonym");
		}
		String ans = "";
		try {

			JSch jsch = new JSch();
			Session session = jsch.getSession(ConstantController.user, AjaxController.eserver, 22);
			// session.setConfig( "PreferredAuthentications", "password" );
			session.setPassword(ConstantController.pwd);
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");// do not prefer this.
														// demo only
			session.setConfig(config);
			session.connect(12000);
			if(isDebug){
				System.out.println("Connected");
			}

			Channel channel = session.openChannel("exec");
			// ((ChannelExec) channel).setCommand("pwd");
			((ChannelExec) channel)
					.setCommand("cat "+ConstantController.path+"synonym.txt");

			// ((ChannelExec) channel).setCommand("scp -v -pw hdpuser@123
			// hdpuser@10.50.72.80:/home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt
			// /home/hdpuser/Chatbot_Production_Test/");
			// ((ChannelExec) channel).setCommand("scp -v -pw hdpuser@123
			// hdpuser@10.50.72.80:/home/hdpuser/elasticNew/elasticsearch-5.4.0/config/analysis/synonym.txt
			// .");

			// ((ChannelExec) channel).setCommand("/opt/vertica/bin/vsql -h
			// 10.50.72.56 -p 6439 -U tech -w Tech@12345 -c \"COPY
			// reconp.temp_web_cronic_exchange_rates_y_sid FROM
			// '/vertica_load/ExtractedFiles/Test_ExchangeRates.csv' PARSER
			// fcsvparser(header = false);\"");
			channel.setInputStream(null);
			((ChannelExec) channel).setErrStream(System.err);

			InputStream in = channel.getInputStream();
			channel.connect();
			byte[] tmp = new byte[1024 * 1024 * 2];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024 * 1024 * 2);
					if (i < 0)
						break;
					ans = (new String(tmp, 0, i));
				}
				if (channel.isClosed()) {
					if(isDebug){
						System.out.println("exit-status: " + channel.getExitStatus());
					}
					break;
				}
				try {
					Thread.sleep(1000);
				} catch (Exception ee) {
				}
			}
			channel.disconnect();
			session.disconnect();

			if(isDebug){
				System.out.println("DONE GET SYNONYM" + ans);
			}
			return ans;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ans;

	}

}
