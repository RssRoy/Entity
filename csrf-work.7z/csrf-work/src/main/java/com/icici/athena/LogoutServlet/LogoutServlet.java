package com.icici.athena.LogoutServlet;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icici.athena.LoginServlet.SessionServlet;

/**
 * Servlet implementation class LogoutServlet
 */
@Controller
public class LogoutServlet extends HttpServlet {
	
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	SessionServlet sessionservlet=null;
	
	 public SessionServlet getSessionservlet() {
		return sessionservlet;
	}

	public void setSessionservlet(SessionServlet sessionservlet) {
		this.sessionservlet = sessionservlet;
	}
	
	 
	private static final long serialVersionUID = 1L;
	@ResponseBody
	@RequestMapping(value="LogoutServlet",method=RequestMethod.POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");
    	/*Cookie[] cookies = request.getCookies();
    	if(cookies != null){
    	for(Cookie cookie : cookies){
    		if(cookie.getName().equals("JSESSIONID")){
    			if(isDebug){
    				System.out.println("JSESSIONID="+cookie.getValue());
    			}
    			break;
    		}
    	}
    	}*/
    	//invalidate the session if exists
    	HttpSession session = request.getSession(false);
    	
    	if(session!=null){
    		this.setSessionservlet(new SessionServlet(session));
    		int x=new SessionServlet().resetActiveUser((String)session.getAttribute("userid"));
    		if(x>0){
    			if(isDebug){
    				System.out.println("User Reset Done.");
    			}
    		}else{
    			if(isDebug){
    				System.out.println("User Reset Failed.");
    			}
    		}
    	}
    	if(isDebug){
    		if(session!=null)
    		System.out.println("User="+session.getAttribute("user"));
    	}
    	if(session != null){
    		session.invalidate();

        	response.sendRedirect("/login");
        	return;
    	}
    	response.sendRedirect("/login");
    	return;
    }
	
	@ResponseBody
	@RequestMapping(value="LogoutServlet",method=RequestMethod.GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	if(isDebug){
    		System.out.println("GET LogoutServlet... ");
    	}
		
		response.setContentType("text/html");
    	
    	//invalidate the session if exists
    	HttpSession session = request.getSession(false);
    	
    	if(session!=null){
    		if(isDebug){
        		System.out.println("GET LogoutServlet... Session NOT NULL ");
        	}
    		this.sessionservlet=new SessionServlet(session);
    		int x=this.sessionservlet.resetActiveUser((String)session.getAttribute("userid"));
    		if(x>0){
    			if(isDebug){
    				System.out.println("User Reset Done.");
    			}
    		}else{
    			if(isDebug){
    				System.out.println("User Reset Failed.");
    			}
    		}
    	}else{
    		if(isDebug){
        		System.out.println("GET LogoutServlet... Session  NULL ");
        	}
    	}
    	if(isDebug){
    		if(session!=null)
    		System.out.println("User="+session.getAttribute("user"));
    	}
    	if(session != null){
    		session.invalidate();

        	response.sendRedirect("/login");
        	return;
    	}
    	response.sendRedirect("/login");
    	return;
    }
	

	

}