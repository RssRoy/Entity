package com.icici.athena.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.Key;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestController;

@Configuration
@Component
@RestController
public class ConstantController {

	@Value("${spring.elasticsearch.jest.proxy.host}")
	public static String eserver;

	@Value("${spring.elasticsearch.jest.proxy.host}")
	public void setEserver(String db) {

		eserver = db;
	}

	
	@Value("${elasticsearch.tns.index}")
	public static String tnsIndex;

	@Value("${elasticsearch.tns.index}")
	public void settnsIndex(String db) {

		tnsIndex = db;
	}

	@Value("${elasticsearch_nextserver}")
	public static String nextServer;

	@Value("${elasticsearch_nextserver}")
	public void setnextServer(String db) {

		nextServer = db;
	}
	
	@Value("${server.port}")
	public static String port;

	@Value("${server.port}")
	public void setPort(String db) {

		port = db;
	}
	@Value("${server.user}")
	public static String user;

	@Value("${server.user}")
	public void setUser(String db) {

		user = db;
	}
	@Value("${server.pwd}")
	public static String pwd;

	@Value("${server.pwd}")
	public void setPwd(String db) {

		pwd = db;
	}
	@Value("${synonym.path}")
	public static String path;

	@Value("${synonym.path}")
	public void setSynonym(String db) {

		path = db;
	}
	
	@Value("${sqlquery.path}")
	public static String sqlpath;

	@Value("${sqlquery.path}")
	public void setSqlQueryPath(String db) {

		sqlpath = db;
	}
	
	@Value("${ldap_host}")
	public static String ldapHost;

	@Value("${ldap_host}")
	public void setldapHost(String db) {

		ldapHost = db;
	}

	@Value("${ldap_dc}")
	public static String ldapDc;

	@Value("${ldap_dc}")
	public void setldapDc(String db) {

		ldapDc = db;
	}

	@Value("${ldap_dc1}")
	public static String ldapDc1;

	@Value("${ldap_dc1}")
	public void setldapDc1(String db) {

		ldapDc1 = db;
	}

	@Value("${ldap_port1}")
	public static String ldapPort1;

	@Value("${ldap_port1}")
	public void setldapPort1(String db) {

		ldapPort1 = db;
	}

	@Value("${ldap_port2}")
	public static String ldapPort2;

	@Value("${ldap_port2}")
	public void setldapPort2(String db) {

		ldapPort2 = db;
	}

	@Value("${ldap.user}")
	public static String ldapUser;

	@Value("${ldap.user}")
	public void setLdapUser(String db) {

		ldapUser = db;
	}
	@Value("${ldap.filepassword}")
	public static boolean filePassword;

	@Value("${ldap.filepassword}")
	public void setLdapFilePassword(boolean db) {

		filePassword = db;
	}

	@Value("${ldap.enc}")
	public static boolean ldapEnc;

	@Value("${ldap.enc}")
	public void setLdapEnc(boolean db) {

		ldapEnc = db;
	}

	@Value("${ldap.pwd}")
	public static String ldapPwd;

	@Value("${ldap.pwd}")
	public void setLdapPwd(String db) {
		if(isDebug) {
			System.out.println("Cipher----"+db);
			System.out.println("Cipher----"+db.length());
		}
		if (ldapEnc == true) {
			if(filePassword==true){
				File f=new File("athena.secret");
				String pass=db;
				if(f.exists()==false){
					try {
						f.createNewFile();
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					FileWriter fw=null;
					try {
						fw = new FileWriter(f);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					BufferedWriter bw=new BufferedWriter(fw);
					try {
						bw.write(db);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						bw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					db=decode(db);
				}else{
					FileReader fr=null;
					try {
						fr = new FileReader(f);
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					BufferedReader br=new BufferedReader(fr);
					 try {
						pass=br.readLine();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						br.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					db=pass;
					db = new String(decode(db));
				}
			}else{
				
				db = new String(decode(db));
				
			}
			

		} else {
			Base64.Decoder decoder = Base64.getDecoder();
			db = new String(decoder.decode(db));
		}
		if (ConstantController.isDebug) {
			 //System.out.println("::"+db);
		}
		ldapPwd = db;
	}

	@Value("${elasticsearch_index}")
	public static String eindex;

	@Value("${elasticsearch_index}")
	public void setElasticSearchIndex(String db) {
		eindex = db;
	}

	@Value("${myDebug}")
	public static boolean isDebug;

	@Value("${myDebug}")
	public void setdebug(boolean db) {
		isDebug = db;
	}

	@Value("${uploadFolder}")
	public static String uploadFolder;

	@Value("${uploadFolder}")
	public void setUploadFolder(String db) {
		uploadFolder = db;
	}

	@Value("${user_table_name}")
	public static String userTable;

	@Value("${user_table_name}")
	public void setUserTable(String db) {
		userTable = db;
	}

	@Value("${user_app_table_name}")
	public static String userAppTable;

	@Value("${user_app_table_name}")
	public void setUserAppTable(String db) {
		userAppTable = db;
	}

	@Value("${user_app_sr_table_name}")
	public static String userAppSrTable;

	@Value("${user_app_sr_table_name}")
	public void setUserAppSrTable(String db) {
		userAppSrTable = db;
	}
	
	@Value("${user_sr_reason_table_name}")
	public static String userSrReasonTable;

	@Value("${user_sr_reason_table_name}")
	public void setUserSrReasonTable(String db) {
		userSrReasonTable = db;
	}
	
	@Value("${user_app_properties_table_name}")
	public static String userAppPropTable;

	@Value("${user_app_properties_table_name}")
	public void setUserAppPropTable(String db) {
		userAppPropTable = db;
	}

	@Value("${user_role_table_name}")
	public static String userRoleTable;

	@Value("${user_role_table_name}")
	public void setUserRoleTable(String db) {
		userRoleTable = db;
	}

	@Value("${user_grant_table_name}")
	public static String userGrantTable;

	@Value("${user_grant_table_name}")
	public void setUserGrantTable(String db) {
		userGrantTable = db;
	}
	
	
	
	
	// database userinfo

	@Value("${spring.datasource.url}")
	public static String userDatabaseUrl;

	@Value("${spring.datasource.url}")
	public void setUserDatabaseUrl(String db) {
		userDatabaseUrl = db;
	}

	@Value("${spring.datasource.username}")
	public static String userDatabaseUserName;

	@Value("${spring.datasource.username}")
	public void setUserDatabaseUserName(String db) {
		userDatabaseUserName = db;
	}

	@Value("${spring.datasource.password}")
	public static String userDatabasePassword;

	@Value("${spring.datasource.password}")
	public void setUserDatabasePassword(String db) {
		userDatabasePassword = db;
	}

	@Value("${spring.datasource.driver-class-name}")
	public static String userDatabaseDriverClassName;

	@Value("${spring.datasource.driver-class-name}")
	public void setUserDatabaseDriverClassName(String db) {
		userDatabaseDriverClassName = db;
	}

	

	// redirect_url
	@Value("${redirect_url}")
	public static String redirecturl;

	@Value("${redirect_url}")
	public void setRedirectURL(String db) {
		redirecturl = db;
	}

	@Value("${file_upload}")
	public static boolean fileUpload;

	@Value("${file_upload}")
	public void setFileUpload(boolean db) {
		fileUpload = db;
	}

	@Value("${image_upload}")
	public static boolean imageUpload;

	@Value("${image_upload}")
	public void setImageUpload(boolean db) {
		imageUpload = db;
	}

	@Value("${sql_upload}")
	public static boolean sqlUpload;

	@Value("${sql_upload}")
	public void setSqlUpload(boolean db) {
		sqlUpload = db;
	}

	@Value("${send_feedback}")
	public static boolean sendFeedback;

	@Value("${send_feedback}")
	public void setsendFeedback(boolean db) {
		sendFeedback = db;
	}

	@Value("${export_data}")
	public static boolean exportData;

	@Value("${export_data}")
	public void setexportData(boolean db) {
		exportData = db;
	}

	@Value("${article_id}")
	public static boolean articleId;

	@Value("${article_id}")
	public void setarticleId(boolean db) {
		articleId = db;
	}
	
	
	@Value("${search_article_id}")
	public static boolean searchArticleId;

	@Value("${search_article_id}")
	public void setsearchArticleId(boolean db) {
		searchArticleId = db;
	}

	@Value("${image_zoom}")
	public static boolean imageZoom;

	@Value("${image_zoom}")
	public void setimageZoom(boolean db) {
		imageZoom = db;
	}

	@Value("${dashboard}")
	public static boolean dashboard;

	@Value("${dashboard}")
	public void setdashboard(boolean db) {
		dashboard = db;
	}

	@Value("${logs_home}")
	public static String logsHome;

	@Value("${logs_home}")
	public void setlogsHome(String db) {
		logsHome = db;
	}

	@Value("${app_prop}")
	public static boolean appProp;

	@Value("${app_prop}")
	public void setAppProp(boolean db) {
		appProp = db;
	}

	//TNS Entry Begin
	
	@Value("${tns_management}")
	public static boolean tnsManagement;

	@Value("${tns_management}")
	public void settnsManagement(boolean db) {
		tnsManagement = db;
	}
	
	//TNS Entry End
	
	@Value("${maintenance_url}")
	public static String maintenance_url;

	@Value("${maintenance_url}")
	public void setMaintenanceUrl(String db) {
		maintenance_url = db;
	}

	/********************************* Encryption and Decryption algo ********************************************/
	 
	public static String encode(String text) 
    {
        try 
        {
	   String key = "athenaChatbot123"; // 16*8 bit key
       // Create key and cipher
       Key aesKey = new SecretKeySpec(key.getBytes("utf-8"), "AES");
       Cipher cipher = Cipher.getInstance("AES");
       // encrypt the text
       cipher.init(Cipher.ENCRYPT_MODE, aesKey);
       byte[] encrypted = cipher.doFinal(text.getBytes("utf-8"));

       StringBuilder sb = new StringBuilder();
       for (byte b: encrypted) {
           sb.append((char)b);
       }

        //the encrypted String
       String enc = sb.toString();
     String enc_64=Base64.getEncoder().encodeToString(enc.getBytes("UTF-8"));
      // System.out.println("encrypted:" + enc);
       
       return enc_64;
       
        }
        catch(Exception e) 
        {
            e.printStackTrace();
            return "Failed to Encrypt";
        }
    }

	public static String decode(String text) {
		try {

			String key = "athenaChatbot123"; // 16*8 bit key
			// Create key and cipher
			if(isDebug) {
				System.out.println("Text:1 "+text);
			}
			Key aesKey = new SecretKeySpec(key.getBytes("utf-8"), "AES");
			Cipher cipher = Cipher.getInstance("AES");
			text=new String(Base64.getDecoder().decode(text.getBytes("UTF-8")));
			if(isDebug) {
				System.out.println("Text:2 "+text);
			}
			byte[] bb = new byte[text.length()];
			for (int i = 0; i < text.length(); i++) {
				bb[i] = (byte) text.charAt(i);
			}

			// decrypt the text
			if(ConstantController.isDebug){
				System.out.println(new String(bb,"UTF-8"));
					
			}
			if(isDebug) {
				System.out.println("Text:3 "+text);
			}
			cipher.init(Cipher.DECRYPT_MODE, aesKey);
			String decrypted = new String(cipher.doFinal(bb),"UTF-8");
			 //System.err.println("decrypted:" + decrypted);
			if(isDebug) {
				System.out.println("Text:4 "+decrypted);
			}
			return decrypted;
		} catch (Exception e) {
			e.printStackTrace();
			return "Failed to Decrypt";
		}
	}
	
	/********************************* Encryption and Decryption TNS  algo ********************************************/
	 
	public static String encodeTNS(String text) 
    {
        try 
        {
	   String key = "athenaChatTNS123"; // 16*8 bit key
       // Create key and cipher
       Key aesKey = new SecretKeySpec(key.getBytes("utf-8"), "AES");
       Cipher cipher = Cipher.getInstance("AES");
       // encrypt the text
       cipher.init(Cipher.ENCRYPT_MODE, aesKey);
       byte[] encrypted = cipher.doFinal(text.getBytes("utf-8"));

       StringBuilder sb = new StringBuilder();
       for (byte b: encrypted) {
           sb.append((char)b);
       }

        //the encrypted String
       String enc = sb.toString();
     String enc_64=Base64.getEncoder().encodeToString(enc.getBytes("UTF-8"));
      // System.out.println("encrypted:" + enc);
       
       return enc_64;
       
        }
        catch(Exception e) 
        {
            e.printStackTrace();
            return "Failed to Encrypt";
        }
    }

	public static String decodeTNS(String text) {
		try {

			String key = "athenaChatTNS123"; // 16*8 bit key
			// Create key and cipher
			Key aesKey = new SecretKeySpec(key.getBytes("utf-8"), "AES");
			Cipher cipher = Cipher.getInstance("AES");
			text=new String(Base64.getDecoder().decode(text.getBytes("UTF-8")));
			
			byte[] bb = new byte[text.length()];
			for (int i = 0; i < text.length(); i++) {
				bb[i] = (byte) text.charAt(i);
			}

			// decrypt the text
			if(ConstantController.isDebug){
				System.out.println(new String(bb,"UTF-8"));
					
			}
			cipher.init(Cipher.DECRYPT_MODE, aesKey);
			String decrypted = new String(cipher.doFinal(bb),"UTF-8");
			// System.err.println("decrypted:" + decrypted);
			return decrypted;
		} catch (Exception e) {
			e.printStackTrace();
			return "Failed to Decrypt";
		}
	}
}
