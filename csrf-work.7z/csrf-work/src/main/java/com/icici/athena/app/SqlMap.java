package com.icici.athena.app;

import java.util.ArrayList;

import oracle.sql.TIMESTAMP;

public class SqlMap {
	private String map_id;
	private String map_name;
	private ArrayList<String> map_list;
	private String map_value;
	private TIMESTAMP modified_time;
	private String modified_by;
	
	public String getMap_id() {
		return map_id;
	}
	public void setMap_id(String map_id) {
		this.map_id = map_id;
	}
	public String getMap_name() {
		return map_name;
	}
	public void setMap_name(String map_name) {
		this.map_name = map_name;
	}
	public ArrayList<String> getMap_list() {
		return map_list;
	}
	public void setMap_list(ArrayList<String> map_list) {
		this.map_list = map_list;
	}
	public String getMap_value() {
		return map_value;
	}
	public void setMap_value(String map_value) {
		this.map_value = map_value;
	}
	public TIMESTAMP getModified_time() {
		return modified_time;
	}
	public void setModified_time(TIMESTAMP modified_time) {
		this.modified_time = modified_time;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	
}
