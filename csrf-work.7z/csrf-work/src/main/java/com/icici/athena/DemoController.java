package com.icici.athena;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.gson.JsonObject;
import com.icici.athena.controller.ConstantController;
import com.icici.athena.user.User;


/*public class DemoController implements ErrorController {*/
@Controller
public class DemoController implements ErrorController {
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	
	@RequestMapping("/")
	String reload(HttpServletRequest request){
			return "default";
	}	
	@RequestMapping("/Chat")
	String index(HttpServletRequest request) throws IOException{
		if(isDebug){
			System.out.println("CHAT ACCESSING Controller");
		}
		

	/*	if (ConstantController.isDebug) {
			if(isDebug){
				System.out.println("Headers of chat page : ");
			}
			Map<String, String> map = new HashMap<String, String>();
			Enumeration<String> headerNames = request.getHeaderNames();
			while (headerNames.hasMoreElements()) {
				String key = (String) headerNames.nextElement();
				String value = request.getHeader(key);
				map.put(key, value);
				
				if(isDebug){
				System.out.println(key + " Demo/Chat: " + value);
				System.out.println(key + " Demo/Chat: " + value.length());
				}
			}
			if(isDebug){
	        	System.out.println(map.toString());
	        }
		}*/
        return "index";
	}	
	
	
	@RequestMapping("/search")
	String search(){
		return "search";
	}
	@RequestMapping("/popupsearch")
	String popupsearch(){
		return "popup-search";
	}
	@RequestMapping("/insert")
	String insert(){
		return "insert";
	}	
	@RequestMapping("/show")
	String show(){
		return "show";
	}	
	@RequestMapping("/delete")
	String delete(){
		return "delete";
	}
	@RequestMapping("/modify")
	String modify(){
		return "modify";
	}
	@RequestMapping("admin")
	String admin() {//(HttpServletRequest request){
		/*Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    	String username="";
    	if (principal instanceof User) {
    		username = ((User)principal).getUser_name();
    	} else {
    	   username = principal.toString();
    	}
    	request.getSession(false).setAttribute("User",username);*/
		return "admin";
	}
	@RequestMapping("login")
	String defaultlogin(){
		return "defaultlogin";
	}
	@RequestMapping("adminsuperlogin")
	String adminsuperlogin(){
		return "adminsuperlogin";
	}
	@RequestMapping("adminlogin")
	String adminlogin(){
		return "adminlogin";
	}
	
	@RequestMapping("help")
	String help(){
		return "SRHelp";
	}
	/*
	@RequestMapping("/faq-management")
	String faq(){
		return "faq-management";
	}*/
	
	@RequestMapping("/subject-area")
	String subject(){
		return "subject-area";
	}
	
	@RequestMapping("/user-management")
	String user(){
		return "user-management";
	}
	@RequestMapping("/grant-management")
	String grant(){
		return "grant-management";
	}
	@RequestMapping("/role-management")
	String role(){
		return "role-management";
	}
	@RequestMapping("/fileupload")
	String fileupload(){
		return "fileupload";
	}
	@RequestMapping("/error")
	String Error(){
		return "Error";
	}
	@Override
	public String getErrorPath() {
		
	
		return "/error";
	}
	
	@RequestMapping("/synonym")
	String synonym(){
		return "synonym";
	}
	@RequestMapping("/adminhelp")
	String adminhelp(){
		return "help";
	}
	@RequestMapping("/uploadpage")
	String upload(){
		return "upload";
	}
	@RequestMapping("/uploadimage")
	String uploadimage(){
		return "uploadimage";
	}
	@RequestMapping("/uploadfile")
	String uploadfile(){
		return "uploadfile";
	}
	/*@RequestMapping("/replaceimage")
	String replaceimage(){
		return "replaceimage";
	}
	@RequestMapping("/replacefile")
	String replacefile(){
		return "replacefile";
	}*/
	@RequestMapping("/uploadsql")
	String uploadsql(){
		return "uploadsql";
	}
	@RequestMapping("/modifysql")
	String modifysql(){
		return "modifysql";
	}
	
	@RequestMapping("/downloadPage")
	String downloadPage(){
		return "downloadPage";
	}
	
	@RequestMapping("/adminChat")
	String adminChat(){
		return "adminchat";
	}
	@RequestMapping("/adminChatDefault")
	String adminChatDefault(){
		return "adminchatdefault";
	}
	@RequestMapping("/chatLogin")
	String chatLogin(){
		return "chatlogin";
	}
	@RequestMapping("/appPropertiesPage")
	String appPropertiesPage(){
		return "app-properties";
	}
	@RequestMapping("/MaintenancePage")
	String MaintenancePage(){
		return "MaintenancePage";
	}
	@RequestMapping("/encode")
	String EncodePage(){
		return "encode";
	}
	@RequestMapping("/decode")
	String DecodePage(){
		return "decode";
	}
	@RequestMapping("/tnsManagement")
	String tnsManagement(){
		return "tns-management";
	}
	@RequestMapping("/SqlMap")
    String sqlmapping(){
        return "sqlmap";
    }
	
	
	@RequestMapping("/appSrManagement")
	String appSrManagement(){
		return "sr-management";
	}
	@RequestMapping("/appSubCategory")
    String appSubCategory(){
        return "app-reason";
    }
	
	
	
	@RequestMapping("/Dashboard")
    String dashboard(){
        return "dashboard";
    }
	@RequestMapping("/TopTrending")
    String getTopTrending(){
        return "TopTrendingTab";
    }

@RequestMapping("/QuestionWithNoSuggestion")
String getQuestionWithNoSuggestion(){
    return "QuestionWithNoSugg";
}

@RequestMapping("/QuestionsLeadingToSR")
String questionLeadingToSR(){
    return "QuestLeadingToSR";
}

@RequestMapping("/InteractionDetails")
String interactionDetails(){
    return "IntrDetails";
}


}
