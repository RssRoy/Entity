package com.icici.athena.grant;

import oracle.sql.TIMESTAMP;

public class Grant {
	private String grant_id;
	private String granter_id;
	private String granter_name;
	private String role_id;
	private String app_id;
	private String grantee_id;
	private String grantee_name;
	private String can_grant;
	private String is_valid_grant;
	private TIMESTAMP modified_time;
	private String modified_by;
	
	public Grant(){
		
	}
	public Grant(String grant_id, String granter_id, String granter_name, String role_id, String app_id,
			String grantee_id, String grantee_name, String can_grant, String is_valid_grant) {
		
		this.grant_id = grant_id;
		this.granter_id = granter_id;
		this.granter_name = granter_name;
		this.role_id = role_id;
		this.app_id = app_id;
		this.grantee_id = grantee_id;
		this.grantee_name = grantee_name;
		this.can_grant = can_grant;
		this.is_valid_grant = is_valid_grant;
	}


	public String getGrant_id() {
		return grant_id;
	}


	public void setGrant_id(String grant_id) {
		this.grant_id = grant_id;
	}


	public String getGranter_id() {
		return granter_id;
	}


	public void setGranter_id(String granter_id) {
		this.granter_id = granter_id;
	}


	public String getGranter_name() {
		return granter_name;
	}


	public void setGranter_name(String granter_name) {
		this.granter_name = granter_name;
	}


	public String getRole_id() {
		return role_id;
	}


	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}


	public String getApp_id() {
		return app_id;
	}


	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}


	public String getGrantee_id() {
		return grantee_id;
	}


	public void setGrantee_id(String grantee_id) {
		this.grantee_id = grantee_id;
	}


	public String getGrantee_name() {
		return grantee_name;
	}


	public void setGrantee_name(String grantee_name) {
		this.grantee_name = grantee_name;
	}


	public String getCan_grant() {
		return can_grant;
	}


	public void setCan_grant(String can_grant) {
		this.can_grant = can_grant;
	}


	public String getIs_valid_grant() {
		return is_valid_grant;
	}


	public void setIs_valid_grant(String is_valid_grant) {
		this.is_valid_grant = is_valid_grant;
	}
	public TIMESTAMP getModified_time() {
		return modified_time;
	}
	public void setModified_time(TIMESTAMP modified_time) {
		this.modified_time = modified_time;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}


/*	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}*/

}
