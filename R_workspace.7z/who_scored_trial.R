library('rvest')
library(jsonlite)

RowData<-vector()
MainData<-data.frame()

mainurl<-"https://www.whoscored.com/Matches/1317545"

previewUrl <- paste(mainurl,'/Preview',sep = "")
previewWeb <- read_html(previewUrl)

avgAge <- html_node(previewWeb,'#probable-lineup-stats > div.three-cols.stat-info.stat-bars-with-field-colors > div.centre > div > div:nth-child(2) > div:nth-child(2)')
avgAge <- strsplit(trimws(html_text(avgAge)),"\\s{2,}")
home_avg_age<- as.numeric(avgAge[[1]][1])
RowData["Home Average Age"]<-home_avg_age
away_avg_age<-as.numeric(avgAge[[1]][3])
RowData["Away Average Age"]<-away_avg_age

avgHght <- html_node(previewWeb,'#probable-lineup-stats > div.three-cols.stat-info.stat-bars-with-field-colors > div.centre > div > div:nth-child(2) > div:nth-child(3)')
avgHght <- strsplit(trimws(html_text(avgHght)),"\\s{2,}")
home_avg_height<- as.numeric(avgHght[[1]][1])
RowData["Home Average Height"]<-home_avg_height
away_avg_height<-as.numeric(avgHght[[1]][3])
RowData["away Average Height"]<-away_avg_height

shotsPg <- html_node(previewWeb,'#probable-lineup-stats > div.three-cols.stat-info.stat-bars-with-field-colors > div.centre > div > div:nth-child(3) > div:nth-child(1)')
shotsPg <- strsplit(trimws(html_text(shotsPg)),"\\s{2,}")
home_shots_pg<- paste(shotsPg[[1]][1],shotsPg[[1]][2],sep = "")
away_shots_pg<-paste(shotsPg[[1]][4],shotsPg[[1]][5],sep = "")
RowData["Home Shots PG"]<-home_shots_pg
RowData["Away Shots PG"]<-away_shots_pg

dribblePg <- html_node(previewWeb,'#probable-lineup-stats > div.three-cols.stat-info.stat-bars-with-field-colors > div.centre > div > div:nth-child(3) > div:nth-child(3)')
dribblePg <- strsplit(trimws(html_text(dribblePg)),"\\s{2,}")
home_dribble_pg<- paste(dribblePg[[1]][1],dribblePg[[1]][2],sep = "")
away_dribble_pg<-paste(dribblePg[[1]][4],dribblePg[[1]][5],sep = "")
RowData["Home Dribble PG"]<-home_dribble_pg
RowData["Away Dribble PG"]<-away_dribble_pg

preview_js <- html_node(previewWeb,xpath =  '//*[@id="preview"]/script[5]/text()')
preview_js<-strsplit(trimws(html_text(preview_js)),"\\s{2,}")
home_team_players<-substr(preview_js[[1]][2],31,nchar(preview_js[[1]][2])-3)
away_team_players<-substr(preview_js[[1]][3],31,nchar(preview_js[[1]][3])-3)
#home team player parsing to top player
home_team_players<-fromJSON(home_team_players)
home_team_players<-home_team_players[order(home_team_players$Rating ,decreasing = TRUE ),]
home_top_players<- c(home_team_players$Name[1],home_team_players$Name[2],home_team_players$Name[3])
#Away team player parsing to top player
away_team_players<-fromJSON(away_team_players)
away_team_players<-away_team_players[order(away_team_players$Rating ,decreasing = TRUE ),]
away_top_players<- c(away_team_players$Name[1],away_team_players$Name[2],away_team_players$Name[3])


#Missing player home and away
hmp_list<- vector()
amp_list<- vector()
i<- 1:3
for (val in i) {
  mpxpath<-paste('//*[@id="missing-players"]/div[1]/table/tbody/tr[',val,sep = "")
  mpxpath<-paste(mpxpath,']/td[1]/a',sep = )
  missing_player <- previewWeb %>% html_node(xpath = mpxpath) %>% html_text()
  hmp_list[val]<- missing_player
  mpxpath<-paste('//*[@id="missing-players"]/div[2]/table/tbody/tr[',val,sep = "")
  mpxpath<-paste(mpxpath,']/td[1]/a',sep = )
  missing_player <- previewWeb %>% html_node(xpath = mpxpath) %>% html_text()
  amp_list[val]<- missing_player
}
hmp_list <- hmp_list[!is.na(hmp_list)]
htp_m1<-""
htp_m2<-""
htp_m3<-""
atp_m1<-""
atp_m2<-""
atp_m3<-""
check_htop_missing<-match(hmp_list,home_top_players)
htopMiss<-check_htop_missing[!is.na(check_htop_missing)]
if(length(htopMiss)>0){
  i<- 1 : as.numeric(length(htopMiss))
  for(val in i ){
    
    if(htopMiss[val]==1){
      htp_m1<-"Y"
    }
    else{
      htp_m1<-"N"
    }
    if(htopMiss[val]==2){
      htp_m2<-"Y"
    }
    else{
      htp_m2<-"N"
    }
    if(htopMiss[val]==3){
      htp_m3<-"Y"
    }
    else{
      htp_m3<-"N"
    }
  }
  
}
amp_list <- amp_list[!is.na(amp_list)]
check_atop_missing<-match(amp_list,away_top_players)
atopMiss<-check_atop_missing[!is.na(check_atop_missing)]
if(length(atopMiss)>0){
  i<- 1 : as.numeric(length(atopMiss))
  for(val in i ){
    message("top player missing : ",away_top_players[atopMiss[val]])
    if(atopMiss[val]==1){
      atp_m1<-"Y"
    }
    else{
      atp_m1<-"N"
    }
    if(atopMiss[val]==2){
      atp_m2<-"Y"
    }
    else{
      atp_m2<-"N"
    }
    if(atopMiss[val]==3){
      atp_m3<-"Y"
    }
    else{
      atp_m3<-"N"
    }
  }
  
}
RowData["Top Player 1 missing (home)"]<-htp_m1
RowData["Top Player 2 missing (home)"]<-htp_m2
RowData["Top Player 3 missing (home)"]<-htp_m3
RowData["Top Player 1 missing (away)"]<-atp_m1
RowData["Top Player 2 missing (away)"]<-atp_m2
RowData["Top Player 3 missing (away)"]<-atp_m3

showUrl <- paste(mainurl,'/Show',sep = "")
showWeb <- read_html(showUrl)

matchCentreUrl<-paste(mainurl,'/Live',sep="")
matchCentreWeb<-read_html(matchCentreUrl)
centreData<- html_node(matchCentreWeb, xpath = '//*[@id="layout-content-wrapper"]/script[1]') %>%
html_text()
centreData<-strsplit(trimws(centreData),"\\s{2,}")
centreData<- centreData[[1]][1]
cd<-substr(centreData,22,nchar(centreData)-1)
cd<-fromJSON(cd)
MDate<-cd$startTime 
MDate<- strsplit(MDate,split = 'T')[[1]][1]
###################### Date of Match ##################
MDate<-format(as.Date(MDate), "%d/%m/%Y")
RowData["Date"]<-MDate
###################### League #########################
league<-html_node(matchCentreWeb,xpath = '//*[@id="breadcrumb-nav"]/a') %>% html_text(trim = TRUE)
RowData["League"]<-league
###################### Venue/Stadium #################
venue<- cd['venueName']
RowData["Stadium"]<-venue
###################### Home Team #####################
match_homeid<-"0"
match_home<-""
home_manager<-""
if (length(cd["home"])>0){ 
  if (length(cd$'home'$teamId)>0){
      match_homeid <- cd$'home'$teamId
      } else {
    match_homeid <- "0"
  }

  if (length(cd$'home'$name)>0){ 
    match_home <- cd$'home'$name 
  } else {
    match_home <- "Not Found!"
  }
  
  
  if(length(cd$'home'$managerName)>0){
    home_manager <- cd$'home'$managerName
  } else {
    home_manager <- ""
  }
} else {
  match_home <- "Not Found!"
  match_homeid <- "0"
}
RowData["Home Team"]<-match_home

###################### away Team #####################
match_awayid<-"0"
match_away<-""
away_manager<-""
if (length(cd["away"])>0){ 
  if (length(cd$'away'$teamId)>0){
    match_awayid <- cd$'away'$teamId
  } else {
    match_awayid <- "0"
  }
  
  if (length(cd$'away'$name)>0){ 
    match_away <- cd$'away'$name 
  } else {
    match_away <- "Not Found!"
  }
  
  
  if(length(cd$'away'$managerName)>0){
    away_manager <- cd$'away'$managerName
  } else {
    away_manager <- ""
  }
} else{
  match_away <- "Not Found!"
  match_awayid <- "0"
}
RowData["Away Team"]<-match_away

RowData["Home Manager"]<-home_manager
RowData["Away Manager"]<-away_manager
################# match weather ########################
match_weather <- ""
if(length(cd["weatherCode"])>0){
  match_weather <- cd["weatherCode"]
  
  if(match_weather == "1" ){
    match_weather <- "1"
  }
    
    if(match_weather == "2" ){
    match_weather <- "Rain"
    }
    
    if(match_weather == "3" ){
    match_weather <- "3"
    }
    
    if(match_weather == "4" ){
    match_weather <- "4"
    }
    
    if(match_weather == "5" ){
    match_weather <- "Clear"
    }
    
    if(match_weather == "6" ){
    match_weather <- "6"
    }
    
    if(match_weather == "7" ){
    match_weather <- "Cloudy"
    }
    
    if(match_weather == "8" ){
    match_weather <- "8"
    }
    
    if(match_weather == "9" ){
    match_weather <- "9"
    }
    
    if(match_weather == "10" ){
    match_weather <- "10"
    }
} else {
  match_weather <- ""
}
RowData["Weather"]<-match_weather
source('half_time.R')

