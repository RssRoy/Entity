
################################## HT home goals ############################

ht_home_goals<-cd$home$scores$halftime
RowData["HT Home Goals"]<-ht_home_goals
################################## HT away goals ############################

ht_away_goals<-cd$away$scores$halftime
RowData["HT Away Goals"]<-ht_away_goals

############################################################################
plimit<-45
if(length(cd$periodEndMinutes)>0){
  plimit<-cd$periodEndMinutes$`1`
}

################################# ht home shots ##############################
ht_totalHS<-0
if(length(cd$home$stats$shotsTotal)>0){
  totalShots<-names(cd$home$stats$shotsTotal)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_totalHS<-ht_totalHS+as.numeric(cd$home$stats$shotsTotal[v])
    }
  }
}
RowData["HT Home Shots"]<-ht_totalHS
################################# ht away shots ##############################
ht_totalAS<-0
if(length(cd$away$stats$shotsTotal)>0){
  totalShots<-names(cd$away$stats$shotsTotal)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_totalAS<-ht_totalAS+as.numeric(cd$away$stats$shotsTotal[v])
    }
  }
}
RowData["HT Away Shots"]<-ht_totalAS

################################# ht home shots on target ##############################
ht_totalHSOT<-0
if(length(cd$home$stats$shotsOnTarget)>0){
  totalShots<-names(cd$home$stats$shotsOnTarget)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_totalHSOT<-ht_totalHSOT+as.numeric(cd$home$stats$shotsOnTarget[v])
    }
  }
}
RowData["HT Home Shots OT"]<- ht_totalHSOT
################################# ht away shots on target ##############################
ht_totalASOT<-0
if(length(cd$away$stats$shotsOnTarget)>0){
  totalShots<-names(cd$away$stats$shotsOnTarget)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_totalASOT<-ht_totalASOT+as.numeric(cd$away$stats$shotsOnTarget[v])
    }
  }
}

RowData["HT Away Shots OT"]<- ht_totalASOT

################################# ht home shots on post ##############################
ht_totalHSOP<-0
if(length(cd$home$stats$shotsOnPost)>0){
  totalShots<-names(cd$home$stats$shotsOnPost)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_totalHSOP<-ht_totalHSOP+as.numeric(cd$home$stats$shotsOnPost[v])
    }
  }
}
RowData["HT Home Woodwork"]<- ht_totalHSOP
################################# ht away shots on post ##############################
ht_totalASOP<-0
if(length(cd$away$stats$shotsOnPost)>0){
  totalShots<-names(cd$away$stats$shotsOnPost)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_totalASOP<-ht_totalASOP+as.numeric(cd$away$stats$shotsOnPost[v])
    }
  }
}
RowData["HT Away Woodwork"]<- ht_totalASOP
##############################ht home and away 6yrd box #####################
hc_6yrd <- 0
ac_6yrd <- 0
ev<-which(cd$events$isShot==TRUE)
if (length(cd$events)>0) {
  for (i in ev){
    if(("SmallBoxCentre" %in% cd$events$qualifiers[i][[1]]$type$displayName ) && (cd$events$period$displayName[i] == "FirstHalf")){
      if(cd$events$teamId[i]==match_homeid){
        hc_6yrd<-hc_6yrd+1
      }
      if(cd$events$teamId[i]==match_awayid){
        ac_6yrd<-ac_6yrd+1
      }
    }
    
  }
}
RowData["HT Home 6yrd Box"]<-hc_6yrd
RowData["HT Away 6yrd Box"]<-ac_6yrd
##############################ht home and away pen/A #####################
hc_pen <- 0
ac_pen <- 0
ev<-which(cd$events$isShot==TRUE)
if (length(cd$events)>0) {
  for (i in ev){
    if(("SmallBoxCentre" %in% cd$events$qualifiers[i][[1]]$type$displayName ) || ( "BoxLeft" %in% cd$events$qualifiers[i][[1]]$type$displayName ) || ("BoxRight" %in% cd$events$qualifiers[i][[1]]$type$displayName )){
      if(cd$events$period$displayName[i] == "FirstHalf"){
        if(cd$events$teamId[i]==match_homeid){
          hc_pen<-hc_pen+1
        }
        if(cd$events$teamId[i]==match_awayid){
          ac_pen<-ac_pen+1
        }
      }
      
    }
    
  }
}
RowData["HT Home Pen/A"]<- hc_pen
RowData["HT Away Pen/A"]<- ac_pen

##############################ht away pen/A  #####################
hc_open <- 0
ac_open <- 0
ev<-which(cd$events$isShot==TRUE)
if (length(cd$events)>0) {
  for (i in ev){
    if(("RegularPlay" %in% cd$events$qualifiers[i][[1]]$type$displayName ) && (cd$events$period$displayName[i] == "FirstHalf")){
      if(cd$events$teamId[i]==match_homeid){
        hc_open<-hc_open+1
      }
      if(cd$events$teamId[i]==match_awayid){
        ac_open<-ac_open+1
      }
    }
    
  }
}
RowData["HT Home Open Play"]<-hc_open
RowData["HT Away Open Play"]<-ac_open

################################# ht home passes ##############################
ht_totalHPasses<-0
if(length(cd$home$stats$passesTotal)>0){
  totalShots<-names(cd$home$stats$passesTotal)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_totalHPasses<-ht_totalHPasses+as.numeric(cd$home$stats$passesTotal[v])
    }
  }
}
RowData["HT Home Passes"]<-ht_totalHPasses
################################# ht away passes ##############################
ht_totalAPasses<-0
if(length(cd$away$stats$passesTotal)>0){
  totalShots<-names(cd$away$stats$passesTotal)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_totalAPasses<-ht_totalAPasses+as.numeric(cd$away$stats$passesTotal[v])
    }
  }
}
RowData["HT Away Passes"]<-ht_totalAPasses
################################## HT Home and away Forward Passes #####################
ht_hforwrd<-0
ht_aforwrd<-0
ex<-0
endX<-0
i<-1:length(cd$events$type$displayName)
for (v in i ){
  if((cd$events$type$displayName[v]== "Pass") && (cd$events$period$displayName[v]=="FirstHalf")){
    ex<-cd$events$x[v]
    if(is.na(cd$events$endX[v])){
      endX<-as.double(ex)
    } else {
      endX<- as.double(cd$events$endX[v])
    }
    if(endX>ex){
      if(cd$events$teamId[v] == match_homeid){
        ht_hforwrd<-ht_hforwrd+1
      }
      if(cd$events$teamId[v] == match_awayid){
        ht_aforwrd<-ht_aforwrd+1
      }
    }
  }
}
RowData["HT Home Forward Passes"]<-ht_hforwrd
RowData["HT Away Forward Passes"]<-ht_aforwrd

##################### HT Home Corner ##################################
ht_hcorners<-0
if(length(cd$home$stats$cornersTotal)>0){
  totalShots<-names(cd$home$stats$cornersTotal)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_hcorners<-ht_hcorners+as.numeric(cd$home$stats$cornersTotal[v])
    }
  }
}
RowData["HT Home Corner"]<-ht_hcorners
##################### HT Away Corner ##################################
ht_acorners<-0
if(length(cd$away$stats$cornersTotal)>0){
  totalShots<-names(cd$away$stats$cornersTotal)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_acorners<-ht_acorners+as.numeric(cd$away$stats$cornersTotal[v])
    }
  }
}
RowData["HT Away Corner"]<-ht_acorners
##################### HT Home and away Third Passes ##################################
ht_h3rdp<-0
ht_a3rdp<-0
ex<-0
endX<-0
i<-1:length(cd$events$type$displayName)
for (v in i ){
  if((cd$events$type$displayName[v]== "Pass") && (cd$events$period$displayName[v]=="FirstHalf")){
    ex<-cd$events$x[v]
  if(is.na(cd$events$endX[v])){
    endX<-as.double(ex)
  } else {
    endX<- as.double(cd$events$endX[v])
  }
  if(endX>66.6){
    if(cd$events$teamId[v] == match_homeid){
      ht_h3rdp<-ht_h3rdp+1
    }
    if(cd$events$teamId[v] == match_awayid){
      ht_a3rdp<-ht_a3rdp+1
    }
  }
  }
}
RowData["HT Home Final Third Passes"]<-ht_h3rdp
RowData["HT Away Final Third Passes"]<-ht_a3rdp

##################### HT Home and away mid Passes ##################################
ht_hmidPass<-0
ht_amidPass<-0
ex<-0
endX<-0
i<-1:length(cd$events$type$displayName)
for (v in i ){
  if((cd$events$type$displayName[v]== "Pass") && (cd$events$period$displayName[v]=="FirstHalf")){
    ex<-cd$events$x[v]
    if(is.na(cd$events$endX[v])){
      endX<-as.double(ex)
    } else {
      endX<- as.double(cd$events$endX[v])
    }
    if((endX<=66.6) && (endX > 33.3)){
      if(cd$events$teamId[v] == match_homeid){
        ht_hmidPass<-ht_hmidPass+1
      }
      if(cd$events$teamId[v] == match_awayid){
        ht_amidPass<-ht_amidPass+1
      }
    }
  }
}

RowData["HT Home Mid Third Passes"]<-ht_hmidPass
RowData["HT Away Mid Third Passes"]<-ht_amidPass
##################### HT Home and away Dribbles ##################################
ht_hdribbles<-0
ht_adribbles<-0
ex<-0
endX<-0
i<-1:length(cd$events$type$displayName)
for (v in i ){
  if((cd$events$type$displayName[v]== "TakeOn") && (cd$events$period$displayName[v]=="FirstHalf")){
    if(cd$events$teamId[v] == match_homeid){
      ht_hdribbles<-ht_hdribbles+1
    }
    if(cd$events$teamId[v] == match_awayid){
      ht_adribbles<-ht_adribbles+1
    }
  }
}

RowData["HT Home Dribbles"]<-ht_hdribbles
RowData["HT Away Dribbles"]<-ht_adribbles
##################### HT Home Touches ##################################
ht_hTouches<-0
if(length(cd$home$stats$touches)>0){
  totalShots<-names(cd$home$stats$touches)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_hTouches<-ht_hTouches+as.numeric(cd$home$stats$touches[v])
    }
  }
}
RowData["HT Home Touches"]<-ht_hTouches
##################### HT Away Touches ##################################
ht_aTouches<-0
if(length(cd$away$stats$touches)>0){
  totalShots<-names(cd$away$stats$touches)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      ht_aTouches<-ht_aTouches+as.numeric(cd$away$stats$touches[v])
    }
  }
}
RowData["HT Away Touches"]<-ht_aTouches
##################### HT Home Ratings ##################################
ht_hRatings<-0
cnt<-0
if(length(cd$home$stats$ratings)>0){
  totalShots<-names(cd$home$stats$ratings)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      cnt<-cnt+1
      ht_hRatings<-ht_hRatings+as.numeric(cd$home$stats$ratings[v])
    }
  }
}
ht_hRatings<- ht_hRatings/as.double(cnt)
RowData["HT Home Total Player Ratings"]<-ht_hRatings
##################### HT Away Ratings ##################################
ht_aRatings<-0
cnt<-0
if(length(cd$away$stats$ratings)>0){
  totalShots<-names(cd$away$stats$ratings)
  for(v in totalShots){
    if(as.numeric(v) < plimit){
      cnt<-cnt+1
      ht_aRatings<-ht_aRatings+as.numeric(cd$away$stats$ratings[v])
    }
  }
}
ht_aRatings<- ht_aRatings/as.double(cnt)
RowData["HT Away Total Player Ratings"]<-ht_aRatings

source('full_time.R')

