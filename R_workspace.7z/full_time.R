####################################### FT Home Goals ###############################
ft_home_goals<- cd$home$scores$fulltime
RowData["FT Home Goals"]<-ft_home_goals
####################################### FT Away Goals ###############################
ft_away_goals<- cd$away$scores$fulltime
RowData["FT Away Goals"]<-ft_away_goals
################################# FT home shots ##############################
ft_totalHS<-0
if(length(cd$home$stats$shotsTotal)>0){
  totalShots<-names(cd$home$stats$shotsTotal)
  for(v in totalShots){
    ft_totalHS<-ft_totalHS+as.numeric(cd$home$stats$shotsTotal[v])
    
  }
}
RowData["FT Home Shots"]<-ft_totalHS
################################# FT away shots ##############################
ft_totalAS<-0
if(length(cd$away$stats$shotsTotal)>0){
  totalShots<-names(cd$away$stats$shotsTotal)
  for(v in totalShots){
    ft_totalAS<-ft_totalAS+as.numeric(cd$away$stats$shotsTotal[v])
    
  }
}
RowData["FT Away Shots"]<-ft_totalAS

################################# FT home shots on target ##############################
ft_totalHSOT<-0
if(length(cd$home$stats$shotsOnTarget)>0){
  totalShots<-names(cd$home$stats$shotsOnTarget)
  for(v in totalShots){
    
      ft_totalHSOT<-ft_totalHSOT+as.numeric(cd$home$stats$shotsOnTarget[v])
    
  }
}
RowData["FT Home Shots OT"]<-ft_totalHSOT
################################# FT away shots on target ##############################
ft_totalASOT<-0
if(length(cd$away$stats$shotsOnTarget)>0){
  totalShots<-names(cd$away$stats$shotsOnTarget)
  for(v in totalShots){
    
    ft_totalASOT<-ft_totalASOT+as.numeric(cd$away$stats$shotsOnTarget[v])
    
  }
}
RowData["FT Away Shots OT"]<-ft_totalASOT


################################# ft home shots on woodwork ##############################
ft_totalHSOP<-0
if(length(cd$home$stats$shotsOnPost)>0){
  totalShots<-names(cd$home$stats$shotsOnPost)
  for(v in totalShots){
    
      ft_totalHSOP<-ft_totalHSOP+as.numeric(cd$home$stats$shotsOnPost[v])
    
  }
}
RowData["FT Home Woodwork"]<- ft_totalHSOP
################################# ft away shots on woodwork ##############################
ft_totalASOP<-0
if(length(cd$away$stats$shotsOnPost)>0){
  totalShots<-names(cd$away$stats$shotsOnPost)
  for(v in totalShots){
    
      ft_totalASOP<-ft_totalASOP+as.numeric(cd$away$stats$shotsOnPost[v])
    
  }
}
RowData["FT Away Woodwork"]<- ft_totalASOP

############################## ft home and away 6yrd box #####################
fthc_6yrd <- 0
ftac_6yrd <- 0
ev<-which(cd$events$isShot==TRUE)
if (length(cd$events)>0) {
  for (i in ev){
    if(("SmallBoxCentre" %in% cd$events$qualifiers[i][[1]]$type$displayName ) ){
      if(cd$events$teamId[i]==match_homeid){
        fthc_6yrd<-fthc_6yrd+1
      }
      if(cd$events$teamId[i]==match_awayid){
        ftac_6yrd<-ftac_6yrd+1
      }
    }
    
  }
}
RowData["FT Home 6yrd Box"]<-fthc_6yrd
RowData["FT Away 6yrd Box"]<-ftac_6yrd



############################## ft home and away pen/A #####################
fthc_pen <- 0
ftac_pen <- 0
ev<-which(cd$events$isShot==TRUE)
if (length(cd$events)>0) {
  for (i in ev){
    if(("SmallBoxCentre" %in% cd$events$qualifiers[i][[1]]$type$displayName ) || ( "BoxLeft" %in% cd$events$qualifiers[i][[1]]$type$displayName ) || ("BoxRight" %in% cd$events$qualifiers[i][[1]]$type$displayName )){

        if(cd$events$teamId[i]==match_homeid){
          fthc_pen<-fthc_pen+1
        }
        if(cd$events$teamId[i]==match_awayid){
          ftac_pen<-ftac_pen+1
        }
      
      
    }
    
  }
}
RowData["FT Home Pen/A"]<- fthc_pen
RowData["HT Away Pen/A"]<- ftac_pen


############################## ft home and open  #####################
fthc_open <- 0
ftac_open <- 0
ev<-which(cd$events$isShot==TRUE)
if (length(cd$events)>0) {
  for (i in ev){
    if("RegularPlay" %in% cd$events$qualifiers[i][[1]]$type$displayName){
      if(cd$events$teamId[i]==match_homeid){
        fthc_open<-fthc_open+1
      }
      if(cd$events$teamId[i]==match_awayid){
        ftac_open<-ftac_open+1
      }
    }
    
  }
}
RowData["FT Home Open Play"]<-fthc_open
RowData["FT Away Open Play"]<-ftac_open


################################# ft home passes ##############################
ft_totalHPasses<-0
if(length(cd$home$stats$passesTotal)>0){
  totalShots<-names(cd$home$stats$passesTotal)
  for(v in totalShots){
    
      ft_totalHPasses<-ft_totalHPasses+as.numeric(cd$home$stats$passesTotal[v])
    
  }
}
RowData["FT Home Passes"]<-ft_totalHPasses

################################# ft away passes ##############################
ft_totalAPasses<-0
if(length(cd$away$stats$passesTotal)>0){
  totalShots<-names(cd$away$stats$passesTotal)
  for(v in totalShots){
    
      ft_totalAPasses<-ft_totalAPasses+as.numeric(cd$away$stats$passesTotal[v])
    
  }
}
RowData["FT Away Passes"]<-ft_totalAPasses

################################## FT Home and away Forward Passes #####################
ft_hforwrd<-0
ft_aforwrd<-0
ex<-0
endX<-0
i<-1:length(cd$events$type$displayName)
for (v in i ){
  if(cd$events$type$displayName[v]== "Pass"){
    ex<-cd$events$x[v]
    if(is.na(cd$events$endX[v])){
      endX<-as.double(ex)
    } else {
      endX<- as.double(cd$events$endX[v])
    }
    if(endX>ex){
      if(cd$events$teamId[v] == match_homeid){
        ft_hforwrd<-ft_hforwrd+1
      }
      if(cd$events$teamId[v] == match_awayid){
        ft_aforwrd<-ft_aforwrd+1
      }
    }
  }
}
RowData["FT Home Forward Passes"]<-ft_hforwrd
RowData["FT Away Forward Passes"]<-ft_aforwrd

##################### FT Home Corner ##################################
ft_hcorners<-0
if(length(cd$home$stats$cornersTotal)>0){
  totalShots<-names(cd$home$stats$cornersTotal)
  for(v in totalShots){

      ft_hcorners<-ft_hcorners+as.numeric(cd$home$stats$cornersTotal[v])
    
  }
}
RowData["FT Home Corner"]<-ft_hcorners

##################### fT Away Corner ##################################
ft_acorners<-0
if(length(cd$away$stats$cornersTotal)>0){
  totalShots<-names(cd$away$stats$cornersTotal)
  for(v in totalShots){


      ft_acorners<-ft_acorners+as.numeric(cd$away$stats$cornersTotal[v])
    
  }
}
RowData["FT Away Corner"]<-ft_acorners

##################### FT Home and away Third Passes ##################################
ft_h3rdp<-0
ft_a3rdp<-0
ex<-0
endX<-0
i<-1:length(cd$events$type$displayName)
for (v in i ){
  if(cd$events$type$displayName[v]== "Pass"){
    ex<-cd$events$x[v]
    if(is.na(cd$events$endX[v])){
      endX<-as.double(ex)
    } else {
      endX<- as.double(cd$events$endX[v])
    }
    if(endX>66.6){
      if(cd$events$teamId[v] == match_homeid){
        ft_h3rdp<-ft_h3rdp+1
      }
      if(cd$events$teamId[v] == match_awayid){
        ft_a3rdp<-ft_a3rdp+1
      }
    }
  }
}
RowData["FT Home Final Third Passes"]<-ft_h3rdp
RowData["FT Away Final Third Passes"]<-ft_a3rdp

##################### FT Home and away mid Passes ##################################
ft_hmidPass<-0
ft_amidPass<-0
ex<-0
endX<-0
i<-1:length(cd$events$type$displayName)
for (v in i ){
  if(cd$events$type$displayName[v]== "Pass"){
    ex<-cd$events$x[v]
    if(is.na(cd$events$endX[v])){
      endX<-as.double(ex)
    } else {
      endX<- as.double(cd$events$endX[v])
    }
    if((endX<=66.6) && (endX > 33.3)){
      if(cd$events$teamId[v] == match_homeid){
        ft_hmidPass<-ft_hmidPass+1
      }
      if(cd$events$teamId[v] == match_awayid){
        ft_amidPass<-ft_amidPass+1
      }
    }
  }
}

RowData["FT Home Mid Third Passes"]<-ft_hmidPass
RowData["FT Away Mid Third Passes"]<-ft_amidPass

##################### FT Home and away Dribbles ##################################
ft_hdribbles<-0
ft_adribbles<-0
ex<-0
endX<-0
i<-1:length(cd$events$type$displayName)
for (v in i ){
  if(cd$events$type$displayName[v]== "TakeOn"){
    if(cd$events$teamId[v] == match_homeid){
      ft_hdribbles<-ft_hdribbles+1
    }
    if(cd$events$teamId[v] == match_awayid){
      ft_adribbles<-ft_adribbles+1
    }
  }
}

RowData["FT Home Dribbles"]<-ft_hdribbles
RowData["FT Away Dribbles"]<-ft_adribbles
##################### fT Home Touches ##################################
ft_hTouches<-0
if(length(cd$home$stats$touches)>0){
  totalShots<-names(cd$home$stats$touches)
  for(v in totalShots){

      ft_hTouches<-ft_hTouches+as.numeric(cd$home$stats$touches[v])
    
  }
}
RowData["FT Home Touches"]<-ft_hTouches
##################### fT Away Touches ##################################
ft_aTouches<-0
if(length(cd$away$stats$touches)>0){
  totalShots<-names(cd$away$stats$touches)
  for(v in totalShots){

    ft_aTouches<-ft_aTouches+as.numeric(cd$away$stats$touches[v])
    
  }
}
RowData["FT Away Touches"]<-ft_aTouches

##################### fT Home Ratings ##################################
ft_hRatings<-0
cnt<-0
if(length(cd$home$stats$ratings)>0){
  totalShots<-names(cd$home$stats$ratings)
  for(v in totalShots){

      cnt<-cnt+1
      ft_hRatings<-ft_hRatings+as.numeric(cd$home$stats$ratings[v])
    
  }
}
ft_hRatings<- ft_hRatings/as.double(cnt)
RowData["FT Home Total Player Ratings"]<-ft_hRatings
##################### fT Away Ratings ##################################
ft_aRatings<-0
cnt<-0
if(length(cd$away$stats$ratings)>0){
  totalShots<-names(cd$away$stats$ratings)
  for(v in totalShots){

      cnt<-cnt+1
      ft_aRatings<-ft_aRatings+as.numeric(cd$away$stats$ratings[v])
    
  }
}
ft_aRatings<- ft_aRatings/as.double(cnt)
RowData["FT Away Total Player Ratings"]<-ft_aRatings
##################################### current minute ####################
ts<- cd$elapsed
ts<-gsub("'","",ts)
RowData["Current Minute"]<-ts
MainData<-rbind(MainData,RowData)
write.csv(MainData,file = 'whoScored.csv')

