$( document ).ready(function() {
    console.log( "ready!" );
    //alert("ready");
    $.ajax({
        type : "POST",
        url : "/getAppList",
        success : function(res) {
        	//alert(res);
        	$('#appName').html(res);
        	
        },
        error : function(res) {
        	alert(res);
        }
    });
});


function encodeHtml(text) {
	  return text
	      .replace(/&/g, "&amp;")
	      .replace(/</g, "&lt;")
	      .replace(/>/g, "&gt;")
	      .replace(/"/g, "&quot;")
	      .replace(/'/g, "&#039;");
}
function decodeHtml(text) {
	  return text
	      .replace(/&amp;/g, "&")
	      .replace(/&lt;/g, "<")
	      .replace(/&gt;/g, ">")
	      .replace(/&quot;/g, "\"")
	      .replace(/&#039;/g, "\'");
}


/*$('#submitBtn').click(function(){
	$('#submitBtn').attr("disabled","disabled");
});*/




function showLoading(){
	$('body').fadeTo(500, 0.4);
	$('#loader').show();
	$('#loading').show();
}
function hideLoading(){
	$('#loader').hide();
	$('#loading').hide();
	$('body').fadeTo(1000, 1);
}


function submitFile(){
	 //$('#submitBtn').attr("disabled","disabled");
	//$('body').css('display', 'none');
	
	 event.preventDefault();
	 console.log("loading started");
		showLoading();
     // Get form
     var form = $('#uploadForm')[0];

		// Create an FormData object 
     var data = new FormData(form);

		// If you want to add an extra field for the FormData
     //data.append("appName", $('#appName option:selected').val());

		// disabled the submit button
     console.log(data);
     $("#submitBtn").prop("disabled", true);
     if($('#appName option:selected').val()==='none'){
    	 $.confirm({
      	    title: 'Incomplete Data!',
      	    content: "No Application selected",
      	  buttons: {
		        OK: function () {
		        	location.reload(true);
		        },
		     }
      	});
    	 
     }
     $.ajax({
         type: "POST",
         enctype: 'multipart/form-data',
         url: "/uploadFile",
         data: data,
         processData: false,
         contentType: false,
         cache: false,
         timeout: 600000,
         success: function (data) {
        	 console.log("loading done");
        	 hideLoading();
        	 //$('body').css('display', 'block');
             $("#result").text(data);
             if(data=='No Application selected'){
            		 console.log("app not passed");
             }
             else if(data=='No file Selected'){
            	 /*$.alert({
               	    title: 'Incomplete Data!',
               	    content: data,
               	 location.reload(true);
               	});*/
            	 $.confirm({
            		 	title: 'Incomplete Data!',
                	    content: data,
            		    buttons: {
            		        OK: function () {
            		        	location.reload(true);
            		        },
            		     }
            		});
            	 //location.reload(true);
             }
             else if(data.includes("fail")){
            	 console.log("Failed during elasticsearch Posting : ", data);
                 $.confirm({
                	    title: 'Failed!',
                	    content: data,
                	    buttons: {
            		        OK: function () {
            		        	location.reload(true);
            		        },
            		     }
                	});
             }
             else{
             console.log("SUCCESS : ", data);
             $.confirm({
            	    title: 'Success!',
            	    content: data,
            	    buttons: {
        		        OK: function () {
        		        	location.reload(true);
        		        },
        		     }
            	});
             }
             
             //$("#btnSubmit").prop("disabled", false);

         },
         error: function (e) {
        	 hideLoading();
        	 $.alert({
         	    title: 'Error!',
         	    content: e.responseText,
         	});
             $("#result").text(e.responseText);
             console.log("ERROR : ", e);
             //$("#btnSubmit").prop("disabled", false);

         }
     });
	
}
