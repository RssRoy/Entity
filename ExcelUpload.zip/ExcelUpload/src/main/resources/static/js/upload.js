$( document ).ready(function() {
    console.log( "ready!" );
    //alert("ready");
    $.ajax({
        type : "POST",
        url : "/getAppList",
        success : function(res) {
        	//alert(res);
        	$('#appName').html(res);
        	
        },
        error : function(res) {
        	alert(res);
        }
    });
});