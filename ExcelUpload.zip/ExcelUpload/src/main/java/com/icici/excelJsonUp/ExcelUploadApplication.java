package com.icici.excelJsonUp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelUploadApplication.class, args);
	}
}
