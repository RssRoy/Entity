package com.icici.excelJsonUp;

import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Configuration
@Component
@RestController
public class MainController {

	@Value("${spring.elasticsearch.jest.proxy.host}")
	public static String eserver;

	@Value("${spring.elasticsearch.jest.proxy.host}")
	public void setEserver(String db) {

		eserver = db;
	}

	@Value("${spring.datasource.url}")
	public static String dbUrl;

	@Value("${spring.datasource.url}")
	public void setDbUrl(String db) {

		dbUrl = db;
	}

	@Value("${spring.datasource.username}")
	public static String dbUser;

	@Value("${spring.datasource.username}")
	public void setDbUser(String db) {

		dbUser = db;
	}

	@Value("${spring.datasource.password}")
	public static String dbPass;

	@Value("${spring.datasource.password}")
	public void setDbPass(String db) {

		dbPass = db;
	}

	@Value("${user_app_table_name}")
	public static String tableName;

	@Value("${user_app_table_name}")
	public void setTableName(String db) {

		tableName = db;
	}
	
	
	private Object getCellValue(Cell cell) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();

		case Cell.CELL_TYPE_BOOLEAN:
			return cell.getBooleanCellValue();

		case Cell.CELL_TYPE_NUMERIC:
			return cell.getNumericCellValue();
		}

		return null;
	}

	public String readBooksFromExcelFile(String excelFilePath) throws IOException {
		//List<FAQ> listBooks = new ArrayList<FAQ>();
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet firstSheet = workbook.getSheetAt(0);
		Iterator<Row> iterator = firstSheet.iterator();
		JsonArray jarr = new JsonArray();
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			if(nextRow.getRowNum()==0) {
				System.out.println("Skipped first row ");
				continue;
			}
			//System.out.println("Row number ------ : ---"+nextRow.getRowNum());
			Iterator<Cell> cellIterator = nextRow.cellIterator();
			//FAQ aBook = new FAQ();
			
			JsonObject element = new JsonObject();
			while (cellIterator.hasNext()) {
				
				Cell nextCell = cellIterator.next();
				int columnIndex = nextCell.getColumnIndex();
				//System.out.println(columnIndex);
				switch (columnIndex) {
				case 1:
					//System.out.println("questions:  "+getCellValue(nextCell).toString());
					element.addProperty("question", getCellValue(nextCell).toString());
					break;
				case 2:
					String variations = (String) getCellValue(nextCell);
					JsonArray varArr = new JsonArray();
					//System.out.println("variations:  "+variations);
					List<String> var = Arrays.asList(variations.split("\\$\\$"));
					for(String v : var) {
						//System.out.println("v----------"+v);
						varArr.add(v);
					}
					//System.out.println("variations:  "+variations.split(" \\$\\$ "));
					element.add("variation", varArr);
					break;
				case 3:
					//System.out.println("answer:  "+getCellValue(nextCell).toString());
					String ans = getCellValue(nextCell).toString();
					element.addProperty("answer", ans.replaceAll("·\\t", ">"));
					break;
				}

			}
			//System.out.println("element:   "+element);
			if(element.size()>0) {
				jarr.add(element);
			}
			//listBooks.add(aBook);
		}

		inputStream.close();
		//System.out.println(jarr.toString());
		return jarr.toString();
		//return listBooks;
	}

	@RequestMapping(value = "/getAppList", method = RequestMethod.POST)
	public String getAppList() throws SQLException, ClassNotFoundException {
		Class.forName("oracle.jdbc.driver.OracleDriver");

		// step2 create the connection object
		Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPass);

		// step3 create the statement object
		Statement stmt = con.createStatement();

		// step4 execute query
		ResultSet rs = stmt.executeQuery("select * from " + tableName);
		String res = "<option value='none'>Select Application</option>";
		while (rs.next()) {
			// System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));
			res += "<option value='" + rs.getString(2).toLowerCase().trim() + "'>" + rs.getString(2).trim() + "</option>";

		}
		// step5 close the connection object
		con.close();
		stmt.close();
		rs.close();
		System.out.println(res);
		return res;
	}
	public String elasticLoad(String jsondata, String appname) throws IOException {
		JsonParser parser = new JsonParser();
	    JsonArray data = parser.parse(jsondata.trim()).getAsJsonArray();
	    int size=data.size();
	    RestClient restClient = RestClient.builder(new HttpHost("10.78.11.134", 9200, "http")).build();
	    HttpEntity entity = null;
	    Response indexResponse = null;
	    //HttpEntity ent = null;
	    //String responseBody = null;
	    for(int i=0;i<size;i++) {
	    	String body = data.get(i).getAsJsonObject().toString(); 
	    	System.out.println("Json faq body ::::: "+body);
	    	/*if (i >20) {
	    		break;
	    	}*/
	    	entity = new NStringEntity(body, ContentType.APPLICATION_JSON);

	        indexResponse = restClient.performRequest("POST", "/excel_data_chatbot/"+appname,
	                Collections.<String, String>emptyMap(), entity);
	        //ent = indexResponse.getEntity();
	        //responseBody = EntityUtils.toString(ent,"UTF-8");
	        System.out.println("Status code of response : "+indexResponse.getStatusLine().getStatusCode());
	        if(indexResponse.getStatusLine().getStatusCode()!=201) {
	        	System.out.println("failed at "+i+" position data");
	        	return "failed at "+i+" position data";
	        }
	     }
	    restClient.close();
		return "success";
	}

	@ResponseBody
	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	public String doPost(@RequestParam("file") MultipartFile file, @RequestParam("appName") String appName)
			throws ServletException, IOException {
		appName=URLEncoder.encode(appName, "UTF-8");
		/*System.out.println("Print atleast something");
		System.out.println("appname:  " + appName);
		System.out.println("file : " + file);*/
		if(appName==null || appName.trim().equals("") || appName.trim().equals("none")) {
			return "No Application selected";
		}
		if (file.isEmpty()) {
			System.out.println("No file selected");
			return "No file Selected";
		}

		byte[] bytes = file.getBytes();
		Path path = Paths.get(file.getOriginalFilename());
		System.out.println("filename : " + file.getOriginalFilename());
		Files.write(path, bytes);
	    //File currDir = new File(file);
	    //String path1 = currDir.getAbsolutePath();
	    //String fileLocation = path1.substring(0, path1.length() - 1) + file.getOriginalFilename();
	    String fileLocation=path.toAbsolutePath().toString();
		System.out.println("File Path: "+fileLocation);
	    String jsondata= readBooksFromExcelFile(fileLocation);
	    System.out.println("After getting data:\n"+jsondata.trim());
	    String result = elasticLoad(jsondata.trim(),appName.trim());
	    if(result.contains("fail")) {
	    	return "Data insertion failed";
	    }
		return "Data successfully inserted for Application : " + URLDecoder.decode(appName).toUpperCase();

	}
}
