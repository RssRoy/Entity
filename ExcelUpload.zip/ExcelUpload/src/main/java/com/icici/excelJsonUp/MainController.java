package com.icici.excelJsonUp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Configuration
@Component 
@RestController
public class MainController {
	@RequestMapping(value = "/getAppList", method = RequestMethod.POST)
	public String getAppList() throws SQLException, ClassNotFoundException{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:49161:xe","ranjit","ranjit");  
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select * from chatbot_user_app_table");
		String res = "";
		while(rs.next()){
			//System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
			res+="<option value='"+rs.getString(2).toLowerCase()+"'>"+rs.getString(2)+"</option>";
			  
		}
		//step5 close the connection object  
		con.close();
		stmt.close();
		rs.close(); 
		System.out.println(res); 
		return res;
	}

}
