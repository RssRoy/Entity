#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 24 17:52:38 2018

@author: ranjit
"""

import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep
from dateutil.parser import parse
import traceback
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
import csv
import re
import urllib

dir_path = os.path.dirname(os.path.realpath(__file__))
print(dir_path)

#prefs = {"profile.managed_default_content_settings.images":2}
#chromeOptions = webdriver.ChromeOptions()
#chromeOptions.add_experimental_option("prefs",prefs)
driver = webdriver.Chrome(dir_path+'/chromedriver')#,chrome_options=chromeOptions)
pageid=4
for pageid in range(27,35):
    
    newpath = dir_path+'/images/image-'+str(pageid) 
    if not os.path.exists(newpath):
        os.makedirs(newpath)
    
    csvfile = newpath+'/image-data-'+str(pageid)+'.csv'
    social_link = dir_path+'/social_link.csv'
    header = ['event_name', 'event_image_name']
        
    #driver.get('https://trdevents.no/events/list/?tribe_event_display=list&tribe-bar-date=2018-03-01')
    driver.get('https://trdevents.no/events/list/?tribe_paged='+str(pageid)+'&tribe_event_display=list&tribe-bar-date=2018-03-01')
    eventDivs = driver.find_elements_by_css_selector('#tribe-events-content > div.tribe-events-loop.vcalendar > div')
    
    print(len(eventDivs))
    
    main_window = driver.current_window_handle
    i=0
    netid=0
    done=0
    with open(csvfile, "a") as output:
          writer = csv.writer(output, lineterminator='\n')
          if(done==0):
              writer.writerow(header)
    
    for div in eventDivs:
        try:
            i=i+1
            if(i<=done):
                continue;
            #start_date
            '''month = div.find_element_by_css_selector('div > div.col-event-date.col-sm-2.hidden-xs > div > div > p.calendar-month').text
            day = div.find_element_by_css_selector('div > div.col-event-date.col-sm-2.hidden-xs > div > div > p.calendar-day').text
            year = '2018'
            start_date = day+'-'+month+'-'+year
            print(start_date)'''
            print(i)
            print(div.get_attribute('id'))
            print(str(div.get_attribute('id')).find('netboard'));
            if(str(div.get_attribute('id')).find('netboard')>=0):
                continue;
            try:
                url = div.find_element_by_css_selector('div > div.col-event-content.col-sm-6.hidden-xs > h2 > a')
            except:
                sleep(1)
                print('Exception  in URL element not found')
                url = div.find_element_by_css_selector('div >  div.col-event-content.col-xs-12.visible-xs > h2 > a')
            
            print ("URL to open: "+url.get_attribute('href'))
            #sleep(3)
            print ("URL opened: "+url.get_attribute('href'))
            url.send_keys(Keys.CONTROL+Keys.RETURN)
            driver.switch_to_window(driver.window_handles[1])
            sleep(2) #seconds
            #event_name
            
            try:
                event_name = driver.find_element_by_css_selector('#tribe-events-content > h2').text
            except:
                print('Exception  in Event Name')
                sleep(2)
                event_name = driver.find_element_by_css_selector('#tribe-events-content > h2').text
            
            #event_name = driver.find_element_by_css_selector('#tribe-events-content > h2').text
            print("Event Name:"+event_name)
            event_name=re.sub(" ","-",event_name)
            event_name=re.sub("/","--",event_name)
            sleep(1)
            #event_img
            print("Downloading image for event : "+event_name)
            try:
                event_img = driver.find_element_by_css_selector('div.tribe-events-event-image > a > img')
                img_src=event_img.get_attribute("src")
                urllib.request.urlretrieve(img_src, newpath+'/'+img_src[(img_src.rfind('/')+1):])
                print("Downloaded image for event :"+event_name)
                final_list = [event_name, img_src[(img_src.rfind('/')+1):]]
            
            except:
                print("No Image for the event : "+event_name)
                final_list = [event_name, '']
            #print(img_src[(img_src.rfind('/')+1):])
            #break
            #event_img = " ".join(event_desc.split())
            #print("Event Desc:"+event_desc)
            
            # download the image
            
            
            print("Final List:")
            print(final_list)
            with open(csvfile, "a") as output:
                writer = csv.writer(output, lineterminator='\n')
                writer.writerow(final_list)
            
            print('============================================')
            print('')
            
            sleep(1)
            driver.close()
            #sleep(1)

            driver.switch_to_window(main_window)
            #break
        except Exception:
            print('no data here')
            print(traceback.format_exc())
            break
    #close chrome driver
driver.close()