var debug=false;

////////////////////////////////////////////get selected app name from url////////////////////////////////////////////////////////////////////

$.urlParam = function(name) {
var results = new RegExp('[\?&]' + name + '=([^&#]*)')
.exec(window.location.href);
if (results == null) {
return null;
} else {
return decodeURI(results[1]) || 0;
}
}

/////////////////////////////////////////////////////////////////////////////////////////////////// getting error message


function checkSession(){
	
	
	
	$.ajax({
		type : "POST",
		url : "/checkSession",
		data : {},
		success : function(res) {
			if(res===-1){
				var choice=confirm("Session Expired, Please press OK to reload \n CANCEL  to close window");
				if(choice===true){
					var App=$('#AppNameSelect option:selected').text();
					var url=window.location.href;
					var AppinUrl=$.urlParam('appName');
					if(App===AppinUrl){
						window.location.assign(url);
						
					}else if(App!==AppinUrl && AppinUrl!==null){
						
						var baseUrl=url.substring(0,url.indexOf('/'));
						window.location.assign(baseUrl+"?appName="+App);
					
					}else{
						window.location.assign(url+"?appName="+App);
					}
					if(debug){console.log("Session dead,Reload");}
				}else{
					
					window.close();
					if(debug){console.log("Session dead,Close");}
				}
			}else{
				if(debug){console.log("Session active");}
			}
		},
		error : function(res) {
			if(debug){ console.log("error in check session");}
		}
	
});
}
/*
function checkTime(){
	
	
	
	$.ajax({
		type : "POST",
		url : "/checkRemainingTime",
		data : {},
		success : function(res) {
			if(res===-1){
				var choice=confirm("Session Expired, Please press OK to reload \n CANCEL  to close window");
				if(choice===true){
					var App=$('#AppNameSelect option:selected').text();
					var url=window.location.href;
					var AppinUrl=$.urlParam('appName');
					if(App===AppinUrl){
						window.location.assign(url);
						
					}else if(App!==AppinUrl && AppinUrl!==null){
						
						var baseUrl=url.substring(0,url.indexOf('/'));
						window.location.assign(baseUrl+"?appName="+App);
					
					}else{
						window.location.assign(url+"?appName="+App);
					}					if(debug){console.log("Session dead,Reload");}
				}else{
					//window.open('','_self');
					window.close();
					if(debug){console.log("Session dead,Close");}
				}
			}else{
				if(debug){console.log("Time Remaining:"+res);}
				var remain=res;
				if(remain<120){
				if(res)
				var choice=confirm("Your Session will  Expire in "+res+" Seconds, Please press OK to reload \n CANCEL  to close window");
				if(choice===true){
					var App=$('#AppNameSelect option:selected').text();
					var url=window.location.href;
					var AppinUrl=$.urlParam('appName');
					if(App===AppinUrl){
						window.location.assign(url);
						
					}else if(App!==AppinUrl && AppinUrl!==null){
						
						var baseUrl=url.substring(0,url.indexOf('/'));
						window.location.assign(baseUrl+"?appName="+App);
					
					}else{
						window.location.assign(url+"?appName="+App);
					}
					if(debug){console.log("AppNameSelected:"+App);}
					
					
					if(debug){console.log("Session dead,Reload");}
				}else{
					
					window.close();
					if(debug){console.log("Session dead,Close");}
				}
				}else{
					if(debug){console.log("Session time is larger than 2 minutes ");}
				}
				if(debug){console.log("Session active");}
			}
		},
		error : function(res) {
			if(debug){ console.log("error in check session");}
		}
	
});
}*/

$(document).ready(function(){
	//for 14 minutes;
	var validateSession = setInterval(checkSession, 5*61*1000);//61 sec 	// check every 12 minutes 
	/*var validateSessionTime = setInterval(checkTime, 1*4*1000); // 15 sec */
});