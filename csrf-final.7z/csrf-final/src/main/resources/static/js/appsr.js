function fillAppSRModal(id) {
	if(debug){ console.log(id);}
	if(debug){ console.log(id.id);}
	if(debug){ console.log($('#' + id.id).attr("value"));}
	 var date = new Date();
	if ($('#' + id.id).attr("value") === 'new') {
		$('#myappid').val('');
		$('#appIdHide').hide();
		$('#myreasonid').val('');
		$('#myreasonlink').val('');
		$('#myreasonname').val('');
		$('#myappname').val('');
		$('#myappname').removeAttr('disabled');
		$('#myreasonid').removeAttr('disabled');
		$('#myAppSRModal').modal('toggle');
	} else {
	
		$.ajax({
			type : "POST",
			url : "/getJsonAppSR",
			data : {
				"reasonid" : $('#' + id.id).attr("data-reason-id"),
				"appid":$('#' + id.id).attr("data-app-id")
			},
			success : function(res) {
				res = JSON.parse(res);
				console.log(res);
				$('#myappid').val(res.app_id.toLowerCase());
				$('#myappname').val(res.app_name.toLowerCase());
				
				$('#myreasonid').val(res.reason_name.toLowerCase());
				//$('#myreasonname').val(res.reason_name.toLowerCase());
				
				$('#myreasonlink').val(res.reason_link);
				$('#myappname').attr('disabled','disabled');
				$('#myreasonid').attr('disabled','disabled');
				
				
			
				if(debug){ console.log(res);}
	
				$('#myAppSRModal').modal('toggle');
	
				if(debug){ console.log("logging done");}
			},
			error : function(res) {
				if(debug){ console.log("error logging---------");}
				if(debug){ console.log(res);}
			}
	
		});
	}

}


function createAppSRModal(id){
if(validateSRForm()==false){
	return false;
}
	$.ajax({
		type : "POST",
		url : "/insertAppSRLink",
		data : {
			"app_id" : $('#myappname option:selected').attr('data-id').trim(),
			"app_name" : $('#myappname').val().trim(),
			"reason_id": $('#myreasonid option:selected').attr('data-id').trim(),
			"reason_name": $('#myreasonid').val().trim(),
			"reason_link" : $('#myreasonlink').val().trim()
			
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res==-1){
				if(debug){ console.log("error inserting");}
				if(debug){ console.log("ERROR INSERTING APP SUB");}
				$('#createAppSR').attr('onclick','');
				$('#createAppSR').html('Error ! Please try  after some time.');
				$('#createAppSR').attr('disabled','disabled');
				
			}else if(res==3){
				if(debug){ console.log("APP Sub Area EXISTS");}
				$('#createAppSR').attr('onclick','');
				$('#createAppSR').html('App Name Already Exists.');
				$('#createAppSR').attr('disabled','disabled');
			}else{
				
				if(debug){ console.log("SUCCESS INSERTING");}
				$('#createAppSR').attr('onclick','commit();');
				$('#createAppSR').html('Commit');
				$('#cancelAppSR').attr('disabled','disabled');
			}
			
			
			
			

		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}
function validateSRForm(){
	var valid=true;
	var innerValid=false;
	$("form input").each(function(e){
		console.log($(this).val());
		console.log(this);
		console.log($(this).attr('id'));
		
		
		innerValid=false;
		 var reg =/<(.|\n)*?>/g; 
		//  var reg1 =/(\$|\^|\*|\|\/|\?|\:|\~|\!)/g; 
		 
		  
	        if (reg.test($(this).val()) == true) {
	         	console.log("HTML TAG");
	        	
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","HTML Tag are not allowed");
	          
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	       
	       return false;
	        }/*else if(reg1.test($(this).val()) == true){
	         	
	        	console.log("Symbols");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Special symbols like   $      \ ! ` ~  are not allowed");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');

	       
	       return false;
	        }*/
	        else if($(this).val()==undefined || ($(this).val()).length==0){
	        	/*console.log($(this).val()==undefined)
	        	console.log($(this).val()===undefined)
	        	console.log($(this).val()==='undefined')*/
	        	
	        	console.log("Empty or undefined");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Please fill the field.");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        }else{
	        	console.log("No Error");
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
	        	$(this).css('color','');
	        	innerValid=true;
	        }
	        	
	        
	       valid=valid && innerValid;
	});
	$("form textarea").each(function(e){
		console.log($(this).val());
		console.log(this);
		console.log($(this).attr('id'));
		
		
		innerValid=false;
		 var reg =/<(.|\n)*?>/g; 
		  var reg1 =/(\$|\^|\*|\|\/|\?|\:|\~|\!)/g; 
		 
		  
	        if (reg.test($(this).val()) == true) {
	         	console.log("HTML TAG");
	        	
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","HTML Tag are not allowed");
	          
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	       
	       return false;
	        }/*else if(reg1.test($(this).val()) == true){
	         	
	        	console.log("Symbols");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Special symbols like   $      \ ! ` ~  are not allowed");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');

	       
	       return false;
	        }*/else if($(this).val()==undefined || ($(this).val()).length==0){
	        	/*console.log($(this).val()==undefined)
	        	console.log($(this).val()===undefined)
	        	console.log($(this).val()==='undefined')*/
	        	
	        	console.log("Empty or undefined");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Please fill the field.");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        }else{
	        	console.log("No Error");
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
	        	$(this).css('color','');
	        	innerValid=true;
	        }
	        	
	        
	       valid=valid && innerValid;
	});
	
	$("form input[type=text]:not([type=hidden]").each(function(e){
		console.log($(this).val());
		console.log(this);
		console.log($(this).attr('id'));
		
		
		innerValid=false;
		 var reg =/<(.|\n)*?>/g; 
		  var reg1 =/(\$|\^|\*|\||\<|\>|\/|\?|\:|\~|\!)/g; 
		 
		  
	        if (reg.test($(this).val()) == true) {
	         	console.log("HTML TAG");
	        	
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","HTML Tag are not allowed");
	          
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	       
	       return false;
	        }else if(reg1.test($(this).val()) == true){
	         	
	        	console.log("Symbols");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Special symbols like   $   < > ,  \ ! ` ~  are not allowed");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');

	       
	       return false;
	        }else if($(this).val()==undefined || ($(this).val()).length==0){
	        	/*console.log($(this).val()==undefined)
	        	console.log($(this).val()===undefined)
	        	console.log($(this).val()==='undefined')*/
	        	
	        	console.log("Empty or undefined");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Please fill the field.");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        }else{
	        	console.log("No Error");
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
	        	$(this).css('color','');
	        	innerValid=true;
	        }
	        	
	        
	       valid=valid && innerValid;
	});
	
	
	/*$("form select").each(function(e){
		innerValid=innerValid && true;
		console.log($(e));
		if($(this).val()==undefined || $(this).val().trim().length==0){
			console.log("Empty or undefined select");
        	$(this).attr("data-toggle","tooltip")
        	$(this).attr("data-placement","auto")
        	$(this).attr("data-original-title","Please fill the field.");
           
        	$(this).css('color','red');
            $(this).tooltip({trigger: 'manual'}).tooltip('show');
            console.log("False");
            innerValid=false;
            
		}else{
			console.log("No Error in select ");
        	$(this).removeAttr("data-toggle")
        	$(this).removeAttr("data-placement")
        	$(this).removeAttr("title");
        	$(this).removeAttr("data-original-title");
            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
            $(this).attr('disabled','disabled');
        	$(this).css('color','');
        	innerValid=innerValid && true;
		}
		valid=valid && innerValid;
	});
	*/
	
	return valid && innerValid;
	
}