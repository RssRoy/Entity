/*$(document).ready(function(){
		var userid=$('#userid').val().toString().trim();
		$.ajax({
		    			type:"POST",
		    			url: "/LoginSSO",
		    			data : {"userid" : userid
		    					
		    					},
		    			success : function(res){
		    				console.log(res);
		    				UserActivitylog(userid.toUpperCase(),"LOGIN");
		    				location.replace('/admin');	    			
		    			},error:function(res){
		    				console.log(res);
		    				$('#alerttext').removeClass('alert-success').addClass('alert-danger');
							$('#alerttext').html("username or password incorrect!!!");
							$('#password').val('');

							$('#passDiv').attr("hidden","hidden");
							$('#login_btn').attr("onclick","check();");
		    				
		    			}
	});
	
});*/