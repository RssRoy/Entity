
	
function startConversation(ans){
	
	////alert("starting conversation:"+JSON.stringify(ans));
	ans=encode(JSON.stringify(ans));
	$('#jsondata').val(ans);
	startChat(ans);
}
/*function startChat(da){
	//alert("start chat");
	var path=$('#jsondatapath').val();
	var data=$('#jsondata').val();
	data=decode(data);
	//alert("start chat -->after decode data"+data);
	data=JSON.parse(data);
	////alert(data);
	if(debug){ console.log("data-------->");}
	if(debug){ console.log(data);}
	
	//alert("length-->"+data.length);
	if(debug){ console.log("length-->"+data.length);}
	
	
		//alert("all--->");
	
		
		if(data.constructor === Array && data.length>0){
			
			if(debug){ console.log("in if");}
			if(debug){ console.log(data);}
			var questions=new Array();
			var resp="";
			for(var i=0;i<data.length;){
				if(data[i].hasOwnProperty('answer') && data[i].hasOwnProperty('conv_ans')){
					sendMessage(data[i].answer,1);
        			log($("#AppNameSelect").val(),"CLICK ON LINK ",data[i].answer,"NULL","NULL","CONV_CHAT_ANSWER");	
        			if(debug){ console.log("data---->"+data[i].conv_ans[i].question.toString());}
					if(debug){ console.log(data[i].conv_ans.length);}
					
					resp='';
					for(var k=0;k<data[i].conv_ans.length;k++){
						questions.push(data[i].conv_ans[k].question);
						resp+="<li>" +
								"<h5>" +
								"<button class='conv_suggestion btn btn-responsive' id='myanswer'  onclick='getMyAnswer(this);'" +
									" value='"+encode(JSON.stringify(data[i].conv_ans[k]))+"'>"+(k+1)+".&nbsp;"+data[i].conv_ans[k].question +
								"</button>"+
								"</h5>"+
							"</li>";
	        			log($("#AppNameSelect").val(),"CLICK ON LINK ",data[i].conv_ans[k].question,"NULL","NULL","CONV_CHAT_SUGGESTIONS");	

					}
					i++;
				}else{
					if( data[i].hasOwnProperty('question')){
					if(debug){ console.log("else "+data[i].question+"  i::"+i);}
					questions.push(data[i].question);
					resp+="<li><h5><button class='conv_suggestion btn btn-responsive' id='myanswer' onclick='getMyAnswer(this);' value='"+encode(JSON.stringify(data[i]))+"'>"+(i+1)+".&nbsp;"+data[i].question+"</button></h5></li>";
        			log($("#AppNameSelect").val(),"CLICK ON LINK ",data[i].question,"NULL","NULL","CONV_CHAT_SUGGESTIONS");	
        			
					}
					i++;
					
				}
				
				
			}
			sendMessage(resp,1);
		}else{
			if(debug){ console.log("in else");}//when conv_ans length is 0 but it exist;
			sendDivFeedBack();
			//sendMessage(data.answer,1);
			
		}
	
	
}*/

function startChat(da){
	//alert("start chat");
	var path=$('#jsondatapath').val();
	var data=$('#jsondata').val();
	data=decode(data);
	data=JSON.parse(data);
	if(debug){ console.log("data---in conv.js----->");}
	if(debug){ console.log(data);}
	if(debug){ console.log("length-->"+data.length);}
	if(data.constructor === Array && data.length>0){
			if(debug){ console.log("conv.js--> data.constructor === Array ");}
			if(debug){ console.log(data);}
			var questions=new Array();
			var resp="";
			for(var i=0;i<data.length;	i++){
				if(data[i].hasOwnProperty('question')){ //if it has questions to show as options: 
					
					if(debug){ console.log("data[i].question---->"+data[i].question.toString());}
						questions.push(data[i].question);
						resp+="<li>" +
								"<h5>" +
									"<button class='conv_suggestion btn btn-responsive' id='myanswer'  onclick='getMyAnswer(this);'" +
										" value='"+encode(JSON.stringify(data[i]))+"'>"+(i+1)+".&nbsp;"+data[i].question +
									"</button>"+
								"</h5>"+
							   "</li>";
	        			log($("#AppNameSelect").val(),"CONV_CHAT_Q_CONV_ANS ",data[i].question,"NULL","NULL","CONV_CHAT_SUGGESTIONS");	

					}else if(data[i].hasOwnProperty('answer') && !data[i].hasOwnProperty('question') && data[i].hasOwnProperty('conv_ans')){
						//if it has solution to show firest then inner conv_ans--> questions;
						//sendMessage(data[i].answer,1);
						resp+='<h5><b>'+data[i].answer+'</b></h5>'
						for(var k=0;k<data[i].conv_ans.length;k++){
							questions.push(data[i].conv_ans[k].question);
							resp+="<li>" +
									"<h5>" +
									"<button class='conv_suggestion btn btn-responsive' id='myanswer'  onclick='getMyAnswer(this);'" +
										" value='"+encode(JSON.stringify(data[i].conv_ans[k]))+"'>"+(k+1)+".&nbsp;"+data[i].conv_ans[k].question +
									"</button>"+
									"</h5>"+
								"</li>";
		        			log($("#AppNameSelect").val(),"CLICK ON LINK ",data[i].conv_ans[k].question,"NULL","NULL","CONV_CHAT_SUGGESTIONS");	

						}	
						
						
					}
			}
			sendMessage(resp,1);
		}else{
		
			if(debug){ console.log("in else");}//when conv_ans length is 0 but it exist;
			sendDivFeedBack();
			//sendMessage(data.answer,1);
			
		}
	
	
}

function getMyAnswer(id){
	////alert("get my answer--->"+$(id).val());
	var jsond=($(id).val());
		jsond=decode(jsond);
		jsond=JSON.parse(jsond);
		
	
	if(jsond.hasOwnProperty('answer') && jsond.hasOwnProperty('question') && !jsond.hasOwnProperty('conv_ans')){
		//alert("all");
		
		var linkbtn="<div class='col-lg-12 pull-right' style='font-size:small; '><button class='btn col-sm-5 btn-link ' style='color:blue' onclick='openLink();'><span>Raise a Service Request</span></button></div>";
		
		sendMessage(jsond.question,2);
		sendMessage("<h4>"+jsond.question+"</h4>"+jsond.answer,1);
		//var divfeedback='<div><h4>Does it resolve your issue?</h4><button class="btn btn-link btn-success" id="yesbtn" onclick="thankyou();" style="padding-right: 5px;padding-left: 5px;"><span class="" style="color:chartreuse">Yes</span></button><button class="btn btn-link btn-warning" id="nobtn" onclick="raiseSR();" nstyle="padding-right: 5px;padding-left: 5px;"><span class=" " style="color:darkorange;">No</span></button></div>';
		//sendMessage(divfeedback,1);
		sendDivFeedBack();
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CONV_CHAT_QA");
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CLICKED ON LINK AND HAS CONV_CHAT_END");	
    	

	}if(jsond.hasOwnProperty('sql') && jsond.hasOwnProperty('question') && !jsond.hasOwnProperty('conv_ans')){
		var d=[]
		d[0]=jsond;
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	

		get_by_sql(d,0,uQuery);

	}else if(jsond.hasOwnProperty('question') && jsond.hasOwnProperty('answer') && jsond.hasOwnProperty('conv_ans')){
		
		sendMessage(jsond.question,2);
		sendMessage(jsond.answer,1);
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	

		startConversation(jsond.conv_ans);
	}else if(jsond.hasOwnProperty('question') && jsond.hasOwnProperty('sql') && jsond.hasOwnProperty('conv_ans')){
		
		sendMessage(jsond.question,2);
		
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");
		var d=[]
		d[0]=jsond;
		get_by_sql(d,0,uQuery);
		startConversation(jsond.conv_ans);
	}else if(jsond.hasOwnProperty('question') && jsond.hasOwnProperty('conv_ans')){
		
		sendMessage(jsond.question,2);
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	

		startConversation(jsond.conv_ans);
	}else if(jsond.hasOwnProperty('question') && jsond.hasOwnProperty('article_id')){
		log($("#AppNameSelect").val(),"CLICK ON LINK ",jsond.question,"NULL","NULL","CONV_CHAT_Q_CONV_ANS");	
		
		sendMessage(jsond.question,2);
		get_article_id(jsond.article_id,$('#user_last_query').val());
	}
}