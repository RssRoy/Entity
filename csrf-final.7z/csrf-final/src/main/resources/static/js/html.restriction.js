
if(debug){console.log($(':focus'));}
	


	var currentLocation=window.location.pathname;
	if(debug){console.log(currentLocation);};
/*
 * 
 * var inputArr= $(document).find('input[type=text]:not([readonly]');
 * 
 * console.log(inputArr);
 */
	
function validateForm(){
	var valid=true;
	var innerValid=false;
	$("form input[type=text]").each(function(e){
		if(debug){ console.log($(this).val());}
		if(debug){ console.log(this);}
		if(debug){ console.log($(this).attr('id'));}
		
		
		innerValid=false;
		 var reg =/<(.|\n)*?>/g; 
		  var reg1 =/(\@|\#|\$|\&|\,|\%|\^|\*|\||\<|\>|\/|\?|\:|\;|\=|\+|\`|\~|\!)/g; 
	        if (reg.test($(this).val()) == true) {
	         	if(debug){ console.log("HTML TAG");}
	        	
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","HTML Tag are not allowed");
	          
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	           
	       
	       return false;
	        }else if(reg1.test($(this).val()) == true){
	         	
	        	if(debug){ console.log("Symbols");}
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Special symbols like $ & % < > , \' \" ! ` ~  are not allowed");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');

	            
	          
	        
	       return false;
	        }else if($(this).val()==undefined || ($(this).val()).length==0){
	        	/*if(debug){ console.log($(this).val()==undefined)
	        	if(debug){ console.log($(this).val()===undefined)
	        	if(debug){ console.log($(this).val()==='undefined')*/
	        	
	        	if(debug){ console.log("Empty or undefined");}
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Please fill the field.");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	            if(debug){ console.log("False");}
	           return false;
	        }else{
	        	if(debug){ console.log("No Error");}
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
	        	$(this).css('color','');
	        	innerValid=true;
	        }
	        	
	        
	       valid=valid && innerValid;
	});
	
	$("form select").each(function(e){
		innerValid=innerValid && true;
		if(debug){ console.log($(e));}
		if($(this).val()==undefined || $(this).val().trim().length==0){
			if(debug){ console.log("Empty or undefined select");}
        	$(this).attr("data-toggle","tooltip")
        	$(this).attr("data-placement","auto")
        	$(this).attr("data-original-title","Please fill the field.");
           
        	$(this).css('color','red');
            $(this).tooltip({trigger: 'manual'}).tooltip('show');
            if(debug){ console.log("False");}
            innerValid=false;
            
		}else{
			if(debug){ console.log("No Error in select ");}
        	$(this).removeAttr("data-toggle")
        	$(this).removeAttr("data-placement")
        	$(this).removeAttr("title");
        	$(this).removeAttr("data-original-title");
            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
            $(this).attr('disabled','disabled');
        	$(this).css('color','');
        	innerValid=innerValid && true;
		}
		valid=valid && innerValid;
	});
	
	
	return valid && innerValid;
	
}
	
$(document).on('click','#createUser',function(e){

	if(debug){console.log("button click-->"+validateForm());}
		if(validateForm()===true){
			if(debug){console.log("Form Validated");}
			$('#createUser').removeAttr('disabled');
			$('#createUser').attr('onclick','createUserModal(this)');
			$('#createUser').html('Create');
			
			$('#myuserid').attr('readonly','readonly');
			$('#myusername').attr('readonly','readonly');
			$('#mymanagerid').attr('readonly','readonly');
			//if(debug){ console.log(this);
			$('#createUser').attr('onclick','createUserModal(this);');
			$('#createUser').html('Confirm');
			$('#myUserModal').css('display','block');
			
			
			$('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('hide'); 
			$(this).removeAttr("data-toggle")
			$(this).removeAttr("data-placement")
			$(this).removeAttr("data-original-title");
		    
			$(this).css('color','');
	
		}
});
	
$(document).on('click','#createApp',function(e){
	/*if(debug){ console.log($('#createApp').attr('onclick'));
	if(debug){ console.log('confirmAppModal(this)');
	if(debug){ console.log($('#createApp').attr('onclick')==='confirmAppModal(this)');
	if(debug){ console.log($('#createApp').attr('onclick')=='confirmAppModal(this)');}

	if($('#createApp').attr('onclick')==='confirmAppModal(this)'){
		return false;
	}*/
	if(debug){ console.log("button click");}
		if(validateForm()===true){
			if(debug){ console.log("Form Validated");}
			
			$('#myappname').attr('readonly','readonly');
			
			$('#createApp').removeAttr('disabled');
			$('#createApp').attr('onclick','createAppModal(this)');
			//$('#createApp').html('Confirm');
			
			//if(debug){ console.log(this);
			//$('#createApp').attr('onclick','createAppModal(this);');
			$('#createApp').html('Confirm');
			$('#myAppModal').css('display','block');
			
			$('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('hide'); 
			$(this).removeAttr("data-toggle")
			$(this).removeAttr("data-placement")
			$(this).removeAttr("data-original-title");
		    
			$(this).css('color','');
	
		}
});

$(document).on('click','#createGrant',function(e){
	$('#verifygranteeid').click();
	/*if(debug){ console.log($('#createGrant').attr('onclick'));
	if(debug){ console.log('createGrantModal(this)');
	if(debug){ console.log($('#createGrant').attr('onclick')==='createGrantModal(this)');
	if(debug){ console.log($('#createGrant').attr('onclick')=='createGrantModal(this)');}

	if($('#createGrant').attr('onclick')==='createGrantModal(this)'){
		if(debug){ console.log('return false;');}
		return false;
	}*/
	
	if(debug){ console.log("button click");}
		if(validateForm()===true){
			if(debug){ console.log("Form Validated");}
			
			$('#mygrantername').attr('readonly','readonly');
			$('#mygranteeusername').attr('readonly','readonly');
			$('#mygranteeid').attr('readonly','readonly');
			//$('#createGrant').attr('onclick','createGrantModal(this);');
			
			$('#myGrantModal').css('display','block');
			
			
			$('#createGrant').removeAttr('disabled');
			//if(debug){ console.log(this);}
			$('#createGrant').attr('onclick','createGrantModal(this)');
			$('#createGrant').html('Create');
			
			$('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('hide'); 
			$(this).removeAttr("data-toggle")
			$(this).removeAttr("data-placement")
			$(this).removeAttr("data-original-title");
		    
			$('form input').css('color','');
		}
});



$( "input[type=text] :not([readonly])" ).focusin(function(e) {
		if(debug){console.log($(this).val());}
		  
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            
	        	$(this).css('color','');
	         
	        
	        if(debug){console.log(this);}
	        e.preventDefault();
});
 

 