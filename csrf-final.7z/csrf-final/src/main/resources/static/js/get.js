	
	
	
	function getCompany(){
		
		var ans="";
		
	    	cname=$('#company').val().toString().toUpperCase().trim();
	    	if(cname.length>0){
	    		sendMessage("For "+cname+"<br/>",2);
	    		ansArr=$('#ans').val().toString().split('#');
	    		ansc=ansArr[0].replace("COMP_NAME = '&variable2'","COMP_NAME LIKE '%"+cname+"%'");
	    		
	    		if(debug){ console.log("after replacing &variable2 Final query after all :"+ansc);}
	    		$.ajax({
	    			type:"GET",
	    			url: "/executeQuery",
	    			data : {"appName" : "rmwb",
	    					"q" : ansc 
	    					},
	    			success : function(res){
	    						sendMessage(res,1);
	    						
	    			},
	    			error:function(res){
	    				sendMessage("Sorry error in sql query",1);
	    		}
	    	});// end of ajax
		  }
	    	//$('#sendcompany').remove();
		  }



	function getUccId(){
		if(debug){ console.log("UCC ID click");}
		var ans="";
		
	    	uccid=$('#uccid').val().toString().trim();
	    	if(debug){ console.log(uccid);}
	    	if(uccid.length>0){
	    		
	    		
	    		$.ajax({
	    			type:"GET",
	    			url: "/searchCompany",
	    			data : {"appName" : "companies",
	    					"q" : uccid 
	    					},
	    			success : function(res){
	    						
	    						if(debug){ console.log("-------------------------"+res);}
	    						var qa = JSON.parse(res);
	    						if(qa.hits.hits.length>0){
	    							sendMessage("For "+qa.hits.hits[0]._source.DISPLAY_STRING+"<br/>",2);
	    							ansArr=$('#ans').val().toString().split('#');
	    				    		ansu=ansArr[1].replace("&variable3","'"+uccid+"'");
	    			    		
	    							if(debug){ console.log("after replacing &variable3 Final query after all :"+ansu);}
	    							$.ajax({
	    								type:"GET",
	    								url: "/executeQuery",
	    								data : {"appName" : "rmwb",
	    										"q" : ansu 
	    			    						},
	    			    					success : function(res){
	    			    							sendMessage(res,1);
	    			    						
	    			    							
	    			    						},
	    			    					error:function(res){
	    			    							sendMessage("Sorry error in sql query",1);
	    			    						}
	    							});// end of ajax
	    						
	    						}else{
	    							sendMessage("No such code exists. Please verify again.",2);
	    						}	
	    			},
	    			error:function(res){
	    				sendMessage("Sorry error in sql query",1);
	    		}
	    	});
	    		
	    		
		  }
	}


	//drop down company
	
function getList(e){	
		var value = $('#company').val();
		if(debug){ console.log(value);}
		
		
		$.ajax({
			type : "GET",
			url : "/searchQuery",
			data : {"appName" : "companies",
				"q" : value
			},
			success : function(res) {
				if(debug){ console.log("res=:"+res);}
				var qa = JSON.parse(res);
				if(debug){ console.log("qa:"+qa.hits.hits.length);}
				if(debug){ console.log(qa.hits.hits);}
				$(".companylist li").remove();
				result = null;
				result = qa.hits.hits;
				set = new Set();
				qa.hits.hits.forEach(function(entry) {
					
					set.add(entry._source.DISPLAY_STRING);
				});
				var i=0;
				
				let array = Array.from(set);
				array.forEach(function (value){
					$(".companylist").show();
					if(debug){ console.log("source:"+value);}
					
					$(".companylist").append(
							"<li class='show' id='"+i+"' style='cursor: pointer; cursor: hand;' onclick='sendComp("+i+");'><h5>" + value
									+ "</h5></li>");
					
					i=i+1;
				}); 
				
			/*	qa.hits.hits.forEach(function(entry) {
					
					$(".companylist").show();
					if(debug){ console.log("source:"+entry._source.DISPLAY_STRING);}
					//if(entry._source.question){
					$(".companylist").append(
							"<li class='show' id='"+i+"' style='cursor: pointer; cursor: hand;' onclick='sendComp("+i+");'><h5>" + entry._source.DISPLAY_STRING
									+ "</h5></li>");
					
					i=i+1;
					//}
				});
				*/
			},
			error : function(res) {
				if(debug){ console.log("fail");}
				//sendMessage("Not enough data");
			}
		});
	
	}

function sendComp(i){
	//alert("click");
	//(result[$(this).attr("id")]._source.question);
	
		$('#company').val(result[i]._source.DISPLAY_STRING);
		if(debug){ console.log(result[i]._source.DISPLAY_STRING);}
		
		var ans="";
		
    	var cname=$('#company').val().toString().toUpperCase().trim();
    	if(cname.length>0){
    		sendMessage("For "+cname,2);
    		ansArr=$('#ans').val().toString().split('#');
    		ansc=ansArr[0].replace("COMP_NAME = '&variable2'","COMP_NAME LIKE '%"+cname+"%'");
    		
    		if(debug){ console.log("after replacing &variable2 Final query after all :"+ansc);}
    		$.ajax({
    			type:"GET",
    			url: "/executeQuery",
    			data : {"appName" : "rmwb",
    					"q" : ansc 
    					},
    			success : function(res){
    						sendMessage(res,1);
    						$('.companylist').text('');
    			},
    			error:function(res){
    				sendMessage("Sorry error in sql query",1);
    		}
    	});// end of ajax
	  }
}
	

	


	
	