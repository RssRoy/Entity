	
function validateMapForm(){
	var valid=true;
	var innerValid=false;
	$("form input[type=text]").each(function(e){
		console.log($(this).val());
		console.log(this);
		console.log($(this).attr('id'));
		
		
		innerValid=false;
		 var reg =/<(.|\n)*?>/g; 
		  var reg1 =/(\|\$|\&|\,|\%|\^|\*|\||\<|\>|\/|\?|\:|\;|\=|\+|\`|\~|\!)/g; 
		 
		  
	        if (reg.test($(this).val()) == true) {
	         	console.log("HTML TAG");
	        	
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","HTML Tag are not allowed");
	          
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	       
	       return false;
	        }else if(reg1.test($(this).val()) == true){
	         	
	        	console.log("Symbols");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Special symbols like # $ & % < > , \' \" ! ` ~  are not allowed");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');

	       
	       return false;
	        }else if($(this).val()==undefined || ($(this).val()).length==0){
	        	/*console.log($(this).val()==undefined)
	        	console.log($(this).val()===undefined)
	        	console.log($(this).val()==='undefined')*/
	        	
	        	console.log("Empty or undefined");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Please fill the field.");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        }      
	        else{
	        	console.log("No Error");
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
	        	$(this).css('color','');
	        	innerValid=true;
	        }
	        	
	        
	       valid=valid && innerValid;
	});
	
	$("form textbox").each(function(e){
		console.log($(this).val());
		console.log(this);
		console.log($(this).attr('id'));
		
		
		innerValid=false;
		 var reg =/<(.|\n)*?>/g; 
		  var reg1 =/(\|\$|\&|\,|\%|\^|\*|\||\<|\>|\/|\?|\:|\;|\=|\+|\`|\~|\!)/g; 
		 
		  
	        if (reg.test($(this).val()) == true) {
	         	console.log("HTML TAG");
	        	
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","HTML Tag are not allowed");
	          
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	       
	       return false;
	        }else if(reg1.test($(this).val()) == true){
	         	
	        	console.log("Symbols");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Special symbols like  # $ & % < > , \' \" ! ` ~  are not allowed");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');

	       
	       return false;
	        }else if($(this).val()==undefined || ($(this).val()).length==0){
	        	/*console.log($(this).val()==undefined)
	        	console.log($(this).val()===undefined)
	        	console.log($(this).val()==='undefined')*/
	        	
	        	console.log("Empty or undefined");
	        	$(this).attr("data-toggle","tooltip")
	        	$(this).attr("data-placement","auto")
	        	$(this).attr("data-original-title","Please fill the field.");
	           
	        	$(this).css('color','red');
	            $(this).tooltip({trigger: 'manual'}).tooltip('show');
	            console.log("False");
	           return false;
	        }      
	        else{
	        	console.log("No Error");
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
	        	$(this).css('color','');
	        	innerValid=true;
	        }
	        	
	        
	       valid=valid && innerValid;
	});
	
	$("form select").each(function(e){
		innerValid=innerValid && true;
		console.log($(e));
		if($(this).val()==undefined || $(this).val().trim().length==0){
			console.log("Empty or undefined select");
        	$(this).attr("data-toggle","tooltip")
        	$(this).attr("data-placement","auto")
        	$(this).attr("data-original-title","Please fill the field.");
           
        	$(this).css('color','red');
            $(this).tooltip({trigger: 'manual'}).tooltip('show');
            console.log("False");
            innerValid=false;
            
		}else{
			console.log("No Error in select ");
        	$(this).removeAttr("data-toggle")
        	$(this).removeAttr("data-placement")
        	$(this).removeAttr("title");
        	$(this).removeAttr("data-original-title");
            $(this).tooltip({trigger: 'manual'}).tooltip('hide');
            $(this).attr('disabled','disabled');
        	$(this).css('color','');
        	innerValid=innerValid && true;
		}
		valid=valid && innerValid;
	});
	
	
	return valid && innerValid;
	
}

$(document).on('click','#createMap',function(e){
		console.log("button click");
		if(validateMapForm()===true){
			console.log("Form Validated");
			
			$('#mymapname').attr('readonly','readonly');
			$('#mymapvalue').attr('readonly','readonly');
			$('#mymaplist').attr('readonly','readonly');
			
			
			
			//$('#createGrant').attr('onclick','createGrantModal(this);');
			
			$('#myMapModal').css('display','block');
			
			
			$('#createMap').removeAttr('disabled');
			//console.log(this);
			$('#createMap').attr('onclick','createMapModal(this)');
			$('#createMap').html('Create');
			
			$('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('hide'); 
			$(this).removeAttr("data-toggle")
			$(this).removeAttr("data-placement")
			$(this).removeAttr("data-original-title");
		    
			$('form input').css('color','');
		}
});



$( "input[type=text] :not([readonly])" ).focusin(function(e) {
		if(debug){console.log($(this).val());}
		  
	        	$(this).removeAttr("data-toggle")
	        	$(this).removeAttr("data-placement")
	        	$(this).removeAttr("title");
	        	$(this).removeAttr("data-original-title");
	            
	        	$(this).css('color','');
	         
	        
	        if(debug){console.log(this);}
	        e.preventDefault();
});
 