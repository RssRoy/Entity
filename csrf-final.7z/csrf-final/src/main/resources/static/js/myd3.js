/*---------------------bar graph--------*/
function plot_bar() {var margin = {top: 50, right: 20, bottom: 250, left: 45};
   

var x0 = d3.scaleBand().rangeRound([ 0, 510 ]).padding(0.6);

var x1 = d3.scaleOrdinal();

var y = d3.scaleLinear().range([145, 5]);

//var colorRange = d3.scale.category20();
var color = d3.scaleOrdinal().range([ "#8B0000","#CD853F" ]);
//#ff9900 #A52A2A
var xAxis = d3.axisBottom()
.scale(x0);

var yAxis = d3.axisLeft().scale(y).tickFormat(d3.format(".12"));

var divTooltip = d3.select("#bar-graph").append("svg").attr("class", "toolTip");

d3.select("#bar-graph").select("g").remove();

var svg = d3.select("#bar-graph").append("svg")
    .attr("width", 550)
    .attr("height", 990)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


dataset = document.getElementById("json-data").value;

dataset = JSON.parse(dataset);

var options = d3.keys(dataset[0]).filter(function(key) { return key !== "year"; });

dataset.forEach(function(d) {
    d.values = options.map(function(name) { return {name: name, value: +d[name]}; });
    document.getElementById("totIntDate").value = d.year;
    document.getElementById("totInt").value = d.value;
    console.log("BAr---->");
    console.log(d);
	
});

x0.domain(dataset.map(function(d) { return d.year; }));
x1.domain(options).range([0, x0.bandwidth()]);
y.domain([0, d3.max(dataset, function(d) { return d3.max(d.values, function(d) { return d.value; }); })]);

svg.append("g")
    .attr("class", "x axis")
    .call(xAxis)
//    .append("text")
    .attr("transform", "translate(0," + 150 + ")")
    .attr("x", 16)
    .attr("dx", ".71em")
    ;

svg.append("g")
    .attr("class", "y axis")
    .call(yAxis)
    .append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", 16)
    .attr("dy", ".71em")
    .style("text-anchor", "end");

var bar = svg.selectAll(".bar")
    .data(dataset)
    .enter().append("g")
    .attr("class", "rect")
    .attr("transform", function(d) { return "translate(" + x0(d.year) + ",0)"; });

var bar_enter = bar.selectAll("rect")
.data(function(d) { return d.values; })
.enter()

bar_enter.append("g")
.attr("width", x1)
.attr("x", function(d) { return x1(d.name); })
.attr("y", function(d) { return 0; })
.attr("value", function(d){return d.name;})
.attr("height", function(d) { return y(d.value); })
.style("fill", function(d) { return color(d.name); });

bar_enter.append("text")
.attr("y", function(d) { return y(d.value) - 8;  })
.attr("x", function(d) { return x1(d.name) +(x0.bandwidth()/4); })
.attr("dy", ".3em")
.text(function(d) { return d.value; });

bar.selectAll("rect")
    .data(function(d) { return d.values; })
    .enter().append("rect")
    .attr("width", x0.bandwidth())
    .attr("x", function(d) { return x1(d.name); })
    .attr("y", function(d) { return y(d.value); })
    .attr("value", function(d){return d.name;})
    .attr("height", function(d) { return 150 - y(d.value); })
    .style("fill", function(d) { return color(d.name); });


bar
    .on("mousemove", function(d){
        divTooltip.style("left", d3.event.pageX+10+"px");
        divTooltip.style("top", d3.event.pageY-25+"px");
        divTooltip.style("display", "inline-block");
        var x = d3.event.pageX, y = d3.event.pageY
        divTooltip.html((d.label)+"<br>"+(d.value)+"%")
        var elements = document.querySelectorAll(':hover');
        l = elements.length
        l = l-1
        elementData = elements[l].__data__
        divTooltip.html((d.year)+"<br>"+elementData.name+"<br>"+elementData.value+"%");
    });
bar
    .on("mouseout", function(d){
        divTooltip.style("display", "none");
    })
    .on("click", function(d) {
    	document.getElementById("totIntDate").value = d.year;
    	document.getElementById("totInt").value = elementData.value;
    	getSucRatio();
    	//getSucRatio(document.getElementById("totIntDate").value);
    	console.log("totIntDate - "+totIntDate+", totInt -- "+document.getElementById("totInt").value);
    });


var legend = svg.selectAll(".legend")
    .data(options.slice())
    .enter().append("g")
    .attr("class", "legend")
    .attr("transform", function(d, i) { return "translate(0," + (i - 15) * - 15 + ")"; });

legend.append("rect")
    .attr("x",  160)
    .attr("width", 28)
    .attr("height", 18)
    .style("fill", color);

legend.append("text")
    .attr("x", 280)
    .attr("y", 10)
    .attr("dy", ".5em")
    .style("text-anchor", "end")
    .attr("font-size","34px")
    .style("font-weight", "bold")
    .text(function(d) { return d; });

}
/*-------------power - gauge--------------*/
var gauge = function(container, configuration) {
	var that = {};
	var config = {
		size : 510,
		clipWidth : 500,
		clipHeight : 110,
		ringInset : 10,
		ringWidth : 10,

		pointerWidth : 10,
		pointerTailLength : 5,
		pointerHeadLengthPercent : 0.9,

		minValue : 0,
		maxValue : 10,

		minAngle : -90,
		maxAngle : 90,

		transitionMs : 500,

		majorTicks : 5,
		labelFormat : d3.format('d'),
		labelInset : 10,

		arcColorFn : d3.interpolateHsl(d3.rgb('#8B0000'),d3.rgb('#7FFF00'),d3.rgb('#008000'))
		//d3.rgb('#a05d56'), d3.rgb('#3e6c0a')
	};
	var range = 1000;
	var r = undefined;
	var pointerHeadLength = undefined;
	var value = 0;

	var svg = undefined;
	var arc = undefined;
	var scale = undefined;
	var ticks = undefined;
	var tickData = undefined;
	var pointer = undefined;

	var ratioVal = $('#ratio').val();
	
	var tip = d3.tip()
	.attr('class', 'd3-tip')
	.offset([-10, 0])
	.html(function (d) {
		return "<strong>Success Ratio:</strong> <span style='color:red'>" + $('#ratio').val() +"%</span>";
	});
	
	
	
	var donut = d3.pie();
	
	function deg2rad(deg) {
		return deg * Math.PI / 180;
	}

	function newAngle(d) {
		var ratio = scale(d);
		var newAngle = config.minAngle + (ratio * range);
		return newAngle;
	}

	function configure(configuration) {
		var prop = undefined;
		for (prop in configuration) {
			config[prop] = configuration[prop];
		}

		range = config.maxAngle - config.minAngle;
		r = config.size / 2;
		pointerHeadLength = Math.round(r * config.pointerHeadLengthPercent);

		// a linear scale that maps domain values to a percent from 0..1
		scale = d3.scaleLinear().range([ 0, 1 ]).domain(
				[ config.minValue, config.maxValue ]);

		ticks = scale.ticks(config.majorTicks);
		tickData = d3.range(config.majorTicks).map(function() {
			return 1 / config.majorTicks;
		});

		arc = d3.arc().innerRadius(r - config.ringWidth - config.ringInset)
				.outerRadius(r - config.ringInset).startAngle(function(d, i) {
					var ratio = d * i;
					return deg2rad(config.minAngle + (ratio * range));
				}).endAngle(function(d, i) {
					var ratio = d * (i + 1);
					return deg2rad(config.minAngle + (ratio * range));
				});
	}
	that.configure = configure;

	function centerTranslation() {
		return 'translate(' + r + ',' + r + ')';
	}

	function isRendered() {
		return (svg !== undefined);
	}
	that.isRendered = isRendered;

	function render(newValue) {
		
		gauges = d3.selectAll(container).datum(function () { return this.dataset; });
		
		svg = gauges.append('svg:svg')
					.attr('class', 'gauge')
					.attr('width', config.clipWidth)
					.attr('height',config.clipHeight);

//		svg.call(tip);	
		
		var centerTx = centerTranslation();

		var arcs = svg.append('g').attr('class', 'arc').attr('transform',
				centerTx);

		arcs.selectAll('path').data(tickData)
								.enter().append('path')
								.attr('fill', function(d, i) {
										return config.arcColorFn(d * i);
								}).attr('d', arc);

		var lg = svg.append('g').attr('class', 'label').attr('transform',
				centerTx);
		
		lg.selectAll('text').data(ticks).enter().append('text').attr(
				'transform',
				function(d) {
					var ratio = scale(d);
					var newAngle = config.minAngle + (ratio * range);
					return 'rotate(' + newAngle + ') translate(0,'
							+ (config.labelInset - r) + ')';
				}).text(config.labelFormat);

		var lineData = [ [ config.pointerWidth / 2, 0 ],
				[ 0, -pointerHeadLength ], [ -(config.pointerWidth / 2), 0 ],
				[ 0, config.pointerTailLength ], [ config.pointerWidth / 2, 0 ] ];
		
		var targetData = [[0, config.labelInset - r], [-config.pointerWidth / 2,
			config.labelInset - r - (config.pointerWidth / 2)], [config.pointerWidth / 2, config.labelInset - r - (config.pointerWidth / 2)]];
		
		var pointerLine = d3.line().curve(d3.curveMonotoneX)
		var pg = svg.append('g').data([ lineData ]).attr('class', 'pointer')
				.attr('transform', centerTx);

		pointer = pg.append('path').attr('d', pointerLine(lineData)
		 /*
			 * function(d) { return pointerLine(d) +'Z';}
			 */
		 ).attr('transform', 'rotate(' + config.minAngle + ')')
		 .on('mouseover', tip.show)
					.on('mouseout', tip.hide);;
		
		update(newValue === undefined ? 0 : newValue);
// update();
	}
	
	that.render = render;
	
	function update(newValue, newConfiguration) {
		if (newConfiguration !== undefined) {
			configure(newConfiguration);
		}
		
		var ratio = scale(newValue);
		var newAngle = config.minAngle + (ratio * range);
		pointer.transition().duration(config.transitionMs).ease(d3.easeElastic)
				.attr('transform', 'rotate(' + newAngle + ')');
	}
	that.update = update;

	configure(configuration);

	return that;
};

function onDocumentReady() {
	var powerGauge = gauge('#power-gauge', {
		size : 300,
		clipWidth : 300,
		clipHeight : 300,
		ringWidth : 60,
		maxValue : 100,
		transitionMs : 2000,
// arcColorFn: d3.scaleOrdinal().range(['#3182bd', '#9ecae1', '#3182bd'])
	});
	powerGauge.render();
	
	console.log("ratio:"+$('#ratio').val());
	function updateReadings() {
		// just pump in random data here...
		var ratioVal = $('#ratio').val();
		powerGauge.update(ratioVal);
		$('#power-gauge').each(function () {
			this.ratioVal = parseInt(parseInt(this.ratioVal));
		$(this).siblings("span").text(this.ratioVal);
		});
	}
	// every few seconds update reading values
	updateReadings();
	
	setInterval(function() {
		updateReadings();
	}, 3 * 100);
}

if (!window.isLoaded) {
	window.addEventListener("load", function() {
		onDocumentReady();
	}, false);
} else {
	onDocumentReady();
}

