
var valreg=/(@[A-Za-z0-9_\-]+@)/g;
function parse_sql(){
	if(validateSqlForm()==false){
if(debug){console.log("Validation Fails");}
		return;
	}
	
	var json = {};
	json.app_id=$('#myappname option:selected').attr('data-id');
	json.question=$('#question').val();
	json.answer=$('#answer').val();
	json.sql=$('#sql').val();	
	
if(debug){ console.log(JSON.stringify(json));}
// now parse table details and column details;

//note only character allowed are a-z A-Z 0-9 _ -
var valreg=/(@[A-Za-z0-9_\-]+@)/g;
if(debug){console.log(json.sql.match(valreg));}
if(debug){console.log(json);}

$('#parse_data').val(JSON.stringify(json));

// get input of respective values;
var listval=Array.from(new Set(json.sql.match(valreg)));
console.log(listval);
listval.forEach(function(val){
	$.ajax({
		type : "POST",
		url : "/getJsonMap",
		data : {
			"mapid" : val
		},
		success : function(res) {
			res=JSON.parse(res);
			append_column_value(res.map_id,res.map_name);
		},
		error:function(res){
			res=JSON.parse(res);
			append_column_value_readonly(res.map_id,res.map_name);
		}

	
		});
	});

	$('#upload_sql').html('Check');
	$('#upload_sql').attr('onclick','check_sql()');
	
}

function append_column_value(id,col_ask_name){
	var table_html="";
if(debug){console.log(id);}
	if(col_ask_name==='undefined' || col_ask_name==undefined){
		table_html+='<div class="form-group"><label id="label'+id+'" for="'+id+'" class="control-label col-sm-5" style="color:red;">'+col_ask_name +': '+id+'  :</label><div class="col-md-4"><input type="text"  class="form-control col-md-4" id="'+id+'" placeholder="mapping value not defined for '+id+'" required="required" readonly="readonly" /></div></div>';
	}else{
		table_html+='<div class="form-group"><label id="label'+id+'" for="'+id+'" class="control-label col-sm-5">'+col_ask_name +': '+id+'  :</label><div class="col-md-4"><input type="text"  class="form-control col-md-4" id="'+id+'" placeholder="value for '+id+'" required="required" /></div></div>';
	}
$('#sqllevel0').append(table_html);
	
}


function check_sql(){
	if(validateSqlForm()==false){
if(debug){console.log("Validation Fails");}
		return;
	}
	
	var json=$('#parse_data').val();
	json=JSON.parse(json);
	var keylist=Array.from(new Set(json.sql.match(valreg)));
	var coldata={};
	keylist.forEach(function(a){
		coldata[a]=$('#'+$.escapeSelector(a)).val();
		
	});
if(debug){console.log(keylist);}
if(debug){console.log(keylist.toString());}
	$.ajax({
		type : "POST",
		url : "/checkSql",
		data : {
			"appName" : $('#myappname').val().toLowerCase(),
			"keylist":keylist.toString(),
			"sqldata":JSON.stringify(json),
			"coldata":JSON.stringify(coldata)
		},
		success : function(res) {
			
			if(res.indexOf('Exception: ORA-')>0){
				$('#sqlresultbody').html("<h2>ERROR In SQL as per our Analysis:</h2></br>"+res);
				$('#sql_result_div').removeAttr('hidden');
				return;
			}
			$('#sqlresultbody').html(res);
			$('#sql_result_div').removeAttr('hidden');
			$('#submit_sql').removeAttr('disabled');
			$('#submit_sql').removeClass('btn-danger').addClass('btn-success');
			$('#submit_sql').html('Insert');
			$('#submit_sql').attr('onclick','confirm_insert_sql();');
			//$('#upload_sql').html('Modify');
			//$('#upload_sql').attr('onclick',modify_sql());
		},
		error:function(res){
			$('#sqlresultbody').html(res);
			$('#sql_result_div').removeAttr('hidden');
		}

	
		});
	
}

function confirm_insert_sql(){
	$('#question').attr('readonly','readonly');
	$('#answer').attr('readonly','readonly');
	$('#sql').attr('readonly','readonly');
	$('#myappname').attr('disabled','disabled');
	$('#submit_sql').html('Confirm Insert');
	$('#submit_sql').attr('onclick','insert_sql();');
}

function insert_sql(){
	var json=$('#parse_data').val();
	json=JSON.parse(json);
	
	$.ajax({
		type : "POST",
		url : "/insertSql",
		data : {
			"app_name" : $('#myappname').val().toLowerCase(),
			"jsonObj":JSON.stringify(json)		
		},
		success : function(res) {
			id=res.substring(res.indexOf("\"")+1);
			id=id.substring(0,id.indexOf("\""));
			//console.log(id.substring(0,id.indexOf("\"")+1));
			 $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ID: "+id+" \nData Inserted successfully");
				$('#data').html('');
				  $('#alerttext').addClass('alert alert-success').addClass('btn-success').removeClass(
				'btn-danger');
		},
		error:function(res){
			$('#sqlresultbody').html('ERROR');
			$('#sql_result_div').removeAttr('hidden');
		}

	
		});
	
}






$('#myappname').change(function(){
if(debug){console.log("appname--> change-->"+$('#myappname :selected').val().toUpperCase());}

	var t_app=$(this).val().trim();
	
	$('#myappid').val($('#myappname :selected').attr('data-id').toUpperCase());
	//console.log($('#myappname :selected').attr('data-id'))
	
	//$('#myappid option[text="'+encodeHtml(t_app).trim().toUpperCase()+'"]').attr("selected", "selected");
	$.ajax({
		type : "POST",
		url : "/appTnsExist",
		data : {
			"app_id" : $('#myappid').val()
		},

		success : function(res) {
if(debug){console.log(res);}
			if(res.toString().toUpperCase()=="NO"){
				$('#tns_exist').addClass("well well-sm alert-danger")
				$('#tns_exist').html("TNS not present. Please change app or contact application manager");
				$('#tns_exist').removeAttr("hidden");
			}else{
				$('#tns_exist').removeClass("well well-sm alert-danger");
				$('#tns_exist').attr("hidden","hidden");
			//$('#upload_sql').attr('disabled','disabled');
			}
		},
		error:function(res){
			$('#tns_exist').html("<button class='btn btn-danger'>ERROR</button>");
			
		}
	});
	
	
});

