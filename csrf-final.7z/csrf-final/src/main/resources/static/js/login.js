//debug on/off
var debug = false

/////////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////

if (typeof Array.prototype.forEach != 'function') {
    Array.prototype.forEach = function(callback){
      for (var i = 0; i < this.length; i++){
        callback.apply(this, [this[i], i, this]);
      }
    };
}


/////////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////





function check(){
	var username=$('#username').val().toString().trim();
	//alert("check");

		$.ajax({
			type:"POST",
			url: "/authenticateUser",
			data : {"username" : username
					},
			success : function(res){
				console.log(res);
				if(res.substr(0,7)==='Success'){
					$('#alerttext').removeClass('alert-danger').addClass('alert-success');
					$('#alerttext').html("Welcome : "+res.substring(8,res.indexOf('/')));
					$('#passDiv').removeAttr("hidden");
					$('#username').attr('readonly','readonly');
					$('#username').removeAttr('autofocus');
					
                    $('#login_btn').attr("type","submit");
                    $('#login_btn').removeAttr("onclick");
                    $('#password').focus();
				}else{
					$('#alerttext').removeClass('alert-success').addClass('alert-danger');
					$('#alerttext').html("Invalid Credentials");
					$('#username').removeAttr('disabled');
				}
			},error:function(res){
				$('#alerttext').removeClass('alert-success').addClass('alert-danger').html("Error");
				
			}
	});
};

function loginnow(){ 
	//alert("login");
	
		
	var username=$('#username').val().toString().trim();

			
	
			var password=$('#password').val().toString().trim();
			//if(debug){ console.log(username+"-----------"+password);}
			
			$.ajax({
	    			type:"POST",
	    			url: "/LoginServlet",
	    			data : {"username" : username,
	    					"password" : password
	    					
	    					},
	    			success : function(res){
	    				if(debug){ console.log(res);}
	    				UserActivitylog(username.toUpperCase(),"LOGIN DONE");
	    				location.replace('admin');	    			
	    			},error:function(res){
	    				if(debug){ console.log(res);}
	    				$('#alerttext').removeClass('alert-success').addClass('alert-danger');
						$('#alerttext').html("username or password incorrect!!!");
						$('#username').removeAttr('disabled');
						$('#password').val('');

						$('#passDiv').attr("hidden","hidden");
						$('#login_btn').attr("onclick","check();");
	    				
	    			}
});
};



function logout(){ 
	//alert("logout");
			$.ajax({
	    			type:"POST",
	    			url: "/LogoutServlet",
	    			data : {},	    					
	    			success : function(res){
	    				if(debug){ console.log(res);}
	    				
	    				UserActivitylog($('#userid').attr('value'),"LOGOUT",$('#sessionid').val().toString().trim());
	    				location.replace('/login');	    			
	    			},error:function(res){
	    				$('#alerttext').html(res);
	    				
	    				location.replace('/login');	 
	    			}
});
};

/*$(window).on('beforeunload', function() {
	alert("Close");
				$.ajax({
		    			type:"POST",
		    			url: "/LogoutServlet",
		    			data : {},	    					
		    			success : function(res){
		    				alert("Close");
		    				return true;			
		    			},error:function(res){
		    				alert("Close Failed");
		    				return false;
		    			}
				});
});*/