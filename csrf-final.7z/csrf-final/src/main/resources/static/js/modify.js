
var stack = '';

var _first = 0;
var id="lilevel0";
var divId='#data';
function init(){
	_first=0;
	id="lilevel0";
	divId="#data";
}

function modifySearchData() {
	$('#data').html('');
	init();
	var appName = $('#appName').val().toString().trim();
	var id = $('#id').val().toString().trim();
	$.ajax({
				type : "POST",
				url : "/searchData",
				data : {
					"appName" : appName,
					"id" : id
				},
				success : function(res) {
					if(debug){ console.log(res);}

					if(debug){ console.log("res=:" + res);}
					var qa = JSON.parse(res);
					if(debug){ console.log("qa:" + qa.hits.hits.length);}
					if(debug){ console.log('-------------------------------------');}
					if(qa.hits.hits[0]._source.hasOwnProperty('image') || qa.hits.hits[0]._source.hasOwnProperty('file')){
						
						 $('#alerttext').removeAttr('hidden');
						   $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>This Question has Image or File data which can't be modified. Please delete and create new Data.");
						   $('#alerttext').addClass('alert alert-danger').addClass('btn-danger').removeClass('alert-success btn-success');
						
					
						return;
					}
					
					jsonToHtml("lilevel0",qa.hits.hits[0]._source);
					$('#modifybtn').css('display',"initial");
					isVariation=true;
					


				},
				error : function(res) {
					if(debug){ console.log("fail");}
					 $('#alerttext').removeAttr('hidden');
					   $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ERROR : Please Check ID and Application Name");
					   $('#alerttext').addClass('alert alert-danger').addClass('btn-danger').removeClass('alert-success btn-success');
					
				
				}
			});// end of ajax

}








function modifyData() {
	
	if(debug){console.log("Modify Data()");}
	var art_id=$('.check_article_id');
	for(var i = 0; i < art_id.length; i++){
		if(debug){console.log($(art_id[i]).html());}
	   if($(art_id[i]).html().trim()=='Invalid ID' || $(art_id[i]).html().trim()=='Check'){
		   $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ERROR : Please Check All Article IDs to be VALID.");
		   $('#alerttext').addClass('alert alert-danger').addClass('btn-danger').removeClass('btn-success');
		  return false; 
	   }
	}
	
	
	var id = document.getElementById('lilevel0');
	filejson={}
	filejson=toJson(id, filejson, -1);

	if(debug){ console.log("--------------------------------------------------------");}
	if(debug){ console.log(JSON.stringify(filejson));}
	if(debug){ console.log(filejson);}
	var appName = $('#appName').val().toString().trim();
	appName=decodeHtml(appName);
	
	var id = $('#id').val().toString().trim();
	if(Object.getOwnPropertyNames(filejson).length > 0){
	$.ajax({
				type : "POST",
				url : "/modifyData",
				data : {
					"appName":appName,
					"id":id,
					"jsonObj":JSON.stringify(filejson)
				},
				success : function(res) {
					//if(debug){ console.log(res);}
					
					if(debug){ console.log(res);}
					/*var id=res.substring(res.search('#')+2,res.length-1);
					if(debug){ console.log(id);}*/
					
					Activitylog(appName,filejson.question,"MODIFY",id);
					 $('#alerttext').html("<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ID: "+id+"Data Modified successfully");
					$('#data').html('');
					  $('#alerttext').addClass('alert alert-success').addClass('btn-success').removeClass(
					'btn-danger');
					init();
					 $('#modifybtn').css('display',"none");
					 if(debug){ console.log('---------------------------------------------------------------completed');}
					 isVariation=true;
				},
				error : function(res) {
					if(debug){ console.log("fail");}
					$('#alerttext')
							.html(
									"<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ERROR : Please Check ID and Application Name.");
					  $('#alerttext').addClass('alert alert-danger').addClass('btn-danger').removeClass(
					'btn-success');
				}
			});// end of ajax
	}else{
		$('#alerttext')
		.html(
				"<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>ERROR : Please fill all the details");
$('#alerttext').addClass('btn-danger').removeClass(
'btn-success');
	}
}

