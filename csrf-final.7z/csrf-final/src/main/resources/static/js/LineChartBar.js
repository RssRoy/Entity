function lineBarChart() {
	// set the dimensions and marginLines of the graph
	var marginLine = {top: 20, right: 50, bottom: 30, left: 50},
	    width = 650 - marginLine.left - marginLine.right,
	    height = 200 - marginLine.top - marginLine.bottom;
	
	// parse the date / time
	var parseTime = d3.timeParse("%d%b%Y");
	var formatTime = d3.timeFormat("%d%b%Y");
	
	// set the ranges
	var line_x = d3.scaleTime().range([0, width]);
	//var x = d3.scaleBand().rangeRound([ 0, width ]);
	var line_y = d3.scaleLinear().range([height, 0]);
	
	// define the line
	var valueline = d3.line()
	    .x(function(d) { return line_x(d.date); })
	    .y(function(d) { return line_y(d.close); });
	
	// append the svg obgect to the body of the page
	// appends a 'group' element to 'svg'
	// moves the 'group' element to the top left marginLine
	
	d3.select("#line-graph").select("svg").remove();
	
	var svg = d3.select("#line-graph").append("svg")
	    .attr("width", width + marginLine.left + marginLine.right)
	    .attr("height", height + marginLine.top + marginLine.bottom)
	  .append("g")
	    .attr("transform",
	          "translate(" + marginLine.left + "," + marginLine.top + ")");
	
	var div = d3.select("body").append("div")
	    .attr("class", "tooltip")
	    .style("opacity", 0);
	
	data = document.getElementById("csv_data").value;
	data = JSON.parse(data);
	
	// Get the data
	/*d3.csv("data/data_lineChart.csv", function(error, data) {
	  if (error) throw error;*/
	
	  // format the data
	  data.forEach(function(d) {
	      console.log("d.Date:="+d.date);
	      d.date = parseTime(d.date);
//	      d.date = d.date;
	      console.log("d.Date="+d.date);
	      d.close = +d.close;
	  });
	
	  // scale the range of the data
	  line_x.domain(d3.extent(data, function(d) { return d.date; }));
	  line_y.domain([0, d3.max(data, function(d) { return d.close; })]);
	
	  // add the valueline path.
	  svg.append("path")
	     .data([data])
	     .attr("class", "line")
	     .attr("d", valueline);
	
	  // add the dots with tooltips
	  svg.selectAll("dot")
	     .data(data)
	   .enter().append("circle")
	     .attr("r", 5)
	     .attr("cx", function(d) { return line_x(d.date); })
	     .attr("cy", function(d) { return line_y(d.close); })
	     .on("mouseover", function(d) {
	       div.transition()
	         .duration(50)
	         .style("opacity", 10);
	       div.html("Date               :"+formatTime(d.date) + "<br/> Number of Interactions:" + d.close)
	         .style("left", (d3.event.pageX) + "px")
	         .style("top", (d3.event.pageY - 28) + "px")})
	         
	       .on("mouseout", function(d) {		
	           div.transition()		
	               .duration(50)		
	               .style("opacity", 0);	
	       });
	  
	  svg.selectAll("text.bar")
	  .data(data)
	.enter().append("text")
	  .attr("class", "bar")
	  .attr("text-anchor", "middle")
	  .attr("x", function(d) { return line_x(d.date); })
	  .attr("y", function(d) { return line_y(d.close) - 10; })
	  .style("fill", "#8B0000")
	  .attr("width", 128)
	   .style("font-weight", "bold")
	  .text(function(d) { return d.close; });
	
	//Add the X Axis
	  console.log("X-axis");
	  console.log(line_x);
	  console.log(data);
	  svg.append("g")
	      .attr("class", "axis")
	      .attr("transform", "translate(0," + height + ")")
	      
	      .call(d3.axisBottom(line_x).ticks(data.length).tickFormat(d3.timeFormat("%d%b%Y")))
//	      .call(d3.axisBottom(line_x).ticks(data.length+2).tickFormat(d3.timeFormat("%d%b%Y")))
	      .selectAll("text") 
	      .attr("cx", "-.10em")
	      .attr("cy", ".15em");
	//      .attr("transform", "rotate(-65)");
	  
	  // add the Y Axis
	  svg.append("g")
	      .call(d3.axisLeft(line_y));
	
//	});
}