/////////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////

if (typeof Array.prototype.forEach != 'function') {
    Array.prototype.forEach = function(callback){
      for (var i = 0; i < this.length; i++){
        callback.apply(this, [this[i], i, this]);
      }
    };
}

if (typeof NodeList.prototype.forEach != 'function') {
    NodeList.prototype.forEach = function(callback){
      for (var i = 0; i < this.length; i++){
        callback.apply(this, [this[i], i, this]);
      }
    };
}
/////////////////////////////////////------------------------ForEach----------------------/////////////////////////////////////////////////////
function encodeHtml(text) {
	if(text==null || text==='undefined'){
		return text;
	}
	  return text
	      .replace(/&/g, "&amp;")
	      .replace(/</g, "&lt;")
	      .replace(/>/g, "&gt;")
	      .replace(/"/g, "&quot;")
	      .replace(/'/g, "&#039;");
}
function decodeHtml(text) {
	if(text==null || text==='undefined'){
		return text;
	}
	  return text
	      .replace(/&amp;/g, "&")
	      .replace(/&lt;/g, "<")
	      .replace(/&gt;/g, ">")
	      .replace(/&quot;/g, "\"")
	      .replace(/&#039;/g, "\'");
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////

function download(filename, text) {
  var element = document.createElement('a');
  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
  element.setAttribute('download', filename);

  element.style.display = 'none';
  document.body.appendChild(element);

  element.click();

  document.body.removeChild(element);
}

function syntaxHighlight(json) {
    if (typeof json != 'string') {
         json = JSON.stringify(json, undefined, 2);
    }
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
        var cls = 'number';
        if (/^"/.test(match)) {
            if (/:$/.test(match)) {
                cls = 'key';
            } else {
                cls = 'string';
            }
        } else if (/true|false/.test(match)) {
            cls = 'boolean';
        } else if (/null/.test(match)) {
            cls = 'null';
        }
        //return '<span class="' + cls + '">' + match + '</span>';
        return match;
    });
}
///////////////////////////////////////////////////////////////////////////////////////

function showData() {
	var appName = $('#appName').val().toString().trim();
	
	if (appName.length > 0) {
		$
				.ajax({
					type : "GET",
					url : "/showData",
					data : {
						"appName" : appName

					},
					success : function(res) {
						console.log(res);

						console.log("res=:" + res);
						var qa = JSON.parse(res);
						console.log("qa:" + qa.hits.hits.length);
						console.log(qa.hits.hits);
						var table = "<table class='table table-striped table-bordered table-hover'><thead><tr><td>No.</td><td>ID</td><td>Question</td><td>Action</td></tr></thead><tbody>";
						result = null;
						result = qa.hits.hits;
						///////////////////////////////////////////////////
						
						//var output = '[\n';						
						//download(appName+"_data.json",JSON.stringify(result).replaceAll(",",",\n"));
						
						///////////////////////////////////////////////////
						//console.log("Json as string : "+JSON.stringify(result));
						var i = 1;
						qa.hits.hits.forEach(function(entry) {

							console.log("------------------------->source:" + entry._source.question);
							entry._source.question=encodeHtml(entry._source.question);
							console.log("--------------------->source<>:" + entry._source.question);
							table += "<tr><td>" + i + "</td><td>" + entry._id
									+ "</td><td>"
									+ entry._source.question
									if(entry._source.hasOwnProperty('sql')){
    									table+="</td><td><a href='./modifysql?id=";
    								}else{
    									table+="</td><td><a href='./modify?id=";
    								}
                                    table+= entry._id + "&appName=" + entry._type
									+ "' class='btn btn-warning'>Modify</a>"
									+ "<a href='./delete?id=" + entry._id
									+ "&appName=" + entry._type
									+ "' class='btn btn-danger'>Delete</a>"
									+ "</td></tr>";

							i = i + 1;
							//output+=syntaxHighlight(entry._source)+",\n";

						});
						//var lastE = output.substr(output.length-1);
						//console.log("lastElement--------"+lastE);
						//output=output.substr("0",output.length-1)+"\n]";
						//output.replace(lastE,"]");
						//console.log("String of Json----------------"+JSON.parse(output));
						//download(appName+"_data.json",output);
						table += "</tbody></table>";
						$('#databody').html(table);
						// $('#alerttext').html("<h3 class='alert
						// alert-success'>Success Loading..</h3>");

					},
					error : function(res) {
						console.log("fail");
						$('#alerttext')
								.html(
										"<h3 class='alert alert-danger'>Error Showing data..</h3>");

					}
				});// end of ajax
	} else {
		$('#alertbox').text("Please select an Application:")
	}
}
