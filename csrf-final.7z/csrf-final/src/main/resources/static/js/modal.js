////////////////////////////////////////////////User Management Functions Start/////////////////////////////////////////////////////

$('#verifyuserid').on('click',function(){
	var id=$('#myuserid').val().trim().toString().toUpperCase();
	
	$.ajax({
		type : "POST",
		url : "/authenticateUser",
		data : {
			"username" : id
		},
		success : function(res) {
			if(res.substr(0,7)==='Success'){
				$('#resultverifyuserid').addClass('glyphicon glyphicon-ok btn-success btn-sm');
				$('#resultverifyuserid').removeClass(' glyphicon-remove btn-danger ');
				$('#mymanagerid').val($('#userid').attr('value'));
				$('#myusername').val(res.substring(8,res.indexOf('/')).trim());
				
			}else{
				$('#resultverifyuserid').addClass('glyphicon glyphicon-remove btn-danger btn-sm ');
				$('#resultverifyuserid').removeClass(' glyphicon-ok btn-success ');
			}
			},error:function(res){
			$('#resultverifyuserid').addClass('glyphicon glyphicon-remove btn-success btn-sm ');
			$('#resultverifyuserid').removeClass(' glyphicon-ok btn-success ');
		
		}
	});

});

$('#verifygranteeid').on('click',function(){
	var id=$('#mygranteeuserid').val().trim().toString().toUpperCase();
	if(debug){ console.log("Verify :"+id);}
	$.ajax({
		type : "POST",
		url : "/verifyGranteeUser",
		data : {
			"userid" : id
		},
		success : function(res) {
			if(debug){ console.log(res);}
			if(res.substr(0,3)==='YES'){
				$('#resultverifygranteeid').addClass('glyphicon glyphicon-ok btn-success btn-sm');
				$('#resultverifygranteeid').removeClass(' glyphicon-remove btn-danger ');
				$('#resultverifygranteeid').html("User is Valid and present in our database");
				//$('#mygranteeusername').val(res.substring(4,res.indexOf('/')).trim());
				if(res.indexOf('/'>0)){
					$('#mygranteeusername').val(res.substring(4,res.indexOf('/')).trim());
				}else{
					$('#mygranteeusername').val(res.substring(4).trim());
				}
				
				
				
				$('#divresultverifygranteeid').show();
				
			}else if(res.substr(0,2)==='NO' && res.length>5){
				$('#resultverifygranteeid').addClass('glyphicon glyphicon-remove btn-danger btn-sm ');
				$('#resultverifygranteeid').removeClass(' glyphicon-ok btn-success ');
				$('#resultverifygranteeid').html("User is Valid but not present in our database");
				//$('#mygranteeusername').val(res.substring(3,res.indexOf('/')).trim());
				if(res.indexOf('/')>0){
					$('#mygranteeusername').val(res.substring(3,res.indexOf('/')).trim());
					
				}else{
					$('#mygranteeusername').val(res.substring(3).trim());
					
				}
				
				$('#divresultverifygranteeid').removeAttr('hidden');
			}
			},error:function(res){
			$('#resultverifygranteeid').addClass('glyphicon glyphicon-remove btn-success btn-sm ');
			$('#resultverifygranteeid').removeClass(' glyphicon-ok btn-success ');
			$('#resultverifygranteeid').html("Some error occured while checking ,Please try again");
			$('#divresultverifygranteeid').removeAttr('hidden');
		
		}
	});

});
/////////////////////////////////////////////////////USER MODAL/////////////////////////////////////////////////////////////////////




function fillUserModal(id) {
	if(debug){ console.log(id);}
	if(debug){ console.log(id.id);}
	if(debug){ console.log($('#' + id.id).attr("value"));}
	if ($('#' + id.id).attr("value") === 'new') {
		$('#myuserid').val('');
		$('#myusername').val('');
		//$('#mymanagerid').val('');
		$('#myissuperuser').val('');
		$('#myislocked').val('');
		$('#myroleid').val('');
		$('#operation').val('create');
		$('#myUserModal').modal('toggle');
	} else {
		$.ajax({
			type : "POST",
			url : "/getJsonUser",
			data : {
				"userid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				
				res = JSON.parse(res);
				
				$('#myuserid').val(encodeHtml(res.user_id));
				$('#myusername').val(encodeHtml(res.user_name));
				//$('#mymanagerid').val(encodeHtml(res.manager_id));
				
				$("input[name=myissuperuser][value=" + res.is_superuser + "]").attr('checked', 'checked');
				//$('#myissuperuser').val(res.is_superuser);
				$("input[name=myislocked][value=" + res.is_locked + "]").attr('checked', 'checked');
				$('#operation').val('update');
				//$('#myislocked').val(res.is_locked);
				
				if(debug){console.log(res.role_id);}
				$('#myroleid').val(encodeHtml(res.role_id));

				if(debug){ console.log(res);}
				if(debug){ console.log($('#myuserid').val());}

				$('#myUserModal').modal('toggle');
					
				if(debug){ console.log("logging done");}
			},
			error : function(res) {
				if(debug){ console.log("error logging---------");}
				//alert(res);
				if(debug){ console.log(res);}
			}

		});
	}

}

function createUserModal(id){

	$.ajax({
		type : "POST",
		url : "/insertUser",
		data : {
			"myuser_id" : $('#myuserid').val(),
			"myuser_name" : $('#myusername').val(),
			"myrole_id" : $('#myroleid').val(),
			"mymanager_id" : $('#userid').attr('value'),
			"myis_superuser" : $("input[name='myissuperuser']:checked").val(),
			"myis_locked" :  $("input[name='myislocked']:checked").val(),
			"operation" : $('#operation').val(),
		},
		success : function(res) {

			if(debug){ console.log("RESULT OF CREATE USER "+res);}
			if(debug){ console.log(typeof res);}
			if(debug){ console.log(res);}
			if(debug){ console.log(res==3);}
			if(debug){ console.log(res==3);}
			if(debug){ console.log(res==='3');}
			
			
			
			
			if(res==-1){
				if(debug){ console.log("ERROR INSERTING User");}
				$('#createUser').attr('onclick','');
				$('#createUser').html('Error ! Please try  after some time.');
				$('#createUser').attr('disabled','disabled');
				
				
			}else if(res==1){
				if(debug){ console.log("SUCCESS INSERTING");}
				$('#createUser').attr('onclick','commit();');
				$('#createUser').html('User Inserted ! Commit');
				$('#cancelUser').attr('disabled','disabled');
				
			}else if(res==2){
				if(debug){ console.log("USER UPDATED");}
				$('#createUser').attr('onclick','commit();');
				$('#createUser').html('User Updated! commit');
				$('#cancelUser').attr('disabled','disabled');
				
			}else if(res==3){
				if(debug){ console.log("USER ALREADY EXIST");}
				$('#createUser').attr('onclick','');
				$('#createUser').html('User Already Exist!');
				$('#createUser').attr('disabled','disabled');
				
			}else{
				if(debug){ console.log("ERROR INSERTING User");}
				$('#createUser').attr('onclick','');
				$('#createUser').html('Error ! Please try  after some time.');
				$('#createUser').attr('disabled','disabled');
				
			}
			
			

		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}

////////////////////////////////////////////////User Management Functions End/////////////////////////////////////////////////////

////////////////////////////////////////////////Grant Management Functions START/////////////////////////////////////////////////////



function fillGrantModal(id) {
	if(debug){ console.log(id);}
	if(debug){ console.log(id.id);}
	if(debug){ console.log($('#' + id.id).attr("value"));}

	if ($('#' + id.id).attr("value") === 'new') {
		
		//$('#mygrantid').val('new');
		$('#mygrantid').val('new');
		$('#mygranteruserid').val($('#userid').text());
		$('#mygranterusername').val($('#userid').text());
		$('#mygrantroleid').val('');
		$('#mygrantappid').val('');
		$('#mygranteeuserid').val('');
		$('#mygranteeusername').val('');
		$('#mycangrant').val('');
		$('#myisvalidgrant').val('');
		
		$('#myGrantModal').modal('toggle');
	} else {
		$.ajax({
			type : "POST",
			url : "/getJsonGrant",
			data : {
				"grantid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				res = JSON.parse(res);
				$('#mygrantid').val(res.grant_id);
				$('#mygranteruserid').val(res.granter_id);
				$('#mygranterusername').val($('#userid').text());
				$('#mygrantroleid').val(res.role_id);
				//console.log("---------------------------------->"+res.app_id);
				$('#mygrantappid option[data-id='+res.app_id.toLowerCase()+']').prop('selected', 'true');
				$('#mygranteeuserid').val(res.grantee_id);
				$('#mygranteeusername').val(res.grantee_name);
				
				if(res.role_id.toUpperCase()=='ROLE0'){
					$("input[name=mycangrant][value=" + res.can_grant + "]").attr('checked', 'checked');
				}else{
					$("input[name=mycangrant][value=NO]").attr('checked', 'checked');
					 $("input:radio[name='mycangrant']").attr('disabled','disabled');
				}
				
				//$('#mycangrant').val(res.can_grant);
				$("input[name=myisvalidgrant][value=" + res.is_valid_grant + "]").attr('checked', 'checked');
				//$('#myisvalidgrant').val(res.is_validGrant);
				if(debug){ console.log(res);}
				if(debug){ console.log($('#mygrantuserid').value);}
				$('#createGrant').text('Update');
				$('#myGrantModal').modal('toggle');
	
				if(debug){ console.log("logging done");}
			},
			error : function(res) {
				if(debug){ console.log("error logging---------");}
				if(debug){ console.log(res);}
			}
		
	});
	}

}

function createGrantModal(id){
	
	if(debug){ console.log("mygranter_id" + $('#mygranteruserid').val()+"mygranter_name" + $('#mygranterusername').val()+"myrole_id" + $('#mygrantroleid').val()+"myapp_id" + $('#mygrantappid').val()+"mygrantee_id" + $('#mygranteeuserid').val()+"mygrantee_name" + $('#mygranteeusername').val()+"can_grant" + $("input[name='mycangrant']:checked").val()+"is_validGrant" + $("input[name='myisvalidgrant']:checked").val());}
	$.ajax({
		type : "POST",
		url : "/insertGrant",
		data : {
			"mygrant_id":$('#mygrantid').val(),
			"mygranter_id" : $('#mygranteruserid').attr('value'),
			"mygranter_name" : $('#mygranterusername').val(),
			"myrole_id" : $('#mygrantroleid').val(),
			"myapp_id" : $('#mygrantappid option:selected').attr('data-id'),
			"mygrantee_id" : $('#mygranteeuserid').val(),
			"mygrantee_name" : $('#mygranteeusername').val(),
			"can_grant" :  $("input[name='mycangrant']:checked").val(),
			"is_validGrant" : $("input[name='myisvalidgrant']:checked").val(),
			
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res=='-1'){
				if(debug){ console.log("ERROR INSERTING Grant");}
				$('#createGrant').attr('onclick','');
				$('#createGrant').html('Error ! Please try  after some time.');
				$('#createGrant').attr('disabled','disabled');
				
			}if(res==3){
				
				if(debug){ console.log("Data Already Exist");}
				$('#createGrant').attr('onclick','');
				$('#createGrant').html('Grant already Exist');
				
			}else{
				
				if(debug){ console.log("SUCCESS INSERTING");}
				$('#createGrant').attr('onclick','commit();');
				$('#createGrant').html('Confirm');
				$('#cancelGrant').attr('disabled','disabled');
				

			}
			
			

		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}

////////////////////////////////////////////////Grant Management Functions End/////////////////////////////////////////////////////

////////////////////////////////////////////////ROLE Management Functions START/////////////////////////////////////////////////////







function fillRoleModal(id) {
	if(debug){ console.log(id);}
	if(debug){ console.log(id.id);}
	if(debug){ console.log($('#' + id.id).attr("value"));}
	
	if ($('#' + id.id).attr("value") === 'new') {
		$('#roleIdHide').hide();
		$('#myrolename').val('');
		$('#myroledetail').val('');
				
		$('#myRoleModal').modal('toggle');
	} else {
			$.ajax({
			type : "POST",
			url : "/getJsonRole",
			data : {
				"roleid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				res = JSON.parse(res);
				$('#myroleid').val(res.role_id);
				$('#myrolename').val(res.role_name);
				$('#myroledetail').val(res.details);
	
				if(debug){ console.log(res);}
	
				$('#myRoleModal').modal('toggle');
	
				if(debug){ console.log("logging done");}
			},
			error : function(res) {
				if(debug){ console.log("error logging---------");}
				if(debug){ console.log(res);}
			}
	
		});	
	}

}




function createRoleModal(id){

	$.ajax({
		type : "POST",
		url : "/insertRole",
		data : {
			"myrole_name" : $('#myrolename').val(),
			"myrole_details" : $('#myroledetail').val(),
					
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res=='-1'){
				if(debug){ console.log("error inserting");}
				if(debug){ console.log("ERROR INSERTING Role");}
				$('#createRole').attr('onclick','');
				$('#createRole').html('Error ! Please try  after some time.');
				$('#createRole').attr('disabled','disabled');
				
			}else{
				
				if(debug){ console.log("SUCCESS INSERTING");}
				
			}
			$('#createRole').attr('onclick','commit();');
			$('#createRole').html('Confirm');
			$('#cancelRole').attr('disabled','disabled');
			

		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}


////////////////////////////////////////////////ROLE Management Functions END/////////////////////////////////////////////////////

////////////////////////////////////////////////APP Management Functions START/////////////////////////////////////////////////////


function fillAppModal(id) {
	if(debug){ console.log(id);}
	if(debug){ console.log(id.id);}
	if(debug){ console.log($('#' + id.id).attr("value"));}
	 var date = new Date();
	if ($('#' + id.id).attr("value") === 'new') {
		$('#myappid').val('new');
		$('#appIdHide').hide();
		$('#myappname').val('');
		$('#myappname').val('');
		$('#mycreateddate').val(date.getDate()+"-"+(date.getMonth()+1)+"-"+date.getFullYear());
		$('#myAppModal').modal('toggle');
	} else {
	
		$.ajax({
			type : "POST",
			url : "/getJsonApp",
			data : {
				"appid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				res = JSON.parse(res);
				//$('#myappid').val(res.app_id);
				$('#myappid option[data-id='+res.app_id.toLowerCase()+']').prop('selected', 'true');
				$('#myappname').val(res.app_name);
				$('#myuserid').val(res.user_id);
				$('#myusername').val(res.user_name);
				$('#mycreateddate').val(res.created_date);
	
				if(debug){ console.log(res);}
	
				$('#myAppModal').modal('toggle');
	
				if(debug){ console.log("logging done");}
			},
			error : function(res) {
				if(debug){ console.log("error logging---------");}
				if(debug){ console.log(res);}
			}
	
		});
	}

}

/*function confirmAppModal(id){
	
	$('#myappid').attr('readonly','readonly');
	$('#myappname').attr('readonly','readonly');
	$('#myusername').attr('readonly','readonly');
	
	$('#createApp').attr('onclick','createAppModal(this);');
	$('#createApp').html('Confirm');

	$('#myAppModal').css('display','block');
	
	
}*/

function createAppModal(id){

	$.ajax({
		type : "POST",
		url : "/insertApp",
		data : {
			"myapp_name" : $('#myappname').val().trim(),
			"myuser_id" : $('#myuserid').attr('value'),
			"myuser_name" : $('#myusername').val(),
					
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res==-1){
				if(debug){ console.log("error inserting");}
				if(debug){ console.log("ERROR INSERTING APP");}
				$('#createApp').attr('onclick','');
				$('#createApp').html('Error ! Please try  after some time.');
				$('#createApp').attr('disabled','disabled');
				
			}else if(res==3){
				if(debug){ console.log("APP ALREADY EXISTS");}
				$('#createApp').attr('onclick','');
				$('#createApp').html('App Name Already Exists.');
				$('#createApp').attr('disabled','disabled');
			}else{
				
				if(debug){ console.log("SUCCESS INSERTING");}
				$('#createApp').attr('onclick','commit();');
				$('#createApp').html('Commit');
				$('#cancelApp').attr('disabled','disabled');
			}
			
			
			
			

		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}

////////////////////////////////////////////////APP Management Functions END/////////////////////////////////////////////////////

function fillAppPropModal(id) {
	if(debug){ console.log(id);}
	if(debug){ console.log(id.id);}
	if(debug){ console.log($('#' + id.id).attr("value"));}
	if ($('#' + id.id).attr("value") === 'new') {
		$('#myappid').val('');
		$('#myappname').val('');
		$('#myappname').removeAttr('disabled');
		$('#mysrpath').val('');
		$('#myappvisibility').val('');
		$('#myappwelcomemsg').val('');
		
		
		$('#myAppPropModal').modal('toggle');
	} else {
		$.ajax({
			type : "POST",
			url : "/getJsonAppProp",
			data : {
				"appid" : $('#' + id.id).attr("value")
			},
			success : function(res) {
				
				res = JSON.parse(res);
				
				/*$('#myappid').val(encodeHtml(res.app_id));
				$('#myappname').val(encodeHtml(res.app_name));
				$('#mysrpath').val(decodeHtml(res.app_sr_link));
				$("input[name=myappvisibility][value=" + res.app_visibility + "]").attr('checked', 'checked');
				$('#myappwelcomemsg').val(encodeHtml(res.app_welcome_msg));*/
				
				//$('#myappid').val(encodeHtml(res.app_id));
				//$('#myappname').val(encodeHtml(res.app_name));
				if(debug){
					console.log(res);
				}
			    
				$('#myappid').val(res.app_id);
				
				$('#myappname option[value="'+decodeHtml(res.app_name.trim().toLowerCase())+'"]').attr("selected", "selected");
				console.log(decodeHtml(res.app_name).trim().toLowerCase());
				if(encodeHtml(res.app_name).trim().toLowerCase()=='i-core india'){
					$('#myappname option[value="finacle"]').attr("selected", "selected");
				}
				
				$('#myappid').attr("disabled","disabled");
				$('#myappname').attr("disabled","disabled");
				
				$('#mysrpath').val(res.app_sr_link);
				$("input[name=myappvisibility][value=" + res.app_visibility + "]").attr('checked', 'checked');
				$('#myappwelcomemsg').val(res.app_welcome_msg);
				
				if(debug){ console.log(res);}
				if(debug){ console.log($('#userid').val());}

				$('#myAppPropModal').modal('toggle');
					
				if(debug){ console.log("logging done");}
			},
			error : function(res) {
				if(debug){ console.log("error logging---------");}
//				alert(res);
				if(debug){ console.log(res);}
			}

		});
	}

}

function createAppPropModal(id){

	$.ajax({
		type : "POST",
		url : "/insertAppProperty",
		data : {
			"app_id" : $('#myappid ').val(),
			"app_name" : $('#myappname option:selected').html(),
			"app_sr_link" : $('#mysrpath').val(),
			"app_visibility" : $("input[name='myappvisibility']:checked").val(),
			"app_welcome_msg" : $('#myappwelcomemsg').val(),
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res=='-1'){
				if(debug){ console.log("error inserting");}
				$('#createAppProp').attr('onclick','fillAppPropModal(this);');
				$('#createAppProp').html('Create');
				
			}else{
				
				
				
				
				if(debug){ console.log("SUCCESS INSERTING");}
				$('#createAppProp').attr('onclick','commit();');
				$('#createAppProp').html('Confirm');
				$('#cancelAppProp').attr('disabled','disabled');
				
			}
			
			

		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}






////////////////////////////////////////////////COMMIT Function for SQL/////////////////////////////////////////////////////


function commit(){
	if(debug){ console.log("commit");}

	$.ajax({
		type : "POST",
		url : "/commit",
		data : {
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res=='-1'){
				if(debug){ console.log("error commiting");}
			}else{
				
				if(debug){ console.log("SUCCESS COMMIT");}
				
			}
			$('#createUser').attr('onclick','createUserModal(this);');
			$('#createUser').html('Create');
			$('#myUserModal').modal('toggle');
			$('#createRole').attr('onclick','createRoleModal(this);');
			$('#createRole').html('Create');
			$('#myRoleModal').modal('toggle');
			$('#createGrant').attr('onclick','createGrantModal(this);');
			$('#createGrant').html('Create');
			$('#myGrantModal').modal('toggle');
			$('#createApp').attr('onclick','createAppModal(this);');
			$('#createApp').html('Create');
			$('#myAppModal').modal('toggle');
			$('#createAppProp').html('Create');
			$('#myAppPropModal').modal('toggle');
			
			location.reload();
		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}

////////////////////////////////////////////////COMMIT Function for SQL/////////////////////////////////////////////////////



function rollback(){
	if(debug){ console.log("rollback");}

	$.ajax({
		type : "POST",
		url : "/rollback",
		data : {
		},
		success : function(res) {

			if(debug){ console.log(res);}
			if(res=='-1'){
				if(debug){ console.log("error rollback");}
			}else{
				
				if(debug){ console.log("SUCCESS ROLLBACK");}
				
			}
			location.reload();
		},
		error : function(res) {
			if(debug){ console.log(res);}
		}

	});
	
}


