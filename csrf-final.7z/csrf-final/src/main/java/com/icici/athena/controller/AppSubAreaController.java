package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.icici.athena.user.User;

import oracle.sql.TIMESTAMP;

import com.icici.athena.app.AppSub;

@Controller
@Component
@RestController
public class AppSubAreaController {
	
	
	
	@Value("${myDebug}")
	public static boolean isDebug;

	@Value("${myDebug}")
	public void setdebug(boolean db) {
		isDebug = db;
	}
	
	
	@RequestMapping(value = "/getJsonAppSub", method = RequestMethod.POST)
	public String getJsonAppSub(@RequestParam("reasonid") String myreasonid) throws IOException {
		JsonObject result = new JsonObject();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (isDebug) {
				System.out.println("You made it, take control of your database now!");
			}
			
			
			try {
								
				String sql ="SELECT * FROM " + ConstantController.userSrReasonTable + " WHERE  reason_id=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myreasonid.toUpperCase());
				
				if (isDebug) {
					System.out.println("Reason_ID:"+myreasonid.toUpperCase());
					System.out.println(sql);
				}
				 rs = pstmt.executeQuery();
				
				while (rs.next()) {

					
					result.addProperty("reason_id", rs.getString("reason_id"));
					result.addProperty("reason_name", rs.getString("reason_name"));
					result.addProperty("modified_time", rs.getString("modified_time"));
					result.addProperty("modified_by", rs.getString("modified_by"));
					result.addProperty("created_time", rs.getString("created_time"));
					result.addProperty("created_by", rs.getString("created_by"));
					
				}

				if (isDebug) {
					System.out.println("this is result" + result);
				}
				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result.toString();
				}
				connection.close();
				return result.toString();
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("error in stmt creation");
				}
				 e.printStackTrace();
				return result.toString();
			}finally{
				try {
					 if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if (isDebug) {
				System.out.println("Failed to make connection!");
			}
			return result.toString();
		}

	}

	
	
	public ArrayList<AppSub> getAppSubs(User user) throws IOException {
		return getAppSubs(user,"NULL");
	}
	
	@RequestMapping(value = "/getAppSubs", method = RequestMethod.POST)
	public ArrayList<AppSub> getAppSubs(User user,String myreasonid) throws IOException {

		ArrayList<AppSub> result = new ArrayList<AppSub>();
		Connection connection = new DatabaseController().createUserConnection();
		ResultSet rs=null;
		PreparedStatement pstmt = null;
		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}
			
			try {
				
								
				String sql= "";//"SELECT * FROM "+ConstantController.userSrReasonTable+" JOIN "+ConstantController.userAppTable+" USING (app_id) WHERE UPPER(reason_id)=? AND UPPER(user_id)=?";
				
				//if(user.getIs_superuser().equals("YES")){
					if(ConstantController.isDebug){
						System.out.println("Super user");
					}
					sql="SELECT * FROM " + ConstantController.userSrReasonTable + "";
					pstmt = connection.prepareStatement(sql);
				/*}else{
					if(user.getRole_id().equals("ROLE0")){
						if(ConstantController.isDebug){
							System.out.println("Admin user");
						}
						sql = "SELECT * FROM " + ConstantController.userSrReasonTable + " join " + ConstantController.userGrantTable + " USING (APP_ID) WHERE UPPER(GRANTEE_ID)=? AND UPPER(ROLE_ID)='ROLE0'";
						pstmt = connection.prepareStatement(sql);
						pstmt.setString(1, user.getUser_id().toUpperCase());
						
					}
					else{
						if(ConstantController.isDebug){
							System.out.println("Normal user");
						}
						sql= "SELECT * FROM "+ConstantController.userSrReasonTable+" JOIN "+ConstantController.userAppTable+" USING (app_id) WHERE UPPER(app_id)=? AND UPPER(user_id)=?";
						pstmt = connection.prepareStatement(sql);
						pstmt.setString(1, myreasonid.toUpperCase());
						pstmt.setString(2, user.getUser_id().toUpperCase());
					}
				}
				*/
				rs = pstmt.executeQuery();
				

				while (rs.next()) {
					AppSub temp=new AppSub();
					temp.setReason_id(rs.getString("reason_id"));
					temp.setReason_name(rs.getString("reason_name"));
					temp.setCreated_by(rs.getString("created_by"));
					temp.setCreated_time((TIMESTAMP) rs.getObject("created_time"));
					temp.setModified_by(rs.getString("modified_by"));
					temp.setModified_time((TIMESTAMP) rs.getObject("modified_time"));
					result.add(temp);
				}

				//System.out.println("this is result" + result);
				if (result.size() == 0) {
					if(isDebug){
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result;
				}
				connection.close();
				return result;
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in stmt creation");
				}
				e.printStackTrace();
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			
			return result;
		}

	}
	
	public int findAppSubByName(String myreasonname) throws IOException {
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("AppSubAreaController :You made it, take control of your database now!");
			}

			try {

				String sql = "SELECT * FROM " + ConstantController.userSrReasonTable+ " WHERE UPPER(reason_name) = ?";

				pstmt = connection.prepareStatement(sql);

				pstmt.setString(1, myreasonname.toString().toUpperCase().trim());

				rs = pstmt.executeQuery();
				if (rs.next()) {
					if (ConstantController.isDebug) {
						System.out.println("REASON NAME  exists with given Namee");
					}
					return 1;
				} else {
					if (ConstantController.isDebug) {
						System.out.println("REASON NAME   Sub Area doesn't  exists with given name");
					}
					return -1;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("AppSubAreaController :Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("AppSubAreaController :Failed to make connection!");
			}
			return -1;
		}
	}
	// Find App Sub Area
		public int findAppSubById(String myreasonid) throws IOException {
			Connection connection =  new DatabaseController().createUserConnection();
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			if (connection != null) {
				if (ConstantController.isDebug) {
					System.out.println("AppSubAreaController:You made it, take control of your database now!");
				}

				try {
					String sql = "SELECT * FROM " + ConstantController.userSrReasonTable + " WHERE  reason_id=?";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, myreasonid.toString().toUpperCase());
					
					if(isDebug){
						System.out.println("Check For Reason ID in Table");
						System.out.println("myReason_id:"+myreasonid.toUpperCase());
					}

					rs = pstmt.executeQuery();
					if (rs.next()) {
						if (ConstantController.isDebug) {
							System.out.println("App Sub Area  exists"+rs.getString("reason_id")+" | "+rs.getString(2));
						}
						return 1;
					} else {
						if (ConstantController.isDebug) {
							System.out.println("App Sub Area  doesn't  exists");
						}
						return -1;
					}

				} catch (Exception e) {
					if (ConstantController.isDebug) {
						System.out.println("AppSubAreaController:Error in insert stmt creation");
					}
					e.printStackTrace();
					try {

						connection.close();
					} catch (SQLException e1) {

						e1.printStackTrace();

					}
					return -1;
				} finally {
					try {
						if (rs != null)
							rs.close();
						if (pstmt != null)
							pstmt.close();
						if (connection != null)
							connection.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}

			} else {
				if (ConstantController.isDebug) {
					System.out.println("AppSubAreaController:Failed to make connection!");
				}
				return -1;
			}

		}

		

		@RequestMapping(value = "/insertAppSub", method = RequestMethod.POST)
		public int insertAppSub(

				@RequestParam(value = "reason_id", required = false) String myreasonid,

				@RequestParam(value = "reason_name", required = false) String myreasonname,
				//@RequestParam(value = "myuser_name", required = false) String myusername,
				@RequestParam(value = "modified_time", required = false) String mymodifiedtime,
				//@RequestParam(value = "modified_by", required = false) String mymodifiedby,
				
				HttpServletRequest request) throws IOException {

			// '||chr(38)||'
			
			
			if(request.getSession(false)==null || request.getSession(false).getAttribute("user")==null){
				return -1;
			}
			User user=(User)request.getSession(false).getAttribute("user");
			myreasonname = myreasonname.toUpperCase();
			myreasonid = myreasonid.toUpperCase();
			//myusername = myusername.toUpperCase();
			//mymodifiedby = mymodifiedby.toUpperCase();


			if (ConstantController.isDebug) {
					System.out.println("AppSubAreaController: ");
					System.out.println("reason Name: " + myreasonname);
					System.out.println("Reason ID: " + myreasonid);
					System.out.println("Modified time: " + mymodifiedtime);
					//System.out.println("Modified by: " + myreasonid);
				}

			Connection connection =  new DatabaseController().createUserConnection();
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			if (connection != null) {
				if (ConstantController.isDebug) {
					System.out.println("AppSubAreaController:You made it, take control of your database now!");
				}

				try {

					if (findAppSubById(myreasonid) == 1) {
						if (ConstantController.isDebug) {
							System.out.println("App Sub  WILL BE UPDATED.");
						}
						// return 3;
					} else {
						if (ConstantController.isDebug) {
							System.out.println("App Sub CAN BE INSERTED");
						}
					}
					if (findAppSubById(myreasonid) == 1 && findAppSubByName(myreasonname)!=1 ) {
						String sql = "UPDATE " + ConstantController.userSrReasonTable + " SET " 
								
								+ "reason_name=?," //1
								+ "modified_time=SYSDATE," 
								+ "modified_by=? "//2
								+ " WHERE reason_id=?";// 3

						pstmt = connection.prepareStatement(sql);
						//java.sql.Date date = getCurrentDatetime();
						//pstmt.setString(1, myreasonid.toString().toUpperCase());
						pstmt.setString(1, myreasonname.toString().toUpperCase());
						//pstmt.setString(2, date.toString());
						
						pstmt.setString(2, user.getUser_id().toUpperCase());
						pstmt.setString(3, myreasonid.toString().toUpperCase());
						//pstmt.setString(6, user.getUser_name());
						
						//pstmt.setString(7, myreasonid.toString().toUpperCase());

						if (ConstantController.isDebug) {
							System.out.println(sql);
							ParameterMetaData pmtdt = pstmt.getParameterMetaData();
							int count = pmtdt.getParameterCount();
							System.out.println("UPDATE  App Sub area SQL ????? ?" + count);
							for (int i = 1; i <= count; i++) {
								System.out.println(
										"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
							}
						}

						int x = pstmt.executeUpdate();
						if (x > 0) {
							System.out.println("App Sub Area  Successfully Updated");

							if (ConstantController.isDebug) {
								System.out.println("App Sub Area Updated and Commited");
							}
							connection.commit();
							pstmt.close();
							connection.close();
							if (ConstantController.isDebug) {
								System.out.println("return 1");
							}
							return 1;

						} else {
							System.out.println("Update App Sub Area Failed");

							pstmt.close();
							connection.close();
							return -1;
						}

					} else {
						if (findAppSubByName(myreasonname) == 1) {
							
							return 3;
						}

						String sql = "INSERT INTO " + ConstantController.userSrReasonTable
								+ " (reason_id,reason_name,modified_time,modified_by,created_time,created_by) VALUES (?,?,SYSDATE,?,SYSDATE,?)";

						pstmt = connection.prepareStatement(sql);

						pstmt.setString(1, myreasonid.toString().toUpperCase());
						pstmt.setString(2, myreasonname.toString().toUpperCase());
						pstmt.setString(3, user.getUser_id());
						pstmt.setString(4, user.getUser_id());
						

						if (ConstantController.isDebug) {
							System.out.println(sql);
							ParameterMetaData pmtdt = pstmt.getParameterMetaData();
							int count = pmtdt.getParameterCount();
							System.out.println("Insert App Sub Area SQL ????? ?" + count);
							for (int i = 1; i <= count; i++) {
								System.out.println(
										"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
							}
						}
						int x = pstmt.executeUpdate();
						if (x > 0) {
							System.out.println("App Sub Area Successfully Inserted");

							if (ConstantController.isDebug) {
								System.out.println("App Sub Area Inserted and Commited");
							}
							connection.commit();
							pstmt.close();
							connection.close();
							if (ConstantController.isDebug) {
								System.out.println("return 1");
							}
							return 1;

						} else {
							System.out.println("Insert Failed");

							pstmt.close();
							connection.close();
							return -1;
						}
					}

				} catch (Exception e) {
					if (ConstantController.isDebug) {
						System.out.println("AppSubAreaController:Error in insert stmt creation");
					}
					e.printStackTrace();
					try {

						connection.close();
					} catch (SQLException e1) {

						e1.printStackTrace();

					}
					return -1;
				} finally {
					try {
						if (rs != null)
							rs.close();
						if (pstmt != null)
							pstmt.close();
						if (connection != null)
							connection.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}
			} else {
				if (ConstantController.isDebug) {
					System.out.println("AppSubAreaController:Failed to make connection!");
				}
				return -1;
			}

		}
	
	
}
