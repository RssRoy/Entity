
package com.icici.athena.LoginServlet;

import java.io.IOException;
import java.util.Base64;

import javax.naming.ldap.LdapContext;

import com.icici.athena.controller.ConstantController;
import com.icici.athena.controller.DatabaseController;
import com.icici.athena.controller.UserController;
import com.icici.athena.ldap.LDAPUtil;
import com.icici.athena.user.User;

public class ChatUser {

	boolean isDebug = ConstantController.isDebug;

	public User getUser(String userid) {
		LdapContext conn = null;

		try {
			conn = LDAPUtil.getConnection(ConstantController.ldapUser, ConstantController.ldapPwd, ConstantController.ldapDc);
			if (conn == null) {
				if (isDebug) {
					System.out.println("Connection NULL With  !!!\nConnection Details:\nHost:"
							+ ConstantController.ldapHost + "\nPort:" + ConstantController.ldapPort1 + "\nUser:"
							+ userid + "\n" + Base64.getEncoder().encodeToString(ConstantController.ldapPwd.getBytes()) + "\nDC:"
							+ ConstantController.ldapDc);
				}
				return null;
			}

		} catch (Exception e) {
			if (isDebug) {
				System.out.println("Your EmployeeId might be locked !!!!");
			}
			if (isDebug) {
				System.out.println("LoginServlet : Redirect to : /login?msg=user id and password not matched");
			}

			return null;
		}
		LDAPUtil user = null;
		try {
			user = LDAPUtil.getUser(userid, conn);

			if (isDebug) {
				System.out.println("LoginServletUser: User Info " + user.getUserName());
			}
		} catch (Exception e) {
			if (isDebug) {
				System.out.println("Your EmployeeId might be locked !!!");
			}
			e.printStackTrace();
			return null;
		}
		
		
		if (isDebug) {
			System.out.println("User common name = " + user.getCommonName());
			System.out.println("User distinguised name = " + user.getDistinguishedName());
			System.out.println("User principle = " + user.getUserPrincipal());
			System.out.println("User Given Name = " + user.getGivenName());
			System.out.println("User Name = " + user.getUserName());
		}

		User ldapuser=new User();
		String username=user.getUserName().substring(0, user.getUserName().indexOf("/"));
		String userID=user.getUserPrincipal().substring(0,user.getUserPrincipal().indexOf("@"));
		ldapuser.setUser_id(userID);
		ldapuser.setUser_name(username);
		
		return ldapuser;

	}
}