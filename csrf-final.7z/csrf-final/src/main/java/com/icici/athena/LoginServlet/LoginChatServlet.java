package com.icici.athena.LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Date;

import javax.naming.ldap.LdapContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.icici.athena.controller.AjaxController;
import com.icici.athena.controller.ConstantController;
import com.icici.athena.controller.UserController;
import com.icici.athena.ldap.LDAPUtil;
import com.icici.athena.user.User;

/**
 * Servlet implementation class LoginServlet
 */

@Controller
public class LoginChatServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private  String username = "admin";
    private  String password = "password";
    private String userid="BAN0000000";
  
    @Value("${myDebug}")
    public static boolean isDebug;
    @Value("${myDebug}")
    public void setdebug(boolean db) {
        isDebug = db;
    }
   
    /*public void toLink(String link,HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
    	RequestDispatcher rd = req.getRequestDispatcher(link);
    	rd.forward(req, resp);
    }*/
    @RequestMapping(value = "LoginChatServlet",method = RequestMethod.POST)
    public  void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
       
    	RequestDispatcher rd= null;
       
         userid=(String) request.getParameter("username");
         password=(String) request.getParameter("password");
         if(isDebug){
               // System.out.println("LoginServlet: Line:52: Userid:"+userid+"Password:"+password+" Time :"+new Date().getTime());

            }
        try{
            //LdapContext conn = LDAPUtil.getConnection("ban63230","dhiraj@123","icicibankltd.com");
            LdapContext conn=null;
            if(password.length()==0 || password.trim().length()==0 || userid.length()==0 || userid.trim().length()==0)
            {
            	if(isDebug){
                    System.out.println("Failed to Connect without password !!!!");
                    }
                /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                dd.forward(request, response);*/
             
                response.sendRedirect("chatLogin?msg=user id and password not matched");
            	/*rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            	rd.forward(request,response);*/
            	
            	//toLink("/login?msg=user id and password not matched",request,response);

                 return;
            }
            try{
                 conn = LDAPUtil.getConnection(userid,password,ConstantController.ldapDc);
                
               
                 if(conn==null){
                   	 if(isDebug){
                            System.out.println("Failed to Connect conn is null again !!!!");
                            }
                        /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                        dd.forward(request, response);*/
                     
                        response.sendRedirect("chatLogin?msg=user id and password not matched");
                   	 
                   /* rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                	rd.forward(request,response);*/
                 	//toLink("/login?msg=user id and password not matched",request,response);

                         return;
                    }
                 if(isDebug){
                     System.out.println("LoginChatServlet: Line:101: UserName:"+userid+"Context:"+conn.toString());

                 }
                
            }catch(Exception e){
                if(isDebug){
                    System.out.println("Your EmployeeId might be locked !!!!");
                    }
                /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                dd.forward(request, response);*/
                if(isDebug){
                    System.out.println("LoginChatServlet : Redirect to : /chatLogin?msg=user id and password not matched");
                    }
               response.sendRedirect("chatLogin?msg=user id and password not matched");
                
                /*rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            	rd.forward(request,response);*/
            	//toLink("/login?msg=user id and password not matched",request,response);

                 return;
            }
            LDAPUtil user =null;
            try{
                user = LDAPUtil.getUser(userid, conn);
            
                if(isDebug){
                    System.out.println("LoginChatServletUser: User Info "+user.getUserName());
                    }
                
            
            
            
            }catch(Exception e){
                if(isDebug){
                System.out.println("Your EmployeeId might be locked !!!");
                }
                e.printStackTrace();

                    /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                    dd.forward(request, response);*/
               response.sendRedirect("chatLogin?msg=EmployeeId might be locked");
                /*rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            	rd.forward(request,response);*/
            	//toLink("/login?msg=user id and password not matched",request,response);


                     return;
            }
            User curr_user=new User();
            String user_principle=user.getUserPrincipal();
            curr_user.setUser_id(user_principle.substring(0,user_principle.indexOf("@")));
            curr_user.setUser_name(user.getUserName());
         
            username=curr_user.getUser_name();
            if(isDebug){
                System.out.println("UserName:"+username);
            }
            if(isDebug){
                System.out.println("User common name = "+user.getCommonName());
                System.out.println("User distinguised name = "+user.getDistinguishedName());
                System.out.println("User principle = "+user.getUserPrincipal());
                System.out.println("User Given Name = "+user.getGivenName());
                System.out.println("User Name = "+user.getUserName());
            }
           
            try{
            HttpSession session = request.getSession(true);
            session.setAttribute("username", curr_user.getUser_name());
            session.setAttribute("userid", curr_user.getUser_id());
            session.setAttribute("ipaddress", request.getRemoteAddr());
            session.setAttribute("sessionid", request.getSession().getId());

            if(isDebug){
                System.out.println("user to set");
            }
            session.setAttribute("user", curr_user);
           
            if(isDebug){
                System.out.println("user set");
            }
           
            //setting session to expiry in 30 mins
            session.setMaxInactiveInterval(5*60);
           /* Cookie userName = new Cookie("username", URLEncoder.encode(username, "UTF-8"));
            userName.setMaxAge(5*60);
            response.addCookie(userName);*/
            
            if(isDebug){
                System.out.println("Redirected to Admin.jsp");
            }
			AjaxController.athenaUserActivity.info(" Â¶ "+request.getRemoteAddr()+" Â¶ "+request.getSession().getId()+" Â¶ LOGIN  Â¶ "+userid);

            response.sendRedirect("/adminChat");
			/*rd=request.getRequestDispatcher("/admin");
        	rd.forward(request,response);*/
        	//toLink("/admin",request,response);

            return;
            }catch(Exception e){
                if(isDebug){
                    System.out.println("ERROR in SESSION"+e);
                    e.printStackTrace();
                }
               
                response.sendRedirect("chatLogin?msg=user id and password not matched");
                /*rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            	rd.forward(request,response);*/
            	//toLink("/login?msg=user id and password not matched",request,response);
                 return;
                /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                dd.forward(request, response);*/
               
                //response.sendRedirect("/login?msg=Error in session creation");

            }

        }catch(Exception e){
            if(isDebug){
                System.out.println(e);
            }
           
            PrintWriter out= response.getWriter();
            out.println("<font color=red>Either user name or password is wrong.</font>");
            //response.sendRedirect("login?msg=user id and password not matched");
            rd=request.getRequestDispatcher("/chatLogin?msg=user id and password not matched");
        	rd.forward(request,response);
             return;
            /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            dd.forward(request, response);*/
           
           

        }
       
    }
   
   
   
}