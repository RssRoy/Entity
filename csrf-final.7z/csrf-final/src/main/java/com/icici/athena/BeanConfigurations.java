package com.icici.athena;

import javax.servlet.http.HttpSessionListener;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.icici.athena.LoginServlet.SessionServlet;

@Configuration
public class BeanConfigurations {
 
    @Bean
    public AuthenticationSuccessHandler authenticationSuccessHandler() {
        return new CustomAuthenticationSuccessHandler();
    }
  
    
    @Bean
	public HttpSessionListener httpSessionListener(){
	    // MySessionListener should implement javax.servlet.http.HttpSessionListener
	    return new SessionServlet(); 
	}
}