package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.icici.athena.app.App;
import com.icici.athena.grant.Grant;
import com.icici.athena.role.Role;
import com.icici.athena.user.User;

import oracle.sql.TIMESTAMP;

@Configuration
@Component
@RestController
public class UserController {

	// private String driverName = "oracle.jdbc.driver.OracleDriver";
	private String driverName = ConstantController.userDatabaseDriverClassName;
	// private String dbURL = "jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
	private String dbURL = ConstantController.userDatabaseUrl;
	// private String dbUser = "CXPSADM";
	private String dbUser = ConstantController.userDatabaseUserName;
	// private String dbPassword = "CXPSADM_123";
	private String dbPassword = ConstantController.userDatabasePassword;

	private String userID = "";
	
	@Value("${myDebug}")
	public static boolean isDebug;

	@Value("${myDebug}")
	public void setdebug(boolean db) {
		isDebug = db;
	}

	public static String refineName(String userName) {
		String regex = "/([^a-zA-Z0-9\\s\\[\\]\\(\\)\\@\\\\\\_\\#\\/])/g";// to
																			// remove
																			// all
																			// special
																			// characters
																			// other
																			// than
																			// @[]()\/#_
																			// and
																			// space

		if (ConstantController.isDebug) {
			System.out.println("UserName : in refineName:" + userName);
		}
		userName = userName.replaceAll(regex, "");
		userName = userName.replaceAll("([\\ \\ￂ])", "");
		if (ConstantController.isDebug) {
			// System.out.println("UserName : IN refineName:"+userName);
		}
		if (userName.indexOf("/") > 0) {
			userName = userName.substring(0, userName.indexOf("/")).trim();
		} else {
			userName = userName.trim();
		}
		if (ConstantController.isDebug) {
			// System.out.println("UserName : refineName:"+userName);
		}
		return userName;
	}
	// user query execution method

	@RequestMapping(value = "/getUsers", method = RequestMethod.POST)
	public ArrayList<User> getUsers(User user) throws IOException {

		ArrayList<User> result = new ArrayList<User>();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;

		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			 * query = "SELECT * FROM "+ConstantController.
			 * userTable+" WHERE UPPER(manager_id)='" +
			 * user.getUser_id().toUpperCase() + "' ;"; query =
			 * "SELECT * FROM "+ConstantController.
			 * userTable+" WHERE UPPER(manager_id)='" +
			 * user.getUser_id().toUpperCase() + "' ;";
			 * 
			 * if (user.getIs_superuser() == "YES") { query =
			 * "SELECT * FROM "+ConstantController.userTable+"  ";
			 * 
			 * } else { query = "SELECT * FROM "+ConstantController.
			 * userTable+" WHERE UPPER(manager_id)='" +
			 * user.getUser_id().toUpperCase() + "' ";
			 * 
			 * }
			 */
			try {
				String sql = "SELECT * FROM " + ConstantController.userTable + " WHERE UPPER(manager_id)=? ";

				pstmt = null;
				if (user.getIs_superuser() == "YES") {
					sql = "SELECT * FROM " + ConstantController.userTable + "  ";
					pstmt = connection.prepareStatement(sql);

				} else {
					sql = "SELECT * FROM " + ConstantController.userTable + " WHERE UPPER(manager_id)=?";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, user.getUser_id().toUpperCase());
				}

				rs = pstmt.executeQuery();

				while (rs.next()) {
					User temp = new User();
					temp.setUser_id(rs.getString("user_id"));
					temp.setUser_name(rs.getString("user_name"));
					temp.setLogin_time((TIMESTAMP) rs.getObject("login_time"));
					temp.setIs_locked(rs.getString("is_locked"));
					temp.setLock_time((TIMESTAMP) rs.getObject("lock_time"));
					temp.setIs_superuser(rs.getString("is_superuser"));
					temp.setRole_id(rs.getString("role_id"));
					temp.setManager_id(rs.getString("manager_id"));
					result.add(temp);
				}

				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					pstmt.close();
					connection.close();
					return result;
				} else {
					pstmt.close();
					connection.close();
					return result;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return result;
		}

	}

	@RequestMapping(value = "/getRoles", method = RequestMethod.POST)
	public ArrayList<Role> getRoles(User user) throws IOException {

		ArrayList<Role> result = new ArrayList<Role>();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}

			try {
				String sql = "";
				pstmt = null;
				if (user.getIs_superuser().equals("YES") || user.getRole_id().equalsIgnoreCase("ROLE0")) {
					sql = "SELECT * FROM " + ConstantController.userRoleTable + "  ";
					pstmt = connection.prepareStatement(sql);
				}

				rs = pstmt.executeQuery();
				while (rs.next()) {
					Role temp = new Role();
					temp.setRole_id(rs.getString("role_id"));
					temp.setRole_name(rs.getString("role_name"));
					temp.setPriviledges(rs.getString("priviledges"));
					result.add(temp);
				}
				// System.out.println("this is result" + result);
				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result;
				}
				connection.close();
				return result;

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return result;
		}

	}

	@RequestMapping(value = "/getApps", method = RequestMethod.POST)
	public ArrayList<App> getApps(User user) throws IOException {

		ArrayList<App> result = new ArrayList<App>();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			 * String query = "SELECT * FROM "+ConstantController.
			 * userAppTable+" WHERE UPPER(user_id)='" +
			 * user.getUser_id().toUpperCase() + "' ";
			 * 
			 * if (user.getIs_superuser().equals("YES")) { query =
			 * "SELECT * FROM "+ConstantController.userAppTable+" ";
			 * 
			 * } else { query = "SELECT * FROM "+ConstantController.
			 * userAppTable+" WHERE UPPER(user_id)='" +
			 * user.getUser_id().toUpperCase() + "' ";
			 * 
			 * }
			 */
			try {

				String sql = "SELECT * FROM " + ConstantController.userAppTable + " WHERE UPPER(user_id)=? ";

				pstmt = null;

				if (user.getIs_superuser().equals("YES")) {
					sql = "SELECT * FROM " + ConstantController.userAppTable + " ";
					pstmt = connection.prepareStatement(sql);
				} else {
					if(user.getRole_id().equals("ROLE0")){
						sql = "SELECT * FROM " + ConstantController.userGrantTable + " JOIN " + ConstantController.userRoleTable + "  USING (ROLE_ID) JOIN " + ConstantController.userAppTable + " USING (APP_ID) WHERE UPPER(GRANTEE_ID)=? AND UPPER(ROLE_ID)='ROLE0'";

					}else{
						sql = "SELECT * FROM " + ConstantController.userAppTable + " WHERE UPPER(user_id)=?";
					}
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, user.getUser_id().toUpperCase());
				}
				// System.out.println(query);
				rs = pstmt.executeQuery();

				while (rs.next()) {
					App temp = new App();
					temp.setUser_id(rs.getString("user_id"));
					temp.setUser_name(rs.getString("user_name"));
					temp.setApp_id(rs.getString("app_id"));
					temp.setApp_name(rs.getString("app_name"));
					temp.setCreated_date((TIMESTAMP) rs.getObject("created_date"));
					result.add(temp);
				}
				// System.out.println("this is result" + result);
				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result;
				}
				connection.close();
				return result;

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return result;
		}

	}

	@RequestMapping(value = "/getGrants", method = RequestMethod.POST)
	public ArrayList<Grant> getGrants(User user) throws IOException {

		ArrayList<Grant> result = new ArrayList<Grant>();

		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			 * stmt = connection.createStatement(); String query =
			 * "SELECT * FROM "+ConstantController.
			 * userGrantTable+" WHERE UPPER(granter_id)='" +
			 * user.getUser_id().toUpperCase() + "' ";
			 * 
			 * if (user.getIs_superuser().equals("YES")) { query =
			 * "SELECT * FROM "+ConstantController.userGrantTable+"  ";
			 * 
			 * } else { query = "SELECT * FROM "+ConstantController.
			 * userGrantTable+" WHERE UPPER(granter_id)='" +
			 * user.getUser_id().toUpperCase() + "' ";
			 * 
			 * }
			 */
			try {

				String sql = "SELECT * FROM " + ConstantController.userGrantTable + " WHERE UPPER(granter_id)=?";

				pstmt = null;

				if (user.getIs_superuser().equals("YES")) {
					sql = "SELECT * FROM " + ConstantController.userGrantTable + "  ";
					pstmt = connection.prepareStatement(sql);
				} else {
					sql = "SELECT * FROM " + ConstantController.userGrantTable + " WHERE UPPER(granter_id)=?";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, user.getUser_id().toUpperCase());
				}
				// System.out.println(query);
				rs = pstmt.executeQuery();

				while (rs.next()) {
					Grant temp = new Grant();
					temp.setGrant_id(rs.getString("grant_id"));
					temp.setGranter_name(rs.getString("granter_name"));
					temp.setGranter_id(rs.getString("granter_id"));
					temp.setRole_id(rs.getString("role_id"));
					temp.setGrantee_id(rs.getString("grantee_id"));
					temp.setGrantee_name(rs.getString("grantee_name"));
					temp.setCan_grant(rs.getString("can_grant"));
					temp.setApp_id(rs.getString("app_id"));
					temp.setIs_valid_grant(rs.getString("is_valid_grant"));
					temp.setModified_by(rs.getString("modified_by"));
					temp.setModified_time((TIMESTAMP) rs.getObject("modified_time"));
					
					result.add(temp);
				}

				// System.out.println("this is result" + result);
				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result;
				}
				connection.close();
				return result;

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return result;
		}

	}

	public User getUser(String myuserid) throws IOException {
		if (isDebug) {
			System.out.println("UserController: NEW USER " + myuserid);
		}
		return getUser(myuserid, "NEW USER");

	}

	
	@RequestMapping(value = "/getUser", method = RequestMethod.POST)
	public User getUser(String myuserid, String myusername) throws IOException {
		if (myusername.indexOf('/') >= 0) {
			myusername = myusername.substring(0, myusername.indexOf('/')).trim();
		}
		User result = new User(myuserid.toUpperCase(), myusername.toUpperCase());

		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			
				 */
			try {
				String sql = "SELECT * FROM " + ConstantController.userTable + " WHERE UPPER(user_id)=?";

				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myuserid.toUpperCase());
				if (isDebug) {
					System.out.println("UserController:" + sql);
				}
				rs = pstmt.executeQuery();
				while (rs.next()) {
					// ResultSetMetaData rsmd = rs.getMetaData();
					result.setUser_id(rs.getString("user_id"));
					result.setUser_name(rs.getString("user_name"));
					result.setLogin_time((TIMESTAMP) rs.getObject("login_time"));
					result.setIs_locked(rs.getString("is_locked"));
					result.setLock_time((TIMESTAMP) rs.getObject("lock_time"));
					result.setIs_superuser(rs.getString("is_superuser"));
					result.setRole_id(rs.getString("role_id"));
					result.setManager_id(rs.getString("manager_id"));
					result.setLast_login((TIMESTAMP) rs.getObject("last_login"));
					result.setActive(rs.getString("active"));
				}
				/* no need to get detail of user if user is already active somewhere*/
				
				//Instant.now().plusSeconds( TimeUnit.MINUTES.toSeconds( 5 ) );
				 Clock clock=Clock.system(ZoneId.of("Asia/Kolkata"));
					//Format format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
		            DateFormat oracleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		            if(isDebug){
		            	System.out.println(oracleFormat.parse(result.getLogin_time().toString()).toInstant()+"  --->"+Instant.now(clock).plusSeconds(TimeUnit.MINUTES.toSeconds( 15 )));
		            }
			        	
		        if(result.getActive()!=null && result.getActive().toString().toUpperCase().equals("YES") ){
			     		return result;
				}

				// get all apps
					HashMap<String, String> allapps = new HashMap<String, String>();
					allapps = getAllApps();
					
				
				// grant details
				HashMap<String, String> tmpGrant = new HashMap<String, String>();
				HashMap<String, String> tmpCanGrant = new HashMap<String, String>();
				HashMap<String,String> a = new HashMap<String,String>();
				HashMap<String,String> i = new HashMap<String,String>();
				
				HashMap<String,String> u = new HashMap<String,String>();
				HashMap<String,String> d = new HashMap<String,String>();
				HashMap<String,String> m = new HashMap<String,String>();
				HashMap<String,String> s = new HashMap<String,String>();

				/* admin apps */
				pstmt.close();
				sql = "SELECT * FROM " + ConstantController.userAppTable + " WHERE UPPER(USER_ID)=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myuserid.toUpperCase());
				if (isDebug) {
					System.out.println("UserController: tquery" + sql);
				}

				ResultSet rsa = pstmt.executeQuery();

				while (rsa.next()) {
					String tapp = rsa.getString("app_name");
					String tid = rsa.getString("app_id");
					a.put(tid, tapp);
					s.put(tid, tapp);
					i.put(tid, tapp);
					m.put(tid, tapp);
					d.put(tid, tapp);
					//HASHCODE
					tmpCanGrant.put(tid, tapp);//can grant application
				}

				//////////////

				if (result.getIs_superuser().equalsIgnoreCase("NO")) {
					sql = "SELECT * FROM " + ConstantController.userGrantTable + " join "
							+ ConstantController.userRoleTable + "  using (ROLE_ID) join "
							+ ConstantController.userAppTable + " using (APP_ID) WHERE UPPER(grantee_id)=?";
					//sql = "SELECT * FROM " + ConstantController.userAppTable + " app join "+ConstantController.userGrantTable+" grnt using (app_id) where UPPER(grnt.grantee_id)= ? and upper(grnt.role_id)='ROLE0'";
					//sql = "SELECT * FROM " + ConstantController.userAppTable + " app join "+ConstantController.userGrantTable+" grnt using (app_id) where UPPER(grnt.grantee_id)='"+myuserid.toUpperCase()+"' and UPPER(grnt.role_id)='ROLE0'";
					pstmt.close();
					pstmt = connection.prepareStatement(sql);
					//userID=myuserid;
					pstmt.setString(1, myuserid.toUpperCase());

				} else {

					sql = "SELECT * FROM " + ConstantController.userGrantTable + " join "
							+ ConstantController.userRoleTable + "  using (ROLE_ID) join "
							+ ConstantController.userAppTable + " using (APP_ID) ";
					pstmt.close();
					pstmt = connection.prepareStatement(sql);
				}
				if (isDebug) {
					System.out.println("Query For FAQ:" + sql);
				}
				rs = pstmt.executeQuery();
				while (rs.next()) {
					String userAppName = rs.getString("app_name");
					String userAppid = rs.getString("app_id");
					String rolename = rs.getString("role_name");
					String canGrant = rs.getString("can_grant");
					String isValid = rs.getString("is_valid_grant");
					if (isDebug) {
						System.out.println("App:" + userAppName + " Role:" + rolename + " CanGrant:" + canGrant
								+ " isValid:" + isValid);
					}
					
					//IMPORTANT
					//HASHCODE WHAT TO DO?? IF USER IS A DEFAULT ROLE ADMIN
					// CAN USER IS ADMIN TO ALL APPS:
					//OR USER IS ADMIN TO ONLY APP HE HAS GIVEN RIGHTS:
					
					/*if (result.getRole_id().equalsIgnoreCase("ROLE0")) {
						// if the user has a default role is admin role then:: ??
						// HASHCODE MODIFYING THIS::
						for (HashMap.Entry<String, String> entry : allapps.entrySet()) {
							a.put(entry.getKey(), entry.getValue());
							s.put(entry.getKey(), entry.getValue());
							i.put(entry.getKey(), entry.getValue());
							m.put(entry.getKey(), entry.getValue());
							d.put(entry.getKey(), entry.getValue());
						}
						a.put(userAppid,userAppName);
						s.put(userAppid,userAppName);
						i.put(userAppid,userAppName);
						m.put(userAppid,userAppName);
						d.put(userAppid,userAppName);
						
					}*/
					
					if (canGrant.equalsIgnoreCase("YES") && isValid.equalsIgnoreCase("YES")) {
						tmpCanGrant.put(userAppid, userAppName);//can grant application
					}
					if (isValid.equalsIgnoreCase("YES")) {
						if (rolename.indexOf("i") >= 0) {
							i.put(userAppid, userAppName);
						}
						if (rolename.indexOf("admin") >= 0) {
							i.put(userAppid, userAppName);
							a.put(userAppid, userAppName);
							//((List<User>) a).add(userAppName);
							m.put(userAppid, userAppName);
							d.put(userAppid, userAppName);
							s.put(userAppid, userAppName);
						}
						if (rolename.indexOf("m") >= 0) {
							m.put(userAppid, userAppName);
						}
						if (rolename.indexOf("d") >= 0) {
							d.put(userAppid, userAppName);
						}
						if (rolename.indexOf("s") >= 0) {
							s.put(userAppid, userAppName);
						}
					}
					tmpGrant.put(userAppName, rs.getString("role_name"));
				}
				

				result.setGrant(tmpGrant);
				result.setCanGrant(tmpCanGrant);
				result.setInsert(i);
				
				result.setUpdate(u);
				result.setDelete(d);
				result.setModify(m);
				result.setShow(s);
				HashMap<String, String> allroles = new HashMap<String, String>();

				/* admin roles */
				pstmt.close();
				sql = "SELECT * FROM " + ConstantController.userRoleTable + " ";
				pstmt = connection.prepareStatement(sql);
				rsa = pstmt.executeQuery();
				while (rsa.next()) {

					String troleid = rsa.getString("role_id");
					String trolep = rsa.getString("priviledges");
					allroles.put(troleid, trolep);

				}
				result.setAllroles(allroles);
				
				if(result.getIs_superuser().equalsIgnoreCase("YES")){
					result.setAdminApps(allapps);
					result.setInsert(allapps);
					result.setModify(allapps);
					result.setDelete(allapps);
					result.setShow(allapps);
					result.setGrant(allapps);
					result.setCanGrant(allapps);
				
					
						for(HashMap.Entry<String,String> entity:a.entrySet()){
							if (isDebug) {
								System.out.println(entity.getValue()+" All apps --> "+entity.getKey());
							}
						}
				}
				else{
					result.setAdminApps(a);
					for(HashMap.Entry<String,String> entity:a.entrySet()){
						if (isDebug) {
							System.out.println(entity.getValue()+"  a --> "+entity.getKey());
						}
					}
				}
				result.setAllapps(allapps);
				pstmt.close();
				connection.close();
				return result;

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return result;
		}
	}

	/* get all appps */

	@RequestMapping(value = "/getAllApps", method = RequestMethod.POST)
	public HashMap<String, String> getAllApps() throws IOException {
		HashMap<String, String> result = new HashMap<String, String>();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			 * String sql="SELECT * FROM "+ConstantController.userAppTable+"";
			 */
			try {

				/* all Apps */
				String sql = "SELECT * FROM " + ConstantController.userAppTable + "";
				pstmt = connection.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					result.put(rs.getString("app_id"), rs.getString("app_name"));
				}
				// System.out.println("this is result" + result);
				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this allapps sql.");
					}
					pstmt.close();
					connection.close();
					return result;
				}
				pstmt.close();
				connection.close();
				return result;
			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return result;
		}

	}

	//////////////////////get Admin Apps
	/*@RequestMapping(value = "/getAdminApps", method = RequestMethod.POST)
	public HashMap<String, String> getAdminApps() throws IOException {
		HashMap<String, String> result = new HashMap<String, String>();
		Connection connection = new DatabaseController().createUserConnection();
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			
			 * String sql="SELECT * FROM "+ConstantController.userAppTable+"";
			 
			try {

				 all Apps 
				//String sql = "SELECT * FROM " + ConstantController.userAppTable + "";
				String sql = "SELECT * FROM " + ConstantController.userAppTable + " a join "+ConstantController.userGrantTable+" b using (app_id) where UPPER(b.grantee_id)= ? and UPPER(b.role_id)='ROLE0'";
				PreparedStatement pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, userID.toUpperCase());
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					result.put(rs.getString("app_id"), rs.getString("app_name"));
				}
				// System.out.println("this is result" + result);
				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this allapps sql.");
					}
					pstmt.close();
					connection.close();
					return result;
				}
				pstmt.close();
				connection.close();
				return result;
			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return result;
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return result;
		}

	}*/
	
	/* get Visible Apps on Chat Screen */

	@RequestMapping(value = "/getVisibleApps", method = RequestMethod.POST)
	public HashMap<String, String> getVisibleApps() throws IOException {
		HashMap<String, String> result = new HashMap<String, String>();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			/*
			 * String sql="SELECT * FROM "+ConstantController.
			 * userAppPropTable+" WHERE UPPER(app_visibility)='YES'";
			 */
			try {

				/* all Apps */
				String sql = "SELECT * FROM " + ConstantController.userAppPropTable
						+ " WHERE UPPER(app_visibility)='YES'";
				pstmt = connection.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					result.put(rs.getString("app_id"), rs.getString("app_name"));
				}
				// System.out.println("this is result" + result);
				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this allapps sql.");
					}
					pstmt.close();
					connection.close();
					return result;
				}
				pstmt.close();
				connection.close();
				return result;
			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			return result;
		}
	}

}
