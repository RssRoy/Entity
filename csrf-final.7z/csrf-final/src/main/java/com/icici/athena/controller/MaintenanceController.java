package com.icici.athena.controller;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Configuration
@Component 
@RestController
public class MaintenanceController {

	@RequestMapping(value = "/Maintenance", method = RequestMethod.POST)
	public static void maintenance(HttpServletRequest request,HttpServletResponse response ) throws IOException {
		File f=new File("maintenance.flag");
		if(request.getParameter("maintenance")!=null && request.getParameter("maintenance").toString().toLowerCase().equals("true")) {
			FileWriter fw=new FileWriter(f);
			BufferedWriter bw=new BufferedWriter(fw);
			bw.write("true");
			bw.close();
		}else {
			FileWriter fw=new FileWriter(f);
			BufferedWriter bw=new BufferedWriter(fw);
			
			bw.write("false");
			bw.close();
		}
		response.sendRedirect("/MaintenancePage");
	}
	

}
