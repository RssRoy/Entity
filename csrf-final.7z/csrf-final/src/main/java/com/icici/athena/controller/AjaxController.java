package com.icici.athena.controller;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;

import javax.naming.ldap.LdapContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.ParseException;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.icici.athena.ldap.LDAPUtil;
import com.icici.athena.user.User;

@Configuration
@Component 
@RestController
public class AjaxController {
	
	public  static Logger athena = LoggerFactory.getLogger("athena-chat-log");
	public  static Logger audit = LoggerFactory.getLogger("athena-audit-log");
	public  static Logger athenaUser = LoggerFactory.getLogger("athena-User-log");
	public  static Logger athenaActivity = LoggerFactory.getLogger("athena-Activity-log");
	public  static Logger athenaUserActivity = LoggerFactory.getLogger("athena-User-Activity-log");
	public  static Logger athenaFeedback = LoggerFactory.getLogger("athena-feedback-log");
	public  static Logger athenaData = LoggerFactory.getLogger("athena-data-log");
	

	public String appname = null;
	
	@Value("${spring.elasticsearch.jest.proxy.host}")
	 public static  String eserver;
	@Value("${spring.elasticsearch.jest.proxy.host}")
    public void setEserver(String db) {
		
		eserver = db;
    }
	
	@Value("${elasticsearch_nextserver}")
	 public static  String nextServer;
	 @Value("${elasticsearch_nextserver}")
	 public void setnextServer(String db) {
		
		nextServer = db;
	 }
	
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	
	@Value("${elasticsearch_index}")
	public static String eindex;
	@Value("${elasticsearch_index}")
    public void setEindex(String db) {
		eindex = db;
    }
	
	@Value("${server.port}")
	public static int ServerPort;
	@Value("${server.port}")
    public void setServerPort(int port) {
		ServerPort = port;
    }
	///////////////////////User Activity Log Controller///////////////////////////////////////
	@RequestMapping(value = "/Activitylog", method = RequestMethod.POST)
	public static void Activitylog(
			@RequestParam(value="appName",required=false) String appName, 			
			@RequestParam(value="question",required=false) String question,
			@RequestParam(value="Action",required=false) String action,
			@RequestParam(value="QueID",required=false) String id,
			@RequestParam(value="ban",required=false) String ban,
			HttpServletRequest request ) throws IOException {
		 		
		
				
				if(question == null || question.length()==0){
					question="NULL";
				}
				if(action == null || action.length()==0){
					action="NOTHING";
				}
				
				//action="ACTION_{ "+action+" }";
				question = question.replaceAll("Â¶", "Âµ");
				question = question.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");
				
				//question = "QUESTION_{ "+question+" }";
				if(checkSession(request)!=-1)
				athenaActivity.info(" Â¶ "+request.getRemoteAddr()+" Â¶ "+ban+" Â¶  "+request.getSession(false).getId()+" Â¶ "+appName+" Â¶ "+action+" Â¶ "+question+" Â¶ "+id);
				
	
	}
	
	@RequestMapping(value = "/UserActivitylog", method = RequestMethod.POST)
	public static void loginLog(
			@RequestParam(value="id",required=false) String id, 			
			@RequestParam(value="action",required=false) String action,@RequestParam(value="sid",required=false) String sid,
			
			HttpServletRequest request ) throws IOException {
		 		
		
				
				if(action == null || action.length()==0){
					action="NOTHING";
				}
				
				//action=action+" }";
				
				if(sid.equals("NULL")){
					if(checkSession(request)!=-1)
					athenaUserActivity.info(" Â¶ "+request.getRemoteAddr()+" Â¶ "+request.getSession(false).getId()+" Â¶ "+action+" Â¶ "+id);
					
				}else{
					if(checkSession(request)!=-1)
					athenaUserActivity.info(" Â¶ "+request.getRemoteAddr()+" Â¶ "+sid+" Â¶ "+action+" Â¶ "+id);
				}
	
	}
	//////////////////////////////////////////////////////////////////////////////////////////
	
	@RequestMapping(value = "/log", method = RequestMethod.POST)
	public static void log(
			@RequestParam(value="appName",required=false) String appName, 
			@RequestParam(value="q",required=false) String query,
			@RequestParam(value="thumbs",required=false) String thumbs,
			@RequestParam(value="question",required=false) String question,
			@RequestParam(value="wanted",required=false) String wanted,
			@RequestParam(value="message",required=false) String msg,
			@RequestParam(value="ban",required=false) String ban,
			
			HttpServletRequest request,HttpServletResponse response ) throws IOException {
		 		
			String feedbackQuery = "";
		
		if(appName==null && query==null && question==null && ban==null){
			if(isDebug){
				System.out.println("All NULL-> return");
			}
			return;
		}
				if ( query==null || query.length()==0 ){
					query="NO_USER_QUERY";
				}
				if(thumbs!=null && thumbs.equals("UP")){
					wanted="YES";
				}
				else if(thumbs!=null && thumbs.equals("DOWN")){
					wanted="NO";
				}
				if(wanted==null || wanted.length()==0 ){
					wanted="NULL";
				}
				if(question==null || question.length()==0 ){
					question="NULL";
				}
				if( msg==null || msg.length()==0 ){
					msg="NULL";
				}
				if(isDebug){
					System.out.println("Query:"+query);
				}
				query = query.replaceAll("Â¶", "Âµ");
				query = query.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");

				question = question.replaceAll("Â¶", "Âµ");
				question = question.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");
				
				//removing single quotes
				if(question!=null && question.indexOf("\'")>=0 && question.lastIndexOf("\'")>=0){
					question=question.replaceAll("(\')(.{0,})(\')", "$2");
					
				}
				
				wanted = wanted.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");
				msg = msg.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");
				if (query.length()>9 && query.substring(0, 9).trim().toLowerCase().equals("#feedback")){
					feedbackQuery=query.substring(9).trim();
					feedbackQuery = feedbackQuery.replaceFirst(":", " ");
					
					athenaFeedback.info(" | "+ban+" | "+ feedbackQuery);
					if(isDebug){
						System.out.println("Feedback query passed by user!!!");
					}
					return;
				}
				query="USER_QUERY_{ "+query+" }";
				wanted = "WANTED_"+wanted;
				thumbs="THUMBS_"+thumbs;
				msg="MESSAGE_{ "+msg+" }";
				
				question = "QUESTION_{ "+question+" }";
				if(isDebug){
					System.out.println("Query:"+query);		
				}
				if(isDebug){
					System.out.println("Message"+msg+"\nQuestion:"+question+"\n BAN:"+ban);		
				}
				//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
				if(checkSession(request)!=-1){
				athena.info(" Â¶ "+request.getRemoteAddr()+" Â¶ "+ban+" Â¶ "+request.getSession(false).getId()+" Â¶ APPNAME_"+appName+" Â¶ "+query+" Â¶ "+thumbs+" Â¶ "+msg+" Â¶ "+wanted+" Â¶ "+question);
				if(isDebug){
					System.out.println("log: Â¶ "+request.getRemoteAddr()+" Â¶ "+ban+" Â¶ "+request.getSession(false).getId()+" Â¶ APPNAME_"+appName+" Â¶ "+query+" Â¶ "+thumbs+" Â¶ "+msg+" Â¶ "+wanted+" Â¶ "+question);
				}

				}
				
				
	}
	@RequestMapping(value = "/Userlog", method = RequestMethod.POST)
	public static void Userlog(
			@RequestParam(value="appName",required=false) String appName, 
			@RequestParam(value="q",required=false) String query,
			@RequestParam(value="thumbs",required=false) String thumbs,
			@RequestParam(value="question",required=false) String question,
			@RequestParam(value="wanted",required=false) String wanted,
			@RequestParam(value="message",required=false) String msg,
			
			HttpServletRequest request ) throws IOException {
		 		
		
				if ( query==null || query.length()==0 ){
					query="NO_USER_QUERY";
				}
				if(thumbs!=null && thumbs.equals("UP")){
					wanted="YES";
				}
				else if(thumbs!=null && thumbs.equals("DOWN")){
					wanted="NO";
				}
				if(wanted==null || wanted.length()==0 ){
					wanted="NULL";
				}
				if(question==null || question.length()==0 ){
					question="NULL";
				}
				if( msg==null || msg.length()==0 ){
					msg="NULL";
				}
				query = query.replaceAll("Â¶", "Âµ");
				query = query.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");

				question = question.replaceAll("Â¶", "Âµ");
				question = question.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");
				wanted = wanted.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");
				msg = msg.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");
				query="USER_QUERY_{ "+query+" }";
				wanted = "WANTED_"+wanted;
				thumbs="THUMBS_"+thumbs;
				msg="MESSAGE_{ "+msg+" }";
				
				question = "QUESTION_{ "+question+" }";
					
				if(checkSession(request)!=-1)
				athenaUser.info(" Â¶ "+request.getRemoteAddr()+" Â¶ "+request.getSession(false).getId()+" Â¶ APPNAME_"+appName+" Â¶ "+query+" Â¶ "+thumbs+" Â¶ "+msg+" Â¶ "+wanted+" Â¶ "+question);
				
	
	}
	
	//@RequestMapping(value = "/myreindex", method = RequestMethod.GET)
	public void refresh (String server) throws IOException{
		//int status =-1;
		HttpEntity entity = null;
		Response response = null;
		String body = "";
		RestClient restClient = RestClient.builder(new HttpHost(server, 9200, "http")).build();
		entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		if(isDebug){
			System.out.println("Body:+"+body);
		}
		response = restClient.performRequest("POST", "/"+eindex+"/_refresh", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		if(isDebug){
			System.out.println("body:::::"+body+"\nresult:::::"+result);
		}
		restClient.close();
		//status = response.getStatusLine().getStatusCode();
		
	}
	public int reindex() throws IOException{
		
		if(eserver.equals(nextServer)){
			return 200;
		}
		
		int statusCode = -1;
		String nextserver = "";
		
		String body="";
		HttpEntity entity = null;
		Response response = null;
		
		
		refresh(eserver);
	
		
		
		nextserver = nextServer;
		
		if(isDebug){
    		System.out.println("Reindexing from "+eserver+" to "+nextServer);
    	}
		//body = "{\"source\":{\"remote\":{\"host\":\"http://"+nextServer+":9200\",\"username\":\"hdpuser\",\"password\":\"hdpuser@123\"},\"index\":\""+eindex+"\"},\"dest\":{\"index\":\""+eindex+"\"}}";
		body = "{\"source\":{\"remote\":{\"host\":\"http://"+eserver+":9200\",\"username\":\""+ConstantController.user+"\",\"password\":\""+ConstantController.pwd+"\"},\"index\":\""+eindex+"\"},\"dest\":{\"index\":\""+eindex+"\"}}";
		
		//RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		RestClient restClient = RestClient.builder(new HttpHost(nextserver, 9200, "http")).build();
		entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		if(isDebug){
			System.out.println("Body:+"+body);
		}
		response = restClient.performRequest("POST", "/_reindex?pretty=true'", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		if(isDebug){
			System.out.println("body:::::"+body+"\nresult:::::"+result);
		}
		statusCode = response.getStatusLine().getStatusCode();
		
		refresh(eserver);
		refresh(nextServer);
		
		if(statusCode == 200){
			restClient.close();

			if(isDebug){
	    		System.out.println("Reindexing Successful");
	    	}
			return statusCode;
			
		}
		else{
			if(isDebug){
	    		System.out.println("Failed while reindexing");
	    	}
		}
		restClient.close();

		return statusCode;
	}
	
	@RequestMapping(value = "/getvalue", method = RequestMethod.GET)
	public String getResource(@RequestParam("appName") String appName, @RequestParam("q") String query,HttpServletRequest request) throws IOException {
		//System.out.println(eserver);
		appName=URLEncoder.encode(appName, "UTF-8");
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		

		String body="";
		String result = null;

		JsonParser parser = new JsonParser();
		HttpEntity entity = null;
		Response response = null;
		
		
		int wordCount=query.trim().split(" ").length;
		int resultSize = 0;
		query=query.toLowerCase();
		if(isDebug){
			System.out.println("No. of words queried-------------"+wordCount);
		}

		//////////////////////////////////////////////////////////////////With AND operator
		
		if(wordCount==1){
			body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"fuzziness\":\"1\"}}}";
		}
		else{
			body = "{ \"size\":5, \"query\": {\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\": \""+query+"\", \"fuzziness\": \"1\" ,\"operator\":\"and\"} } } ";
		}
		if(isDebug){
			System.out.println("*********************Without Synonyms ************************"+body);
		}
		entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
		result = EntityUtils.toString(response.getEntity());
		if(isDebug){
			System.out.println("\n Query: "+query+"\n Result with fuzziness 1 and operator = 'AND' and without synonyms : "+result);
		}
		//////////////////////////////////////////////////////////////////////
		
		resultSize = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size();
		if(isDebug){
			System.out.println("\nResultSize()-"+resultSize);
		}
		///////////////////////////////////////////////////////////////With Synonym
		if(resultSize==0){
			if(wordCount==1){
				
				body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"fuzziness\":\"1\",\"analyzer\":\"synonym\"}}}";

			
			}
			else{
				body = "{ \"size\":5, \"query\": {\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\": \""+query+"\", \"fuzziness\": \"1\" ,\"operator\":\"and\", \"analyzer\":\"synonym\"} } } ";

			}
			if(isDebug){
				System.out.println("*********************************************"+body);
			}

			
			entity = new NStringEntity(
			        body, ContentType.APPLICATION_JSON);
			
			response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
			result = EntityUtils.toString(response.getEntity());
			if(isDebug){
				System.out.println("\n Query: "+query+"\n Result with fuzziness 1 and operator = 'AND' and synonyms : "+result);
			}
		
		}
		
		///////////////////////////////////////////////////////////////////////Without And Operator for Enter Key 
		resultSize = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size();
		if(isDebug){
			System.out.println("\nResultSize1()-"+resultSize);
		}
		if(resultSize==0){
			query=removeStopWords(query);
			wordCount=query.trim().split(" ").length;
			if(isDebug){
				System.out.println("No. of words queried-------------"+wordCount);
			}
			if(wordCount==1){
				body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"fuzziness\":\"1\",\"analyzer\":\"synonym\"}}}";

			}
			else{
				body = "{ \"size\":5, \"query\": {\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\": \""+query+"\", \"fuzziness\": \"1\" , \"operator\":\"and\", \"analyzer\":\"synonym\"} } } ";

			}
			if(isDebug){
				System.out.println("----------------------------------------"+body);
			}
			entity = new NStringEntity(
			        body, ContentType.APPLICATION_JSON);
			
			response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
			result = EntityUtils.toString(response.getEntity());
			
			if(isDebug){
				System.out.println("\n Query: "+query+"\n Result with fuzziness 1 but without operator = 'AND' :"+result);
			}
		}	
		//////////////////////////////////////////////////////////////////////////////Without And Operator for Enter Key 
		resultSize = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size();
		if(isDebug){
			System.out.println("\nResultSize2()-"+resultSize);
		}
		if(resultSize==0){
			query=removeStopWords(query);
			wordCount=query.trim().split(" ").length;
			if(isDebug){
				System.out.println("No. of words queried-------------"+wordCount);
			}
			if(wordCount==1){
				body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"fuzziness\":\"2\",\"analyzer\":\"synonym\"}}}";

			}
			else{
				body = "{ \"size\":5, \"query\": {\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\": \""+query+"\", \"fuzziness\": \"2\" , \"analyzer\":\"synonym\"} } } ";

			}
			if(isDebug){
				System.out.println("----------------------------------------"+body);
			}
			entity = new NStringEntity(
			        body, ContentType.APPLICATION_JSON);
			
			response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
			result = EntityUtils.toString(response.getEntity());
		}
		if(isDebug){
			System.out.println("\n Query: "+query+"\n Result: "+result);
		}
		if(isDebug){
			System.out.println("\n Query: "+query+"\n Result with fuzziness auto but without operator = 'or' and  :"+result);
		}
	
	 
			resultSize = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size();
				if(isDebug){
						System.out.println("\nResultSize3()-"+resultSize);
				}
		restClient.close();
		return result;
	}
	
	
	public String removeStopWords(String query){
		//String sbquery=new String();
		if(isDebug){
			System.out.println("REMOVE STOPWORDS:"+query);
		}
		// added to remove stopwords
		
		String[] stopwords={"able","about","above","abst","accordance","according","accordingly","across","act","actually","added","adj","affected","affecting","affects","after","afterwards","again","against","ah","all","almost","alone","along","already","also","although","always","am","among","amongst","an","and","announce","another","any","anybody","anyhow","anymore","anyone","anything","anyway","anyways","anywhere","apparently","approximately","are","aren","arent","arise","around","as","aside","ask","asking","at","auth","available","away","awfully","b","back","be","became","because","become","becomes","becoming","been","before","beforehand","begin","beginning","beginnings","begins","behind","being","believe","below","beside","besides","between","beyond","biol","both","brief","briefly","but","by","ca","came","can","cannot","can't","cause","causes","certain","certainly","co","com","come","comes","contain","containing","contains","could","couldnt","d","date","did","didn't","different","do","does","doesn't","doing","done","don't","down","downwards","due","during","e","each","ed","edu","effect","eg","eight","eighty","either","else","elsewhere","end","ending","enough","especially","et","et-al","etc","even","ever","every","everybody","everyone","everything","everywhere","ex","except","f","far","few","ff","fifth","first","five","fix","followed","following","follows","for","former","formerly","forth","found","four","from","further","furthermore","g","gave","get","gets","getting","give","given","gives","giving","go","goes","gone","got","gotten","h","had","happens","hardly","has","hasn't","have","haven't","having","he","hed","hence","her","here","hereafter","hereby","herein","heres","hereupon","hers","herself","hes","hi","hid","him","himself","his","hither","home","how","howbeit","however","hundred","i","id","ie","if","i'll","im","immediate","immediately","importance","important","in","inc","indeed","index","information","instead","into","invention","inward","is","isn't","it","itd","it'll","its","itself","i've","j","just","k","keep","keeps","kept","kg","km","know","known","knows","l","largely","last","lately","later","latter","latterly","least","less","lest","let","lets","like","liked","likely","line","little","'ll","look","looking","looks","ltd","m","made","mainly","make","makes","many","may","maybe","me","mean","means","meantime","meanwhile","merely","mg","might","million","miss","ml","more","moreover","most","mostly","mr","mrs","much","mug","must","my","myself","n","na","name","namely","nay","nd","near","nearly","necessarily","necessary","need","needs","neither","never","nevertheless","new","next","nine","ninety","no","nobody","non","none","nonetheless","noone","nor","normally","nos","not","noted","nothing","now","nowhere","o","obtain","obtained","obviously","of","off","often","oh","ok","okay","old","omitted","on","once","one","ones","only","onto","or","ord","other","others","otherwise","ought","our","ours","ourselves","out","outside","over","overall","owing","own","p","page","pages","part","particular","particularly","past","per","perhaps","placed","please","plus","poorly","possible","possibly","potentially","pp","predominantly","present","previously","primarily","probably","promptly","proud","provides","put","q","que","quickly","quite","qv","r","ran","rather","rd","re","readily","really","recent","recently","ref","refs","regarding","regardless","regards","related","relatively","research","respectively","resulted","resulting","results","right","run","s","said","same","saw","say","saying","says","sec","section","see","seeing","seem","seemed","seeming","seems","seen","self","selves","sent","seven","several","shall","she","shed","she'll","shes","should","shouldn't","show","showed","shown","showns","shows","significant","significantly","similar","similarly","since","six","slightly","so","some","somebody","somehow","someone","somethan","something","sometime","sometimes","somewhat","somewhere","soon","sorry","specifically","specified","specify","specifying","still","stop","strongly","sub","substantially","successfully","such","sufficiently","suggest","sup","sure","t","take","taken","taking","tell","tends","th","than","thank","thanks","thanx","that","that'll","thats","that've","the","their","theirs","them","themselves","then","thence","there","thereafter","thereby","thered","therefore","therein","there'll","thereof","therere","theres","thereto","thereupon","there've","these","they","theyd","they'll","theyre","they've","think","this","those","thou","though","thoughh","thousand","throug","through","throughout","thru","thus","til","tip","to","together","too","took","toward","towards","tried","tries","truly","try","trying","ts","twice","two","u","un","unable","under","unfortunately","unless","unlike","unlikely","until","unto","up","upon","ups","us","use","used","useful","usefully","usefulness","uses","using","usually","v","value","various","'ve","very","via","viz","vol","vols","vs","w","want","wants","was","wasn't","way","we","wed","welcome","we'll","went","were","weren't","we've","what","whatever","what'll","whats","when","whence","whenever","where","whereafter","whereas","whereby","wherein","wheres","whereupon","wherever","whether","which","while","whim","whither","who","whod","whoever","whole","who'll","whom","whomever","whos","whose","why","widely","willing","wish","with","within","without","won't","words","world","would","wouldn't","www","x","y","yes","yet","you","youd","you'll","your","youre","yours","yourself","yourselves","you've","z","zero"};
        HashMap<String,String> stopMap=new HashMap<String,String>();
        for(String e:stopwords){
        	stopMap.put(e,"true".toString());
        }
        
		
		
		ArrayList<String> arrq=new ArrayList<String>(Arrays.asList(query.split(" ")));
		String optimizedQ="";
        for(String temp:arrq){
        	if(stopMap.containsKey((temp.toLowerCase())) && stopMap.get(temp.toLowerCase()).equals("true")){
        	
        	}else{
        		optimizedQ+=temp.trim()+" ";
        	}
        }
        
        
		query=new String(optimizedQ);
		if(isDebug){
			System.out.println("REMOVEd STOPWORDS QUERY:"+query);
		}
		return query;
	}
	@RequestMapping(value = "/searchQuery", method = RequestMethod.GET)
	public String getResources(@RequestParam("appName") String appName, @RequestParam("q") String query) throws IOException {
		appName=URLEncoder.encode(appName, "UTF-8");
		String body = "";
		int wordCount =0;
		JsonParser parser = new JsonParser();
		//LowerCase query
		query=query.toLowerCase();
		
		query=removeStopWords(query);
		
		Response response = null;
		String result = "";
		HttpEntity entity = null;
		
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		
		//query=removeStopWords(query);
		wordCount=query.trim().split(" ").length;
		
		
		if(isDebug){
			System.out.println("No. of words queried search Query-------------"+wordCount);
		}
		if(wordCount==1){
			body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"fuzziness\":\"auto\",\"analyzer\":\"synonym\"}}}";

		}
		//String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";
			
		else{
			//body = "{ \"size\":5, \"query\": {\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\": \""+query+"\", \"fuzziness\": \"auto\" ,\"operator\":\"and\", \"analyzer\":\"synonym\"} } } ";
			body="{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"tie_breaker\":0.1,\"minimum_should_match\":\"30%\",\"fuzziness\":\"auto\",\"analyzer\":\"synonym\"}}}";
			//body="{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"tie_breaker\":0.1,\"slop\":10,\"fuzziness\":\"auto\",\"analyzer\":\"synonym\"}}}";
		}

		entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
		result = EntityUtils.toString(response.getEntity());
		
		//5 suggestions must 
		if(isDebug){
			System.out.println("No. of results --------"+parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
		}
		if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size()<5){
			body = "{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"tie_breaker\":0.1,\"minimum_should_match\":\"30%\",\"analyzer\":\"synonym\"}}}";
			
			entity = new NStringEntity(
			        body, ContentType.APPLICATION_JSON);
			
			response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
			result = EntityUtils.toString(response.getEntity());
			if(isDebug){
				System.out.println("Inside first -if No. of results --------"+parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
			}
			if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size()<5){
				body = "{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"tie_breaker\":0.1,\"minimum_should_match\":\"30%\"}}}";
				
				entity = new NStringEntity(
				        body, ContentType.APPLICATION_JSON);
				
				response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
				result = EntityUtils.toString(response.getEntity());
				if(isDebug){
					System.out.println("Inside second -if No. of results --------"+parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
				}
				if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size()<5){
					body = "{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"tie_breaker\":0.1}}}";
					
					entity = new NStringEntity(
					        body, ContentType.APPLICATION_JSON);
					
					response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
					result = EntityUtils.toString(response.getEntity());
					if(isDebug){
						System.out.println("Inside third -if No. of results --------"+parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
					}
					if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size()<5){
						body = "{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\",\"operator\":\"OR\"}}}";
						
						entity = new NStringEntity(
						        body, ContentType.APPLICATION_JSON);
						
						response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
						result = EntityUtils.toString(response.getEntity());
						if(isDebug){
							System.out.println("Inside fourth -if No. of results --------"+parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
						}
					}
					if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size()<5){
						body = "{\"size\":5,\"query\":{\"match\":{\"_all\":{\"query\":\""+query+"\",\"operator\":\"AND\"}}}}";
						
						entity = new NStringEntity(
						        body, ContentType.APPLICATION_JSON);
						
						response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
						result = EntityUtils.toString(response.getEntity());
						if(isDebug){
							System.out.println("Inside fifth -if() No. of results --------"+parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
						}
					}
				}
			}
		}
		
		//
		
		restClient.close();
		if(isDebug){
			System.out.println("\nBody:"+body+"\n Query: "+query+"\n Result: "+result);
		}
		return result;
	}
	
	@RequestMapping(value = "/searchCompany", method = RequestMethod.GET)
	public String getCompany(@RequestParam("appName") String appName, @RequestParam("q") String query) throws IOException {
		//String str= 
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		
		//String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";
		String body = "{ \"size\": 1, \"query\": { \"match\": { \"UCC_CODE\": { \"query\": \""+query+"\" } } } }";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		return result;
	}
	
	
	
	
	@RequestMapping(value = "/insertData", method = RequestMethod.POST)
	public int  insertQA(@RequestParam("appName") String appName, @RequestParam("question") String question,@RequestParam("answer") String answer) throws IOException {
		
		appName=URLEncoder.encode(appName, "UTF-8");
		if(isDebug){
			System.out.println("insertData"+appName+" "+answer+" "+question+" ");
		}
		JsonObject innerObject = new JsonObject();
		innerObject.addProperty("question", question);
		innerObject.addProperty("answer", answer);
		
		
		
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		
		HttpEntity entity = new NStringEntity(innerObject.toString(), ContentType.APPLICATION_JSON);

        Response indexResponse = restClient.performRequest("POST", "/"+eindex+ "/" + appName,
                Collections.<String, String>emptyMap(), entity);
        int status = reindex();
        /*if(eserver.equals("10.50.72.79")){
        	status = reindex();
        }
        if(eserver.equals("10.50.72.80")){
        	status = myreindex();
        }*/
        if(status == 200){
        	if(isDebug){
	    		System.out.println("Insert----Successfully reindexed!");
	    	}
        	return indexResponse.getStatusLine().getStatusCode(); 
        }
        else{
        	if(isDebug){
	    		System.out.println("Failed to do reindex!");
	    	}
        }
		restClient.close();

		return indexResponse.getStatusLine().getStatusCode();
	}
	
	
	
	@RequestMapping(value = "/showData", method = RequestMethod.GET)
	public String showResources(@RequestParam("appName") String appName) throws IOException {

		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();

		String body="";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		appName=URLEncoder.encode(appName, "UTF-8");
		Response response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search?size=1000", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		return result;
	}
	
	/////////////////////////////////download data app based start
	
	/*@RequestMapping(value = "/downloadData", method = RequestMethod.GET)
	public String downloadResources(@RequestParam("appName") String appName) throws IOException {

		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();

		String body="";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search?size=1000", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		return result;
	}*/
	/////////////////////////////////download stop
	
	@RequestMapping(value = "/searchData", method = RequestMethod.POST)
	public String getSearchData(@RequestParam("appName") String appName,@RequestParam("id") String id) throws IOException {
		appName=URLEncoder.encode(appName, "UTF-8");
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();

		String body="{\"query\": {\"terms\": {\"_id\":  [\""+id+"\"]}}}";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		if(isDebug){
			System.out.println("appname : ::::::::::"+appName);
		}
		Response response = restClient.performRequest("POST", "/"+eindex+"/"+appName+"/_search?size=10", Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		return result;
	}
	
	
	@RequestMapping(value = "/deleteData", method = RequestMethod.POST)
	public String deleteData(@RequestParam("appName") String appName,@RequestParam("id") String id) throws IOException, InterruptedException {

		appName=URLEncoder.encode(appName, "UTF-8");
		
		if(!deleteFiles(appName,id)){
			return new String("500 # Failed to do reindex!");
		}
		String body="";
		Thread.sleep(1000);
		//RestClient restClient79 = RestClient.builder(new HttpHost("10.50.72.79", 9200, "http")).build();
		RestClient restClient79 = RestClient.builder(new HttpHost(nextServer, 9200, "http")).build();

		
		HttpEntity entity79 = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response79 = restClient79.performRequest("DELETE", "/"+eindex+"/"+appName+"/"+id, Collections.<String, String>emptyMap(),entity79);
		String result79 = EntityUtils.toString(response79.getEntity());
		restClient79.close();
		
		//Thread.sleep(1000);
		//RestClient restClient80 = RestClient.builder(new HttpHost("10.50.72.80", 9200, "http")).build();
		if(!eserver.equalsIgnoreCase(nextServer)){
		
		RestClient restClient80 = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		HttpEntity entity80 = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
			Response response80 = restClient80.performRequest("DELETE", "/"+eindex+"/"+appName+"/"+id, Collections.<String, String>emptyMap(),entity80);
			String result80 = EntityUtils.toString(response80.getEntity());
			
			restClient80.close();
			return result80;
		}
		
		return result79;
	}
	
	//delete files 
	public  boolean deleteFiles(String appName, String id) throws ParseException, IOException {
		
		//appName=URLEncoder.encode(appName, "UTF-8");
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();

		String body="";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response = restClient.performRequest("GET", "/"+eindex+"/"+appName+"/"+id, Collections.<String, String>emptyMap(),entity);
		String result = EntityUtils.toString(response.getEntity());
		JsonParser parser=new JsonParser();
		JsonArray resultArr=null;
		boolean res=false;

		if(parser.parse(result).getAsJsonObject().get("_source").getAsJsonObject().has("file")){
			 resultArr = parser.parse(result).getAsJsonObject().get("_source").getAsJsonObject().get("file").getAsJsonArray();
			for(JsonElement tempFile:resultArr){
				String temp=tempFile.getAsString();
				File f=new File(temp);
				 res=false;
				if(f.exists()){
					res=f.delete();
				}else{
					res=true;
				}
			}
		}else if(parser.parse(result).getAsJsonObject().get("_source").getAsJsonObject().has("image")){
			 resultArr = parser.parse(result).getAsJsonObject().get("_source").getAsJsonObject().get("image").getAsJsonArray();
			 for(JsonElement tempFile:resultArr){
					String temp=tempFile.getAsString();
					File f=new File(temp);
					 res=false;
					if(f.exists()){
						res=f.delete();
					}else{
						res=true;
					}
				}
		}else{
			res=true;
		}
		
		
		
		restClient.close();

		
		
		return res;
	}
	
	
	@RequestMapping(value = "/modifyData", method = RequestMethod.POST)
	public int modifyData(HttpServletRequest request,HttpServletResponse response,@RequestParam("appName") String appName,@RequestParam("id") String id,@RequestParam("jsonObj") String json) throws IOException {
		//appName=URLEncoder.encode(appName, "UTF-8");
		appName=URLEncoder.encode(appName, "UTF-8");
		if(isDebug){
			System.out.println("\n\n\n\n-----------------------"+appName+"-----------------------\n\n\n\n"+"\n\n\n\n-----------------------"+URLEncoder.encode(appName, "UTF-8")+"-----------------------\n\n\n\n");
			
		}
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		
		HttpEntity entity = new NStringEntity(json, ContentType.APPLICATION_JSON);

        Response indexResponse = restClient.performRequest("POST", "/" +eindex + "/" + appName+"/"+id,
                Collections.<String, String>emptyMap(), entity);

        int status = reindex();
        if(status == 200){
        	if(isDebug){
	    		System.out.println("Modify---Successfully reindexed!");
	    	}
        	return indexResponse.getStatusLine().getStatusCode(); 
        }
        else{
        	if(isDebug){
	    		System.out.println("Failed to do reindex!");
	    	}
        }
		restClient.close();

		return indexResponse.getStatusLine().getStatusCode();
		
	}
	@RequestMapping(value = "/suggestWords", method = RequestMethod.POST)
	public String suggestWords(@RequestParam("appName") String appName,@RequestParam("word") String word) throws IOException {
		//String str= 
		appName=URLEncoder.encode(appName, "UTF-8");
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		
		/*String body = "{\"query\":{\"match\":{\"question\":\""+query+"\"}}}";*/
		
		//String queryword="";
		String body="{ \"suggest\" : { \"suggestwords\" : { \"text\" : \""+word+"\",\"term\" : { \"field\" : \"_all\"}}}}";
		//String body = "{ \"size\": 5, \"query\": { \"match\": { \"_all\": { \"query\": \""+query+"\", \"operator\": \"and\" } } } }";
		//String body="{\"query\": {\"terms\": {\"_id\":  [\""+id+"\"]}}}";
		//String body="";
		
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);

        Response indexResponse = restClient.performRequest("POST", "/" + eindex+ "/" + appName+"/_search",
                Collections.<String, String>emptyMap(), entity);
        String result = EntityUtils.toString(indexResponse.getEntity());
		restClient.close();
		
		JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(result);
		
		String answer="";
			JsonObject jobj=(JsonObject)jo.get("suggest");
			JsonArray jarr=(JsonArray)jobj.get("suggestwords");
			if(jarr.size()>0){
				jobj=(JsonObject)jarr.get(0);
				jarr=(JsonArray)jobj.get("options");
				return jarr.toString();
			}
			restClient.close();
		
		return answer;
		
		
	}
	
	
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public User authenticate(@RequestParam("username") String username,@RequestParam("password") String password) throws IOException {
	try {
		
		LdapContext conn = LDAPUtil.getConnection(username, password);
		
		User new_user=new User();
		LDAPUtil user = LDAPUtil.getUser(username, conn);
				
		if(isDebug){
			System.out.println("User common name = "+user.getCommonName());
			System.out.println("User distinguised name = "+user.getDistinguishedName());
			System.out.println("User principle = "+user.getUserPrincipal());
			System.out.println("User Given Name = "+user.getGivenName());
			System.out.println("User Name = "+user.getUserName());
		}
		conn.close();
		if(isDebug){
			System.out.println("Success!");
		}
		return new_user;
	} catch(Exception e) {
		//Failed to authenticate user or change password...
		e.printStackTrace();
		return new User("-1");
		
	}
	
	}
	
	
	@RequestMapping(value = "/authenticateUser", method = RequestMethod.POST)
	public String authenticateUser(@RequestParam("username") String username) throws IOException {
		if(isDebug){
			System.out.println(username);
		}
		//String ans="";
		try {
			//LdapContext conn = LDAPUtil.getConnection("ban63230", "dhiraj@123","icicibankltd.com");
			
			if(ConstantController.isDebug){
				System.out.println("trying to Connect  With  !!!\nConnection Details:\nHost:"+ConstantController.ldapHost+"\nPort:"+ConstantController.ldapPort1+"\nUser:"+ConstantController.ldapUser+"\n"+Base64.getEncoder().encodeToString(ConstantController.ldapPwd.getBytes())+"\nDC:"+ConstantController.ldapDc);
}
			LdapContext conn = LDAPUtil.getConnection(ConstantController.ldapUser,ConstantController.ldapPwd,ConstantController.ldapDc);
			if(ConstantController.isDebug){
				if(conn==null){
					System.out.println("Connection NULL With  !!!\nConnection Details:\nHost:"+ConstantController.ldapHost+"\nPort:"+ConstantController.ldapPort1+"\nUser:"+ConstantController.ldapUser+"\n"+Base64.getEncoder().encodeToString(ConstantController.ldapPwd.getBytes())+"\nDC:"+ConstantController.ldapDc);

				}
				if(isDebug) {
					System.out.println(conn.toString());
				}
			}
			
			LDAPUtil user = LDAPUtil.getUser(username, conn);
			//System.out.println("USER CHECKED"+username);
			try{
				
				if(user.getUserName()!=null){
					return "Success#"+user.getUserName();
				}
				
			}catch(Exception e){
				if(ConstantController.isDebug){
					System.out.println("Connection Failed With  !!!\nConnection Details:\nHost:"+ConstantController.ldapHost+"\nPort:"+ConstantController.ldapPort1+"\nUser:"+ConstantController.ldapUser+"\n"+Base64.getEncoder().encodeToString(ConstantController.ldapPwd.getBytes())+"\nDC:"+ConstantController.ldapDc);
				}
				return "Failed";
			}
						
			conn.close();
			if(isDebug){
				System.out.println("Success!");
			}
			return "Success#"+user.getUserName();
		} catch(Exception e) {
			//Failed to authenticate user or change password...
			e.printStackTrace();
			return "Failed";
		}
		
		
	}
	
	
	
	@RequestMapping(value = "/insertJson", method = RequestMethod.POST)
	public String  insertJsonResources(HttpServletRequest request,HttpServletResponse response, @RequestParam("appName") String appName, @RequestParam("jsonObj") String json) throws IOException {
		if(request.getSession(false)==null){
			response.sendRedirect("/login?msg=session expired ! </br> Please Login!");
			return null;
		}
		appName=URLEncoder.encode(appName, "UTF-8");
		if(isDebug){
			System.out.println(json.toString());
		}
		if(appName==null || appName.equals("none")){
			return null;
		}
		athenaData.info(" Â¶ "+appName+" Â¶ "+json.toString());
		
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		
		HttpEntity entity = new NStringEntity(json, ContentType.APPLICATION_JSON);

        Response indexResponse = restClient.performRequest("POST", "/"+eindex +"/" + appName,
                Collections.<String, String>emptyMap(), entity);
        HttpEntity ent = indexResponse.getEntity();
        String responseBody = EntityUtils.toString(ent,"UTF-8");
        if(isDebug){
        	System.out.println("Body----------"+responseBody);
        }
        JsonParser parser = new JsonParser();
        //Gson gson = new Gson();
        JsonObject obj = parser.parse(responseBody).getAsJsonObject();
        if(isDebug){
        	System.out.println(obj.toString());
        }
        
        String id = obj.get("_id").toString();
        int status = -1;
       /* if(eserver.equals("10.50.72.79")){
        	status = reindex();
        }
        if(eserver.equals("10.50.72.80")){
        	status = myreindex();
        }*/
        status=reindex();
        if(status == 200 || status == 201 || status == 202){
             return indexResponse.getStatusLine().getStatusCode()+"#"+id;
        	//return 200+"#"+id;
        }
        else{
            if(isDebug){
                System.out.println("500#Failed to do reindex!");
            }
        }
		restClient.close();

        return indexResponse.getStatusLine().getStatusCode()+"#"+id;
        //return 200+"#"+id;
		
	}
	@RequestMapping(value = "/checkSession", method = RequestMethod.POST)
	public static int  checkSession(HttpServletRequest request) throws IOException {
		
	 		if(request.getSession(false)==null){
	 			return -1;
	 		}else{
	 			if(isDebug){
		 			System.out.println("MaxInterval:"+request.getSession(false).getMaxInactiveInterval());
		 			System.out.println("Last Accessed Interval :"+(request.getSession(false).getMaxInactiveInterval() - ((System.currentTimeMillis() - request.getSession(false).getLastAccessedTime())/1000)));
				 	}
	 			return 1;
	 		}
	 		
	}
	
}

	 

	
	
	
	
	
	

