package com.icici.athena;
import ch.qos.logback.core.rolling.RollingFileAppender;

public class RollingPolicyFifteenMin<E>   extends RollingFileAppender<E>
{
	   private static long start = System.currentTimeMillis(); // minutes
	   private int rollOverTimeInMinutes = 15;

	   @Override
	   public void rollover()
	   {
	      long currentTime = System.currentTimeMillis();
	      int maxIntervalSinceLastLoggingInMillis = rollOverTimeInMinutes * 60 * 1000;

	      if ((currentTime - start) >= maxIntervalSinceLastLoggingInMillis)
	      {
	         super.rollover();
	         start = System.currentTimeMillis();
	      }
	   }
	
	
	   /*private static long start = System.currentTimeMillis(); // minutes
	   private int rollOverTimeInMinutes = 15;
	  
	   @Override
	   public void rollover()
	   {
		  
	      long currentTime = System.currentTimeMillis();
	      LocalTime localTime = LocalTime.now();
	      System.out.println("local time now : " + localTime);
	      int minutes=localTime.getMinute();
	      long currentTimeInMin=(long) (currentTime/(1000*60));
	      //int rem=(int)currentTimeInMin%60;
	      
	     
	      if (minutes%rollOverTimeInMinutes==0 )
	      {
	    	 super.rollover();
	         start = System.currentTimeMillis();
	         
	      }
	   }*/
	   
	}