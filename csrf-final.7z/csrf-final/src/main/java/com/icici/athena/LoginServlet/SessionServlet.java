package com.icici.athena.LoginServlet;

import java.sql.Connection;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;

import javax.annotation.PreDestroy;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.icici.athena.controller.ConstantController;
import com.icici.athena.controller.DatabaseController;

/**
 * Servlet implementation class.
 */

@Component
public class SessionServlet extends HttpServlet implements HttpSessionListener { 
	private static final long serialVersionUID = 1L;

	@Value("${myDebug}")
	public static boolean isDebug;

	@Value("${myDebug}")
	public void setdebug(boolean db) {
		isDebug = db;
	}
	
	HttpSession httpsession;
	
	public HttpSession getHttpsession() {
		return httpsession;
	}
	public  void setHttpsession(HttpSession httpsession) {
		this.httpsession = httpsession;
	}
	
	public SessionServlet(){
		
	}
	public SessionServlet(HttpSession session){
		this.httpsession=session;
	}
	
	
	
	
	//@RequestMapping(value = "SessionServlet",method = RequestMethod.POST)
	public  HttpSession regenrateSession(HttpServletRequest request,HttpServletResponse response,HttpSession session)  {
		  if(session!=null){
			  if(ConstantController.isDebug){
				  System.out.println("SessionID Before:"+request.getSession(false).getId());
			  }
			  request.changeSessionId();
			  if(ConstantController.isDebug){
				  System.out.println("SessionID After:"+request.getSession(false).getId());
			  }
			  return request.getSession(false);
		  }else{
				try{
					return session;
						
				}catch(Exception e){
					e.printStackTrace();	
					return session;
				}
			}
		 /*
		  if(session!=null){
			  Enumeration attrNames = session.getAttributeNames();
			  Properties props = new Properties();
			  
			  while (attrNames != null && attrNames.hasMoreElements()) {
			   String key = (String) attrNames.nextElement();
			   props.put(key, session.getAttribute(key));
			  }
			  
			  session.invalidate();
			  session = request.getSession(true);
			  attrNames = props.keys();
			  
			  while (attrNames != null && attrNames.hasMoreElements()) {
			   String key = (String) attrNames.nextElement();
			   session.setAttribute(key, props.get(key));
			  }
			  session.setMaxInactiveInterval(5*60);
			  
			  this.httpsession=session;
			  
			  setActiveUser((String)session.getAttribute("userid"));
			  return session;
		}else{
			try{
				return session;
					
			}catch(Exception e){
				e.printStackTrace();	
				return session;
			}
		}*/
		  
	}
	@Override
	public void sessionCreated(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		if(ConstantController.isDebug){
			System.out.println("SessionCreating...... @@@@");
		}
		this.httpsession=arg0.getSession();
	}
	@Override
	public void sessionDestroyed(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		if(ConstantController.isDebug){
			System.out.println("Session Destroying...... @@@@");
		}
		this.httpsession=arg0.getSession();
		int x=resetActiveUser((String)arg0.getSession().getAttribute("userid"));
		if(x>0){
			if(ConstantController.isDebug){
				System.out.println("Active User Reset Done");
			}
		}
	}
	//@PreDestroy
	public int resetActiveUser(String myuserid){
		
		if(myuserid==null){
			if(ConstantController.isDebug){
				System.out.println("SessionServlet:User ID NULL!");
			}
			return 0;
		}
		Connection connection=new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if(ConstantController.isDebug){
				System.out.println("SessionServlet:You made it, take control of your database now!");
			}

			try {
				
			
				if (new DatabaseController().findUserById(myuserid)==1) {
					String sql = "UPDATE  "+ConstantController.userTable +" SET "
								+"  active=?"//1
								+"  WHERE user_id=?";//2
					
			
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1,"NO");

					pstmt.setString(2, myuserid.toString().toUpperCase());
					if(ConstantController.isDebug){
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  USER SQL ????? ?"+count);
						for (int i=1;i<=count;i++){
							System.out.println("?"+i+"?????"+pmtdt.getParameterTypeName(i)+pmtdt.getParameterType(i));
						}
					}
			
						int x = pstmt.executeUpdate();
				        if (x > 0){
				        	System.out.println("Active USER Reset   Successfully Updated::: "+myuserid);
				        
				        		if(ConstantController.isDebug){
									System.out.println("Active USER Reset    Updated and Commited");
								}
				        		connection.commit();
				        		pstmt.close();
								connection.close();
								if(ConstantController.isDebug){
									System.out.println("return 1");
								}
				        		return 1;
				        	
				        }else{
				        	System.out.println("Update User Failed");
			
							pstmt.close();
							connection.close();
				        	return -1;
				        }
				}
			}catch (Exception e) {
				if(ConstantController.isDebug){
					System.out.println("SessionServlet: ERROR in Active USER Reset    stmt creation");
				}
				e.printStackTrace();
				try {
					
					connection.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
					
				}
				return -1;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			return -1;	
		}else {
			if(ConstantController.isDebug){
				System.out.println("SessionServlet:Failed  to make connection!");
			}
			return -1;
		}	
	        
	}
public int setActiveUser(String myuserid){
		
		if(myuserid==null){
			if(ConstantController.isDebug){
				System.out.println("SessionServlet:User ID NULL!");
			}
			return 0;
		}
		Connection connection=new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if(ConstantController.isDebug){
				System.out.println("SessionServlet:You made it, take control of your database now!");
			}

			try {
				
			
				if (new DatabaseController().findUserById(myuserid)==1) {
					String sql = "UPDATE  "+ConstantController.userTable +" SET "
								+"  active=?"//1
								+"  WHERE user_id=?";//2
					
			
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1,"YES");

					pstmt.setString(2, myuserid.toString().toUpperCase());
					if(ConstantController.isDebug){
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  USER SQL ????? ?"+count);
						for (int i=1;i<=count;i++){
							System.out.println("?"+i+"?????"+pmtdt.getParameterTypeName(i)+pmtdt.getParameterType(i));
						}
					}
			
						int x = pstmt.executeUpdate();
				        if (x > 0){
				        	System.out.println("Active USER set   Successfully Updated");
				        
				        		if(ConstantController.isDebug){
									System.out.println("Active USER set    Updated and Commited");
								}
				        		connection.commit();
				        		pstmt.close();
								connection.close();
								if(ConstantController.isDebug){
									System.out.println("return 1");
								}
				        		return 1;
				        	
				        }else{
				        	System.out.println("Update User Failed");
			
							pstmt.close();
							connection.close();
				        	return -1;
				        }
				}
			}catch (Exception e) {
				if(ConstantController.isDebug){
					System.out.println("SessionServlet: ERROR in Active USER set    stmt creation");
				}
				e.printStackTrace();
				try {
					
					connection.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
					
				}
				return -1;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			return -1;	
		}else {
			if(ConstantController.isDebug){
				System.out.println("SessionServlet:Failed  to make connection!");
			}
			return -1;
		}	
	        
	}
	
	public int resetAllUsers(){
		
		
		Connection connection=new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if(ConstantController.isDebug){
				System.out.println("SessionServlet:You made it, take control of your database now!");
			}

			try {
				
			
				String sql = "UPDATE  "+ConstantController.userTable +" SET "
								+"  active=?";//1
								
					
			
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1,"NO");
					if(ConstantController.isDebug){
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  USER SQL ????? ?"+count);
						for (int i=1;i<=count;i++){
							System.out.println("?"+i+"?????"+pmtdt.getParameterTypeName(i)+pmtdt.getParameterType(i));
						}
					}
			
						int x = pstmt.executeUpdate();
				        if (x > 0){
				        	System.out.println("All USER Reset   Successfully Updated::: ");
				        
				        		if(ConstantController.isDebug){
									System.out.println("All USER Reset    Updated and Commited");
								}
				        		connection.commit();
				        		pstmt.close();
								connection.close();
								if(ConstantController.isDebug){
									System.out.println("return 1");
								}
				        		return 1;
				        	
				        }else{
				        	System.out.println("Update User Failed");
			
							pstmt.close();
							connection.close();
				        	return -1;
				        }
				
			}catch (Exception e) {
				if(ConstantController.isDebug){
					System.out.println("SessionServlet: ERROR in All USER Reset    stmt creation");
				}
				e.printStackTrace();
				try {
					
					connection.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
					
				}
				return -1;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}	
		}else {
			if(ConstantController.isDebug){
				System.out.println("SessionServlet:Failed  to make connection!");
			}
			return -1;
		}	
	        
	}

}