package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.icici.athena.user.User;

import oracle.sql.TIMESTAMP;

import com.icici.athena.app.AppProp;

@Controller
@Component
@RestController
public class AppPropertiesController {
	
	
	//private String driverName = "oracle.jdbc.driver.OracleDriver";
	 static String driverName=ConstantController.userDatabaseDriverClassName;
	//private String dbURL = "jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
	 static String dbURL=ConstantController.userDatabaseUrl;
	//private String dbUser = "CXPSADM";
	 static String dbUser=ConstantController.userDatabaseUserName;
	//private String dbPassword = "CXPSADM_123";
	 static String dbPassword=ConstantController.userDatabasePassword;
	
	public static void init(){
	//private String driverName = "oracle.jdbc.driver.OracleDriver";
		  driverName=ConstantController.userDatabaseDriverClassName;
		//private String dbURL = "jdbc:oracle:thin:@10.50.83.47:9001:GGPROD1";
		dbURL=ConstantController.userDatabaseUrl;
		//private String dbUser = "CXPSADM";
		 dbUser=ConstantController.userDatabaseUserName;
		//private String dbPassword = "CXPSADM_123";
		 dbPassword=ConstantController.userDatabasePassword;
		
	}
	
	@Value("${myDebug}")
	public static boolean isDebug;

	@Value("${myDebug}")
	public void setdebug(boolean db) {
		isDebug = db;
	}

	@RequestMapping(value = "/getJsonAppProp", method = RequestMethod.POST)
	public String getJsonAppProp(@RequestParam("appid") String myappid) throws IOException {
		JsonObject result = new JsonObject();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (isDebug) {
				System.out.println("You made it, take control of your database now!");
			}
			
			
			try {
				/*
				 * String query = "SELECT * FROM " + ConstantController.userAppPropTable + " WHERE app_id='" + myappid
						+ "' ";
				 */

				
				String sql ="SELECT * FROM " + ConstantController.userAppPropTable + " WHERE app_id=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myappid.toUpperCase());
				
				if (isDebug) {
					System.out.println(sql);
				}
				 rs = pstmt.executeQuery();
				
				while (rs.next()) {

					
					result.addProperty("app_id", rs.getString("app_id"));
					result.addProperty("app_name", rs.getString("app_name"));
					result.addProperty("app_visibility", rs.getString("app_visibility"));
					result.addProperty("app_sr_link", rs.getString("app_sr_link"));
					result.addProperty("app_welcome_msg", rs.getString("app_welcome_msg"));
					result.addProperty("modified_by",rs.getString("modified_by"));
					result.addProperty("modified_time",rs.getString("modified_time"));
				}

				if (isDebug) {
					System.out.println("this is result" + result);
				}
				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result.toString();
				}
				connection.close();
				return result.toString();
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("error in stmt creation");
				}
				 e.printStackTrace();
				return result.toString();
			}finally{
				try {
					 if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if (isDebug) {
				System.out.println("Failed to make connection!");
			}
			return result.toString();
		}

	}

	
	
	public ArrayList<AppProp> getAppProps(User user) throws IOException {
		return getAppProps(user,"NULL");
	}
	
	@RequestMapping(value = "/getAppProperties", method = RequestMethod.POST)
	public ArrayList<AppProp> getAppProps(User user,String myappid) throws IOException {

		ArrayList<AppProp> result = new ArrayList<AppProp>();
		Connection connection = new DatabaseController().createUserConnection();
		ResultSet rs=null;
		PreparedStatement pstmt = null;
		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}
			
			try {
				
				
				/*
				 * 
				 * String query = "SELECT * FROM "+ConstantController.userAppPropTable+" WHERE UPPER(app_id)='" + myappid.toUpperCase() + "' ";

				 */
				
				String sql= "SELECT * FROM "+ConstantController.userAppPropTable+" JOIN "+ConstantController.userAppTable+" USING (app_id) WHERE UPPER(app_id)=? AND UPPER(user_id)=?";
				
				if(user.getIs_superuser().equals("YES")){
					if(ConstantController.isDebug){
						System.out.println("Super user");
					}
					sql="SELECT * FROM " + ConstantController.userAppPropTable + "";
					pstmt = connection.prepareStatement(sql);
				}else{
					if(user.getRole_id().equals("ROLE0")){
						if(ConstantController.isDebug){
							System.out.println("Admin user");
						}
						sql = "SELECT * FROM " + ConstantController.userAppPropTable + " join " + ConstantController.userGrantTable + " USING (APP_ID) WHERE UPPER(GRANTEE_ID)=? AND UPPER(ROLE_ID)='ROLE0'";
						pstmt = connection.prepareStatement(sql);
						pstmt.setString(1, user.getUser_id().toUpperCase());
						
					}
					else{
						if(ConstantController.isDebug){
							System.out.println("Normal user");
						}
						sql= "SELECT * FROM "+ConstantController.userAppPropTable+" JOIN "+ConstantController.userAppTable+" USING (app_id) WHERE UPPER(app_id)=? AND UPPER(user_id)=?";
						pstmt = connection.prepareStatement(sql);
						pstmt.setString(1, myappid.toUpperCase());
						pstmt.setString(2, user.getUser_id().toUpperCase());
					}
				}
				
				/*if (user.getIs_superuser().equals("YES")) {
					sql = "SELECT * FROM "+ConstantController.userAppPropTable+"  ";
					pstmt = connection.prepareStatement(sql);
				} else {
					sql= "SELECT * FROM "+ConstantController.userAppPropTable+" JOIN "+ConstantController.userAppTable+" USING (app_id) WHERE UPPER(app_id)=? AND UPPER(user_id)=?";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, myappid.toUpperCase());
					pstmt.setString(2, user.getUser_id().toUpperCase());
				}*/
				
				//System.out.println(query);
				rs = pstmt.executeQuery();
				

				while (rs.next()) {
					AppProp temp=new AppProp();
					temp.setApp_id(rs.getString("app_id"));
					temp.setApp_name(rs.getString("app_name"));
					temp.setApp_sr_link(rs.getString("app_sr_link"));
					temp.setApp_visibility(rs.getString("app_visibility"));
					temp.setApp_welcome_msg(rs.getString("app_welcome_msg"));
					temp.setModified_by(rs.getString("modified_by"));
					temp.setModified_time((TIMESTAMP) rs.getObject("modified_time"));
					result.add(temp);
				}

				//System.out.println("this is result" + result);
				if (result.size() == 0) {
					if(isDebug){
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result;
				}
				connection.close();
				return result;
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in stmt creation");
				}
				e.printStackTrace();
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			
			return result;
		}

	}
	
	
	//get srlink from table
	@RequestMapping(value = "/getSRLink", method = RequestMethod.POST)
	public String getSrLink(User user,@RequestParam("app_name") String appnamevalue) throws IOException {

		String result ="";
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
/*
 * 				String query = "SELECT APP_SR_LINK FROM "+ConstantController.userAppPropTable+" WHERE UPPER(app_name)='" + appnamevalue.toUpperCase() + "' ";

 */
				
				pstmt = null;
				String sql= "SELECT APP_SR_LINK FROM "+ConstantController.userAppPropTable+" WHERE UPPER(app_name)=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1,appnamevalue.toUpperCase());
				rs = pstmt.executeQuery();
				while (rs.next()) {
					
					result=rs.getString("app_sr_link");
						
				}

				//System.out.println("this is result" + result);
				if (result.length() == 0) {
					if(isDebug){
						System.out.println("There is no SR Link for this question.");
					}
					connection.close();
					return result;
				}
				connection.close();
				return result;
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in stmt creation");
				}
				e.printStackTrace();
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			
			return result;
		}

	}
	
	//get Welcome_Message from table
		@RequestMapping(value = "/getWelcomeMessage", method = RequestMethod.POST)
		public String getWelcomeMessage(User user,@RequestParam("app_name") String appname) throws IOException {

			String result ="";
			Connection connection = new DatabaseController().createUserConnection();
			PreparedStatement pstmt = null;
			ResultSet rs=null;
			if (connection != null) {
				if(isDebug){
					System.out.println("You made it, take control of your database now!");
				}

				try {
					
					/*
					 *String query = "SELECT APP_WELCOME_MSG FROM "+ConstantController.userAppPropTable+" WHERE UPPER(app_name)='" + appname.toUpperCase() + "' ";

					 */
					
					//System.out.println(query);
					
					pstmt = null;
					String sql= "SELECT APP_WELCOME_MSG FROM "+ConstantController.userAppPropTable+" WHERE UPPER(app_name)=?";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1,appname.toUpperCase());
					
					rs = pstmt.executeQuery();

					while (rs.next()) {
						
						result=rs.getString("app_welcome_msg");
					}

					//System.out.println("this is result" + result);
					if (result.length() == 0) {
						if(isDebug){
							System.out.println("There is no SR Link for this question.");
						}
						connection.close();
						return result;
					}
					connection.close();
					return result;
				} catch (Exception e) {
					if(isDebug){
						System.out.println("error in stmt creation");
					}
					e.printStackTrace();
					return result;
				}finally{
					try {
						if (rs != null) rs.close(); 
						 if (pstmt != null) pstmt.close();
						 if (connection != null) connection.close(); 
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
				}
			} else {
				if(isDebug){
					System.out.println("Failed to make connection!");
				}
				
				return result;
			}

		}
}
