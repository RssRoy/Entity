package com.icici.athena.LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.naming.ldap.LdapContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icici.athena.controller.ConstantController;
import com.icici.athena.controller.UserController;
import com.icici.athena.ldap.LDAPUtil;
import com.icici.athena.user.User;

import ch.qos.logback.core.net.SyslogOutputStream;

/**
 * Servlet implementation class LoginServlet
 */

@Controller
public class LoginSSO extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private  String username = "admin";
	private  String password = "password";
	private String userid="BAN0000000";
	
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	
	@ResponseBody
	@RequestMapping(value = "/LoginSSO")
	public  void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
		
		userid=(String) request.getSession().getAttribute("userid");
		
		try{
			//LdapContext conn = LDAPUtil.getConnection("ban63230","dhiraj@123","icicibankltd.com");
			LdapContext conn = LDAPUtil.getConnection(ConstantController.ldapUser,ConstantController.ldapPwd,ConstantController.ldapDc);
			LDAPUtil user =null;
			try{
			user = LDAPUtil.getUser(userid, conn);
			if(isDebug){
				System.out.println("USER IDDDD------>"+userid);
			}
			}catch(Exception e){
				if(isDebug){
					System.out.println("Your EmployeeId might be locked !!!!");
				}
			}
			
			String user_principle=user.getUserPrincipal();
			if(isDebug){
				System.out.println(username);
				System.out.println("User common name = "+user.getCommonName());
				System.out.println("User distinguised name = "+user.getDistinguishedName());
				System.out.println("User principle = "+user.getUserPrincipal());
				System.out.println("User Given Name = "+user.getGivenName());
				System.out.println("User Name = "+user.getUserName());
			}
			User curr_user=new User(user_principle.substring(0,user_principle.indexOf("@")));
			curr_user.setUser_id(user_principle.substring(0,user_principle.indexOf("@")));
			curr_user.setUser_name(user.getUserName());
			username=curr_user.getUser_name();
			try{
			HttpSession session = request.getSession(true);
			session.setAttribute("username", curr_user.getUser_name());
			session.setAttribute("userid", curr_user.getUser_id());
			session.setAttribute("ipaddress", request.getRemoteAddr());
			session.setAttribute("sessionid", request.getSession().getId());
			session.setAttribute("userId", curr_user.getUser_id());
			session.setAttribute("userName", user.getUserName());

			if(isDebug){
				System.out.println("user to set");
			}
			session.setAttribute("user", new UserController().getUser(userid,username));
			
			if(isDebug){
				System.out.println("user set");
			}
			
			//setting session to expiry in 30 mins
			session.setMaxInactiveInterval(5*60);
			/*Cookie userName = new Cookie("username", URLEncoder.encode(username, "UTF-8"));
			userName.setMaxAge(5*60);
			response.addCookie(userName);*/
			response.sendRedirect("/admin");
			}catch(Exception e){
				if(isDebug){
					System.out.println("ERROR in SESSION"+e);
				}
			}

		}catch(Exception e){
			if(isDebug){
				System.out.println(e);
			}
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/Error");
			PrintWriter out= response.getWriter();
			out.println("<font color=red>Either user name or password is wrong.</font>");
			rd.include(request, response);
		}

	}
	
	
}