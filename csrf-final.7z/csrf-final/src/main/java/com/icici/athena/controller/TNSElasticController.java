package com.icici.athena.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.ParseException;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.ResponseException;
import org.elasticsearch.client.RestClient;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.icici.athena.app.TNSM;
import com.icici.athena.user.User;

import oracle.sql.TIMESTAMP;

@Controller
@Component
@RestController
public class TNSElasticController {
	
	
	
	public int insertToElastic(String method,String index,String type,String id,String body) throws IOException{
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();
		
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		
		Response response=null;
		try {
			response = restClient.performRequest(method.toUpperCase(), "/"+index.toLowerCase()+"/"+type.toLowerCase()+"/"+id+"/", Collections.<String, String>emptyMap(),entity);
			ElasticController.reindex(index);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			restClient.close();
			e1.printStackTrace();
			return -1;
		}
		try {
			restClient.close();
			return response.getStatusLine().getStatusCode();
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			restClient.close();
			return -2;
		}
	}
	
	
	@RequestMapping(value = "/getJsonTns", method = RequestMethod.POST)
	public String getJsonTns(@RequestParam("app_id") String myappid) throws IOException {
		JsonObject result = new JsonObject();
		

		
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body="";
		String res ="";
		//int cnt = 0;
		JsonParser parser = new JsonParser();
		
		body = "";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		//appName=URLEncoder.encode(appName, "UTF-8");
		Response response = null;
		try {
			response = restClient.performRequest("GET", "/"+ConstantController.tnsIndex+"/tns/"+myappid.toLowerCase()+"/", Collections.<String, String>emptyMap(),entity);
			if(ConstantController.isDebug){
				System.out.println(response.toString()+"  "+myappid.toLowerCase());
			}
		}catch (ResponseException e) {
			// TODO Auto-generated catch block
			response = e.getResponse();
			if (ConstantController.isDebug) {
				System.out.println("TNS Not found" + res + "<----");
			}
			JsonObject jsonMap=new JsonObject();
			jsonMap.addProperty("found", false);
			
			
			e.printStackTrace();
			restClient.close();
			
			return jsonMap.toString();
		}  catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject jsonTns =null;
		jsonTns = parser.parse(res).getAsJsonObject().get("_source").getAsJsonObject();
		result=jsonTns;
		
			
		if (ConstantController.isDebug) {
			System.out.println("this is result" + result.toString());
		}
		result.addProperty("server_password",ConstantController.decodeTNS(result.get("server_password").getAsString()) );
		restClient.close();
		return result.toString();
	}

	
	
	public ArrayList<TNSM> getTns(User user) throws IOException {
		return getUserTns("NULL");
	}
	
	//@RequestMapping(value = "/getUserTns", method = RequestMethod.POST)
	public ArrayList<TNSM> getUserTns(String myappid) throws IOException {

		ArrayList<TNSM> result = new ArrayList<TNSM>();
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body="";
		JsonParser parser = new JsonParser();
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		//appName=URLEncoder.encode(appName, "UTF-8");
		Response response = restClient.performRequest("GET", "/"+ConstantController.tnsIndex+"/tns/_search?size=1000", Collections.<String, String>emptyMap(),entity);
		String res = EntityUtils.toString(response.getEntity());
		restClient.close();
		//System.out.println("*********************************"+res.toString());
		int resultSize = parser.parse(res).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size();
		for(int i=0;i<resultSize;i++){
			JsonObject jsonTns = parser.parse(res).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().get(i).getAsJsonObject().get("_source").getAsJsonObject();
		//System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+jsonTns.toString());
			TNSM temp=new TNSM();
			temp.setApp_id(jsonTns.get("app_id").getAsString());
			temp.setApp_name(jsonTns.get("app_name").getAsString());
			temp.setTns_server_host(jsonTns.get("server_host").getAsString());
			temp.setTns_server_port(jsonTns.get("server_port").getAsString());
			temp.setTns_service_name(jsonTns.get("service_name").getAsString());
			temp.setTns_database_name(jsonTns.get("database_name").getAsString());
			temp.setTns_user_name(jsonTns.get("server_user_name").getAsString());
			if(jsonTns.has("modified_by")){
				temp.setModified_by(jsonTns.get("modified_by").getAsString());
			}else{
				temp.setModified_by("");
			}
			if(jsonTns.has("modified_time")){
			temp.setModified_time(new TIMESTAMP(jsonTns.get("modified_time").getAsString()));
			}else{
				temp.setModified_by("");
			}
			//temp.settns_password(jsonTns.get("server_password").getAsString());
			

			result.add(temp);
		}
		
		return result;
		

	}
	
	@RequestMapping(value = "/appTnsExist", method = RequestMethod.POST)
	public String appTnsExist(@RequestParam (value="app_id",required=false) String myappid){
		//System.out.println("appTnsExist::"+myappid);
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body="";
		String res ="";
		int cnt = 0;
		JsonParser parser = new JsonParser();
		
		body = "";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		//appName=URLEncoder.encode(appName, "UTF-8");
		Response response = null;
		try {
			//res = EntityUtils.toString(restClient.performRequest("GET", "/sql-parameters/tns/"+myappid.toLowerCase()+"/", Collections.<String, String>emptyMap(),entity).getEntity());
			response = restClient.performRequest("GET", "/"+ConstantController.tnsIndex+"/tns/"+myappid.toLowerCase()+"/", Collections.<String, String>emptyMap(),entity);
			if(ConstantController.isDebug) {
				System.out.println(response);
			}
			if(ConstantController.isDebug){
				System.out.println(res);
			}
		} catch (ResponseException e) {
			// TODO Auto-generated catch block
			response=e.getResponse();
			if(ConstantController.isDebug){
				System.out.println("App Not found"+res+"<----");
			}
			e.printStackTrace();
		}catch(IOException e){
			if(ConstantController.isDebug){
				System.out.println("Error get app exist");
			}
			e.printStackTrace();
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean tnsexist=parser.parse(res).getAsJsonObject().get("found").getAsBoolean();
		if(tnsexist){
			return "YES";
		}else{
			return "NO";
		}
		
	}
	public TNSM getAppTns(String myappid)  {

		TNSM result = null;
		
		RestClient restClient = RestClient.builder(new HttpHost(ConstantController.eserver, 9200, "http")).build();

		String body="";
		String res ="";
		//int cnt = 0;
		JsonParser parser = new JsonParser();
		
		body = "";
		HttpEntity entity = new NStringEntity(
		        body, ContentType.APPLICATION_JSON);
		//appName=URLEncoder.encode(appName, "UTF-8");
		Response response = null;
		try {
			response = restClient.performRequest("GET", "/"+ConstantController.tnsIndex+"/tns/"+myappid+"/", Collections.<String, String>emptyMap(),entity);
		} catch (ResponseException e) {
			// TODO Auto-generated catch block
			response = e.getResponse();
			if (ConstantController.isDebug) {
				System.out.println("TNS Not found" + res + "<----");
			}
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject jsonTns = parser.parse(res).getAsJsonObject().get("_source").getAsJsonObject();
		
		TNSM temp=new TNSM();
		if (jsonTns.get("app_id").toString().equals(myappid)){
				temp.setApp_id(jsonTns.get("app_id").getAsString());
				temp.setApp_name(jsonTns.get("app_name").getAsString());
				temp.setTns_server_host(jsonTns.get("server_host").getAsString());
				temp.setTns_server_port(jsonTns.get("server_port").getAsString());
				temp.setTns_service_name(jsonTns.get("service_name").getAsString());
				temp.setTns_database_name(jsonTns.get("database_name").getAsString());
				temp.setTns_user_name(jsonTns.get("server_user_name").getAsString());
				//temp.setTns_user_password(ConstantController.decodeTNS(jsonTns.get("server_password").getAsString()));
				result =temp;
			}
		
		
		
		return result;

	}
	
	
	//Find TNS
	public int findTnsByAppId(String myappid) throws IOException{
				if (appTnsExist(myappid).equals("YES")){
					return 1;
				}
				else{
					return -1;
				}
				
	}

	
	@RequestMapping(value = "/insertTnsEntry", method = RequestMethod.POST)
	public  int insertTnsEntry(

			@RequestParam(value = "app_id" , required = false)    String myappid,
			@RequestParam(value = "app_name" , required = false)    String myappname,
			@RequestParam(value = "server_host", required = false)  String  mytnshost,
			@RequestParam(value = "server_port", required = false)  String  mytnsport,
			@RequestParam(value = "service_name", required = false)  String  mytnsservice,
			@RequestParam(value = "database_name", required = false)  String  mytnsdbname,
			@RequestParam(value = "server_user_name", required = false)  String  mytnsusername,
			@RequestParam(value = "server_password", required = false)  String  mytnsuserpwd,
			
			HttpServletRequest request) throws IOException {
		
		if(request.getSession(false)==null && request.getSession(false).getAttribute("user")==null){
			return -1;
		}
		User user=(User)request.getSession(false).getAttribute("user");
		
		
		myappid=myappid.toUpperCase();
		myappname=myappname.toUpperCase();
		mytnshost=mytnshost.toUpperCase();
		mytnsport=mytnsport.toUpperCase();
		mytnsservice=mytnsservice.toUpperCase();
		mytnsdbname=mytnsdbname.toUpperCase();
		mytnsusername=mytnsusername.toUpperCase();
		mytnsuserpwd=ConstantController.encodeTNS(mytnsuserpwd.trim());
		
		
		
		
		if(ConstantController.isDebug){
			System.out.println("TNS Controller: ");
			System.out.println("app Name: "+myappname);
			System.out.println("App ID: "+myappid);
			System.out.println("host : "+mytnshost);
			System.out.println("port: "+mytnsport);
			System.out.println("service: "+mytnsservice);		
			System.out.println("username: "+mytnsusername);
			System.out.println(": "+mytnsuserpwd);
		}
		
		if(findTnsByAppId(myappid)==1){
					if(ConstantController.isDebug){
						System.out.println("TNS WILL BE UPDATED.");
					}				
		}else{
					if(ConstantController.isDebug){
						System.out.println("TNS CAN BE INSERTED");
					}
		}
		if (findTnsByAppId(myappid)==1) {
				/*+ "app_id=?,"		//1
							+ "app_name=?,"		//2
							+ "server_host=?,"//3
							+ "server_port=?,"	//4
							+ "service_name=?,"//5
							+ "database_name=?,"//6
							+ "server_user_name=?,"//7
							+ "server_password=?"//8
							+ "WHERE app_id=?";	//9
					 	*/	
			JsonObject tns=new JsonObject();
			tns.addProperty("app_id", myappid);
			tns.addProperty("app_name", myappname);
			tns.addProperty("server_host", mytnshost);
			tns.addProperty("server_port", mytnsport);
			tns.addProperty("service_name", mytnsservice);
			tns.addProperty("database_name", mytnsdbname);
			tns.addProperty("server_user_name", mytnsusername);
			tns.addProperty("server_password", mytnsuserpwd);
			tns.addProperty("modified_by", user.getUser_name());
			tns.addProperty("modified_time",new java.sql.Timestamp(System.currentTimeMillis()).toString());
			

			int resp= insertToElastic("POST", ""+ConstantController.tnsIndex+"", "tns", myappid.toLowerCase(), tns.toString());
			if(resp>=200){
				return 2;
			}else{
				return -1;
			}
		}else{
			JsonObject tns=new JsonObject();
			tns.addProperty("app_id", myappid);
			tns.addProperty("app_name", myappname);
			tns.addProperty("server_host", mytnshost);
			tns.addProperty("server_port", mytnsport);
			tns.addProperty("service_name", mytnsservice);
			tns.addProperty("database_name", mytnsdbname);
			tns.addProperty("server_user_name", mytnsusername);
			tns.addProperty("server_password", mytnsuserpwd);	
			tns.addProperty("modified_by", user.getUser_name());
			tns.addProperty("modified_time",new java.sql.Timestamp(System.currentTimeMillis()).toString());
			
			int resp= insertToElastic("POST", ConstantController.tnsIndex, "tns", myappid.toLowerCase(), tns.toString());		
					
			if(resp>=200){
				return 1;
			}else{
				return -1;
			}	
		}	
	
	}	
}
