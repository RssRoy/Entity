package com.icici.athena.LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.Clock;
import java.util.Base64;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.naming.ldap.LdapContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.icici.athena.controller.AjaxController;
import com.icici.athena.controller.ConstantController;
import com.icici.athena.controller.DatabaseController;
import com.icici.athena.controller.UserController;
import com.icici.athena.ldap.LDAPUtil;
import com.icici.athena.user.User;

import oracle.sql.TIMESTAMP;

/**
 * Servlet implementation class LoginServlet
 */

@Controller
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private  String username = "admin";
    private  String password = "password";
    private String userid="BAN0000000";
    SessionServlet sessionservlet=null;
	
	 public SessionServlet getSessionservlet() {
		return sessionservlet;
	}

	public void setSessionservlet(SessionServlet sessionservlet) {
		this.sessionservlet = sessionservlet;
	}
	
  
    @Value("${myDebug}")
    public static boolean isDebug;
    @Value("${myDebug}")
    public void setdebug(boolean db) {
        isDebug = db;
    }
   
    /*public void toLink(String link,HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException{
    	RequestDispatcher rd = req.getRequestDispatcher(link);
    	rd.forward(req, resp);
    }*/
    @RequestMapping(value = "LoginServlet",method = RequestMethod.POST)
    public  void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
       
    	RequestDispatcher rd= null;
       
         userid=(String) request.getParameter("username");
         password=(String) request.getParameter("password");
         if(isDebug){
               // System.out.println("LoginServlet: Line:52: Userid:"+userid+"Password:"+password+" Time :"+new Date().getTime());

            }
        try{
            //LdapContext conn = LDAPUtil.getConnection("ban63230","dhiraj@123","icicibankltd.com");
            LdapContext conn=null;
            if(password.length()==0 || password.trim().length()==0 || userid.length()==0 || userid.trim().length()==0)
            {
            	if(isDebug){
            		System.out.println("Connection Failed Without Password  !!!\nConnection Details:\nHost:"+ConstantController.ldapHost+"\nPort:"+ConstantController.ldapPort1+"\nUser:"+userid+"\n"+Base64.getEncoder().encodeToString(password.getBytes())+"\nDC:"+ConstantController.ldapDc);
                    }
                /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                dd.forward(request, response);*/
             
                response.sendRedirect("login?msg=user id and password not matched");
            	/*rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            	rd.forward(request,response);*/
            	
            	//toLink("/login?msg=user id and password not matched",request,response);

                 return;
            }
            try{
                 conn = LDAPUtil.getConnection(userid,password,ConstantController.ldapDc);
                
               
                 if(conn==null){
                   	 if(isDebug){
                   		System.out.println("Connection NULL With  !!!\nConnection Details:\nHost:"+ConstantController.ldapHost+"\nPort:"+ConstantController.ldapPort1+"\nUser:"+userid+"\n"+Base64.getEncoder().encodeToString(password.getBytes())+"\nDC:"+ConstantController.ldapDc);
                            }
                        /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                        dd.forward(request, response);*/
                     
                        response.sendRedirect("login?msg=user id and password not matched");
                   	 
                   /* rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                	rd.forward(request,response);*/
                 	//toLink("/login?msg=user id and password not matched",request,response);

                         return;
                    }
                 if(isDebug){
                     System.out.println("LoginServlet: Line:66: UserName:"+userid+"Context:"+conn.toString());

                 }
                
            }catch(Exception e){
                if(isDebug){
                    System.out.println("Your EmployeeId might be locked !!!!");
                    }
                /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                dd.forward(request, response);*/
                if(isDebug){
                    System.out.println("LoginServlet : Redirect to : /login?msg=user id and password not matched");
                    }
               response.sendRedirect("login?msg=user id and password not matched");
                
                /*rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            	rd.forward(request,response);*/
            	//toLink("/login?msg=user id and password not matched",request,response);

                 return;
            }
            LDAPUtil user =null;
            try{
                user = LDAPUtil.getUser(userid, conn);
            
                if(isDebug){
                    System.out.println("LoginServletUser: User Info "+user.getUserName());
                    }
                
            
            
            
            }catch(Exception e){
                if(isDebug){
                System.out.println("Your EmployeeId might be locked !!!");
                }
                e.printStackTrace();

                    /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                    dd.forward(request, response);*/
               response.sendRedirect("login?msg=EmployeeId might be locked");
                /*rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            	rd.forward(request,response);*/
            	//toLink("/login?msg=user id and password not matched",request,response);


                     return;
            }
            User curr_user=new User();
            String user_principle=user.getUserPrincipal();
            curr_user.setUser_id(user_principle.substring(0,user_principle.indexOf("@")));
            curr_user.setUser_name(user.getUserName());
            username=curr_user.getUser_name();
            if(isDebug){
                System.out.println("UserName:"+username);
            }
            if(isDebug){
                System.out.println("User common name = "+user.getCommonName());
                System.out.println("User distinguised name = "+user.getDistinguishedName());
                System.out.println("User principle = "+user.getUserPrincipal());
                System.out.println("User Given Name = "+user.getGivenName());
                System.out.println("User Name = "+user.getUserName());
            }
           
            try{
            	HttpSession old_session = request.getSession(false);
            	if(old_session!=null){
            		old_session.invalidate();
            	}
          
            
            	
          
            User oracleuser= new UserController().getUser(userid,username);
            
            
            /*Clock clock=Clock.system(ZoneId.of("Asia/Kolkata"));
			//Format format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
            DateFormat oracleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
            if(isDebug){
            	System.out.println(oracleFormat.parse(oracleuser.getLogin_time().toString()).toInstant()+"  --->"+Instant.now(clock).plusSeconds(TimeUnit.MINUTES.toSeconds( 15 )));
            }
	        	
            if(oracleuser.getActive()!=null && oracleuser.getActive().toString().toUpperCase().equals("YES") && oracleFormat.parse(oracleuser.getLogin_time().toString()).toInstant().plusSeconds(TimeUnit.MINUTES.toSeconds( 15 )).isBefore(Instant.now(clock))==false){
	        	if(isDebug){
            		System.out.println("USER ALREADY ACTIVE");
            	}
            	response.sendRedirect("login?msg=You already logged in from another browser or</br> Session is active on another browser");
            	 return;
            }*/
            if(oracleuser.getActive()!=null && oracleuser.getActive().toString().toUpperCase().equals("YES") ){
	        	if(isDebug){
            		System.out.println("USER ALREADY ACTIVE");
            	}
            	//response.sendRedirect("/login?msg=You already logged in from another browser or <br/> Session is active on another browser");
	        	response.sendRedirect("/login?msg=You already logged in from another browser or Session is active on another browser");
            	 return;
            }
            int updateLogin=new DatabaseController().updateLoginTime(curr_user.getUser_id());
            if(isDebug){
                System.out.println("user set and Login Time"+updateLogin);
            }
            HttpSession session = request.getSession(true);
            session.setAttribute("username", curr_user.getUser_name());
            session.setAttribute("userid", curr_user.getUser_id());
            session.setAttribute("ipaddress", request.getRemoteAddr());
            session.setAttribute("sessionid", request.getSession(false).getId());
            this.sessionservlet=new SessionServlet(session);
            if(isDebug){
                System.out.println("user to set");
            }
            if(isDebug){
                System.out.println("UPDATE  USER LOGIN TIME ");
            }
            	
            /*int updateLogin=new DatabaseController().updateLoginTime(userid);
            if(isDebug){
                System.out.println("user set and Login Time"+updateLogin);
            }*/
           
            session.setAttribute("user",oracleuser);
           
            
           
            
            //setting session to expiry in 30 mins
            session.setMaxInactiveInterval(5*60);
           /* Cookie userName = new Cookie("username", URLEncoder.encode(username, "UTF-8"));
            userName.setMaxAge(5*60);
            response.addCookie(userName);*/
            
            if(isDebug){
                System.out.println("Redirected to Admin.jsp");
            }
            if(request.getSession(false)!=null) {
            	AjaxController.athenaUserActivity.info(" Â¶ "+request.getRemoteAddr()+" Â¶ "+request.getSession(false).getId()+" Â¶ LOGIN  Â¶ "+userid);
            }else {
            	if(isDebug){
                    System.out.println("Session is  NULL in Login Servlet");
                }
            }
            /*rd=request.getRequestDispatcher("/admin");
        	rd.forward(request,response);*/
        	//toLink("/admin",request,response);
            response.sendRedirect("admin");
            return;
            
            }catch(Exception e){
                if(isDebug){
                    System.out.println("ERROR in SESSION"+e);
                    e.printStackTrace();
                }
               
                response.sendRedirect("login?msg=user id and password not matched");
                return;
                /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
                dd.forward(request, response);*/
               
                //response.sendRedirect("/login?msg=Error in session creation");
                /*rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            	rd.forward(request,response);*/
            	//toLink("/login?msg=user id and password not matched",request,response);
                 
            }

        }catch(Exception e){
            if(isDebug){
                System.out.println(e);
            }
           
           /* PrintWriter out= response.getWriter();
            out.println("<font color=red>Either user name or password is wrong.</font>");
            
             response.sendRedirect("login?msg=user id and password not matched");
            */ 
            rd=request.getRequestDispatcher("/login?msg=user id and password not matched");
        	rd.forward(request,response);
             return;
            /*RequestDispatcher dd=request.getRequestDispatcher("/login?msg=user id and password not matched");
            dd.forward(request, response);*/
           
           

        }
       
    
    
   
    }
   
   
   
}