package com.icici.athena.controller;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
@Controller
public class FileUploadController extends HttpServlet{
	
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	

	@Value("${uploadFolder}")
	public static String  UPLOADED_FOLDER;
	@Value("${uploadFolder}")
    public void setfolder(String  db) {
		UPLOADED_FOLDER = db;
    }
	
	
	
	private static final long serialVersionUID = 1L;
	public JsonArray fArr=new JsonArray();
	public static String pretty(String json){
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		JsonParser jp = new JsonParser();
		JsonElement je = jp.parse(json);
		String prettyJsonString = gson.toJson(je);
		return prettyJsonString;
	}
public static boolean checkdir(String dirName) throws IOException{
		
	if(isDebug){
		System.out.println("Check DiR !");
	}
		File f = new File(dirName);
		if (f.exists() && f.isDirectory()) {
		   return true;
		}
		Files.createDirectories(Paths.get(dirName));
		 File dir = new File(dirName);
		    
		    // attempt to create the directory here
		    boolean successful =  (dir.exists() && dir.isDirectory());
		    return successful;
		
	}


	@GetMapping("/uploadFile")
	public void doGet (HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.sendRedirect("/uploadfile");
		return;
	}

	@PostMapping("/uploadFile")
    public void doPost (
            @RequestParam("file") MultipartFile[] uploadfiles,@RequestParam("appName") String appName,@RequestParam("question") String question,@RequestParam("answer") String answer,@RequestParam("identity") String id,HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {

		if(request.getSession(false)==null){
			response.sendRedirect("/login?msg=session expired ! </br> Please Login!");
			return;
		}
		if(isDebug){
			System.out.println("Multi file upload!");
			System.out.println("Question:"+question);
			System.out.println("Answer:"+answer);
			System.out.println("Files:"+uploadfiles.length);
			
			
		}
		question=question.replaceAll("'", "\\'").replaceAll("\"","\\\"");
		answer=answer.replaceAll("'", "\\'").replaceAll("\"","\\\"");
		
        if (uploadfiles.length==0) {
        	System.out.println("upload No Files!");
        	response.sendRedirect("/uploadfile");
        	/*request.getRequestDispatcher("/uploadfile").forward(request, response);*/
        	return;
        }
        String result="";
        JsonObject json =null;
        String elastic_id=null;
        try {

            ArrayList<String> uresult=saveUploadedFiles((List<MultipartFile>) Arrays.asList(uploadfiles),appName,id);
            if(uresult.size()>0){
            	json = new JsonObject();
        		json.addProperty("question", question);
        		json.addProperty("answer", answer);
        		JsonArray jsona=new JsonArray();
            	for(String str:uresult){
            		if(str.equals("Executable files are not allowed to upload.")) {
            			request.getRequestDispatcher("/uploadfile?msg=Executable files are not allowed to upload.").forward(request, response);
                    	return;
            		}
            		jsona.add(str);
            	}
            	json.add("file", jsona);
        		AjaxController.athenaData.info(" Â¶ "+appName+" Â¶ "+json.toString());

            	result=new AjaxController().insertJsonResources(request,response,appName,json.toString());            
            }
            request.setAttribute("result", result);
            request.getSession(false).setAttribute("result", result);
            request.setAttribute("json", json.toString());
            request.getSession(false).setAttribute("json", json.toString());
            if(result.indexOf('#')>0){
                elastic_id=result.substring(result.indexOf('#')+1);

            }
            //response.sendRedirect("/uploadfile?msg=success&id="+elastic_id);
        	request.getRequestDispatcher("/uploadfile?msg=success&id="+elastic_id).forward(request, response);
        	return;
        
        } catch (IOException e) {
        	/*response.sendRedirect("/uploadfile?msg=error&id="+elastic_id);*/
        	/*request.getRequestDispatcher("/uploadfile").forward(request, response);*/
        	request.getRequestDispatcher("/uploadimage?msg=error in uploading&id="+elastic_id).forward(request, response);

        	return;
        }

    }
	 private ArrayList<String>  saveUploadedFiles(List<MultipartFile> files,String appName,String id) throws IOException {
		 	ArrayList<String> arr=new ArrayList<String>();
		 	if(isDebug){
		 		System.out.println("Size in saveUploadFiles: "+files.size());
		 	}
	        for (MultipartFile file : files) {

	            if (file.isEmpty()) {
	            	if(isDebug){
	            		System.out.println("File Empty");
	            	}
	                continue; //next pls
	            }
	            String name=file.getOriginalFilename();
	            final String content=new String(file.getBytes());
	            String magicStr = content.substring(0, 2);
		           String ext=name.substring(name.lastIndexOf('.'));
		           System.out.println("extn -  "+ext);
		           if((!ext.equals(".zip") || !ext.equals(".7z") || !ext.equals(".tar") || !ext.equals(".rar"))) {
		            	if(magicStr != null || !magicStr.equals("")) {
		            		if(magicStr.equals("MZ") || magicStr.equals("PK")) {
		            			try {
									//response.sendRedirect("/uploadfile?msg=Executable files are not allowed to upload.");
		            				arr.add("Executable files are not allowed to upload.");
									return arr;
								} catch (Exception e) {
									e.printStackTrace();
								}
		            		}
		            	}
		            } else if (ext.equals(".exe") || ext.equals(".jar") || ext.equals(".phb")) {
		            	arr.add("Executable files are not allowed to upload.");
		            	return arr;
		            }
	            byte[] bytes = file.getBytes();
	            String folder= UPLOADED_FOLDER+appName.toUpperCase()+"/FILES/";
	            Path path = Paths.get(folder +id+"-"+Long.toString(System.nanoTime()).toUpperCase()+ext.toUpperCase());
	           
	            if(isDebug){
	            	System.out.println(folder +id+"-"+file.getOriginalFilename().toUpperCase()+ext.toUpperCase() );//System.nanoTime()
	            	System.out.println(folder +id+"-"+Long.toString(System.nanoTime()).toUpperCase()+ext.toUpperCase() );//System.nanoTime()

	            }
	            if(checkdir(folder)){
	            	Files.write(path, bytes);
	            	arr.add(path.toString());
	            	
	            	
	            }
	            
	            /* byte[] bytes = file.getBytes();
	            String folder= UPLOADED_FOLDER+appName.toUpperCase()+"/FILES/";
	            Path path = Paths.get(folder +file.getOriginalFilename().toUpperCase() );
	           
	            if(isDebug){
	            	System.out.println(folder +file.getOriginalFilename().toUpperCase() );
	            }
	            if(checkdir(folder)){
	            	Files.write(path, bytes);
	            	arr.add(path.toString());
	            	
	            	
	            }*/
	            
	            
	            

	        }
	        return arr;
	        

	    }
	// @RequestMapping(value = "{path}/{upload}/{appName}/FILES/{id}.{ext}",method = RequestMethod.GET)
	//	 public ResponseEntity<byte[]> getFile(@PathVariable("path") String path,@PathVariable("upload") String upload,@PathVariable("appName") String app,@PathVariable("id") String id,@PathVariable("ext") String ext) throws IOException {

	 @RequestMapping(value = "**/{appName}/FILES/{id}.{ext}",method = RequestMethod.GET)
	 public ResponseEntity<byte[]> getFile(@PathVariable("appName") String app,@PathVariable("id") String id,@PathVariable("ext") String ext) throws IOException {
		 if(isDebug){
	    	 System.out.println("GET FILE FROM UPLOAD PATH:"+UPLOADED_FOLDER+"/"+app+"/FILES/"+id+"."+ext);
	     }
		 RandomAccessFile f = new RandomAccessFile(UPLOADED_FOLDER+"/"+app+"/FILES/"+id+"."+ext, "r");
	     
	     byte[] b = new byte[(int)f.length()];
	     f.readFully(b);
	     
	     final HttpHeaders headers = new HttpHeaders();
	     if(isDebug){
	    	 System.out.println("File Downloaded:"+ext+" \n ");
	     }
	     if(ext.equalsIgnoreCase("PDF")){
	    	 headers.setContentType(MediaType.APPLICATION_PDF);
	     }
	    /* else if(ext.equalsIgnoreCase("CSV")){
	    	 headers.setContentType(MediaType.parseMediaType("text/csv"));
	     }*/
	    	 
	     else if(ext.equalsIgnoreCase("DOC") || ext.equalsIgnoreCase("DOCX")){
	    	 headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"));
	     }
	     else if(ext.equalsIgnoreCase("XLS") || ext.equalsIgnoreCase("XLSX")){
	    	 headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
	     }
		 else if(ext.equalsIgnoreCase("PPT") || ext.equalsIgnoreCase("PPTX")){
			 headers.setContentType(MediaType.parseMediaType("application/msword"));
		 }/*
		 else if(ext.equalsIgnoreCase("JSON")){
			 headers.setContentType(MediaType.APPLICATION_JSON);
		 }
		 else if(ext.equalsIgnoreCase("JS")){
			 headers.setContentType(MediaType.parseMediaType("application/javascript"));
		 }
		 else if(ext.equalsIgnoreCase("TXT")){
			 headers.setContentType(MediaType.parseMediaType("text/plain"));
		 }*/
		 else if(ext.equalsIgnoreCase("ZIP") ){
			 headers.setContentType(MediaType.parseMediaType("application/zip"));
		 }
		 else if(ext.equalsIgnoreCase("TAR")){
			 headers.setContentType(MediaType.parseMediaType("application/tar"));
		 }
		 else if(ext.equalsIgnoreCase("7Z")){
			 headers.setContentType(MediaType.parseMediaType("application/7z"));
		 }
		 else if(ext.equalsIgnoreCase("RAR")){
			 headers.setContentType(MediaType.parseMediaType("application/rar"));
		 }else if(ext.equalsIgnoreCase("JPEG")){
			 headers.setContentType(MediaType.IMAGE_JPEG);
		 }
		 else if(ext.equalsIgnoreCase("PNG")){
			 headers.setContentType(MediaType.IMAGE_PNG);
		 }/*
		 else if(ext.equalsIgnoreCase("GIF")){
			 headers.setContentType(MediaType.IMAGE_GIF);
		 }*/
	     
	     //to check internet explorer
	     headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	     headers.setContentDispositionFormData("attachment", id.toLowerCase()+"."+ext.toLowerCase());
		 
	     if(isDebug){
	    	 System.out.println("File Downloaded  :"+headers.toString()+" \n");
	     }
	        
	     f.close();
	     return new ResponseEntity<byte[]>(b, headers, HttpStatus.OK);



	 }
}