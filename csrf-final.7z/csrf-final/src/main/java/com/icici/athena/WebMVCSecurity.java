package com.icici.athena;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.icici.athena.CustomAuthenticationProvider;

@Configuration
@Order(SecurityProperties.ACCESS_OVERRIDE_ORDER)
@EnableWebSecurity
public class WebMVCSecurity extends WebSecurityConfigurerAdapter {

	@Autowired
	private SecurityProperties securityProperties;

	@Autowired
	private CustomAuthenticationProvider authProvider;

	// @Autowired
	// private CustomNtlmAuthenticationProvider ntlmAuthProvider;

	@Autowired
	CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler;

	@Override
	protected void configure(HttpSecurity http) throws Exception {

		// http.csrf().disable();

		// System stuff
		http.authorizeRequests()//
				.antMatchers("/favicon.ico").permitAll();

		// Pages
		http.authorizeRequests().antMatchers("/").permitAll()//
				.antMatchers("/js/chatScript.js").permitAll().antMatchers("/suggestWords").permitAll()
				.antMatchers("**/suggestWords**").permitAll().antMatchers("**/log**").permitAll().antMatchers("/log")
				.permitAll().antMatchers("/getWelcomeMessage").permitAll().antMatchers("**/getWelcomeMessage**")
				.permitAll().antMatchers("/Chat").permitAll().antMatchers("/Chat**").permitAll()//
				.antMatchers("/Chat?appName=**").permitAll()//
				.antMatchers("/LoginSSOChat**").permitAll()//
				.antMatchers("/adminChat**").permitAll()//
				.antMatchers("/LoginSSOChat**").permitAll()//
				// disallow everything else...
				.anyRequest().authenticated();

		http/* cors().and(). */.authorizeRequests().anyRequest().fullyAuthenticated().and().formLogin()
				.loginPage("/adminlogin").loginProcessingUrl("/LoginServlet")
				.successHandler(customAuthenticationSuccessHandler).failureUrl("/adminlogin?msg=Authentication Error")
				.permitAll();

		http.logout().logoutRequestMatcher(new AntPathRequestMatcher("/LogoutServlet")).logoutSuccessUrl("/adminlogin")
				.permitAll();
		/*
		 * http.csrf().disable().antMatcher("/Chat").antMatcher("/Chat**").antMatcher(
		 * "/Chat?appName=**")
		 * .antMatcher("/LoginSSOChat**").antMatcher("/adminChat**").antMatcher(
		 * "/LoginSSOChat**");
		 */
		if (securityProperties.isEnableCsrf()) {
			http.addFilterAfter(new WebSecurityConfig(), CsrfFilter.class);
		} else {
			http.csrf().disable();
		}
		http.csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse());
	}
	/*
	 * @Bean CorsConfigurationSource corsConfigurationSource() { CorsConfiguration
	 * configuration = new CorsConfiguration();
	 * configuration.setAllowedOrigins(Arrays.asList("/Chat","/Chat**",
	 * "/Chat?appName=**","/LoginSSOChat**","/adminChat**","/LoginSSOChat**"));
	 * configuration.setAllowedMethods(Arrays.asList("GET","POST"));
	 * UrlBasedCorsConfigurationSource source = new
	 * UrlBasedCorsConfigurationSource(); source.registerCorsConfiguration("/**",
	 * configuration); return source; }
	 */

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/authenticateUser")
				/*
				 * .and().ignoring().antMatchers("/adminChat").and().ignoring()
				 * .antMatchers("/Chat/**").and().ignoring().antMatchers("/chatLogin").and().
				 * ignoring() .antMatchers("/LoginSSOChat").and().ignoring().antMatchers(
				 * "/LoginSSOChat?appName=**").and().ignoring()
				 * .antMatchers("/?appName**").and().ignoring().antMatchers("/Chat?appName**").
				 * and().ignoring()
				 * .antMatchers("/LoginSSOChat?**").and().ignoring().antMatchers("/index**")
				 */.and().ignoring().antMatchers("/css/**").and().ignoring().antMatchers("/static/**").and().ignoring()
				.antMatchers("/js/**").and().ignoring().antMatchers("assets/js/**").and().ignoring()
				.antMatchers("assets/img/**").and().ignoring().antMatchers("assets/css/lib/**").and().ignoring()
				.antMatchers("assets/css/fonts/**").and().ignoring().antMatchers("assets/css/**").and().ignoring()
				.antMatchers("assets/js/lib/**").and().ignoring().antMatchers("/assets/**").and().ignoring()
				.antMatchers("/data/**").and().ignoring().antMatchers("/images/**").and().ignoring()
				.antMatchers("/suggestWords").and().ignoring().antMatchers("/log").and().ignoring()
				.antMatchers("/getWelcomeMessage").and().ignoring().antMatchers("/getvalue").and().ignoring()
				.antMatchers("/searchQuery").and().ignoring().antMatchers("/getReasonsForApp").and().ignoring()
				.antMatchers("/checkSql").and().ignoring().antMatchers("/getJsonMap").and().ignoring()
				.antMatchers("/searchData").and().ignoring().antMatchers("/fonts/**");
		;

	}

	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		// auth.ldapAuthentication();
		// auth.jdbcAuthentication();

		// auth.authenticationProvider(ntlmAuthProvider);
		auth.authenticationProvider(authProvider);
		// SecurityContext securityContext = SecurityContextHolder.getContext();

	}

}