package com.icici.athena.app;

import oracle.sql.TIMESTAMP;

public class AppSr {
	private String app_id;
	private String app_name;
	
	private String reason_id;
	private String reason_name;
	private String reason_link;
	private String modified_by;

	private TIMESTAMP modified_time;
	
	public String getApp_id() {
		return app_id;
	}
	public String getApp_name() {
		return app_name;
	}
	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}
	
	
	@Override
	public String toString() {
		return "AppSr [app_id=" + app_id + ", app_name=" + app_name + ", reason_id=" + reason_id + ", reason_name="
				+ reason_name + ", reason_link=" + reason_link + ", modified_by=" + modified_by + ", modified_time="
				+ modified_time + "]";
	}
	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}
	public String getReason_id() {
		return reason_id;
	}
	public void setReason_id(String reason_id) {
		this.reason_id = reason_id;
	}
	public String getReason_link() {
		return reason_link;
	}
	public void setReason_link(String reason_link) {
		this.reason_link = reason_link;
	}
	public String getReason_name() {
		return reason_name;
	}
	public void setReason_name(String reason_name) {
		this.reason_name = reason_name;
	}
	public TIMESTAMP getModified_time() {
		return modified_time;
	}
	public void setModified_time(TIMESTAMP modified_time) {
		this.modified_time = modified_time;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	
	
}
