package com.icici.athena.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.HmacAlgorithms;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.icici.athena.user.User;


import com.icici.athena.app.AppSr;
import com.icici.athena.app.AppSub;

@Controller
@Component
@RestController
public class AppSubAreaLinkController {
	
	@Value("${myDebug}")
	public static boolean isDebug;

	@Value("${myDebug}")
	public void setdebug(boolean db) {
		isDebug = db;
	}
	@RequestMapping(value = "/getReasonsForApp", method = RequestMethod.POST)
	public String getJsonReasonsForApp(@RequestParam("appname") String myappname,@RequestParam("appid") String myappid) throws IOException {
		JsonObject result = new JsonObject();
		JsonArray jarr=new JsonArray();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (isDebug) {
				System.out.println("You made it, take control of your database now!");
			}
			
			
			try {
				/*
				 * String query = "SELECT * FROM " + ConstantController.userAppPropTable + " WHERE app_id='" + myappid
						+ "' ";
				 */

				
				String sql ="SELECT * FROM " + ConstantController.userAppSrTable + "   JOIN  "+ConstantController.userSrReasonTable +" USING (REASON_ID)   WHERE app_id=? ";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myappid.toUpperCase());
				
				
				if (isDebug) {
					System.out.println(sql);
				}
				 rs = pstmt.executeQuery();
				
				while (rs.next()) {
					JsonObject temp=new JsonObject();
					
					temp.addProperty("app_id", rs.getString("app_id"));
					temp.addProperty("app_name", rs.getString("app_name"));
					
					temp.addProperty("reason_id", rs.getString("reason_id"));
					temp.addProperty("reason_name", rs.getString("reason_name"));
					
					temp.addProperty("reason_link", rs.getString("reason_link"));
					jarr.add(temp);
				}

				if (isDebug) {
					System.out.println("this is result" + jarr.toString());
				}
				if (jarr.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return jarr.toString();
				}
				connection.close();
				return jarr.toString();
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("error in stmt creation");
				}
				 e.printStackTrace();
				return jarr.toString();
			}finally{
				try {
					 if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if (isDebug) {
				System.out.println("Failed to make connection!");
			}
			return jarr.toString();
		}

	}

	@RequestMapping(value = "/getJsonAppSR", method = RequestMethod.POST)
	public String getJsonAppSR(@RequestParam("appid") String myappid,@RequestParam("reasonid") String myreasonid) throws IOException {
		JsonObject result = new JsonObject();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (isDebug) {
				System.out.println("You made it, take control of your database now!");
			}
			
			
			try {
				/*
				 * String query = "SELECT * FROM " + ConstantController.userAppPropTable + " WHERE app_id='" + myappid
						+ "' ";
				 */

				
				String sql ="SELECT * FROM " + ConstantController.userAppSrTable + "   JOIN  "+ConstantController.userSrReasonTable +" USING (REASON_ID)   WHERE app_id=? AND reason_id=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myappid.toUpperCase());
				pstmt.setString(2, myreasonid.toUpperCase());
				
				if (isDebug) {
					System.out.println(sql);
				}
				 rs = pstmt.executeQuery();
				
				while (rs.next()) {

					
					result.addProperty("app_id", rs.getString("app_id"));
					result.addProperty("app_name", rs.getString("app_name"));
					
					result.addProperty("reason_id", rs.getString("reason_id"));
					result.addProperty("reason_name", rs.getString("reason_name"));
					
					result.addProperty("reason_link", rs.getString("reason_link"));
					
				}

				if (isDebug) {
					System.out.println("this is result" + result);
				}
				if (result.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result.toString();
				}
				connection.close();
				return result.toString();
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("error in stmt creation");
				}
				 e.printStackTrace();
				return result.toString();
			}finally{
				try {
					 if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if (isDebug) {
				System.out.println("Failed to make connection!");
			}
			return result.toString();
		}

	}

	
	
	public ArrayList<AppSr> getAppSRs(User user,HttpServletRequest request,HttpServletResponse response) throws IOException {
		return getAppSRs(user,"NULL",request,response);
	}
	
	@RequestMapping(value = "/getAppSRs", method = RequestMethod.POST)
	public ArrayList<AppSr> getAppSRs(User user,String myappid,HttpServletRequest request,HttpServletResponse response) throws IOException {

		ArrayList<AppSr> result = new ArrayList<AppSr>();
		Connection connection = new DatabaseController().createUserConnection();
		ResultSet rs=null;
		PreparedStatement pstmt = null;
		HashSet<String> hs=new HashSet<String>();
		for(Entry<String, String> e:user.getAdminApps().entrySet()){
			hs.add(e.getKey());
		}
		if(isDebug){
			System.out.println("HashSet :"+hs.toArray().toString());
		}
		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}
			
			try {
				
				
				/*
				 * 
				 * String query = "SELECT * FROM "+ConstantController.userAppPropTable+" WHERE UPPER(app_id)='" + myappid.toUpperCase() + "' ";

				 */
				
				String sql= "SELECT * FROM "+ConstantController.userAppSrTable +"  JOIN  "+ConstantController.userSrReasonTable +" USING (REASON_ID)   WHERE app_id=?";
				
				if(user.getIs_superuser().equals("YES")){
					
					sql="SELECT * FROM " + ConstantController.userAppSrTable  +"   JOIN  "+ConstantController.userSrReasonTable +" USING (REASON_ID)  ";
					if(ConstantController.isDebug){
						System.out.println("Super user SQL:"+sql);
					}
					pstmt = connection.prepareStatement(sql);
				}else{
					if(user.getRole_id().equals("ROLE0")){
						
						sql = "SELECT * FROM " + ConstantController.userAppSrTable +"   JOIN  "+ConstantController.userSrReasonTable +" USING (REASON_ID)   WHERE app_id=?";
						if(ConstantController.isDebug){
							System.out.println("Admin userr SQL:"+sql);
						}
						pstmt = connection.prepareStatement(sql);
						pstmt.setString(1, user.getUser_id().toUpperCase());
						
					}
					else{
						
						sql= "SELECT * FROM "+ConstantController.userAppSrTable+"   JOIN  "+ConstantController.userSrReasonTable +" USING (REASON_ID)   WHERE app_id IN ?";
						pstmt = connection.prepareStatement(sql);
						pstmt.setString(1,hs.toArray().toString() );
						if(ConstantController.isDebug){
							System.out.println("Normal user SQL:"+sql);
						}
					}
				}
				
				/*if (user.getIs_superuser().equals("YES")) {
					sql = "SELECT * FROM "+ConstantController.userAppPropTable+"  ";
					pstmt = connection.prepareStatement(sql);
				} else {
					sql= "SELECT * FROM "+ConstantController.userAppPropTable+" JOIN "+ConstantController.userAppTable+" USING (app_id) WHERE UPPER(app_id)=? AND UPPER(user_id)=?";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, myappid.toUpperCase());
					pstmt.setString(2, user.getUser_id().toUpperCase());
				}*/
				
				//System.out.println(query);
				rs = pstmt.executeQuery();
				

				while (rs.next()) {
					AppSr temp=new AppSr();
					temp.setApp_id(rs.getString("app_id"));
					temp.setApp_name(rs.getString("app_name"));
					
					temp.setReason_id(rs.getString("reason_id"));
					temp.setReason_name(rs.getString("reason_name"));
					
					temp.setReason_link(rs.getString("reason_link"));
					
					result.add(temp);
				}

				System.out.println("this is result" + result);
				if (result.size() == 0) {
					if(isDebug){
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return result;
				}
				connection.close();
				return result;
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in stmt creation");
				}
				e.printStackTrace();
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			
			return result;
		}

	}
	
	
	//get srlink from table
	@RequestMapping(value = "/getAppSRLink", method = RequestMethod.POST)
	public String getAppSrLink(User user,@RequestParam("appid") String appid,@RequestParam("reasonid") String reasonid) throws IOException {

		String result ="";
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}

			try {
/*
 * 				String query = "SELECT APP_SR_LINK FROM "+ConstantController.userAppPropTable+" WHERE UPPER(app_name)='" + appnamevalue.toUpperCase() + "' ";

 */
				
				pstmt = null;
				String sql= "SELECT APP_SR_LINK FROM "+ConstantController.userAppSrTable+"   JOIN  "+ConstantController.userSrReasonTable +" USING (REASON_ID)   WHERE UPPER(reason_id)=? AND UPPER(app_id)=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1,appid.toUpperCase());
				pstmt.setString(1,reasonid.toUpperCase());
				rs = pstmt.executeQuery();
				while (rs.next()) {
					
					result=rs.getString("reason_link");
						
				}

				//System.out.println("this is result" + result);
				if (result.length() == 0) {
					if(isDebug){
						System.out.println("There is no SR Link for this question.");
					}
					connection.close();
					return result;
				}
				connection.close();
				return result;
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in stmt creation");
				}
				e.printStackTrace();
				return result;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			
			return result;
		}

	}
	
	public static HashMap <String,String> getAllReasons(){
		
		Connection connection = new DatabaseController().createUserConnection();
		ResultSet rs=null;
		PreparedStatement pstmt = null;
		HashMap<String,String> hm=new HashMap<String,String>();
		
		if (connection != null) {
			if(isDebug){
				System.out.println("You made it, take control of your database now!");
			}
			
			try {
				
				String sql= "SELECT * FROM "+ConstantController.userSrReasonTable +"   JOIN  "+ConstantController.userSrReasonTable +" USING (REASON_ID)  ";
				pstmt=connection.prepareStatement(sql);
				rs = pstmt.executeQuery();
				

				while (rs.next()) {
					
					hm.put(rs.getString("reason_id").trim(), rs.getString("reason_name").trim());
				}

				
				
				connection.close();
				return hm;
			} catch (Exception e) {
				if(isDebug){
					System.out.println("error in stmt creation");
				}
				e.printStackTrace();
				return hm;
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		} else {
			if(isDebug){
				System.out.println("Failed to make connection!");
			}
			
			return hm;
		}

	}
	
	// Find App Properties
	public int findAppSRLink(String myappid,String myreasonid) throws IOException {
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("AppSubAreaController:You made it, take control of your database now!");
			}

			try {
				String sql = "SELECT * FROM " + ConstantController.userAppSrTable +"   JOIN  "+ConstantController.userSrReasonTable +" USING (REASON_ID)   WHERE  app_id=? AND reason_id=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myappid.toString().toUpperCase());
				pstmt.setString(2, myreasonid.toString().toUpperCase());


				rs = pstmt.executeQuery();
				if (rs.next()) {
					if (ConstantController.isDebug) {
						System.out.println("App SR LINK  exists");
					}
					return 1;
				} else {
					if (ConstantController.isDebug) {
						System.out.println("App SR LInk   doesn't  exists");
					}
					return -1;
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("AppSubAreaController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		} else {
			if (ConstantController.isDebug) {
				System.out.println("AppSubAreaController:Failed to make connection!");
			}
			return -1;
		}

	}
	@RequestMapping(value = "/insertAppSRLink", method = RequestMethod.POST)
	public int insertAppSRLink(

			@RequestParam(value = "app_id", required = false) String myappid,

			@RequestParam(value = "app_name", required = false) String myappname,
			
			@RequestParam(value = "reason_id", required = false) String myreasonid,
			@RequestParam(value = "reason_name", required = false) String myreasonname,
			@RequestParam(value = "reason_link", required = false) String myreasonlink,

			HttpServletRequest request) throws IOException {

		// '||chr(38)||'
		
		
		if(request.getSession(false)==null || request.getSession(false).getAttribute("user")==null){
			return -1;
		}
		User user=(User)request.getSession(false).getAttribute("user");
		myappname = myappname.toUpperCase();
		myappid = myappid.toUpperCase();
		myreasonid=myreasonid.toUpperCase();

		myreasonname=myreasonname.toUpperCase();
		
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (ConstantController.isDebug) {
				System.out.println("AppSubAreaController:You made it, take control of your database now!");
			}

			try {

				
				if (findAppSRLink(myappid,myreasonid) == 1) {
					if (ConstantController.isDebug) {
						System.out.println("App SR LInk  WILL BE UPDATED.");
					}
					String sql = "UPDATE " + ConstantController.userAppSrTable + " SET " 
							+ "app_id=?," // 1
							+ "app_name=?," // 2
							+"reason_id=?,"//3
							+ "modified_time=SYSDATE,"
							+ "modified_by=? ,"//4
							+"reason_link=? "//5
							+ " WHERE app_id=? AND reason_id=?"; // 6,7

					pstmt = connection.prepareStatement(sql);

					pstmt.setString(1, myappid.toString().toUpperCase());
					pstmt.setString(2, myappname.toString().toUpperCase());
					pstmt.setString(3, myreasonid.toString().toUpperCase());
					pstmt.setString(4, user.getUser_id().toString());
					pstmt.setString(5, myreasonlink.toString());
					
					pstmt.setString(6, myappid.toString().toUpperCase());
					
					pstmt.setString(7, myreasonid.toString().toUpperCase());

					if (ConstantController.isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  App Properties SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
					}

					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("App  SR Link   Successfully Updated");

						if (ConstantController.isDebug) {
							System.out.println("App  SR Link  Updated and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (ConstantController.isDebug) {
							System.out.println("return 1");
						}
						return 1;

					} else {
						System.out.println("Update App  SR Link  Failed");

						pstmt.close();
						connection.close();
						return -1;
					}

				} else {
					if (ConstantController.isDebug) {
						System.out.println("App SR Link CAN BE INSERTED");
					}
					String sql = "INSERT INTO " + ConstantController.userAppSrTable
							+ " (app_id,app_name,reason_id,reason_link) VALUES (?,?,?,?)";

					pstmt = connection.prepareStatement(sql);

					pstmt.setString(1, myappid.toString().toUpperCase());
					pstmt.setString(2, myappname.toString().toUpperCase());
					pstmt.setString(3, myreasonid.toString().toUpperCase());
					//pstmt.setString(4, myreasonname.toString());
					pstmt.setString(4, myreasonlink.toString());
					
					

					if (ConstantController.isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("Insert App  App  SR SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
					}
					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("App  App  SR Successfully Inserted");

						if (ConstantController.isDebug) {
							System.out.println("App  App  SR Inserted and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (ConstantController.isDebug) {
							System.out.println("return 1");
						}
						return 1;

					} else {
						System.out.println("Insert Failed");

						pstmt.close();
						connection.close();
						return -1;
					}
				}

			} catch (Exception e) {
				if (ConstantController.isDebug) {
					System.out.println("AppSubAreaController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				return -1;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			if (ConstantController.isDebug) {
				System.out.println("AppSubAreaController:Failed to make connection!");
			}
			return -1;
		}

	}
}
