package com.icici.athena.LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.naming.NamingException;
import javax.naming.ldap.LdapContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.icici.athena.controller.AjaxController;
import com.icici.athena.controller.ConstantController;
import com.icici.athena.controller.UserController;
import com.icici.athena.ldap.LDAPUtil;
import com.icici.athena.user.User;

import ch.qos.logback.core.net.SyslogOutputStream;


/**
 * Servlet implementation class LoginServlet
 */

@Controller
public class LoginSSOChat extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private  String username = "admin";
	private  String password = "password";
	private String userid="BAN0000000";
	
	@Value("${myDebug}")
	public static boolean isDebug;
	@Value("${myDebug}")
    public void setdebug(boolean db) {
		isDebug = db;
    }
	
	//@ResponseBody
	@RequestMapping(value = "/LoginSSOChat")
	public  void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		userid=(String) request.getSession().getAttribute("userid");
		
		if(isDebug){
			System.out.println("USER iD in LoginIDSSO page: "+userid);
		}
		LdapContext conn=null;
		try{
			//LdapContext conn = LDAPUtil.getConnection("ban63230","dhiraj@123","icicibankltd.com");
			conn = LDAPUtil.getConnection(ConstantController.ldapUser,ConstantController.ldapPwd,ConstantController.ldapDc);
			LDAPUtil user =null;
			try{
				user = LDAPUtil.getUser(userid, conn);
				if(isDebug){
					System.out.println("USER IDDDD------>"+userid);
				}
			}catch(Exception e){
				if(isDebug){
					
					System.out.println("Your EmployeeId might be locked !!!!");
					e.printStackTrace();
				}
				if(request.getParameter("appName")==null){
					 response.sendRedirect("/adminChat");
			    	 return;
				}else{
		    	  	response.sendRedirect("/adminChat?appName="+request.getParameter("appName"));
		    	  	return;
				}
			}
			
			String user_principle=user.getUserPrincipal();
			if(isDebug){
				System.out.println(username);
				System.out.println("User common name = "+user.getCommonName());
				System.out.println("User distinguised name = "+user.getDistinguishedName());
				System.out.println("User principle = "+user.getUserPrincipal());
				System.out.println("User Given Name = "+user.getGivenName());
				System.out.println("User Name = "+user.getUserName());
			}
			username=user.getUserName();
			try{
			HttpSession session = request.getSession();
			
			session.setAttribute("username", user.getUserName());
			session.setAttribute("userid", userid);
			session.setAttribute("ipaddress", request.getRemoteAddr());
			session.setAttribute("sessionid", request.getSession().getId());
			session.setAttribute("userId", userid);
			session.setAttribute("userName", user.getUserName());
		
			//System.out.println("user to set");
			//session.setAttribute("user", new UserController().getUser(userid,username));
			
			if(isDebug){
				System.out.println("user set");
			}
			
			//setting session to expiry in 15 minutes // 1 min
			session.setMaxInactiveInterval(5*60);
			request.getSession(false).setMaxInactiveInterval(5*60);
			/*Cookie userName = new Cookie("username", URLEncoder.encode(username, "UTF-8"));
			userName.setMaxAge(5*60);
			response.addCookie(userName);*/
			if(isDebug){
				System.out.println(" in Login SSOCHAT AppName is:"+request.getParameter("appName")+" Response:");
			}
			if(request.getParameter("appName")!=null){
				if(isDebug){
					System.out.println("App Name ---"+request.getParameter("appName")+" Redirecting to Chat>AppName");
				}
	    	  	response.sendRedirect("/Chat?appName="+request.getParameter("appName"));
	    	  	return;
	    	  }else{
	    		  if(isDebug){
	    			  System.out.println("App Name !!!"+request.getParameter("appName")+" redirecting to Chat");
	    		  }
	      	  	response.sendRedirect("/Chat");
	      	  	return;
	    	  }
			//response.sendRedirect("/Chat?appName="+request.getParameter("appName"));
			
			}catch(Exception e){
				if(isDebug){
					System.out.println("ERROR in SESSION"+e);
				}
				if(request.getParameter("appName")==null){
					 response.sendRedirect("/adminChat");
			    	 return;
				}else{
			    	  	response.sendRedirect("/adminChat?appName="+request.getParameter("appName"));
			    	  	return;
				}
			}

		}catch(Exception e){
			if(isDebug){
				System.out.println(e);
			}
			/*RequestDispatcher rd = getServletContext().getRequestDispatcher("/login");
			PrintWriter out= response.getWriter();
			out.println("<font color=red>Either user name or password is wrong.</font>");
			rd.include(request, response);*/
			if(request.getParameter("appName")!=null){
				if(isDebug){
					System.out.println("App Name ---+++"+request.getParameter("appName")+" Redirecting to Chat>AppName");
				}
	    	  	response.sendRedirect("/Chat?appName="+request.getParameter("appName"));
	    	  	return;
	    	  }else{
	    		  if(isDebug){
	    			  System.out.println("App Name !!!+++"+request.getParameter("appName")+" Redirecting to Chat");
	    		  }
	      	  	response.sendRedirect("/Chat");
	      	  return;

	    	  }
			//response.sendRedirect("/Chat?appName="+request.getParameter("appName"));
		}finally{
			try {
				conn.close();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
	
}