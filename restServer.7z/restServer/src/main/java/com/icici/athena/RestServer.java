package com.icici.athena;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@EnableAutoConfiguration
@SpringBootApplication
@ComponentScan(basePackages = {"com.icici.athenaRestServer","com.icici.athena"} )
public class RestServer extends SpringBootServletInitializer{
	
	public RestServer() {
        super();
        setRegisterErrorPageFilter(false); // <- this one to disable error page filteration
    }


	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		  setRegisterErrorPageFilter(false);
		return application.sources(RestServer.class);
	}
	
	public static void main(String[] args) {
		SpringApplication.run(RestServer.class, args);
	}
}

