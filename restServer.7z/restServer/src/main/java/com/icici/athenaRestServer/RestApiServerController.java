package com.icici.athenaRestServer;


import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import java.net.URLEncoder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;



import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.ParseException;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
/*import com.icici.athena.controller.ConstantController;
import com.icici.athena.controller.DatabaseController;
import com.icici.athena.controller.TNSElasticController;
import com.icici.athena.controller.UserController;
import com.icici.athena.user.User;*/

import oracle.sql.TIMESTAMP;

@Configuration
@Component
@RestController
@RequestMapping("/rest")
public class RestApiServerController {
	
	@Value("${myDebug}")
	public static boolean isDebug;

	@Value("${myDebug}")
	public void setdebug(boolean db) {
		isDebug = db;
	}
	@Value("${elasticsearch_index}")
	public static String eindex;

	@Value("${elasticsearch_index}")
	public void setElasticSearchIndex(String db) {
		eindex = db;
	}

	
	@Value("${spring.elasticsearch.jest.proxy.host}")
	public static String eserver;

	@Value("${spring.elasticsearch.jest.proxy.host}")
	public void setEserver(String db) {

		eserver = db;
	}

	@Value("${elasticsearch.tns.index}")
	public static String tnsIndex;

	@Value("${elasticsearch.tns.index}")
	public void settnsIndex(String db) {

		tnsIndex = db;
	}

	@Value("${elasticsearch_nextserver}")
	public static String nextServer;

	@Value("${elasticsearch_nextserver}")
	public void setnextServer(String db) {

		nextServer = db;
	}

	@Value("${server.port}")
	public static String port;

	@Value("${server.port}")
	public void setPort(String db) {

		port = db;
	}
	
	// Files and Images Encoder
	private static String encodeFileToBase64Binary(String fileName) throws IOException {

		File file = new File(fileName);
		boolean exists = file.exists();
		if (exists == true) {
			byte[] encoded = Base64.encode(FileUtils.readFileToByteArray(file));
			return new String(encoded, "UTF-8");
		} else {
			return null;
		}
	}

	// Elasticsearch Connection
	public String elasticConn(String body, String appName) {
		String res = null;
		HttpEntity entity = null;
		Response response = null;
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		if (appName.toUpperCase().equals("I-CORE INDIA")) {
			appName = "finacle";
		}
		try {
			response = restClient.performRequest("POST",
					"/" + eindex + "/" + appName.toLowerCase() + "/_search",
					Collections.<String, String>emptyMap(), entity);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

	// Remove StopWords
	public String removeStopWords(String query) {
		// String sbquery=new String();
		if (isDebug) {
			System.out.println("REMOVE STOPWORDS:" + query);
		}
		// added to remove stopwords

		String[] stopwords = { "able", "about", "above", "abst", "accordance", "according", "accordingly", "across",
				"act", "actually", "added", "adj", "affected", "affecting", "affects", "after", "afterwards", "again",
				"against", "ah", "all", "almost", "alone", "along", "already", "also", "although", "always", "am",
				"among", "amongst", "an", "and", "announce", "another", "any", "anybody", "anyhow", "anymore", "anyone",
				"anything", "anyway", "anyways", "anywhere", "apparently", "approximately", "are", "aren", "arent",
				"arise", "around", "as", "aside", "ask", "asking", "at", "auth", "available", "away", "awfully", "b",
				"back", "be", "became", "because", "become", "becomes", "becoming", "been", "before", "beforehand",
				"begin", "beginning", "beginnings", "begins", "behind", "being", "believe", "below", "beside",
				"besides", "between", "beyond", "biol", "both", "brief", "briefly", "but", "by", "ca", "came", "can",
				"cannot", "can't", "cause", "causes", "certain", "certainly", "co", "com", "come", "comes", "contain",
				"containing", "contains", "could", "couldnt", "d", "date", "did", "didn't", "different", "do", "does",
				"doesn't", "doing", "done", "don't", "down", "downwards", "due", "during", "e", "each", "ed", "edu",
				"effect", "eg", "eight", "eighty", "either", "else", "elsewhere", "end", "ending", "enough",
				"especially", "et", "et-al", "etc", "even", "ever", "every", "everybody", "everyone", "everything",
				"everywhere", "ex", "except", "f", "far", "few", "ff", "fifth", "first", "five", "fix", "followed",
				"following", "follows", "for", "former", "formerly", "forth", "found", "four", "from", "further",
				"furthermore", "g", "gave", "get", "gets", "getting", "give", "given", "gives", "giving", "go", "goes",
				"gone", "got", "gotten", "h", "had", "happens", "hardly", "has", "hasn't", "have", "haven't", "having",
				"he", "hed", "hence", "her", "here", "hereafter", "hereby", "herein", "heres", "hereupon", "hers",
				"herself", "hes", "hi", "hid", "him", "himself", "his", "hither", "home", "how", "howbeit", "however",
				"hundred", "i", "id", "ie", "if", "i'll", "im", "immediate", "immediately", "importance", "important",
				"in", "inc", "indeed", "index", "information", "instead", "into", "invention", "inward", "is", "isn't",
				"it", "itd", "it'll", "its", "itself", "i've", "j", "just", "k", "keep", "keeps", "kept", "kg", "km",
				"know", "known", "knows", "l", "largely", "last", "lately", "later", "latter", "latterly", "least",
				"less", "lest", "let", "lets", "like", "liked", "likely", "line", "little", "'ll", "look", "looking",
				"looks", "ltd", "m", "made", "mainly", "make", "makes", "many", "may", "maybe", "me", "mean", "means",
				"meantime", "meanwhile", "merely", "mg", "might", "million", "miss", "ml", "more", "moreover", "most",
				"mostly", "mr", "mrs", "much", "mug", "must", "my", "myself", "n", "na", "name", "namely", "nay", "nd",
				"near", "nearly", "necessarily", "necessary", "need", "needs", "neither", "never", "nevertheless",
				"new", "next", "nine", "ninety", "no", "nobody", "non", "none", "nonetheless", "noone", "nor",
				"normally", "nos", "not", "noted", "nothing", "now", "nowhere", "o", "obtain", "obtained", "obviously",
				"of", "off", "often", "oh", "ok", "okay", "old", "omitted", "on", "once", "one", "ones", "only", "onto",
				"or", "ord", "other", "others", "otherwise", "ought", "our", "ours", "ourselves", "out", "outside",
				"over", "overall", "owing", "own", "p", "page", "pages", "part", "particular", "particularly", "past",
				"per", "perhaps", "placed", "please", "plus", "poorly", "possible", "possibly", "potentially", "pp",
				"predominantly", "present", "previously", "primarily", "probably", "promptly", "proud", "provides",
				"put", "q", "que", "quickly", "quite", "qv", "r", "ran", "rather", "rd", "re", "readily", "really",
				"recent", "recently", "ref", "refs", "regarding", "regardless", "regards", "related", "relatively",
				"research", "respectively", "resulted", "resulting", "results", "right", "run", "s", "said", "same",
				"saw", "say", "saying", "says", "sec", "section", "see", "seeing", "seem", "seemed", "seeming", "seems",
				"seen", "self", "selves", "sent", "seven", "several", "shall", "she", "shed", "she'll", "shes",
				"should", "shouldn't", "show", "showed", "shown", "showns", "shows", "significant", "significantly",
				"similar", "similarly", "since", "six", "slightly", "so", "some", "somebody", "somehow", "someone",
				"somethan", "something", "sometime", "sometimes", "somewhat", "somewhere", "soon", "sorry",
				"specifically", "specified", "specify", "specifying", "still", "stop", "strongly", "sub",
				"substantially", "successfully", "such", "sufficiently", "suggest", "sup", "sure", "t", "take", "taken",
				"taking", "tell", "tends", "th", "than", "thank", "thanks", "thanx", "that", "that'll", "thats",
				"that've", "the", "their", "theirs", "them", "themselves", "then", "thence", "there", "thereafter",
				"thereby", "thered", "therefore", "therein", "there'll", "thereof", "therere", "theres", "thereto",
				"thereupon", "there've", "these", "they", "theyd", "they'll", "theyre", "they've", "think", "this",
				"those", "thou", "though", "thoughh", "thousand", "throug", "through", "throughout", "thru", "thus",
				"til", "tip", "to", "together", "too", "took", "toward", "towards", "tried", "tries", "truly", "try",
				"trying", "ts", "twice", "two", "u", "un", "unable", "under", "unfortunately", "unless", "unlike",
				"unlikely", "until", "unto", "up", "upon", "ups", "us", "use", "used", "useful", "usefully",
				"usefulness", "uses", "using", "usually", "v", "value", "various", "'ve", "very", "via", "viz", "vol",
				"vols", "vs", "w", "want", "wants", "was", "wasn't", "way", "we", "wed", "welcome", "we'll", "went",
				"were", "weren't", "we've", "what", "whatever", "what'll", "whats", "when", "whence", "whenever",
				"where", "whereafter", "whereas", "whereby", "wherein", "wheres", "whereupon", "wherever", "whether",
				"which", "while", "whim", "whither", "who", "whod", "whoever", "whole", "who'll", "whom", "whomever",
				"whos", "whose", "why", "widely", "willing", "wish", "with", "within", "without", "won't", "words",
				"world", "would", "wouldn't", "www", "x", "y", "yes", "yet", "you", "youd", "you'll", "your", "youre",
				"yours", "yourself", "yourselves", "you've", "z", "zero" };
		HashMap<String, String> stopMap = new HashMap<String, String>();
		for (String e : stopwords) {
			stopMap.put(e, "true".toString());
		}

		ArrayList<String> arrq = new ArrayList<String>(Arrays.asList(query.split(" ")));
		String optimizedQ = "";
		for (String temp : arrq) {
			if (stopMap.containsKey((temp.toLowerCase())) && stopMap.get(temp.toLowerCase()).equals("true")) {

			} else {
				optimizedQ += temp.trim() + " ";
			}
		}

		query = new String(optimizedQ);
		if (isDebug) {
			System.out.println("REMOVEd STOPWORDS QUERY:" + query);
		}
		return query;
	}

	@RequestMapping(value = "/getValue", method = RequestMethod.POST)
	@ResponseBody
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<Object> restServerGetValue(@RequestBody(required = false) String RestRequest)
			throws IOException {
		System.out.println("-------------" + RestRequest);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		JsonObject errorMsg = new JsonObject();

		JsonParser parser = new JsonParser();
		JsonObject jsonObj = parser.parse(RestRequest).getAsJsonObject();
		String appName = jsonObj.get("appname").getAsString();
		if (appName.toUpperCase().equals("I-CORE INDIA")) {
			appName = "finacle";
		}
		String query = jsonObj.get("query").getAsString();
		appName = URLEncoder.encode(appName, "UTF-8");
		String body = "";
		String result = null;

		int wordCount = query.trim().split(" ").length;
		int resultSize = 0;

		query = query.toLowerCase();

		if (isDebug) {
			System.out.println("No. of words queried-------------" + wordCount);
		}

		////////////////////////////////////////////////////////////////// With AND
		////////////////////////////////////////////////////////////////// operator

		if (wordCount == 1) {
			body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
					+ query + "\",\"fuzziness\":\"1\"}}}";
		} else {
			body = "{ \"size\":5, \"query\": {\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\": \""
					+ query + "\", \"fuzziness\": \"1\" ,\"operator\":\"and\"} } } ";
		}
		if (isDebug) {
			System.out.println("*********************Without Synonyms ************************" + body);
		}

		result = elasticConn(body, appName);
		if (isDebug) {
			System.out.println("\n Query: " + query
					+ "\n Result with fuzziness 1 and operator = 'AND' and without synonyms : " + result);
		}
		//////////////////////////////////////////////////////////////////////

		resultSize = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray()
				.size();
		if (isDebug) {
			System.out.println("\nResultSize()-" + resultSize);
		}
		/////////////////////////////////////////////////////////////// With Synonym
		if (resultSize == 0) {
			if (wordCount == 1) {
				body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
						+ query + "\",\"fuzziness\":\"1\",\"analyzer\":\"synonym\"}}}";
			} else {
				body = "{ \"size\":5, \"query\": {\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\": \""
						+ query + "\", \"fuzziness\": \"1\" ,\"operator\":\"and\", \"analyzer\":\"synonym\"} } } ";

			}
			if (isDebug) {
				System.out.println("*********************************************" + body);
			}

			result = elasticConn(body, appName);

			if (isDebug) {
				System.out.println("\n Query: " + query
						+ "\n Result with fuzziness 1 and operator = 'AND' and synonyms : " + result);
			}

		}

		/////////////////////////////////////////////////////////////////////// Without
		/////////////////////////////////////////////////////////////////////// And
		/////////////////////////////////////////////////////////////////////// Operator
		/////////////////////////////////////////////////////////////////////// for
		/////////////////////////////////////////////////////////////////////// Enter
		/////////////////////////////////////////////////////////////////////// Key
		resultSize = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray()
				.size();
		if (isDebug) {
			System.out.println("\nResultSize1()-" + resultSize);
		}
		if (resultSize == 0) {
			query = removeStopWords(query);
			wordCount = query.trim().split(" ").length;
			if (isDebug) {
				System.out.println("No. of words queried-------------" + wordCount);
			}
			if (wordCount == 1) {
				body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
						+ query + "\",\"fuzziness\":\"1\",\"analyzer\":\"synonym\"}}}";

			} else {
				body = "{ \"size\":5, \"query\": {\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\": \""
						+ query + "\", \"fuzziness\": \"1\" , \"operator\":\"and\", \"analyzer\":\"synonym\"} } } ";

			}
			if (isDebug) {
				System.out.println("----------------------------------------" + body);
			}

			result = elasticConn(body, appName);

			if (isDebug) {
				System.out.println(
						"\n Query: " + query + "\n Result with fuzziness 1 but without operator = 'AND' :" + result);
			}
		}
		////////////////////////////////////////////////////////////////////////////// Without
		////////////////////////////////////////////////////////////////////////////// And
		////////////////////////////////////////////////////////////////////////////// Operator
		////////////////////////////////////////////////////////////////////////////// for
		////////////////////////////////////////////////////////////////////////////// Enter
		////////////////////////////////////////////////////////////////////////////// Key
		resultSize = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray()
				.size();
		if (isDebug) {
			System.out.println("\nResultSize2()-" + resultSize);
		}
		if (resultSize == 0) {
			query = removeStopWords(query);
			wordCount = query.trim().split(" ").length;
			if (isDebug) {
				System.out.println("No. of words queried-------------" + wordCount);
			}
			if (wordCount == 1) {
				body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
						+ query + "\",\"fuzziness\":\"2\",\"analyzer\":\"synonym\"}}}";

			} else {
				body = "{ \"size\":5, \"query\": {\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\": \""
						+ query + "\", \"fuzziness\": \"2\" , \"analyzer\":\"synonym\"} } } ";

			}
			if (isDebug) {
				System.out.println("----------------------------------------" + body);
			}

			result = elasticConn(body, appName);
		}
		if (isDebug) {
			System.out.println("\n Query: " + query + "\n Result: " + result);
		}
		if (isDebug) {
			System.out.println(
					"\n Query: " + query + "\n Result with fuzziness auto but without operator = 'or' and  :" + result);
		}

		resultSize = parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray()
				.size();
		if (isDebug) {
			System.out.println("\nResultSize3()-" + resultSize);
		}

		JsonObject jsonResult = parser.parse(result).getAsJsonObject();
		JsonArray jsonResArr = jsonResult.get("hits").getAsJsonObject().get("hits").getAsJsonArray();
		System.out.println("Hits only -- " + jsonResArr.toString());
		int jsonSize = jsonResArr.size();
		for (int i = 0; i < jsonSize; i++) {
			// JsonObject data = new JsonObject();
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("file")) {
				JsonArray fileArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("file")
						.getAsJsonArray();
				JsonArray filePathArr = new JsonArray();
				int fileListSize = fileArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					if (isDebug) {
						System.out.println("file path : " + fileArray.get(j).getAsString());
					}
					try {
						encodedFile = encodeFileToBase64Binary(fileArray.get(j).getAsString());
					} catch (IOException e) {
						if (isDebug) {
							System.out.println("Problem in file encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// fileArray.remove(j);
					filePathArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("file");
				jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().add("file_data", filePathArr);
			}
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("image")) {
				JsonArray imageArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("image")
						.getAsJsonArray();
				JsonArray imagePathArr = new JsonArray();
				int fileListSize = imageArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					if (isDebug) {
						System.out.println("image path : " + imageArray.get(j).getAsString());
					}
					try {
						encodedFile = encodeFileToBase64Binary(imageArray.get(j).getAsString());
					} catch (IOException e) {
						System.out.println("Problem in image encoding");
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// imageArray.remove(j);
					imagePathArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("image");
				jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().add("image_data", imagePathArr);
			}
			// res.add("" + i + "", data);
		}
		// System.out.println("res-------" + res);
		if (isDebug) {
			System.out.println("result-------" + jsonResult.toString());
			System.out.println("result" + result);
		}
		result = jsonResult.toString();

		// Response restResponse = new Response();
		return new ResponseEntity<Object>(result, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/searchQuery", method = RequestMethod.POST)
	@ResponseBody
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<Object> restServerSearchQuery(@RequestBody String RestRequest) throws IOException {

		JsonParser parser = new JsonParser();
		JsonObject jsonObj = parser.parse(RestRequest).getAsJsonObject();
		String appName = jsonObj.get("appname").getAsString();
		if (appName.toUpperCase().equals("I-CORE INDIA")) {
			appName = "finacle";
		}
		String query = jsonObj.get("query").getAsString();

		appName = URLEncoder.encode(appName, "UTF-8");
		String body = "";
		int wordCount = 0;
		// LowerCase query
		query = query.toLowerCase();
		query = removeStopWords(query);
		String result = "";

		// query=removeStopWords(query);
		wordCount = query.trim().split(" ").length;

		if (isDebug) {
			System.out.println("No. of words queried search Query-------------" + wordCount);
		}
		if (wordCount == 1) {
			body = "{\"size\": 5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
					+ query + "\",\"fuzziness\":\"auto\",\"analyzer\":\"synonym\"}}}";

		} else {
			body = "{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
					+ query
					+ "\",\"tie_breaker\":0.1,\"minimum_should_match\":\"30%\",\"fuzziness\":\"auto\",\"analyzer\":\"synonym\"}}}";
		}

		result = elasticConn(body, appName);

		// 5 suggestions must
		if (isDebug) {
			System.out.println("No. of results --------" + parser.parse(result).getAsJsonObject().get("hits")
					.getAsJsonObject().get("hits").getAsJsonArray().size());
		}
		if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray()
				.size() < 5) {
			body = "{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
					+ query + "\",\"tie_breaker\":0.1,\"minimum_should_match\":\"30%\",\"analyzer\":\"synonym\"}}}";

			result = elasticConn(body, appName);
			if (isDebug) {
				System.out.println("Inside first -if No. of results --------" + parser.parse(result).getAsJsonObject()
						.get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
			}
			if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray()
					.size() < 5) {
				body = "{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
						+ query + "\",\"tie_breaker\":0.1,\"minimum_should_match\":\"30%\"}}}";

				result = elasticConn(body, appName);
				if (isDebug) {
					System.out.println("Inside second -if No. of results --------" + parser.parse(result)
							.getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
				}
				if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray()
						.size() < 5) {
					body = "{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
							+ query + "\",\"tie_breaker\":0.1}}}";

					result = elasticConn(body, appName);
					if (isDebug) {
						System.out.println("Inside third -if No. of results --------" + parser.parse(result)
								.getAsJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
					}
					if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits")
							.getAsJsonArray().size() < 5) {
						body = "{\"size\":5,\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""
								+ query + "\",\"operator\":\"OR\"}}}";

						result = elasticConn(body, appName);
						if (isDebug) {
							System.out.println(
									"Inside fourth -if No. of results --------" + parser.parse(result).getAsJsonObject()
											.get("hits").getAsJsonObject().get("hits").getAsJsonArray().size());
						}
					}
					if (parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits")
							.getAsJsonArray().size() < 5) {
						body = "{\"size\":5,\"query\":{\"match\":{\"_all\":{\"query\":\"" + query
								+ "\",\"operator\":\"AND\"}}}}";

						result = elasticConn(body, appName);
						if (isDebug) {
							System.out.println("Inside fifth -if() No. of results --------"
									+ parser.parse(result).getAsJsonObject().get("hits").getAsJsonObject().get("hits")
											.getAsJsonArray().size());
						}
					}
				}
			}
		}

		if (isDebug) {
			System.out.println("\nBody:" + body + "\n Query: " + query + "\n Result: " + result);
		}

		// JsonObject res = new JsonObject();
		JsonObject jsonResult = parser.parse(result).getAsJsonObject();
		JsonArray jsonResArr = jsonResult.get("hits").getAsJsonObject().get("hits").getAsJsonArray();
		if (isDebug) {
			System.out.println("Hits only -- " + jsonResArr.toString());
		}
		int jsonSize = jsonResArr.size();
		for (int i = 0; i < jsonSize; i++) {
			// JsonObject data = new JsonObject();
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("file")) {
				JsonArray fileArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("file")
						.getAsJsonArray();
				JsonArray filePathArr = new JsonArray();
				int fileListSize = fileArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					if (isDebug) {
						System.out.println("file path : " + fileArray.get(j).getAsString());
					}
					try {
						encodedFile = encodeFileToBase64Binary(fileArray.get(j).getAsString());
					} catch (IOException e) {
						if (isDebug) {
							System.out.println("Problem in file encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// fileArray.remove(j);
					filePathArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("file");
				jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().add("file_data", filePathArr);
			}
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("image")) {
				JsonArray imageArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("image")
						.getAsJsonArray();
				JsonArray imagePathArr = new JsonArray();
				int fileListSize = imageArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					if (isDebug) {
						System.out.println("image path : " + imageArray.get(j).getAsString());
					}
					try {
						encodedFile = encodeFileToBase64Binary(imageArray.get(j).getAsString());
					} catch (IOException e) {
						if (isDebug) {
							System.out.println("Problem in image encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// imageArray.remove(j);
					imagePathArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("image");
				jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().add("image_data", imagePathArr);
			}
			// res.add("" + i + "", data);
		}
		// System.out.println("res-------" + res);
		if (isDebug) {
			System.out.println("result-------" + result);
		}
		result = jsonResult.toString();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		return new ResponseEntity<Object>(result, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/suggestWords", method = RequestMethod.GET)
	public ResponseEntity<Object> restServerSuggestWords(
			@RequestParam(value = "appname", required = false) String appName,
			@RequestParam(value = "word", required = false) String word) throws IOException {

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");

		if (appName == null) {
			appName = "";
		}

		if (appName.toUpperCase().equals("I-CORE INDIA")) {
			appName = "finacle";
		}
		JsonObject errorMsg = new JsonObject();
		if (word == null || word.length() == 0) {
			errorMsg.addProperty("exception", "No word Passed through URL");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		appName = URLEncoder.encode(appName, "UTF-8");
		String body = "{ \"suggest\" : { \"suggestwords\" : { \"text\" : \"" + word
				+ "\",\"term\" : { \"field\" : \"_all\"}}}}";
		String result = elasticConn(body, appName);
		if (isDebug) {
			System.out.println(result);
		}
		JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject) jsonParser.parse(result);
		String answer = "";
		JsonObject jobj = (JsonObject) jo.get("suggest");
		JsonArray jarr = (JsonArray) jobj.get("suggestwords");
		if (jarr.size() > 0) {
			jobj = (JsonObject) jarr.get(0);
			jarr = (JsonArray) jobj.get("options");
			return new ResponseEntity<Object>(jarr.toString(), headers, HttpStatus.OK);
		}

		return new ResponseEntity<Object>(answer, headers, HttpStatus.OK);
	}

	//// Get All Data
	@RequestMapping(value = "/allData", method = RequestMethod.GET)
	public ResponseEntity<Object> restServerloadAllData(
			@RequestParam(value = "appname", required = false) String appName) throws IOException {

		JsonParser parser = new JsonParser();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");

		JsonObject errorMsg = new JsonObject();

		if (appName == null || appName.length() == 0) {
			errorMsg.addProperty("exception", "No application name Passed through URL");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}

		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();

		String body = "";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);

		if (appName.toUpperCase().equals("I-CORE INDIA")) {
			appName = "finacle";
		}
		appName = URLEncoder.encode(appName, "UTF-8");
		Response response = restClient.performRequest("GET",
				"/" + eindex + "/" + appName + "/_count", Collections.<String, String>emptyMap(),
				entity);

		String result = EntityUtils.toString(response.getEntity());

		int datasize = parser.parse(result).getAsJsonObject().get("count").getAsInt();
		if (isDebug) {
			System.out.println("count -- " + datasize);
		}
		response = restClient.performRequest("GET",
				"/" + eindex + "/" + appName + "/_search?size=" + datasize,
				Collections.<String, String>emptyMap(), entity);
		result = EntityUtils.toString(response.getEntity());

		if (isDebug) {
			System.out.println("result -- " + result);
		}

		JsonArray res = new JsonArray();
		JsonObject jsonResult = parser.parse(result).getAsJsonObject();
		JsonArray jsonResArr = jsonResult.get("hits").getAsJsonObject().get("hits").getAsJsonArray();

		int jsonSize = jsonResArr.size();
		for (int i = 0; i < jsonSize; i++) {
			JsonObject data = new JsonObject();
			if (jsonResArr.get(i).getAsJsonObject().get("_type").getAsString().toLowerCase().equals("finacle")) {
				data.addProperty("app_name", "i-core india");
			} else {
				data.addProperty("app_name", jsonResArr.get(i).getAsJsonObject().get("_type").getAsString());
			}
			data.addProperty("que_id", jsonResArr.get(i).getAsJsonObject().get("_id").getAsString());
			data.add("data", jsonResArr.get(i).getAsJsonObject().get("_source"));
			if (data.get("data").getAsJsonObject().has("file")) {
				JsonArray fileArray = data.get("data").getAsJsonObject().get("file").getAsJsonArray();
				JsonArray fileDataArr = new JsonArray();
				int fileListSize = fileArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());

					try {
						encodedFile = encodeFileToBase64Binary(fileArray.get(j).getAsString());
					} catch (Exception e) {
						if (isDebug) {
							encodedFile = null;
							System.out.println("Problem in file encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// fileArray.remove(j);
					fileDataArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("file");
				data.get("data").getAsJsonObject().add("file_data", fileDataArr);
			}
			if (data.get("data").getAsJsonObject().has("image")) {
				JsonArray imageArray = data.get("data").getAsJsonObject().get("image").getAsJsonArray();
				int fileListSize = imageArray.size();
				JsonArray imageDataArr = new JsonArray();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());

					try {
						encodedFile = encodeFileToBase64Binary(imageArray.get(j).getAsString());
					} catch (Exception e) {
						if (isDebug) {
							encodedFile = null;
							System.out.println("Problem in image encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// imageArray.remove(j);
					imageDataArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("image");
				data.get("data").getAsJsonObject().add("image_data", imageDataArr);
			}
			res.add(data);
		}
		if (isDebug) {
			System.out.println("res-------" + res);
		}

		restClient.close();
		return new ResponseEntity<Object>(res.toString(), headers, HttpStatus.OK);
	}

	// Get All Data for Chatbot
	@RequestMapping(value = "/showData", method = RequestMethod.GET)
	public ResponseEntity<Object> showResources(@RequestParam("appname") String appName) throws IOException {

		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		JsonParser parser = new JsonParser();
		String body = "";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		appName = URLEncoder.encode(appName, "UTF-8");
		Response response = restClient.performRequest("GET",
				"/" + eindex + "/" + appName + "/_count", Collections.<String, String>emptyMap(),
				entity);
		String result = EntityUtils.toString(response.getEntity());
		int datasize = parser.parse(result).getAsJsonObject().get("count").getAsInt();
		response = restClient.performRequest("GET",
				"/" + eindex + "/" + appName + "/_search?size=" + datasize,
				Collections.<String, String>emptyMap(), entity);
		result = EntityUtils.toString(response.getEntity());
		restClient.close();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		return new ResponseEntity<Object>(result, headers, HttpStatus.OK);
	}

	// Search Query
	@RequestMapping(value = "/searchString", method = RequestMethod.POST)
	@ResponseBody
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<Object> restServerSearchQ(@RequestBody String RestRequest, HttpServletRequest request) {
		if (isDebug) {
			System.out.println("searchQ-------------" + RestRequest);
		}

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");

		String result = "";
		int size = 5;
		// Boolean EnableSynonym = false;
		String TieBraker = "";
		// Boolean EnableStopwords = false;
		// String Fuzzy = "";
		String appName = "";
		String query = "";
		String body = "";
		// String operator = "";
		// Boolean SearchAllFields = false;

		// String RestRequest="{\"appName\":\"fatca\",\"query\":\"fatca\"}";
		JsonParser parser = new JsonParser();
		JsonObject errorMsg = new JsonObject();
		JsonObject jsonObj = parser.parse(RestRequest).getAsJsonObject();
		if (jsonObj.has("appname") && jsonObj.has("query")) {
			if (jsonObj.get("appname").isJsonNull()) {
				errorMsg.addProperty("exception", "Application name is null in request");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
			}
			if (jsonObj.get("query").isJsonNull()) {
				errorMsg.addProperty("exception", "query is null in request");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
			}
			appName = jsonObj.get("appname").getAsString();
			if (appName.toUpperCase().equals("I-CORE INDIA")) {
				appName = "finacle";
			}
			query = jsonObj.get("query").getAsString();
			if (appName == null || appName.length() == 0) {
				errorMsg.addProperty("exception", "Application name not found in request");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
			}
			if (query == null || query.length() == 0) {
				errorMsg.addProperty("exception", "Query not found in request");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
			}
			body = "{\"size\":" + size
					+ ",\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\"" + query
					+ "\"}}}";
		} else {

			errorMsg.addProperty("exception", "Application name or Query not found in request");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
		}
		if (jsonObj.has("size")) {
			size = jsonObj.get("size").getAsInt();
			body = "{\"size\":" + size
					+ ",\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\"" + query
					+ "\"}}}";
		}
		String bodyFirst = "{\"size\":" + size
				+ ",\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\"" + query + "\"";
		String bodyLast = "}}}";
		String bodyParams = "";

		if (jsonObj.has("enable-synonym") && jsonObj.get("enable-synonym").getAsBoolean() == true) {
			bodyParams = bodyParams + ",\"analyzer\":\"synonym\"";
		}
		if (jsonObj.has("tie-braker")) {
			TieBraker = jsonObj.get("tie-braker").getAsString();
			bodyParams = bodyParams + ",\"tie_breaker\":" + TieBraker + "";
		}
		if (jsonObj.has("minimum-should-match")) {
			String minmatch = jsonObj.get("minimum_should_match").getAsString();
			bodyParams = bodyParams + ",\"minimum_should_match\":\"" + minmatch + "\"";
		}
		if (jsonObj.has("fuzzy")) {
			bodyParams = bodyParams + ",\"fuzziness\":\"" + jsonObj.get("fuzzy").getAsString() + "\"";
		}
		if (jsonObj.has("operator")) {
			bodyParams = bodyParams + ",\"operator\":\"" + jsonObj.get("operator").getAsString().toUpperCase() + "\"";
		}
		if (jsonObj.has("enable-stopwords") && jsonObj.get("enable-stopwords").getAsBoolean() == true) {
			query = removeStopWords(query);
			// body
			// ="{\"size\":"+size+",\"query\":{\"multi_match\":{\"fields\":[\"question\",\"variation\"],\"query\":\""+query+"\"}}}";
		}
		body = bodyFirst + bodyParams + bodyLast;
		if (jsonObj.has("search-all-fields") && jsonObj.get("search-all-fields").getAsBoolean() == true) {
			query = removeStopWords(query);
			body = "{\"size\":" + size + ",\"query\":{\"match\":{\"_all\":{\"query\":\"" + query + "\"" + bodyParams
					+ "}}}}";
		}

		if (isDebug) {
			System.out.println("body********" + body);
		}
		try {
			if (isDebug) {
				System.out.println("app name -----" + appName);
			}
			result = elasticConn(body, URLEncoder.encode(appName.toLowerCase(), "UTF-8"));
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JsonArray res = new JsonArray();
		JsonObject jsonResult = parser.parse(result).getAsJsonObject();
		JsonArray jsonResArr = jsonResult.get("hits").getAsJsonObject().get("hits").getAsJsonArray();
		if (isDebug) {
			System.out.println("Hits only -- " + jsonResArr.toString());
		}
		int jsonSize = jsonResArr.size();
		for (int i = 0; i < jsonSize; i++) {
			JsonObject data = new JsonObject();
			if (isDebug) {
				System.out.println(jsonResArr.get(i).toString());
			}
			if (isDebug) {
				System.out.println(jsonResArr.get(i).getAsJsonObject().get("_type").getAsString());
			}
			if (jsonResArr.get(i).getAsJsonObject().get("_type").getAsString().toLowerCase().equals("finacle")) {
				data.addProperty("app_name", "i-core india");
			} else {
				data.addProperty("app_name", jsonResArr.get(i).getAsJsonObject().get("_type").getAsString());
			}
			data.addProperty("que_id", jsonResArr.get(i).getAsJsonObject().get("_id").getAsString());
			data.add("data", jsonResArr.get(i).getAsJsonObject().get("_source"));
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("file")) {
				JsonArray fileArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("file")
						.getAsJsonArray();
				JsonArray fileDataArr = new JsonArray();
				int fileListSize = fileArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					if (isDebug) {
						System.out.println("file path : " + fileArray.get(j).getAsString());
					}
					try {
						encodedFile = encodeFileToBase64Binary(fileArray.get(j).getAsString());
					} catch (IOException e) {
						if (isDebug) {
							System.out.println("Problem in file encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// fileArray.remove(j);
					fileDataArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("file");
				// data.get("data").getAsJsonObject().add("file-path", fileArray);
				data.get("data").getAsJsonObject().add("file_data", fileDataArr);
			}
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("image")) {
				JsonArray imageArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("image")
						.getAsJsonArray();
				JsonArray imageDataArr = new JsonArray();
				int fileListSize = imageArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					if (isDebug) {
						System.out.println("image path : " + imageArray.get(j).getAsString());
					}
					try {
						encodedFile = encodeFileToBase64Binary(imageArray.get(j).getAsString());
					} catch (IOException e) {
						if (isDebug) {
							System.out.println("Problem in image encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// imageArray.remove(j);
					imageDataArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("image");
				// data.get("data").getAsJsonObject().add("image-path", imageArray);
				data.get("data").getAsJsonObject().add("image_data", imageDataArr);
			}
			res.add(data);
		}
		if (isDebug) {
			System.out.println("res-------" + res);
		}
		if (isDebug) {
			System.out.println("result-------" + result);
		}

		return new ResponseEntity<Object>(res.toString(), headers, HttpStatus.OK);
	}

	// Search By Id
	@RequestMapping(value = "/searchById", method = RequestMethod.GET)
	public ResponseEntity<Object> restServerGetSearchDataById(
			@RequestParam(value = "appname", required = false) String appName,
			@RequestParam(value = "id", required = false) String id) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		JsonObject errorMsg = new JsonObject();
		if (appName == null || appName.length() == 0) {
			errorMsg.addProperty("exception", "Application Name Not found in URL");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		if (id == null || id.length() == 0) {
			errorMsg.addProperty("exception", "Question Id Not found in URL");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		if (appName.toLowerCase().equals("i-core india")) {
			appName = "finacle";
		}
		appName = URLEncoder.encode(appName, "UTF-8");
		JsonParser parser = new JsonParser();
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		// String body="";
		String body = "{\"query\": {\"terms\": {\"_id\":  [\"" + id + "\"]}}}";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		if (isDebug) {
			System.out.println("appname : ::::::::::" + appName);
		}
		Response response = restClient.performRequest("GET",
				"/" + eindex + "/" + appName + "/_search", Collections.<String, String>emptyMap(),
				entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		JsonArray res = new JsonArray();
		JsonObject jsonResult = parser.parse(result).getAsJsonObject();

		JsonArray jsonResArr = jsonResult.get("hits").getAsJsonObject().get("hits").getAsJsonArray();
		if (isDebug) {
			System.out.println("Hits only -- " + jsonResArr.toString());
		}
		int jsonSize = jsonResArr.size();
		for (int i = 0; i < jsonSize; i++) {
			JsonObject data = new JsonObject();
			if (isDebug) {
				System.out.println(jsonResArr.get(i).toString());
			}
			if (isDebug) {
				System.out.println(jsonResArr.get(i).getAsJsonObject().get("_type").getAsString());
			}
			if (jsonResArr.get(i).getAsJsonObject().get("_type").getAsString().toLowerCase().equals("finacle")) {
				data.addProperty("app_name", "i-core india");
			} else {
				data.addProperty("app_name", jsonResArr.get(i).getAsJsonObject().get("_type").getAsString());
			}
			data.addProperty("que_id", jsonResArr.get(i).getAsJsonObject().get("_id").getAsString());
			data.add("data", jsonResArr.get(i).getAsJsonObject().get("_source"));
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("file")) {
				JsonArray fileArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("file")
						.getAsJsonArray();
				int fileListSize = fileArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					System.out.println("file path : " + fileArray.get(j).getAsString());
					try {
						encodedFile = encodeFileToBase64Binary(fileArray.get(j).getAsString());
					} catch (IOException e) {
						System.out.println("Problem in file encoding");
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					fileArray.remove(j);
					fileArray.add(encodedFile);
				}
				data.get("data").getAsJsonObject().remove("file");
				data.get("data").getAsJsonObject().add("file", fileArray);
			}
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("image")) {
				JsonArray imageArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("image")
						.getAsJsonArray();
				int fileListSize = imageArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					if (isDebug) {
						System.out.println("image path : " + imageArray.get(j).getAsString());
					}
					try {
						encodedFile = encodeFileToBase64Binary(imageArray.get(j).getAsString());
					} catch (IOException e) {
						if (isDebug) {
							System.out.println("Problem in image encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					imageArray.remove(j);
					imageArray.add(encodedFile);
				}
				data.get("data").getAsJsonObject().remove("image");
				data.get("data").getAsJsonObject().add("image", imageArray);
			}
			res.add(data);
		}
		if (isDebug) {
			System.out.println("res-------" + res);
		}
		if (isDebug) {
			System.out.println("result-------" + result);
		}

		return new ResponseEntity<Object>(res.toString(), headers, HttpStatus.OK);
		// return new ResponseEntity<Object>(result,HttpStatus.OK);
	}

	// Search Data by id for chatbot
	@RequestMapping(value = "/searchData", method = RequestMethod.GET)
	public ResponseEntity<Object> restServerGetSearchData(
			@RequestParam(value = "appname", required = false) String appName,
			@RequestParam(value = "id", required = false) String id) throws IOException {

		JsonParser parser = new JsonParser();
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");

		appName = URLEncoder.encode(appName, "UTF-8");
		String body = "{\"query\": {\"terms\": {\"_id\":  [\"" + id + "\"]}}}";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		if (isDebug) {
			System.out.println("appname : ::::::::::" + appName);
		}
		Response response = restClient.performRequest("POST",
				"/" + eindex + "/" + appName + "/_search?size=10",
				Collections.<String, String>emptyMap(), entity);
		String result = EntityUtils.toString(response.getEntity());
		restClient.close();
		JsonObject jsonResult = parser.parse(result).getAsJsonObject();
		JsonArray jsonResArr = jsonResult.get("hits").getAsJsonObject().get("hits").getAsJsonArray();
		if (isDebug) {
			System.out.println("Hits only -- " + jsonResArr.toString());
		}
		int jsonSize = jsonResArr.size();
		for (int i = 0; i < jsonSize; i++) {
			// JsonObject data = new JsonObject();
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("file")) {
				JsonArray fileArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("file")
						.getAsJsonArray();
				JsonArray filePathArr = new JsonArray();
				int fileListSize = fileArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					if (isDebug) {
						System.out.println("file path : " + fileArray.get(j).getAsString());
					}
					try {
						encodedFile = encodeFileToBase64Binary(fileArray.get(j).getAsString());
					} catch (IOException e) {
						if (isDebug) {
							System.out.println("Problem in file encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// fileArray.remove(j);
					filePathArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("file");
				jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().add("file_data", filePathArr);
			}
			if (jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().has("image")) {
				JsonArray imageArray = jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().get("image")
						.getAsJsonArray();
				JsonArray imagePathArr = new JsonArray();
				int fileListSize = imageArray.size();
				for (int j = 0; j < fileListSize; j++) {
					String encodedFile = null;
					// File file = new File(fileArray.get(j).getAsString());
					if (isDebug) {
						System.out.println("image path : " + imageArray.get(j).getAsString());
					}
					try {
						encodedFile = encodeFileToBase64Binary(imageArray.get(j).getAsString());
					} catch (IOException e) {
						if (isDebug) {
							System.out.println("Problem in image encoding");
						}
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// imageArray.remove(j);
					imagePathArr.add(encodedFile);
				}
				// data.get("data").getAsJsonObject().remove("image");
				jsonResArr.get(i).getAsJsonObject().get("_source").getAsJsonObject().add("image_data", imagePathArr);
			}
			// res.add("" + i + "", data);
		}
		// System.out.println("res-------" + res);
		if (isDebug) {
			System.out.println("result-------" + result);
			System.out.println(jsonResult.toString());
		}
		result = jsonResult.toString();

		return new ResponseEntity<Object>(jsonResult.toString(), headers, HttpStatus.OK);
	}

	/*// Get Welcome Message
	@RequestMapping(value = "/getWelcomeMessage", method = RequestMethod.GET)
	public ResponseEntity<Object> restServerGetWelcomeMessage(
			@RequestParam(value = "appname", required = false) String appname) throws IOException {
		if (isDebug) {
			System.out.println("appname----" + appname);
		}

		String result = "";
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");

		JsonObject errorMsg = new JsonObject();
		if (appname == null || appname.length() == 0) {
			errorMsg.addProperty("exception", "Application name not found in URL");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		appname = URLDecoder.decode(appname, "UTF-8");
		if (isDebug) {
			System.out.println("appname----" + appname);
		}
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JsonObject res = new JsonObject();
		if (isDebug) {
			System.out.println("App Name---" + appname);
		}
		res.addProperty("app_name", appname);
		if (connection != null) {
			if (isDebug) {
				System.out.println("You made it, take control of your database now!");
			}

			try {
				pstmt = null;
				String sql = "SELECT APP_WELCOME_MSG FROM " + userAppPropTable
						+ " WHERE UPPER(app_name)=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, appname.toUpperCase());

				rs = pstmt.executeQuery();

				while (rs.next()) {

					result = rs.getString("app_welcome_msg");
				}
				res.addProperty("welcome-msg", result);
				if (result.length() == 0) {
					if (isDebug) {
						System.out.println("There is no Welcome Message for this application.");
					}
					connection.close();
					return new ResponseEntity<Object>(res.toString(), headers, HttpStatus.OK);
				}
				connection.close();
				return new ResponseEntity<Object>(res.toString(), HttpStatus.OK);
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("error in stmt creation");
				}
				e.printStackTrace();
				return new ResponseEntity<Object>(res.toString(), headers, HttpStatus.OK);
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			if (isDebug) {
				System.out.println("Failed to make connection!");
			}

			return new ResponseEntity<Object>(res.toString(), headers, HttpStatus.OK);
		}

	}

	// TnsExistChecking
	@RequestMapping(value = "/appTnsExist", method = RequestMethod.POST)
	@ResponseBody
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<Object> restServerAppTnsExist(@RequestBody(required = false) String restRequest) {
		// System.out.println("appTnsExist::"+myappid);
		if (isDebug) {
			System.out.println("Request body :: " + restRequest);
		}
		String result = "";
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String myappid = "";
		String myappname = "";
		JsonObject errorMsg = new JsonObject();
		JsonParser parser = new JsonParser();

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");

		JsonObject requestBody = parser.parse(restRequest).getAsJsonObject();
		if (requestBody.has("app_id")) {
			myappid = requestBody.get("app_id").getAsString();
		} else {
			if (requestBody.has("appname")) {
				myappname = requestBody.get("appname").getAsString();
				if (myappname.toUpperCase().equals("I-CORE INDIA")) {
					myappname = "finacle";
				}
				if (connection != null) {
					if (isDebug) {
						System.out.println("You made it, take control of your database now!");
					}

					try {
						pstmt = null;
						String sql = "SELECT app_id FROM " + userAppTable
								+ " WHERE UPPER(app_name)=?";
						pstmt = connection.prepareStatement(sql);
						pstmt.setString(1, myappname.toUpperCase());

						rs = pstmt.executeQuery();

						while (rs.next()) {

							result = rs.getString("app_id");
						}
						myappid = result;
						if (result.length() == 0) {
							if (isDebug) {
								System.out.println("There is no app of this name.");
							}
							errorMsg.addProperty("exception", "There is no app of this name.");
							connection.close();
							return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
						}
						connection.close();
						// return new ResponseEntity<Object>(res.toString(), HttpStatus.OK);
					} catch (Exception e) {
						if (isDebug) {
							System.out.println("error in stmt creation");
						}
						errorMsg.addProperty("exception", e.getMessage());
						e.printStackTrace();
						return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);

						// return new ResponseEntity<Object>(res.toString(),headers, HttpStatus.OK);
					} finally {
						try {
							if (rs != null)
								rs.close();
							if (pstmt != null)
								pstmt.close();
							if (connection != null)
								connection.close();
						} catch (SQLException e) {

							e.printStackTrace();
						}
					}
				} else {
					if (isDebug) {
						System.out.println("Failed to make connection!");
					}

					errorMsg.addProperty("exception", "Failed to Make Connection to Source !!!");
					return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);

				}
			} else {
				errorMsg.addProperty("exception", "App Name or App id not found");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
			}
		}

		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();

		String body = "";
		String res = "";
		// int cnt = 0;

		JsonObject resultStr = new JsonObject();

		// body = "";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		// appName=URLEncoder.encode(appName, "UTF-8");
		Response response = null;
		try {
			// res = EntityUtils.toString(restClient.performRequest("GET",
			// "/sql-parameters/tns/"+myappid.toLowerCase()+"/", Collections.<String,
			// String>emptyMap(),entity).getEntity());
			response = restClient.performRequest("GET",
					"/" + tnsIndex + "/tns/" + myappid.toLowerCase() + "/",
					Collections.<String, String>emptyMap(), entity);
			if (isDebug) {
				System.out.println("response :- " + response);
			}
			if (isDebug) {
				System.out.println(res);
			}
		} catch (ResponseException e) {
			// TODO Auto-generated catch block
			response = e.getResponse();
			if (isDebug) {
				System.out.println("App Not found" + res + "<----");
			}
			e.printStackTrace();
		} catch (IOException e) {
			if (isDebug) {
				System.out.println("Error get app exist");
			}
			e.printStackTrace();
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		boolean tnsexist = parser.parse(res).getAsJsonObject().get("found").getAsBoolean();
		if (tnsexist) {
			resultStr.addProperty("found", true);
			return new ResponseEntity<Object>(resultStr.toString(), headers, HttpStatus.OK);
		} else {
			resultStr.addProperty("found", false);
			return new ResponseEntity<Object>(resultStr.toString(), headers, HttpStatus.OK);
		}

	}

	// get tns details
	@RequestMapping(value = "/getJsonTns", method = RequestMethod.GET)
	public ResponseEntity<Object> restServerGetJsonTns(@RequestParam(value = "app_id", required = false) String myappid,
			@RequestParam(value = "appname", required = false) String myappname) throws IOException {
		JsonObject result = new JsonObject();
		JsonObject errorMsg = new JsonObject();

		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String res = "";
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");

		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();
		if ((myappid == null || myappid.length() == 0) && (myappname == null || myappname.length() == 0)) {
			errorMsg.addProperty("exception", "Application details not found in url");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		if (myappid == null || myappid.length() == 0) {
			if (myappname == null || myappname.length() == 0) {
				errorMsg.addProperty("exception", "Application details not found in url");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
			}
			if (myappname.toLowerCase().trim().equals("i-core india")) {
				myappname = "finacle";
			}
			if (connection != null) {
				if (isDebug) {
					System.out.println("You made it, take control of your database now!");
				}

				try {
					pstmt = null;
					String sql = "SELECT app_id FROM " + userAppTable + " WHERE UPPER(app_name)=?";
					pstmt = connection.prepareStatement(sql);
					if (isDebug) {
						System.out.println("myappname" + myappname);
					}
					pstmt.setString(1, myappname.toUpperCase());

					rs = pstmt.executeQuery();

					while (rs.next()) {

						res = rs.getString("app_id");
					}
					myappid = res;
					if (res.length() == 0) {
						if (isDebug) {
							System.out.println("There is no app of this name.");
						}
						errorMsg.addProperty("exception", "There is no app of this name.");
						connection.close();
						return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
					}
					// connection.close();
					// return new ResponseEntity<Object>(res.toString(), HttpStatus.OK);
				} catch (Exception e) {
					if (isDebug) {
						System.out.println("error in stmt creation");
					}
					errorMsg.addProperty("exception", e.getMessage());
					e.printStackTrace();
					return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);

					// return new ResponseEntity<Object>(res.toString(),headers, HttpStatus.OK);
				}
			} else {
				if (isDebug) {
					System.out.println("Failed to make connection!");
				}

				errorMsg.addProperty("exception", "Failed to Make Connection to Source !!!");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);

			}
		}
		String body = "";
		JsonParser parser = new JsonParser();

		body = "";
		HttpEntity entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
		// appName=URLEncoder.encode(appName, "UTF-8");
		Response response = null;
		try {
			response = restClient.performRequest("GET",
					"/" + tnsIndex + "/tns/" + myappid.toLowerCase() + "/",
					Collections.<String, String>emptyMap(), entity);
			if (isDebug) {
				System.out.println(response.toString() + "  " + myappid.toLowerCase());
			}
		} catch (ResponseException e) {
			// TODO Auto-generated catch block
			response = e.getResponse();
			if (isDebug) {
				System.out.println("TNS Not found" + res + "<----");
			}
			JsonObject jsonMap = new JsonObject();
			jsonMap.addProperty("found", false);

			e.printStackTrace();
			restClient.close();

			return new ResponseEntity<Object>(jsonMap.toString(), headers, HttpStatus.NOT_FOUND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject jsonTns = null;
		jsonTns = parser.parse(res).getAsJsonObject().get("_source").getAsJsonObject();
		result = jsonTns;

		if (isDebug) {
			System.out.println("this is result" + result.toString());
		}
		result.addProperty("server_password",
				decodeTNS(result.get("server_password").getAsString()));
		restClient.close();
		return new ResponseEntity<Object>(result.toString(), headers, HttpStatus.OK);
	}

	// SQL data in json
	@RequestMapping(value = "/checkSql", method = RequestMethod.POST)
	@ResponseBody
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<Object> restServerCheckSql(@RequestBody String RequestBody)
			throws ServletException, IOException {

		JsonParser parser = new JsonParser();
		if (isDebug) {
			System.out.println("Request body of sql upload-------------" + RequestBody);
		}

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		JsonObject errorMsg = new JsonObject();

		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String result = "";
		JsonObject jsonString = parser.parse(RequestBody).getAsJsonObject();
		if (jsonString.get("appname").isJsonNull()) {
			errorMsg.addProperty("exception", "application name not found in request");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		if (jsonString.get("keylist").isJsonNull()) {
			errorMsg.addProperty("exception", "sql mapping keylist not found in request");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		if (jsonString.get("sqldata").isJsonNull()) {
			errorMsg.addProperty("exception", "sql statement not found in request");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		if (jsonString.get("coldata").isJsonNull()) {
			errorMsg.addProperty("exception", "sql mapping keylist with value not found in request");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		String myappname = jsonString.get("appname").getAsString();
		String keylist = jsonString.get("keylist").getAsString();
		JsonObject sqljson = jsonString.get("sqldata").getAsJsonObject();
		JsonObject coljson = jsonString.get("coldata").getAsJsonObject();
		// JsonObject sqljson = parser.parse(mysqldata).getAsJsonObject();

		if (myappname.length() == 0) {
			errorMsg.addProperty("exception", "application name not found in request");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		if (sqljson.get("sql").isJsonNull()) {
			errorMsg.addProperty("exception", "sql statement not found in request");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		if (sqljson.get("sql").getAsString().length() == 0) {
			errorMsg.addProperty("exception", "sql statement not found in request");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}

		String appid = "";
		if (sqljson.has("app_id")) {
			appid = sqljson.get("app_id").getAsString();
		} else {
			if (myappname.toLowerCase().equals("i-core india")) {
				myappname = "finacle";
			}
			if (connection != null) {
				if (isDebug) {
					System.out.println("You made it, take control of your database now!");
				}

				try {
					pstmt = null;
					String sql = "SELECT app_id FROM " + userAppTable + " WHERE UPPER(app_name)=?";
					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, myappname.toUpperCase());

					rs = pstmt.executeQuery();

					while (rs.next()) {

						result = rs.getString("app_id");
					}
					appid = result;
					if (result.length() == 0) {
						if (isDebug) {
							System.out.println("There is no app of this name.");
						}
						errorMsg.addProperty("exception", "There is no app of this name.");
						connection.close();
						return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
					}
					connection.close();
					// return new ResponseEntity<Object>(res.toString(), HttpStatus.OK);
				} catch (Exception e) {
					if (isDebug) {
						System.out.println("error in stmt creation");
					}
					errorMsg.addProperty("exception", e.getMessage());
					e.printStackTrace();
					return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);

					// return new ResponseEntity<Object>(res.toString(),headers, HttpStatus.OK);
				} finally {
					try {
						if (rs != null)
							rs.close();
						if (pstmt != null)
							pstmt.close();
						if (connection != null)
							connection.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}
			} else {
				if (isDebug) {
					System.out.println("Failed to make connection!");
				}

				errorMsg.addProperty("exception", "Failed to Make Connection to Source !!!");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);

			}
		}
		// String tns = new TNSElasticController().getJsonTns(appid);
		// JsonObject tnsBody = new JsonObject();
		// tnsBody.addProperty("app_id", appid);
		if (isDebug) {
			System.out.println("!!!!!!!!!!!!!!!" + restServerGetJsonTns(appid, myappname));
		}

		String tns = restServerGetJsonTns(appid, myappname).getBody().toString();

		if (isDebug) {
			System.out.println("//////////////////!" + tns);
		}

		JsonObject tnsjson = parser.parse(tns).getAsJsonObject();

		if (tnsjson.has("found") && tnsjson.get("found").getAsBoolean() == false) {
			errorMsg.addProperty("exception", "TNS Details not found for the Given Application " + myappname);
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
		}

		// JsonObject coljson = parser.parse(mycoldata).getAsJsonObject();
		ArrayList<String> arr = new ArrayList<String>(Arrays.asList(keylist.split(",")));
		if (isDebug) {
			System.out.println(coljson.toString());
		}
		String sql = sqljson.get("sql").getAsString();
		for (String a : arr) {
			if (coljson.has(a)) {
				if (isDebug) {
					System.out.println(a + "  " + sql + " ::::" + coljson.get(a).getAsString());
				}
				sql = sql.replaceAll(a, coljson.get(a).getAsString());
				if (isDebug) {
					System.out.println(a + "  " + sql);
				}
			}
		}

		// check for keywords
		String tempsql = sql;
		ArrayList<String> sqlarr = new ArrayList<String>(Arrays.asList(tempsql.toLowerCase().split(" ")));
		if (sqlarr.contains("delete") || sqlarr.contains("update") || sqlarr.contains("insert")
				|| sqlarr.contains("alter") || sqlarr.contains("create") || sqlarr.contains("rollback")
				|| sqlarr.contains("commit") || sqlarr.contains("drop") || sqlarr.contains("remove")
				|| sqlarr.contains("modify") || sqlarr.contains("*")) {
			errorMsg.addProperty("exception",
					"SQL Contains Restricted KEYWORDS ( delete,update ,insert,alter,create,rollback,commit,drop,remove,modify,*) Please remove. ");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.FORBIDDEN);
		}

		// prepare the connection;

		connection = null;
		rs = null;
		Statement stmt = null;

		String server_host = tnsjson.get("server_host").getAsString();
		String server_port = tnsjson.get("server_port").getAsString();
		String service_name = tnsjson.get("service_name").getAsString();
		String server_user_name = tnsjson.get("server_user_name").getAsString();
		String server_password = tnsjson.get("server_password").getAsString();

		String dburl = "jdbc:oracle:thin:@" + server_host + ":" + server_port + "/" + service_name;
		if (isDebug) {
			System.out.println(dburl + server_user_name + " ");
		}

		JsonObject TableJson = new JsonObject();
		JsonArray RowArr = new JsonArray();
		try {

			TimeZone timeZone = TimeZone.getTimeZone("Asia/Calcutta");
			TimeZone.setDefault(timeZone);
			connection = DriverManager.getConnection(dburl, server_user_name, server_password);

		} catch (SQLException e) {

			if (isDebug) {
				System.out.println("Connection Failed! Check output console");
			}
			e.printStackTrace();
			errorMsg.addProperty("exception", "Connection Failed!Please Check TNS and Database Version.");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}

		if (connection != null) {
			if (isDebug) {
				System.out.println("You made it, take control of your database now!");
			}

			try {

				// execute the sql;
				stmt = null;
				stmt = connection.createStatement();
				sql = sql.replaceAll(";", "");
				if (isDebug) {
					System.out.println("SQL:" + sql);
				}

				rs = stmt.executeQuery(sql);
				ResultSetMetaData rsmd = rs.getMetaData();

				int columnsNumber = rsmd.getColumnCount();
				for (int i = 1; i <= columnsNumber; i++) {
					RowArr.add(rsmd.getColumnName(i));

				}
				TableJson.add("row1", RowArr);
				RowArr = new JsonArray();
				// result+="</tr>";

				while (rs.next()) {
					// result+="<tr>";
					int j = 2;
					RowArr = new JsonArray();
					for (int i = 1; i <= columnsNumber; i++) {
						if (rs.getObject(i) != null) {
							if (isDebug) {
								System.out.println("this is result->data:" + rs.getObject(i).toString() + ":"
										+ rs.getObject(rsmd.getColumnName(i)).toString());
							}

							RowArr.add(rs.getObject(i).toString());
						} else {
							RowArr.add("NULL");
						}
					}
					TableJson.add("row" + j, RowArr);
					j++;
				}

				if (isDebug) {
					System.out.println("this is result" + TableJson.toString());
				}
				connection.close();
				return new ResponseEntity<Object>(TableJson.toString(), headers, HttpStatus.OK);
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("error in stmt creation");
				}
				e.printStackTrace();
				errorMsg.addProperty("exception", e.toString());
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			if (isDebug) {
				System.out.println("Failed to make connection!");
			}
			errorMsg.addProperty("exception",
					" Failed to make connection! with given TNS \nResult:" + TableJson.toString());
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	// JSON Sql Map
	@RequestMapping(value = "/getJsonMap", method = RequestMethod.POST)
	@ResponseBody
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<Object> restServerGetJsonMap(@RequestBody String restRequest) throws IOException {

		JsonObject result = new JsonObject();
		RestClient restClient = RestClient.builder(new HttpHost(eserver, 9200, "http")).build();

		String res = "";
		String mymapid = "";
		String mymapvalue = "";
		String mymapname = "";
		String body = "";
		HttpEntity entity = null;
		Response response = null;
		JsonParser parser = new JsonParser();

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");

		JsonObject errorMsg = new JsonObject();
		JsonObject restBody = parser.parse(restRequest).getAsJsonObject();
		if (isDebug) {
			System.out.println(restBody.toString());
		}
		if (restBody.has("map_value")) {
			mymapvalue = restBody.get("map_value").getAsString();
			mymapid = mymapvalue;
		} else if (restBody.has("map_name")) {
			mymapname = restBody.get("map_name").getAsString();
			body = "{\"query\":{\"match\":{\"map_name\":\"" + mymapname + "\"}}}";
			entity = new NStringEntity(body, ContentType.APPLICATION_JSON);
			response = restClient.performRequest("POST", "/" + tnsIndex + "/sqlmap/_search",
					Collections.<String, String>emptyMap(), entity);
			res = EntityUtils.toString(response.getEntity());
			body = "";
			JsonArray mapHits = parser.parse(res).getAsJsonObject().get("hits").getAsJsonObject().get("hits")
					.getAsJsonArray();
			if (isDebug) {
				System.out.println("result for map" + res.toString());
			}
			if (mapHits.size() == 0) {
				errorMsg.addProperty("exception", "Map not found for given map name");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
			} else {
				mymapid = mapHits.get(0).getAsJsonObject().get("_id").getAsString();
			}
		}

		try {

			response = restClient.performRequest("GET", "/" + tnsIndex + "/sqlmap/" + mymapid + "/",
					Collections.<String, String>emptyMap(), entity);
			if (isDebug) {
				System.out.println(response.toString() + "  " + mymapid);
			}
		} catch (ResponseException e) {
			// TODO Auto-generated catch block
			response = e.getResponse();
			if (isDebug) {
				System.out.println("Map Not found" + res + "<----" + mymapid);
			}
			JsonObject jsonMap = new JsonObject();

			e.printStackTrace();
			jsonMap.addProperty("map_id", mymapid);
			jsonMap.addProperty("map_value", mymapvalue);
			errorMsg.addProperty("exception", "Map details not found");
			errorMsg.add("map", jsonMap);
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			res = EntityUtils.toString(response.getEntity());
		} catch (ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			restClient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject jsonMap = null;

		jsonMap = parser.parse(res).getAsJsonObject().get("_source").getAsJsonObject();
		jsonMap.remove("modified_by");
		jsonMap.remove("modified_time");
		result = jsonMap;

		if (isDebug) {
			System.out.println("this is result" + result.toString());
		}
		return new ResponseEntity<Object>(result.toString(), headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/getReasonsForApp", method = RequestMethod.POST)
	@ResponseBody
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<Object> restServerGetJsonReasonsForApp(@RequestBody String restRequest) throws IOException {
		// JsonObject result = new JsonObject();
		JsonArray jarr = new JsonArray();
		JsonParser parser = new JsonParser();
		JsonObject errorMsg = new JsonObject();
		String myappid = "";
		String myappname = "";
		String res = "";
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JsonObject requestBody = parser.parse(restRequest).getAsJsonObject();
		if (requestBody.has("app_id")) {
			myappid = requestBody.get("app_id").getAsString();
		} else {
			if (requestBody.has("appname")) {
				myappname = requestBody.get("appname").getAsString();
				if (isDebug) {
					System.out.println("myappname----" + myappname);
				}
				if (myappname.toUpperCase().equals("I-CORE INDIA")) {
					myappname = "finacle";
				}
				if (isDebug) {
					System.out.println("myappname" + myappname);
				}
				if (connection != null) {
					if (isDebug) {
						System.out.println("You made it, take control of your database now!");
					}

					try {
						pstmt = null;
						String sql = "SELECT app_id FROM " + userAppTable
								+ " WHERE UPPER(app_name)=?";
						pstmt = connection.prepareStatement(sql);
						if (isDebug) {
							System.out.println("myappname" + myappname);
						}
						pstmt.setString(1, myappname.toUpperCase());

						rs = pstmt.executeQuery();

						while (rs.next()) {

							res = rs.getString("app_id");
						}
						myappid = res;
						if (res.length() == 0) {
							if (isDebug) {
								System.out.println("There is no app of this name.");
							}
							errorMsg.addProperty("exception", "There is no app of this name.");
							connection.close();
							return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
						}
						// connection.close();
						// return new ResponseEntity<Object>(res.toString(), HttpStatus.OK);
					} catch (Exception e) {
						if (isDebug) {
							System.out.println("error in stmt creation");
						}
						errorMsg.addProperty("exception", e.getMessage());
						e.printStackTrace();
						return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);

						// return new ResponseEntity<Object>(res.toString(),headers, HttpStatus.OK);
					}
				} else {
					if (isDebug) {
						System.out.println("Failed to make connection!");
					}

					errorMsg.addProperty("exception", "Failed to Make Connection to Source !!!");
					return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);

				}
			} else {
				errorMsg.addProperty("exception", "App Name or App id not found");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.NOT_FOUND);
			}
		}

		if (connection != null) {
			if (isDebug) {
				System.out.println("You made it, take control of your database now!");
			}

			try {

				String sql = "SELECT * FROM " + userAppSrTable + "   JOIN  "
						+ userSrReasonTable + " USING (REASON_ID)   WHERE app_id=? ";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myappid.toUpperCase());

				if (isDebug) {
					System.out.println(sql);
				}
				rs = pstmt.executeQuery();

				while (rs.next()) {
					JsonObject temp = new JsonObject();

					temp.addProperty("app_id", rs.getString("app_id"));
					if (rs.getString("app_name").toUpperCase().equals("FINACLE")) {
						temp.addProperty("app_name", "I-CORE INDIA");
					} else {
						temp.addProperty("app_name", rs.getString("app_name"));
					}

					temp.addProperty("reason_id", rs.getString("reason_id"));
					temp.addProperty("reason_name", rs.getString("reason_name"));

					temp.addProperty("reason_link", rs.getString("reason_link"));
					jarr.add(temp);
				}

				if (isDebug) {
					System.out.println("this is result" + jarr.toString());
				}
				if (jarr.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this question.");
					}
					connection.close();
					return new ResponseEntity<Object>(jarr.toString(), headers, HttpStatus.NO_CONTENT);
				}
				connection.close();
				return new ResponseEntity<Object>(jarr.toString(), headers, HttpStatus.OK);
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("error in stmt creation");
				}

				errorMsg.addProperty("exception", e.getMessage());
				e.printStackTrace();
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			if (isDebug) {
				System.out.println("Failed to make connection!");
			}

			errorMsg.addProperty("exception", "Failed to Make Connection");

			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	// visible apps
	@RequestMapping(value = "/getVisibleApps", method = RequestMethod.GET)
	public ResponseEntity<Object> restServerGetVisibleApps() throws IOException {
		HashMap<String, String> result = new HashMap<String, String>();
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		JsonObject errorMsg = new JsonObject();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		JsonArray visibleArray = new JsonArray();
		if (connection != null) {
			if (isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			
			 * String sql="SELECT * FROM "+
			 * userAppPropTable+" WHERE UPPER(app_visibility)='YES'";
			 
			try {

				 all Apps 
				String sql = "SELECT * FROM " + userAppPropTable
						+ " WHERE UPPER(app_visibility)='YES'";
				pstmt = connection.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					JsonObject jsonstr = new JsonObject();
					jsonstr.addProperty("app_id", rs.getString("app_id"));
					jsonstr.addProperty("app_name", rs.getString("app_name"));
					// result.put(rs.getString("app_id"), rs.getString("app_name"));
					visibleArray.add(jsonstr);
				}
				// System.out.println("this is result" + result);
				if (visibleArray.size() == 0) {
					if (isDebug) {
						System.out.println("There is no data for this allapps sql.");
					}
					// errorMsg.addProperty("exception", value);
					pstmt.close();
					connection.close();
					return new ResponseEntity<Object>(visibleArray.toString(), headers, HttpStatus.OK);
				}
				pstmt.close();
				connection.close();
				return new ResponseEntity<Object>(visibleArray.toString(), headers, HttpStatus.OK);
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				errorMsg.addProperty("exception", "Error in insert Statement");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.OK);
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		} else {
			if (isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			errorMsg.addProperty("exception", "Failed to make connection to source");
			return new ResponseEntity<Object>(visibleArray, headers, HttpStatus.OK);
		}
	}

	// reset Active User
	@RequestMapping(value = "/resetActiveUser", method = RequestMethod.GET)
	public ResponseEntity<Object> restServerResetActiveUser(
			@RequestParam(name = "user_id", required = false) String myuserid) {
		JsonObject errorMsg = new JsonObject();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		if (myuserid == null || myuserid.length() == 0) {
			if (isDebug) {
				System.out.println("SessionServlet:User ID NULL!");
			}
			errorMsg.addProperty("exception", "User id null");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (isDebug) {
				System.out.println("SessionServlet:You made it, take control of your database now!");
			}

			try {

				if (new DatabaseController().findUserById(myuserid) == 1) {
					String sql = "UPDATE  " + userTable + " SET " + "  active=?"// 1
							+ "  WHERE user_id=?";// 2

					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "NO");

					pstmt.setString(2, myuserid.toString().toUpperCase());
					if (isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  USER SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
					}

					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("Active USER Reset   Successfully Updated::: " + myuserid);

						if (isDebug) {
							System.out.println("Active USER Reset    Updated and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (isDebug) {
							System.out.println("return 1");
						}
						errorMsg.addProperty("status", "successfully updated active user");
						return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.OK);

					} else {
						System.out.println("Update User Failed");

						pstmt.close();
						connection.close();
						errorMsg.addProperty("exceptin", "user reset failed");
						return new ResponseEntity<Object>(errorMsg.toString(), headers,
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("SessionServlet: ERROR in Active USER Reset    stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				errorMsg.addProperty("exceptin", "user reset failed due to reset statement");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
			errorMsg.addProperty("exceptin", "user reset failed");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			if (isDebug) {
				System.out.println("SessionServlet:Failed  to make connection!");
			}
			errorMsg.addProperty("exceptin", "failed to make connection to DB");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	// set user to active
	@RequestMapping(value = "/setActiveUser", method = RequestMethod.GET)
	public ResponseEntity<Object> setActiveUser(@RequestParam(name = "user_id", required = false) String myuserid) {
		JsonObject errorMsg = new JsonObject();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		if (myuserid == null) {
			if (isDebug) {
				System.out.println("SessionServlet:User ID NULL!");
			}
			errorMsg.addProperty("exceptin", "user id null");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.BAD_REQUEST);
		}
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (isDebug) {
				System.out.println("SessionServlet:You made it, take control of your database now!");
			}

			try {

				if (new DatabaseController().findUserById(myuserid) == 1) {
					String sql = "UPDATE  " + userTable + " SET " + "  active=?"// 1
							+ "  WHERE user_id=?";// 2

					pstmt = connection.prepareStatement(sql);
					pstmt.setString(1, "YES");

					pstmt.setString(2, myuserid.toString().toUpperCase());
					if (isDebug) {
						System.out.println(sql);
						ParameterMetaData pmtdt = pstmt.getParameterMetaData();
						int count = pmtdt.getParameterCount();
						System.out.println("UPDATE  USER SQL ????? ?" + count);
						for (int i = 1; i <= count; i++) {
							System.out.println(
									"?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
						}
					}

					int x = pstmt.executeUpdate();
					if (x > 0) {
						System.out.println("Active USER set   Successfully Updated");

						if (isDebug) {
							System.out.println("Active USER set    Updated and Commited");
						}
						connection.commit();
						pstmt.close();
						connection.close();
						if (isDebug) {
							System.out.println("return 1");
						}
						errorMsg.addProperty("status", "user set to active status successfully");
						return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.OK);

					} else {
						System.out.println("Update User Failed");

						pstmt.close();
						connection.close();
						errorMsg.addProperty("exceptin", "setting user to active failed");
						return new ResponseEntity<Object>(errorMsg.toString(), headers,
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
			} catch (Exception e) {
				if (isDebug) {
					System.out.println("SessionServlet: ERROR in Active USER set    stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				errorMsg.addProperty("exceptin", "error in user active set statement");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
			errorMsg.addProperty("exceptin", "setting user to active failed");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			if (isDebug) {
				System.out.println("SessionServlet:Failed  to make connection!");
			}
			errorMsg.addProperty("exceptin", "failed to establish coonection to DB");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	// Reset all user
	@RequestMapping(value = "/resetAllUsers", method = RequestMethod.GET)
	public ResponseEntity<Object> restServerResetAllUsers() {
		JsonObject errorMsg = new JsonObject();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		// scc.setDomain("example.com");

		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if (connection != null) {
			if (isDebug) {
				System.out.println("SessionServlet:You made it, take control of your database now!");
			}

			try {

				String sql = "UPDATE  " + userTable + " SET " + "  active=?";// 1

				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, "NO");
				if (isDebug) {
					System.out.println(sql);
					ParameterMetaData pmtdt = pstmt.getParameterMetaData();
					int count = pmtdt.getParameterCount();
					System.out.println("UPDATE  USER SQL ????? ?" + count);
					for (int i = 1; i <= count; i++) {
						System.out
								.println("?" + i + "?????" + pmtdt.getParameterTypeName(i) + pmtdt.getParameterType(i));
					}
				}

				int x = pstmt.executeUpdate();
				if (x > 0) {
					System.out.println("All USER Reset   Successfully Updated::: ");

					if (isDebug) {
						System.out.println("All USER Reset    Updated and Commited");
					}
					connection.commit();
					pstmt.close();
					connection.close();
					if (isDebug) {
						System.out.println("return 1");
					}
					errorMsg.addProperty("status", "all user active status reset done");
					return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.OK);

				} else {
					System.out.println("Update User Failed");

					pstmt.close();
					connection.close();
					errorMsg.addProperty("exceptin", "Reset All failed");
					return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
				}

			} catch (Exception e) {
				if (isDebug) {
					System.out.println("SessionServlet: ERROR in All USER Reset    stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				errorMsg.addProperty("exceptin", "Reset All failed due to statement");
				return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			if (isDebug) {
				System.out.println("SessionServlet:Failed  to make connection!");
			}
			errorMsg.addProperty("exceptin", "Reset All failed");
			return new ResponseEntity<Object>(errorMsg.toString(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@RequestMapping(value = "/getUser", method = RequestMethod.POST)
	public ResponseEntity<Object> restServerGetUser(String myuserid, String myusername) throws IOException {
		if (myusername.indexOf('/') >= 0) {
			myusername = myusername.substring(0, myusername.indexOf('/')).trim();
		}
		User result = new User(myuserid.toUpperCase(), myusername.toUpperCase());
		JsonObject errorMsg = new JsonObject();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/json; charset=UTF-8");
		headers.add("transfer-encoding", "chunked");
		
		Connection connection = new DatabaseController().createUserConnection();
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		if (connection != null) {
			if (isDebug) {
				System.out.println("DatabaseController:You made it, take control of your database now!");
			}
			
			
				 
			try {
				String sql = "SELECT * FROM " + userTable + " WHERE UPPER(user_id)=?";

				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myuserid.toUpperCase());
				if (isDebug) {
					System.out.println("UserController:" + sql);
				}
				rs = pstmt.executeQuery();
				while (rs.next()) {
					// ResultSetMetaData rsmd = rs.getMetaData();
					result.setUser_id(rs.getString("user_id"));
					result.setUser_name(rs.getString("user_name"));
					result.setLogin_time((TIMESTAMP) rs.getObject("login_time"));
					result.setIs_locked(rs.getString("is_locked"));
					result.setLock_time((TIMESTAMP) rs.getObject("lock_time"));
					result.setIs_superuser(rs.getString("is_superuser"));
					result.setRole_id(rs.getString("role_id"));
					result.setManager_id(rs.getString("manager_id"));
					result.setLast_login((TIMESTAMP) rs.getObject("last_login"));
					result.setActive(rs.getString("active"));
				}
				 no need to get detail of user if user is already active somewhere
				
				//Instant.now().plusSeconds( TimeUnit.MINUTES.toSeconds( 5 ) );
				 Clock clock=Clock.system(ZoneId.of("Asia/Kolkata"));
					//Format format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
		            DateFormat oracleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		            if(isDebug){
		            	System.out.println(oracleFormat.parse(result.getLogin_time().toString()).toInstant()+"  --->"+Instant.now(clock).plusSeconds(TimeUnit.MINUTES.toSeconds( 15 )));
		            }
			        	
		        if(result.getActive()!=null && result.getActive().toString().toUpperCase().equals("YES") ){
			     		return new ResponseEntity<Object>(result,headers,HttpStatus.OK);
				}

				// get all apps
					HashMap<String, String> allapps = new HashMap<String, String>();
					allapps = new UserController().getAllApps();
					
				
				// grant details
				HashMap<String, String> tmpGrant = new HashMap<String, String>();
				HashMap<String, String> tmpCanGrant = new HashMap<String, String>();
				HashMap<String,String> a = new HashMap<String,String>();
				HashMap<String,String> i = new HashMap<String,String>();
				
				HashMap<String,String> u = new HashMap<String,String>();
				HashMap<String,String> d = new HashMap<String,String>();
				HashMap<String,String> m = new HashMap<String,String>();
				HashMap<String,String> s = new HashMap<String,String>();

				 admin apps 
				pstmt.close();
				sql = "SELECT * FROM " + userAppTable + " WHERE UPPER(USER_ID)=?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, myuserid.toUpperCase());
				if (isDebug) {
					System.out.println("UserController: tquery" + sql);
				}

				ResultSet rsa = pstmt.executeQuery();

				while (rsa.next()) {
					String tapp = rsa.getString("app_name");
					String tid = rsa.getString("app_id");
					a.put(tid, tapp);
					s.put(tid, tapp);
					i.put(tid, tapp);
					m.put(tid, tapp);
					d.put(tid, tapp);
					//HASHCODE
					tmpCanGrant.put(tid, tapp);//can grant application
				}

				//////////////

				if (result.getIs_superuser().equalsIgnoreCase("NO")) {
					sql = "SELECT * FROM " + userGrantTable + " join "
							+ userRoleTable + "  using (ROLE_ID) join "
							+ userAppTable + " using (APP_ID) WHERE UPPER(grantee_id)=?";
					//sql = "SELECT * FROM " + userAppTable + " app join "+userGrantTable+" grnt using (app_id) where UPPER(grnt.grantee_id)= ? and upper(grnt.role_id)='ROLE0'";
					//sql = "SELECT * FROM " + userAppTable + " app join "+userGrantTable+" grnt using (app_id) where UPPER(grnt.grantee_id)='"+myuserid.toUpperCase()+"' and UPPER(grnt.role_id)='ROLE0'";
					pstmt.close();
					pstmt = connection.prepareStatement(sql);
					//userID=myuserid;
					pstmt.setString(1, myuserid.toUpperCase());

				} else {

					sql = "SELECT * FROM " + userGrantTable + " join "
							+ userRoleTable + "  using (ROLE_ID) join "
							+ userAppTable + " using (APP_ID) ";
					pstmt.close();
					pstmt = connection.prepareStatement(sql);
				}
				if (isDebug) {
					System.out.println("Query For FAQ:" + sql);
				}
				rs = pstmt.executeQuery();
				while (rs.next()) {
					String userAppName = rs.getString("app_name");
					String userAppid = rs.getString("app_id");
					String rolename = rs.getString("role_name");
					String canGrant = rs.getString("can_grant");
					String isValid = rs.getString("is_valid_grant");
					if (isDebug) {
						System.out.println("App:" + userAppName + " Role:" + rolename + " CanGrant:" + canGrant
								+ " isValid:" + isValid);
					}
					
					
					if (canGrant.equalsIgnoreCase("YES") && isValid.equalsIgnoreCase("YES")) {
						tmpCanGrant.put(userAppid, userAppName);//can grant application
					}
					if (isValid.equalsIgnoreCase("YES")) {
						if (rolename.indexOf("i") >= 0) {
							i.put(userAppid, userAppName);
						}
						if (rolename.indexOf("admin") >= 0) {
							i.put(userAppid, userAppName);
							a.put(userAppid, userAppName);
							//((List<User>) a).add(userAppName);
							m.put(userAppid, userAppName);
							d.put(userAppid, userAppName);
							s.put(userAppid, userAppName);
						}
						if (rolename.indexOf("m") >= 0) {
							m.put(userAppid, userAppName);
						}
						if (rolename.indexOf("d") >= 0) {
							d.put(userAppid, userAppName);
						}
						if (rolename.indexOf("s") >= 0) {
							s.put(userAppid, userAppName);
						}
					}
					tmpGrant.put(userAppName, rs.getString("role_name"));
				}
				

				result.setGrant(tmpGrant);
				result.setCanGrant(tmpCanGrant);
				result.setInsert(i);
				
				result.setUpdate(u);
				result.setDelete(d);
				result.setModify(m);
				result.setShow(s);
				HashMap<String, String> allroles = new HashMap<String, String>();

				 admin roles 
				pstmt.close();
				sql = "SELECT * FROM " + userRoleTable + " ";
				pstmt = connection.prepareStatement(sql);
				rsa = pstmt.executeQuery();
				while (rsa.next()) {

					String troleid = rsa.getString("role_id");
					String trolep = rsa.getString("priviledges");
					allroles.put(troleid, trolep);

				}
				result.setAllroles(allroles);
				
				if(result.getIs_superuser().equalsIgnoreCase("YES")){
					result.setAdminApps(allapps);
					result.setInsert(allapps);
					result.setModify(allapps);
					result.setDelete(allapps);
					result.setShow(allapps);
					result.setGrant(allapps);
					result.setCanGrant(allapps);
				
					
						for(HashMap.Entry<String,String> entity:a.entrySet()){
							if (isDebug) {
								System.out.println(entity.getValue()+" All apps --> "+entity.getKey());
							}
						}
				}
				else{
					result.setAdminApps(a);
					for(HashMap.Entry<String,String> entity:a.entrySet()){
						if (isDebug) {
							System.out.println(entity.getValue()+"  a --> "+entity.getKey());
						}
					}
				}
				result.setAllapps(allapps);
				pstmt.close();
				connection.close();
				return new ResponseEntity<Object>(result,headers,HttpStatus.OK);

			} catch (Exception e) {
				if (isDebug) {
					System.out.println("DatabaseController:Error in insert stmt creation");
				}
				e.printStackTrace();
				try {

					connection.close();
				} catch (SQLException e1) {

					e1.printStackTrace();

				}
				errorMsg.addProperty("exception", "invalid insert statement");
				return new ResponseEntity<Object>(errorMsg.toString(),headers,HttpStatus.OK);
			}finally{
				try {
					if (rs != null) rs.close(); 
					 if (pstmt != null) pstmt.close();
					 if (connection != null) connection.close(); 
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}

		} else {
			if (isDebug) {
				System.out.println("DatabaseController:Failed to make connection!");
			}
			errorMsg.addProperty("exception", "failed to make database connection");
			return new ResponseEntity<Object>(errorMsg.toString(),headers,HttpStatus.OK);
		}
	}*/
}
